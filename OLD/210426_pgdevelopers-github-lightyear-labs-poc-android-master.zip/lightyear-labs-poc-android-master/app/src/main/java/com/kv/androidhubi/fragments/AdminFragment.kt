package com.kv.androidhubi.fragments

import android.R.id.toggle
import android.content.Intent.getIntent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CompoundButton
import com.kv.androidhubi.MainActivity
import com.kv.androidhubi.R
import com.kv.androidhubi.customClasses.AppNavigator
import com.kv.androidhubi.customClasses.HubiAlertDialog
import com.kv.androidhubi.customClasses.HubiFragmentExtender
import kotlinx.android.synthetic.main.fragment_admin.view.*
import java.lang.Compiler.disable


class AdminFragment: HubiFragmentExtender() {
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        var view = inflater.inflate(R.layout.fragment_admin, container, false)

        view.buttonForceConnect.setOnClickListener() {
//            getRegionBootstrapApplication().performSequentialBackgroundScan(false, false)
            getMainActivity().appNavigator.SetState(AppNavigator.AppPageState.DEBUGGER, true)
        }

        view.buttonSendTestMessage.setOnClickListener() {
            var dialog = HubiAlertDialog(getMainActivity())
            getRegionBootstrapApplication().sendTestData(dialog)
        }

        view.buttonClearProducts.setOnClickListener() {
            var dialog = HubiAlertDialog(getMainActivity())
            getMainActivity().userAccountInfo.deleteAllDevices()
            dialog.show()
            dialog.clearedDevices()
        }

        view.buttonResetMonitoring.setOnClickListener() {
            var dialog = HubiAlertDialog(getMainActivity())
            dialog.show()
            dialog.resetMonitoring()
            for(device in getRegionBootstrapApplication().userAccountInfo.getRegisteredDevices()) {
                getRegionBootstrapApplication().removeRegionFromMonitorForDevice(device)
            }

            // If ignoreDeviceIDs has been set to false from the admin menu, then we need to only scan for specific regions
            if(!getRegionBootstrapApplication().userAccountInfo.getIgnoreDeviceIDs()) {
                for(device in getRegionBootstrapApplication().userAccountInfo.getRegisteredDevices()) {
                    getRegionBootstrapApplication().addNewRegionToMonitorForDevice(device)
                }
            } else {
                // Otherwise, let's monitor for any and all beacons
                getRegionBootstrapApplication().addNewRegionToMonitorForDevice(null)
            }
        }

        view.toggleIgnoreDeviceIDs.setOnCheckedChangeListener() { compoundButton: CompoundButton, checked: Boolean ->
            getMainActivity().userAccountInfo.setIgnoreDeviceIDs(checked)

            // Let's reset region monitoring to match whatever the new settings are, so first clear out existing regions
            getRegionBootstrapApplication().removeAllRegions()

            // If ignoreDeviceIDs has been set to false from the admin menu, then we need to only scan for specific regions
            if(!getRegionBootstrapApplication().userAccountInfo.getIgnoreDeviceIDs()) {
                for(device in getRegionBootstrapApplication().userAccountInfo.getRegisteredDevices()) {
                    getRegionBootstrapApplication().addNewRegionToMonitorForDevice(device)
                }
            } else {
                // Otherwise, let's monitor for any and all beacons
                getRegionBootstrapApplication().addNewRegionToMonitorForDevice(null)
            }
        }

        return view
    }

    override fun onResume() {
        super.onResume()
        view?.toggleIgnoreDeviceIDs?.isChecked = getRegionBootstrapApplication().userAccountInfo.getIgnoreDeviceIDs()
    }
}