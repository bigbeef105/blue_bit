package com.kv.androidhubi.customClasses

import android.annotation.SuppressLint
import android.content.Context
import android.util.Log
import codes.alchemy.awskit.iot.IotAuthState
import codes.alchemy.lemonadeplatform.model.LightyearLabsDevice
import codes.alchemy.lightyearlabs.LightyearLabs
import com.kv.androidhubi.BuildConfig
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import timber.log.Timber
import java.text.SimpleDateFormat
import java.util.*
import com.amazonaws.mobile.client.*
import com.amazonaws.mobileconnectors.iot.*
import com.kineticvision.resbitblesdk.BLEDevice
import com.kineticvision.resbitblesdk.SummaryData
import org.eclipse.paho.client.mqttv3.IMqttActionListener
import org.eclipse.paho.client.mqttv3.IMqttToken

class LightYearHubHandler(context: Context) {
    private var iotAuthState: IotAuthState = IotAuthState.Unknown
    public val deviceId    : String = initializeUniqueId(context)
    public var deviceType  : String = "STAND"

    private val KEYSTORE_PATH : String = context.applicationContext.filesDir.absolutePath
    private val KEYSTORE_NAME : String = "LiLaHu_Test1"
    private val KEYSTORE_PASS : String = "LiLaHu_TestPwd"

    private val PREF_UNIQUE_ID: String = "PREF_UNIQUE_ID"

    public var device : LightyearLabsDevice? = null

    private lateinit var mqttManager: AWSIotMqttManager
    private lateinit var sessionsPubTopic : String
    private lateinit var sessionsSubTopic : String

//    init {
//        loadLightyear(context)
//    }

    @Synchronized
    private fun initializeUniqueId(context: Context): String {

        val sharedPrefs = context.getSharedPreferences(PREF_UNIQUE_ID, Context.MODE_PRIVATE)
        val id = sharedPrefs.getString(PREF_UNIQUE_ID, null)

        if (id == null) {
            val newId : String = UUID.randomUUID().toString().replace("-","")
            val editor = sharedPrefs.edit()
            editor.putString(PREF_UNIQUE_ID, newId)
            editor.apply()
            return newId
        }

        return id
    }

    // entry point for every app open. LightyearLabs must be initialized for every Application.onCreate()
    public fun loadLightyear(context: Context, callback : codes.alchemy.lightyearlabs.LightyearLabsCallback) {
        Timber.v("initializing LightyearLabs communication")

        CoroutineScope(Dispatchers.IO).launch {
            // clientId for the LightyearLabs environment, this is contained in app:build.gradle
            val clientId = BuildConfig.CLIENT_ID
            // clientSecret for the LightyearLabs environment, this is contained in app:build.gradle
            val clientSecret = BuildConfig.CLIENT_SECRET
            // locale from which the connection is being made
            val locale = Locale.US

            // initialize asynchronously loads its dependencies
            // onResult - successfully loaded
            // onError - error initializing
            LightyearLabs.initialize(
                context,
                clientId,
                clientSecret,
                locale,
                object : codes.alchemy.lightyearlabs.LightyearLabsCallback {
                    override fun onResult(authState: IotAuthState, lighyear: LightyearLabs) {
                        iotAuthState = authState
//                        lighyearLabs = lighyear
                        Log.d(TAG,"LightyearLabs AuthState: $authState")

                        callback.onResult(authState, lighyear)
                    }

                    override fun onError(e: Throwable) {
                        // braodcast error
                        e.printStackTrace()
                        Timber.e("LightyearLabs AuthERROR: %s", e.localizedMessage)
                        callback.onError(e)
                    }
                }
            )
        }
    }

    public fun loginUser(username : String, password : String, completion: Callback<Error>) {
        CoroutineScope(Dispatchers.IO).launch {
            Log.d(TAG,"Logging in...")
            val result = LightyearLabs.login(
                username,
                password
            )
            try {
                val loggedIn = result.getOrThrow()
                if (loggedIn){
                    Log.d(TAG,"Logged in")
                    completion.onResult(null)
//                    getDevice()
                }else{
                    Log.d(TAG,"Login failed")
                    completion.onError(null)
                }

            } catch (exception: Exception) {
                Log.d(TAG,exception.localizedMessage)
                completion.onError(exception)
            }
        }
    }

    public fun getDevice(completion: Callback<Error>) {
        Log.d(TAG,"Getting Device Object...")
        CoroutineScope(Dispatchers.IO).launch {
            val result = LightyearLabs.getDevices()
            try {
                val devices = result.getOrThrow()
                for(device in devices){
                    if (device.deviceId == this@LightYearHubHandler.deviceId) {
                        this@LightYearHubHandler.device = device
                        Log.d(TAG,"...found and stored device object : " + device.deviceId)
                        break
                    }
                }
                if (device != null){
                    completion.onResult(null)
                }else{
                    Log.d(TAG,"...device not existing")
                    createDevice(object : Callback<Error> {
                        override fun onResult(result: Error?) {
                            completion.onResult(null)
                        }

                        override fun onError(e: java.lang.Exception?) {
                            completion.onError(e)
                        }
                    })
                }
            } catch (exception: Exception) {
                Log.e(TAG,exception.localizedMessage)
                completion.onError(exception)
            }
        }
    }

    private fun createDevice(completion: Callback<Error>) {
        Log.d(TAG,"Provisioning device...")
        Log.d(TAG,"ID : " + deviceId)
        Log.d(TAG,"Type : " + deviceType)
        CoroutineScope(Dispatchers.IO).launch {
            val result = LightyearLabs.createDevice(
                deviceId,
                deviceType
            )
            try {
                val deviceProvision = result.getOrThrow()
                Log.d(TAG,"Created Device: " + deviceProvision.device!!.deviceId)
                Log.d(TAG,"Adding Certificate to KeyStore...")

                val rootCert : String = LightyearLabs.getRootCA().getOrThrow()

                val cert = deviceProvision.cert + "\n\n" + rootCert
                val key = deviceProvision.privateKey

                if(!AWSIotKeystoreHelper.isKeystorePresent(KEYSTORE_PATH, KEYSTORE_NAME)){
                    Log.d(TAG,"Keystore not present \n->creating Keystore\n->storing Certificate")
                    AWSIotKeystoreHelper.saveCertificateAndPrivateKey(deviceId, cert, key, KEYSTORE_PATH, KEYSTORE_NAME, KEYSTORE_PASS)
                }else{
                    Log.d(TAG,"Keystore present")

                    if (AWSIotKeystoreHelper.keystoreContainsAlias(deviceId,KEYSTORE_PATH,KEYSTORE_NAME,KEYSTORE_PASS)){
                        Log.d(TAG,"Certificate present \n-> deleting Certificate")
                        AWSIotKeystoreHelper.deleteKeystoreAlias(deviceId,KEYSTORE_PATH,KEYSTORE_NAME,KEYSTORE_PASS)
                    }

                    Log.d(TAG,"-> storing Certificate")
                    AWSIotKeystoreHelper.saveCertificateAndPrivateKey(deviceId, cert, key, KEYSTORE_PATH, KEYSTORE_NAME, KEYSTORE_PASS)
                }

                val res = AWSIotKeystoreHelper.keystoreContainsAlias(deviceId,KEYSTORE_PATH,KEYSTORE_NAME,KEYSTORE_PASS)
                Log.d(TAG,"... Certificate stored: $res")

                getDevice(completion)

            } catch (exception: Exception) {
                Log.e(TAG,exception.localizedMessage)
                completion.onError(exception)
            }
        }
    }

    public fun setupMqttClient() {
        val iotEnvironment = LightyearLabs.getIotEnviornment()
        val mqttEndpoint:String = iotEnvironment!!.mqttUrl;

        //clientID has to be identical with "Thing Name"
        val clientID = device!!.thingName

        Timber.v("Setting up MQTT Manager | ClientID: $clientID | Endpoint: $mqttEndpoint")

        mqttManager = AWSIotMqttManager(clientID, mqttEndpoint)

        val keyStore = AWSIotKeystoreHelper.getIotKeystore(deviceId,KEYSTORE_PATH,KEYSTORE_NAME,KEYSTORE_PASS)
        val exists = AWSIotKeystoreHelper.keystoreContainsAlias(deviceId,KEYSTORE_PATH,KEYSTORE_NAME,KEYSTORE_PASS)

        Timber.v("Connecting MQTT Manager | Certificate stored: $exists")

        if(exists) {
            mqttManager.connect(keyStore, statusCallback)
        }
    }

    private var statusCallback = AWSIotMqttClientStatusCallback { status, throwable ->
        Timber.v("MQTT connection status: %s", status.name)
        Log.i("LoginFragment", "MQTT connection status: " + status.name)
        val deviceTopic = "lemonade/$deviceType/$deviceId/v1/".toLowerCase(Locale.ROOT)
        sessionsPubTopic = deviceTopic + "sessions"
        sessionsSubTopic = deviceTopic + "status/sessions"

        if(status== AWSIotMqttClientStatusCallback.AWSIotMqttClientStatus.Connected){
            Log.i("LoginFragment", "We is connected")
            mqttManager.subscribeToTopic(sessionsSubTopic, AWSIotMqttQos.QOS1, subscription)
        }
    }

    private var subscription = AWSIotMqttNewMessageCallback { topic, data ->
        val stringData = String(data)
        Timber.v("MQTT response received! \nTopic:\"$topic\" :$stringData")
    }

    fun sendMqttMessage(message: String, callback: Callback<Error>) {
        Log.i("LightYearHubHandler", "session:" + sessionsPubTopic)
        mqttManager.publishData(message.toByteArray(), sessionsPubTopic, AWSIotMqttQos.QOS1, object : AWSIotMqttMessageDeliveryCallback {

            override fun statusChanged(
                status: AWSIotMqttMessageDeliveryCallback.MessageDeliveryStatus?,
                userData: Any?
            ) {
                Log.i("LoginFragment", "delivery status: " + status?.name)
                if(status == AWSIotMqttMessageDeliveryCallback.MessageDeliveryStatus.Success) {
                    callback.onResult(null)
                } else {
                    callback.onError(null)
                }
            }
        }, "")
    }

    public fun sendSummaryDataJSON(summaryDataAsJSON: String, callback: Callback<Error>) {
        Log.i("LightYearHubHandler", "Sending message: " + summaryDataAsJSON)

        sendMqttMessage(summaryDataAsJSON, object : Callback<Error> {
            override fun onResult(result: Error?) {
                callback.onResult(result)
            }

            override fun onError(e: java.lang.Exception?) {
                callback.onError(e)
            }
        })
    }

    fun sendMqttTestMessage(callback: Callback<Error>){
        var message = buildTestMessage()
        Log.i("LightYearHubHandler", "Sending test message: " + message)

        sendMqttMessage(message, object : Callback<Error> {
            override fun onResult(result: Error?) {
                Log.i("LightYearHubHandler", "Sent test message: ")
                callback.onResult(null)
            }

            override fun onError(e: java.lang.Exception?) {
                callback.onError(e)
            }
        })
    }

    @SuppressLint("SimpleDateFormat")
    private fun buildTestMessage() : String{

        val jsonEventField1 = JSONObject()
        jsonEventField1.put("name","Awake Time")
        jsonEventField1.put("value","9")

        val jsonEventField2 = JSONObject()
        jsonEventField2.put("name","Event_Field_2")
        jsonEventField2.put("value","15")

        val jsonEventFields = JSONArray()
        jsonEventFields.put(jsonEventField1)
        jsonEventFields.put(jsonEventField2)

        val jsonEvent1 = JSONObject()
        jsonEvent1.put("eventUUID", "4C396B1E-1643-4586-A8BE-4379333E0F4A")
        jsonEvent1.put("eventFields", jsonEventFields)

        val jsonEventArray = JSONArray()
        jsonEventArray.put(jsonEvent1)

        val jsonPayload = JSONObject()
        jsonPayload.put("studyId", "ABCD1250")
        jsonPayload.put("participantId", "Werner")
        jsonPayload.put("deviceId", "4A002C0011504B3343393520")
        jsonPayload.put("data", jsonEventArray)

        val jsonMessage = JSONObject()
        val dateFormat = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssXXX")
        val now : String = dateFormat.format(Date(System.currentTimeMillis()))
        val id = UUID.randomUUID().toString()
        jsonMessage.put("consumerId", device!!.consumerId)
        jsonMessage.put("sessionId", id)
        jsonMessage.put("sessionStartTime", now)
        jsonMessage.put("message", jsonPayload)

        val jsonString = jsonMessage.toString()
        val jsonReadableString = jsonMessage.toString(3)

        return jsonString
    }

    companion object {
        private const val TAG = "LightYearHubHandler"
    }
}
