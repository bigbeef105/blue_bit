package com.kv.androidhubi.fragments

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.navigation.fragment.findNavController
import com.kv.androidhubi.customClasses.AppNavigator
import com.kv.androidhubi.MainActivity
import com.kv.androidhubi.R

class SplashFragment : Fragment() {
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

//        Handler(Looper.getMainLooper()).postDelayed({
            (activity as MainActivity).appNavigator.setupNavigator((activity as MainActivity).getActualActionBar()!!, findNavController())
            (activity as MainActivity).appNavigator.SetState(AppNavigator.AppPageState.LOGIN, true)
//            findNavController().navigate(R.id.action_splashFragment_to_loginFragment)
//        }, 2000)

        val permissions = arrayOf(android.Manifest.permission.ACCESS_FINE_LOCATION, android.Manifest.permission.BLUETOOTH, android.Manifest.permission.BLUETOOTH_ADMIN)
        this.requestPermissions(permissions, 0)
//        this.requestPermissions(arrayOf(android.Manifest.permission.ACCESS_BACKGROUND_LOCATION), 0)

        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_splash, container, false)
    }
}