package com.kv.androidhubi.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import codes.alchemy.lightyearlabs.LightyearLabs
import com.kv.androidhubi.customClasses.AppNavigator
import com.kv.androidhubi.customClasses.Constants
import com.kv.androidhubi.customClasses.HubiFragmentExtender
import com.kv.androidhubi.R
import com.kv.androidhubi.customClasses.HubiAlertDialog
import kotlinx.android.synthetic.main.fragment_user_details.view.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class UserDetailsFragment : HubiFragmentExtender() {
    public var username: String = ""
    public var password: String = ""

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        var view = inflater.inflate(R.layout.fragment_user_details, container, false)

        view.textUsername.text = this.getMainActivity().userPrefHandler.userPrefGetString(
            Constants.userPrefKeyUsername
        )

        view.textStudyID.text = this.getMainActivity().userPrefHandler.userPrefGetString(
            Constants.userPrefKeyStudyID
        )

        view.buttonLogOut.setOnClickListener() {
            getMainActivity().userAccountInfo.clearAllData()
            CoroutineScope(Dispatchers.IO).launch {
                LightyearLabs.logout()
            }
            getMainActivity().appNavigator.SetState(AppNavigator.AppPageState.LOGIN, true)
        }

        view.buttonShowEULA.setOnClickListener() {
            getAppNavigator().SetState(AppNavigator.AppPageState.EULA, true)
        }

        view.buttonAdmin.setOnClickListener() {
            var inputAlert = HubiAlertDialog(this.getMainActivity())
            inputAlert.show()
            inputAlert.enterAdminPassword(this.getMainActivity())
        }

        // Inflate the layout for this fragment
        return view
    }


}