package com.kv.androidhubi.customClasses

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONObject
import java.util.*


class UserPrefHandler(var preferences: SharedPreferences) {

    public fun userPrefGetInt(key: String) : Int {
        return this.preferences!!.getInt(key, 0)
    }

    public fun userPrefSetInt(key: String, value: Int) {
        val editor = preferences!!.edit()
        editor.putInt(key, value)
        editor.apply()
    }

    public fun userPrefGetString(key: String) : String? {
        return preferences!!.getString(key, "")
    }

    public fun userPrefSetString(key: String, value: String) {
        val editor = preferences!!.edit()
        editor.putString(key, value)
        editor.apply()
    }

    public fun userPrefRemoveString(key: String) {
        val editor = preferences!!.edit()
        editor.remove(key)
        editor.apply()
    }

    public fun userPrefClearData(key: String) {
        val editor = preferences!!.edit()
        editor.remove(key)
        editor.apply()
    }

    public fun userPrefClearAllData() {
        val editor = preferences!!.edit()
        editor.clear()
        editor.apply()
    }
}