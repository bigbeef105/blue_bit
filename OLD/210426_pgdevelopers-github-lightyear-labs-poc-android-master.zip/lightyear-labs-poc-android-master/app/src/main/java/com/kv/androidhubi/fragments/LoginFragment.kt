package com.kv.androidhubi.fragments

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import codes.alchemy.awskit.iot.IotAuthState
import codes.alchemy.lightyearlabs.LightyearLabs
import codes.alchemy.lightyearlabs.LightyearLabsCallback
import kotlinx.android.synthetic.main.fragment_login.view.*
import com.amazonaws.mobile.client.*
import com.amazonaws.mobile.client.results.SignInResult
import com.kv.androidhubi.R
import com.kv.androidhubi.customClasses.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import timber.log.Timber
import java.lang.Exception
import java.util.*

class LoginFragment() : HubiFragmentExtender() {
//    var username: String = "kv_app_team@mailbeaver.net"//"butts.sg@pg.com"//"aaron+pgtest1234@atomicrobot.com"
//    var password: String = "Cce7&YsT"//"Test1234"//"Asdf123#"
//    var username: String = "butts.sg@pg.com"//"aaron+pgtest1234@atomicrobot.com"
//    var password: String ="Test1234"//"Asdf123#"
    var username: String = ""//"gcourts@saec-kv.com"
    var password: String = ""//"3asyP@ss123"

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        var view = inflater.inflate(R.layout.fragment_login, container, false)

        // Setup handlers for username and password text input fields
        this.setupTextInputHandlers(view)

        // Attempt login on button click.
        view.btnLogin.setOnClickListener()
        {
            attemptLogin(username, password)
        }

        if(getMainActivity().userAccountInfo.userIsSignedIn()) {
            username = getMainActivity().userAccountInfo.getUsername()!!
            password = getMainActivity().userAccountInfo.getPassword()!!
            attemptLogin(username, password)
        }

        // Inflate the layout for this fragment
        return view
    }

    // Logs user in using Lightyear Labs and moves to Product view on success
    private fun attemptLogin(username: String, password: String) {
        Log.d(TAG, "Attempting login : " + username + " " + password)

        getMainActivity().attemptLogin(username, password)
//        getMainActivity().appNavigator.SetState(AppNavigator.AppPageState.PRODUCTLIST, true)

//        CoroutineScope(Dispatchers.IO).launch {
//            val result  = getMainActivity().lightyear.login(username, password)
//            if(result.isSuccess) {
//                Log.i("LoginFragment", "We logged in yo")
//                var myRunnable = Runnable {
//                    dialog.hide()
//
//                    if(!getMainActivity().userAccountInfo.userIsSignedIn()) {
//                        getMainActivity().userAccountInfo.setUsername(username)
//                        getMainActivity().userAccountInfo.setPassword(password)
//                    }
//
//                    getAppNavigator().SetState(AppNavigator.AppPageState.PRODUCTLIST, true)
//                }
//
//                getMainActivity().runOnUiThread(myRunnable)
//            } else {
//                Log.i("LoginFragment", "Failed to log in")
//
//                var myRunnable = Runnable {
//                    dialog.loginFailure()
//                }
//
//                getMainActivity().runOnUiThread(myRunnable)
//            }
//        }
    }

    private fun setupTextInputHandlers(view: View) {
        view.textInputUsername.editText?.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {

            }

            override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {

            }

            override fun afterTextChanged(p0: Editable?) {
                username = p0.toString()
            }
        })

        view.textInputPassword.editText?.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {

            }

            override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {

            }

            override fun afterTextChanged(p0: Editable?) {
                password = p0.toString()
            }
        })
    }

    companion object {
        private const val TAG = "LoginFragment"
    }
}
