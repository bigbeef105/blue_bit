package com.kv.androidhubi.customClasses

import android.app.AlertDialog
import android.content.Context
import android.os.Handler
import android.util.Log
import androidx.core.os.postDelayed
import codes.alchemy.lemonadeplatform.model.LightyearLabsDevice
import com.kineticvision.resbitblesdk.*
import com.kv.androidhubi.BeaconRegionBootstrap
import com.kv.androidhubi.MainActivity
import com.kv.androidhubi.fragments.ReceiveProductFragment
import org.altbeacon.beacon.Beacon
import java.text.SimpleDateFormat
import java.util.*
import kotlin.collections.ArrayList


class BLEScanner(context: Context) {
    var callback : ResBitDeviceCallback? = null

    private var runQueue : RunQueue = RunQueue()

    private var resBit:ResearchBit = ResearchBitImpl(context)

    var isWorking:Boolean = false
        get() = runQueue.runnableCount > 0 || resBit.state.id > 3

    public fun performScan(app: BeaconRegionBootstrap, deviceID:String, completion: (peripheralsFound: Boolean) -> Unit) {
        if(deviceID == "" || deviceID == null) {
            Log.d(TAG, "No devices have been added to this account. Not going to scan.")
            return
        }
        resBit.scanForBLEDevices(5000, object : ResBitScanCallback() {
            var nearbyPeripherals = ArrayList<BLEPeripheral>()
            var nearbyDevices = ArrayList<BLEDevice>()
            var foundPeripherals:Boolean = false

            override fun onPeripheralsFound(peripherals: List<BLEPeripheral>) {
                foundPeripherals = true

                callback = object : ResBitDeviceCallback() {
                    override fun onConnectionEstablished(device: BLEDevice) {
                        Log.d(TAG, "CONNECTION ESTABLISHED")

                        val calendar = Calendar.getInstance()
                        calendar.timeInMillis = device.lastSyncTime
                        val sdf = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'")

                        Log.d(TAG, "ID: ${device.serialID} last synced: ${sdf.format(calendar.time)}")
                        Log.d(TAG, "Minor: ${device.iBeaconMinor}")
                        Log.d(TAG, "Major: ${device.iBeaconMajor}")
                        Log.d(TAG, "UUID: ${device.iBeaconUUID}")

                        if(app.userAccountInfo.getIgnoreDeviceIDs()) {
                            nearbyDevices.add(device)
                        } else if((device.serialID!!.toLowerCase().startsWith(deviceID.toLowerCase()) && deviceID != "")) {
                            nearbyDevices.add(device)
                        } else {
                            Log.d(TAG, "No peripherals with that serial ID were found")
                        }
                    }

                    override fun onConnectionClosed(device: BLEDevice) {
                        Log.d(TAG, "CONNECTION CLOSED")

                        runQueue.runNext()
                    }

                    override fun onSummaryDataReceived(summaries: List<SummaryData>) {
                        Log.d(TAG, "This should never be called")
                    }

                    override fun onFailure(error: ResearchBitError) {
                        Log.d(TAG, "CONNECTION FAILED")
                        runQueue.runNext()
                    }
                }

                for ((index,peripheral) in peripherals.withIndex()) {
                    Log.d(TAG, "Device Found: ${peripheral.address}")
                    nearbyPeripherals.add(peripheral)

                    runQueue.enqueue(Runnable { Log.d(TAG, "Getting BLEDevice for peripheral at " + index); resBit.getBLEDevice(peripheral, callback!!) })
                }
                runQueue.enqueue( Runnable { Log.d(TAG, "Received " + nearbyDevices.count() + " devices"); app.receivedMultipleDevicesInBackgroundScan(nearbyDevices)  })
            }

            override fun onScanFinished() {
                Log.d(TAG, "Scan Finished")
                completion(foundPeripherals)
                runQueue.runNext()
            }

            override fun onFailure(error: ResearchBitError) {
                Log.d(TAG, "Scan Failure: $error")
                completion(foundPeripherals)
            }
        })
    }

    public fun getSummaryDataFromDevice(app: BeaconRegionBootstrap, device: BLEDevice, completion: () -> Unit) {
        val callbackForSummary = object : ResBitDeviceCallback() {
            override fun onConnectionEstablished(device: BLEDevice) {
                Log.d(TAG, "CONNECTION ESTABLISHED FOR SUMMARY")
            }

            override fun onConnectionClosed(device: BLEDevice) {
                Log.d(TAG, "CONNECTION CLOSED")
                completion()
            }

            override fun onSummaryDataReceived(summaries: List<SummaryData>) {
                Log.d(TAG, "SUMMARY DATA RECEIVED: ${summaries.count()} summaries")
                val sdf = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'")
                for(summary in summaries) {
                    Log.d(TAG, "${summary.eventUUID} : ${sdf.format(summary.eventWakeupTime)}")
                    for(eventField in summary.eventFields) {
                        Log.d(TAG, "    ${eventField.name} : ${eventField.value}")
                    }
                    Log.d(TAG, "---------------------------------------")
                }

                app.receivedSummaryData(summaries, device)
            }

            override fun onFailure(error: ResearchBitError) {
                Log.d(TAG, "CONNECTION FAILED")
                completion()
            }
        }

        resBit.getBLEDeviceSummaryData(device, callbackForSummary)
    }

    public fun scanForNewDevice(deviceID: String, app: BeaconRegionBootstrap, progressDialog : HubiAlertDialog?) {
        progressDialog?.show()

        var foundPeripherals = false

        resBit.scanForBLEDevices(5000, object : ResBitScanCallback() {
            var nearbyPeripherals = ArrayList<BLEPeripheral>()

            override fun onPeripheralsFound(peripherals: List<BLEPeripheral>) {
                foundPeripherals = true
                for (peripheral in peripherals) {
                    Log.d(TAG, "Device Found: ${peripheral.address}")
                    nearbyPeripherals.add(peripheral)
                }

                callback = object : ResBitDeviceCallback() {
                    override fun onConnectionEstablished(device: BLEDevice) {
                        Log.d(TAG, "CONNECTION ESTABLISHED")
                        if(device.serialID!!.toLowerCase().startsWith(deviceID.toLowerCase()) && deviceID != "") {
                            val calendar = Calendar.getInstance()
                            calendar.timeInMillis = device.lastSyncTime
                            val sdf = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'")

                            Log.d(TAG, "ID: ${device.serialID} last synced: ${sdf.format(calendar.time)}")
                            Log.d(TAG, "Minor: ${device.iBeaconMinor}")
                            Log.d(TAG, "Major: ${device.iBeaconMajor}")
                            Log.d(TAG, "UUID: ${device.iBeaconUUID}")

                            app.foundValidPeripheralInScan(device, progressDialog)
                        } else {
                            Log.d(
                                TAG,
                                "No peripherals with that serial ID were found"
                            )

                            app.noValidPeripheralsFoundInScan(progressDialog)
                        }
                    }

                    override fun onConnectionClosed(device: BLEDevice) {
                        Log.d(TAG, "CONNECTION CLOSED")
                    }

                    override fun onSummaryDataReceived(summaries: List<SummaryData>) {
                        Log.d(TAG, "This should never be called")

                    }

                    override fun onFailure(error: ResearchBitError) {
                        Log.d(TAG, "CONNECTION FAILED")
                        app.errorDurngScan(progressDialog)
                    }
                }

                var mainHandler = Handler(app.mainLooper)
                var myRunnable = Runnable {
                    resBit.getBLEDevice(peripherals.first() ,callback!!)
                }

                mainHandler.postDelayed(myRunnable, 2000)
            }

            override fun onScanFinished() {
                Log.d(TAG, "Scan Finished")
                app.finishedScan()
                if(!foundPeripherals) {
                    app.noValidPeripheralsFoundInScan(progressDialog)
                }
            }

            override fun onFailure(error: ResearchBitError) {
                Log.d(TAG, "Scan Failure: $error")
                app.errorDurngScan(progressDialog)
            }
        })
    }

    companion object {
        private const val TAG = "BLEScanner"
    }
}
