package com.kv.androidhubi.fragments

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.text.method.ScrollingMovementMethod
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ScrollView
import android.widget.TextView
import com.kineticvision.resbitblesdk.*
import com.kv.androidhubi.R
import com.kv.androidhubi.customClasses.HubiAlertDialog
import com.kv.androidhubi.customClasses.HubiFragmentExtender
import kotlinx.android.synthetic.main.fragment_debugger.view.*
import java.text.SimpleDateFormat
import java.util.*

class DebuggerFragment : HubiFragmentExtender() {
    lateinit var mainHandler: Handler
//    lateinit var  scrollView: ScrollView
    lateinit var textLog: TextView

//    private val updateTextTask = object : Runnable {
//        override fun run() {
//            updateLog()
//            mainHandler.postDelayed(this, 500)
//        }
//    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_debugger, container, false)

//        scrollView = view.scrollviewLog
        textLog = view.textDebug
        textLog.movementMethod = ScrollingMovementMethod()

        textLog.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {

            }

            override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {

            }

            override fun afterTextChanged(p0: Editable?) {
//                scrollView.fullScroll(View.FOCUS_DOWN)
            }
        })

        view.buttonScanForNearby.setOnClickListener {
            performNearbyScan()
        }

        view.buttonScanByID.setOnClickListener {
            var dialog = HubiAlertDialog(getMainActivity())
            dialog.show()
            dialog.debugScanBySerialID(this)
        }

        view.buttonClearLog.setOnClickListener {
            textLog.text = ""
        }

        mainHandler = Handler(Looper.getMainLooper())

        // Inflate the layout for this fragment
        return view
    }

    fun updateLog(text: String) {
        val newText = "\n" + text
        textLog.append(newText)
    }

    public fun performNearbyScan() {
        updateLog("Starting Scan")
        var resBit = ResearchBitImpl(getMainActivity().applicationContext)
        resBit.scanForBLEDevices(5000, object : ResBitScanCallback() {
            var nearbyPeripherals = ArrayList<BLEPeripheral>()

            override fun onPeripheralsFound(peripherals: List<BLEPeripheral>) {
                for (peripheral in peripherals) {
                    updateLog("Device Found: ${peripheral.address}")
                    nearbyPeripherals.add(peripheral)
                }

                var mainHandler = Handler(getMainActivity().mainLooper)
                var myRunnable = Runnable {
                    EstablishConnection(nearbyPeripherals, resBit, "")
                }

                mainHandler.postDelayed(myRunnable, 1000)
            }

            override fun onScanFinished() {
                updateLog("Scan Finished")
                if(nearbyPeripherals.count() <= 0) {
                    updateLog("No peripherals found nearby")
                }
            }

            override fun onFailure(error: ResearchBitError) {
                updateLog("Scan Failure: $error")
            }
        })
    }

    public fun performScanByID(deviceID: String) {
        updateLog("Starting Scan for device with ID: ${deviceID}")
        var resBit = ResearchBitImpl(getMainActivity().applicationContext)
        resBit.scanForBLEDevices(5000, object : ResBitScanCallback() {
            var nearbyPeripherals = ArrayList<BLEPeripheral>()

            override fun onPeripheralsFound(peripherals: List<BLEPeripheral>) {
                for (peripheral in peripherals) {
                    updateLog("Device Found: ${peripheral.address}")
                    Log.d(TAG, "Device Found: ${peripheral.address}")
                    nearbyPeripherals.add(peripheral)
                }

                var mainHandler = Handler(getMainActivity().mainLooper)
                var myRunnable = Runnable {
                    EstablishConnection(nearbyPeripherals, resBit, deviceID)
                }

                mainHandler.postDelayed(myRunnable, 0)
            }

            override fun onScanFinished() {
                updateLog("Scan Finished")
                if(nearbyPeripherals.count() <= 0) {
                    updateLog("No peripherals found nearby")
                }
            }

            override fun onFailure(error: ResearchBitError) {
                updateLog("Scan Failure: $error")
            }
        })
    }

    public fun EstablishConnection(
        nearbyPeripherals: ArrayList<BLEPeripheral>,
        resBit: ResearchBitImpl,
        deviceID: String
    ) {
        updateLog("Attempting Connection...")
        var callback = object : ResBitDeviceCallback() {
            override fun onConnectionEstablished(device: BLEDevice) {
                updateLog("CONNECTION ESTABLISHED to device with ID: ${device.serialID}")
                if(device.serialID!!.toLowerCase().startsWith(deviceID.toLowerCase())) {
                    val calendar = Calendar.getInstance()
                    calendar.timeInMillis = device.lastSyncTime
                    val sdf = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'")

                    updateLog("ID: ${device.serialID} last synced: ${sdf.format(calendar.time)}")
                    updateLog("Minor: ${device.iBeaconMinor}")
                    updateLog("Major: ${device.iBeaconMajor}")
                    updateLog("UUID: ${device.iBeaconUUID}")

                    if (nearbyPeripherals.count() > 1) {
                        var mainHandler = Handler(getMainActivity().mainLooper)
                        var myRunnable = Runnable {
                            nearbyPeripherals.removeAt(0)
                            EstablishConnection(nearbyPeripherals, resBit, deviceID)
                        }

                        mainHandler.postDelayed(myRunnable, 0)
                    }
                } else {
                    updateLog("No peripherals with that serial ID were found")
                }
            }

            override fun onConnectionClosed(device: BLEDevice) {
                updateLog("CONNECTION CLOSED")
            }

            override fun onSummaryDataReceived(summaries: List<SummaryData>) {
                updateLog("This should never be called")
            }

            override fun onFailure(error: ResearchBitError) {
                updateLog("CONNECTION FAILED")
            }
        }

        resBit.getBLEDevice(nearbyPeripherals.first(), callback!!)
    }

    companion object {
        private const val TAG = "DebuggerFragment"
    }
}
