package com.kv.androidhubi.customClasses

import android.util.Log
import androidx.appcompat.app.ActionBar
import androidx.navigation.NavController
import com.kv.androidhubi.BeaconRegionBootstrap
import com.kv.androidhubi.R
import kotlinx.android.synthetic.main.layout_menu.view.*

class AppNavigator {
    enum class AppPageState {
        NONE, SPLASH, LOGIN, PRODUCTLIST, USERDETAILS, RECEIVEPRODUCT, EULA, ADMIN, DEBUGGER
    }

    var navigator: NavController? = null
    var navBar: ActionBar? = null
    var currentPageState: AppPageState = AppPageState.SPLASH
    var previousPageState: AppPageState = AppPageState.NONE
    var pageStateBackStack: ArrayList<AppPageState> = ArrayList<AppPageState>()

    val pageTitleMap = mapOf(
        AppPageState.LOGIN to "Log In",
        AppPageState.PRODUCTLIST to "Product List",
        AppPageState.USERDETAILS to "User Details",
        AppPageState.RECEIVEPRODUCT to "Receive Product",
        AppPageState.EULA to "EULA",
        AppPageState.ADMIN to "Admin & Troubleshooting",
        AppPageState.DEBUGGER to "Debugger")

    public fun setupNavigator(navigationBar: ActionBar, navController: NavController) {
        navBar = navigationBar
        navigator = navController

        var userDetailsButton = navigationBar?.customView?.buttonUserDetails
        val a = userDetailsButton?.let {
            userDetailsButton!!.setOnClickListener() {
                SetState(AppPageState.USERDETAILS, true)
            }
        }

        var previousPageButton = navigationBar?.customView?.buttonPreviousPage
        val b = previousPageButton?.let {
            previousPageButton!!.setOnClickListener() {
                handleBackButtonPress()
            }
        }

        var receiveProductButton = navigationBar?.customView?.buttonReceiveProduct
        val c = receiveProductButton?.let {
            receiveProductButton!!.setOnClickListener() {
                SetState(AppPageState.RECEIVEPRODUCT, true)
            }
        }
    }

    public fun handleBackButtonPress() {
        navigator?.popBackStack()
        val newState = pageStateBackStack[pageStateBackStack.count() - 1]
        pageStateBackStack.removeAt(pageStateBackStack.count() - 1)
        SetState(newState, false)
    }

    public fun SetState(newState: AppPageState, shouldLoadFragment: Boolean) {
        var fragmentIDToLoad = 0

        if(newState == AppPageState.LOGIN) {
            fragmentIDToLoad = R.id.loginFragment
            pageStateBackStack.clear()
            navigator?.popBackStack(0, true)
            navBar?.show()
        } else if(newState == AppPageState.PRODUCTLIST) {
            fragmentIDToLoad = R.id.productListFragment
        } else if(newState == AppPageState.USERDETAILS) {
            fragmentIDToLoad = R.id.userDetailsFragment
        } else if(newState == AppPageState.RECEIVEPRODUCT) {
            fragmentIDToLoad = R.id.receiveProductFragment
        } else if(newState == AppPageState.EULA) {
            fragmentIDToLoad = R.id.eulaFragment
        } else if(newState == AppPageState.ADMIN) {
            fragmentIDToLoad = R.id.adminFragment
        } else if(newState == AppPageState.DEBUGGER) {
            fragmentIDToLoad = R.id.debuggerFragment
        } else {
            // Just a splash screen or something else we don't care about
        }

        // We don't start having a backstack until AFTER the product list page loads.
        // Treat the product list as the first page of our app. The only way to get back to the login page is through the log out button under User Details
        if(shouldLoadFragment && newState != AppPageState.SPLASH && newState != AppPageState.LOGIN && newState != AppPageState.PRODUCTLIST) {
            // We're loading a new page, so store this existing page in the backstack
            previousPageState = currentPageState
            pageStateBackStack.add(previousPageState)
        }

        if(newState == AppPageState.PRODUCTLIST) {
            showReceiveProductButton(true)
            showUserDetailsButton(true)
        } else {
            showReceiveProductButton(false)
            showUserDetailsButton(false)
        }

        if(pageStateBackStack.count() > 0 && newState != AppPageState.PRODUCTLIST) {
            // Show previous page button with proper title
            setPreviousPageButtonTitle(pageTitleMap.getValue(pageStateBackStack[pageStateBackStack.count() - 1]))
            showPreviousPageButton(true)
        } else {
            // No page to go back to, make sure our back button is hidden
            showPreviousPageButton(false)
        }

        setPageTitle(pageTitleMap.getValue(newState))

        if(shouldLoadFragment) {
            navigator?.navigate(fragmentIDToLoad)
        }

        currentPageState = newState
    }

    private fun setPageTitle(text: String) {
        navBar?.customView?.textPageTitle?.text = text
    }

    private fun setPreviousPageButtonTitle(text: String) {
        navBar?.customView?.buttonPreviousPage?.isEnabled = (text != "")
        navBar?.customView?.buttonPreviousPage?.text = text
    }

    private fun showUserDetailsButton(show: Boolean) {
        navBar?.customView?.buttonUserDetails?.isEnabled = show
        if(show) {
            navBar?.customView?.buttonUserDetails?.alpha = 1.0f
        } else {
            navBar?.customView?.buttonUserDetails?.alpha = 0.0f
        }
    }

    private fun showReceiveProductButton(show: Boolean) {
        var previousPageButton = navBar?.customView?.buttonPreviousPage
        var receiveProductButton = navBar?.customView?.buttonReceiveProduct

        if(show) {
            receiveProductButton?.alpha = 1.0f
            receiveProductButton?.isEnabled = true

            previousPageButton?.alpha = 0.0f
            previousPageButton?.isEnabled = false
        } else {
            receiveProductButton?.alpha = 0.0f
            receiveProductButton?.isEnabled = false

            previousPageButton?.alpha = 1.0f
            previousPageButton?.isEnabled = true
        }
    }

    private fun showPreviousPageButton(show: Boolean) {
        var previousPageButton = navBar?.customView?.buttonPreviousPage

        if(show) {
            previousPageButton?.isEnabled = true
            previousPageButton?.alpha = 1.0f
        } else {
            previousPageButton?.isEnabled = false
            previousPageButton?.alpha = 0.0f
        }
    }
}