package codes.alchemy.lightyearlabs

import android.content.Context
import codes.alchemy.awskit.config.IotEnvironment
import codes.alchemy.awskit.config.IotPlatform
import codes.alchemy.awskit.iot.IotAuthState
import codes.alchemy.awskit.iot.IotInteractor
import codes.alchemy.awskit.iot.UserNotConfirmedException
import codes.alchemy.lemonadeplatform.LightyearLabsDataInteractor
import codes.alchemy.lemonadeplatform.model.LightyearLabsDevice
import codes.alchemy.lemonadeplatform.model.User
import codes.alchemy.lemonadeplatform.type.DeviceStatus
import codes.alchemy.lemonadeplatform.type.LogLevel
import codes.alchemy.lemonadeplatform.type.TableSessionFilterInput
import kotlinx.coroutines.Dispatchers.IO
import kotlinx.coroutines.withContext
import timber.log.Timber
import java.util.*

/**
 * Error when trying to access an authInteractor or dataInteractor in LightyearLabs before initialized
 */
class LightyearLabsUninitializedException: Exception("Must wait for LightyearLabs.initialize to finish before making queries, mutations, or authorizing")

/**
 * Callback for the auth state and initialization of the LightyearLabs dependencies
 */
interface LightyearLabsCallback {
    fun onResult(iotAuthState: IotAuthState, lighyearLabs: LightyearLabs)
    fun onError(error: Throwable)
}

object LightyearLabs {
    var initialized: Boolean = false
        get() = innerAuthInteractor != null && innerDataInteractor != null

    private var innerDataInteractor: LightyearLabsDataInteractor? = null
    private val dataInteractor: LightyearLabsDataInteractor
        get() = innerDataInteractor ?: throw LightyearLabsUninitializedException()

    private var innerAuthInteractor: IotInteractor? = null
    private val authInteractor: IotInteractor
        get() = innerAuthInteractor ?: throw LightyearLabsUninitializedException()


    /**
     * [getIotEnviornment]
     * @returns the IotEnvironment configuration, or null if not configured
     */
    fun getIotEnviornment(): IotEnvironment? = authInteractor.getCurrentEnvironment().getOrNull()

    /**
     * Exposed for testing, method for injecting interactors
     */
    fun initializeWithInteractors(
        authInteractor: IotInteractor,
        lightyearLabsDataInteractor: LightyearLabsDataInteractor
    ) {
        innerAuthInteractor = authInteractor
        innerDataInteractor = lightyearLabsDataInteractor
    }

    /**
     * method to initialize the dependencies for LightyearLabs
     * @param context - Context used by the IotPlatform initializer
     * @param clientId - String clientId used to connect to Lightyear
     * @param clientSecret - String clientSecret used to connect to Lightyear
     * @param locale (optional) - Locale to specify the current region when connecting
     * @param callback - [LightyearLabsCallback] that is called when initialization is complete or an error occurred
     */
    suspend fun initialize(
        context: Context,
        clientId: String,
        clientSecret: String,
        locale: Locale = Locale.getDefault(),
        callback: LightyearLabsCallback
    ) = withContext(IO) {
        IotPlatform.initialize(context,
            clientId,
            clientSecret,
            locale,
            callback = object : IotPlatform.InitializeCallback {
                override fun onResult(iotAuthState: IotAuthState) {
                    super.onResult(iotAuthState)
                    initializeWithInteractors(
                        IotInteractor(context),
                        LightyearLabsDataInteractor(context, IotPlatform.getAppSyncClient(context))
                    )
                    callback.onResult(iotAuthState, this@LightyearLabs)
                }

                override fun onError(e: Exception) {
                    super.onError(e)
                    callback.onError(e)
                }
            }
        )
    }

    /**
     * [getRootCA] - downloads the Amazon Root CA as a String
     * @return Result<String> - result object containing the Amazon Root CA as a String. Uses the URL from [IotEnvironment.rootCAUrl]
     */
    suspend fun getRootCA() : Result<String> = authInteractor.getRootCA()

    /**
     *
     * User Methods
     *
     */

    /**
     * [login] - log the user in
     * @param email - Email address of the user
     * @param password - password of the user
     *
     * @return Result<Boolean> - result object containing a boolean that represents if the user has a confirmed email address
     */
    suspend fun login(
        email: String,
        password: String
    ) : Result<Boolean> = authInteractor.login(
            email,
            password
        )

    /**
     * [logout] - log the currently logged in user out
     *
     * @return Result<Unit> - result object to express the success or failure of the operation
     */
    suspend fun logout() = authInteractor.logout()


    /**
     * Sign up with IoT platform
     *
     * @param email - User's email address
     * @param password - User's password
     * @param firstName - User firstName (optional)
     * @param lastName - User lastName (optional)
     * @param phoneNumber - User phoneNumber (E164 formatted)
     *
     * @return Result<Boolean> - includes flag on whether or not the user's account
     * has been confirmed. If not, use the [confirmSignUp] method. (user will get email)
     */
    suspend fun createAccount(
        email: String,
        password: String,
        firstName: String? = null,
        lastName: String? = null,
        phoneNumber: String? = null
    ) = authInteractor.signUp(
        email,
        password,
        firstName,
        lastName,
        phoneNumber
    )

    /**
     * [getUser] - get the latest User values from Lightyear
     *
     * @return Result<User> - result containing the latest User values from Lightyear
     */
    suspend fun getUser() = dataInteractor.getUser()

    /**
     * [deleteUser] - delete the current logged in User from Lightyear
     *
     * @return Result<String> - result with the String id of the delete operation
     */
    suspend fun deleteUser() = dataInteractor.deleteUser()

    /**
     * [updateUser] - update the User stored in Lightyear
     * @param user - [User] which properties are sent to Lightyear
     * @return Result<User> - result containing the updated User
     */
    suspend fun updateUser(user: User) = dataInteractor.updateUser(user)

    /**
     * [updateUser] - update the User stored in Lightyear
     * @param firstName - optional first name of the User
     * @param lastName - optional first name of the User
     * @param marketingOptIn - optional Boolean for if the User has opted in for marketing
     * @param phoneNumber - optional String for the phone number of the User (E164 formatted)
     * @param termsAndConditions - optional Boolean for if the user has accepted the Terms and Conditions
     * @param timezone - optional Double for the timezone of the User
     * @return Result<User> - result containing the updated User
     */
    suspend fun updateUser(
        firstName: String? = null,
        lastName: String? = null,
        marketingOptIn: Boolean? = null,
        phoneNumber: String? = null,
        termsAndConditions: Boolean? = null,
        timezone: Double? = null
    ) = dataInteractor.updateUser(
        firstName,
        lastName,
        marketingOptIn,
        phoneNumber,
        termsAndConditions,
        timezone
    )

    /**
     *
     * Device Methods
     *
     */


    /**
     * [getDeviceTypes] - Gets the valid device types as Strings for the Lightyear Labs environment
     * @return Result<List<String>> - result with a list of the device types
     */
    suspend fun getDeviceTypes() = dataInteractor.getDeviceTypes()

    /**
     * [createDevice] - Creates a device in the Lightyear Labs environment
     * @param deviceId - device UUID as a lowercase string without the '-' character
     * @param deviceType - deviceType of the device being created. Valid device types can be retrived by calling LemonadeDataInteractor#getDevicetTypes()
     * @return Result<DeviceProvision> - result with the DeviceProvision object containing the privateKey and cert for the LightyearLabsDevice
     */
    suspend fun createDevice(
        deviceId: String,
        deviceType: String
    ) = dataInteractor.createDevice(
            deviceId,
            deviceType
        )

    /**
     * [updateDevice] - Updates the Device in the platform with the properties from the new Device object
     * @param device - the device to be updated
     * @return Result<LightyearLabsDevice> - result with the updated device
     */
    suspend fun updateDevice(device: LightyearLabsDevice) = dataInteractor.updateDevice(device)

    /**
     * Update the specified device with data
     * @param deviceId - String deviceId for the device being updated
     * @param message - String for the message associated with the device
     * @param status - Nullable DeviceStatus for the status of the device,
     *                 If null, the value is not updated
     * @param logLevel - Nullable LogLevel enum for the LogLevel of the device,
     *                   If null, the value is not updated
     * @return Result<LightyearLabsDevice> - result with the updated device
     */
    suspend fun updateDevice(
        deviceId: String,
        message: String,
        status: DeviceStatus? = null,
        logLevel: LogLevel? = null
    ) = dataInteractor.updateDevice(
        deviceId,
        message,
        status,
        logLevel
    )

    /**
     * [deleteDevice] - method to delete a device from Lightyear
     * @param deviceId - String id of the device to delete
     * @param deviceType - String type of the device to delete
     * @return Result<String> - result with String id of delete operation
     */
    suspend fun deleteDevice(deviceId: String, deviceType: String) = dataInteractor.deleteDevice(deviceId, deviceType)

    /**
     * [getDevices] - method to get all devices associated with the currently authenticated User
     * @return Result<List<LightyearLabsDevice>> - result with a list of device associated with authenticated User
     */
    suspend fun getDevices() = dataInteractor.getDevices()

    /**
     *
     * Session Methods
     *
     */

    /**
     * [createSession] - creates Session in Lightyear
     * @param deviceId -
     * @param deviceType
     * @param message - optional String message for the Session
     * @param receivedDate - received date of the Session
     * @param sessionId - String id of the Session
     * @param sessionStartTime - Date for the start time of the Session
     * @param sessionType - optional String type of Session
     * @param thingName - thingName of the device for the Session
     * @return Result<Session> - result with the created Session
     */
    suspend fun createSession(
        deviceId: String,
        deviceType: String,
        message: String? = null,
        receivedDate: Date,
        sessionId: String,
        sessionStartTime: Date,
        sessionType: String? = null,
        thingName: String
    ) = dataInteractor.createSession(
        deviceId,
        deviceType,
        message,
        receivedDate,
        sessionId,
        sessionStartTime,
        sessionType,
        thingName
    )

    /**
     * [getSessions] - method to get Sessions within a time range or finer querying parameters
     * @param startDate -
     * @param endDate -
     * @param filter - [TableSessionFilterInput] used for filtering results
     * @param limit - optional Int to limit the number of results
     * @param nextToken - optional String token for the next page of results
     * @return Result<List<Sessions>> - result object with the list of Sessions returned in the query
     */
    suspend fun getSessions(
        startDate: Date,
        endDate: Date,
        filter: TableSessionFilterInput? = null,
        limit: Int? = null,
        nextToken: String? = null
    ) = dataInteractor.getSessions(
        startDate,
        endDate,
        filter,
        limit,
        nextToken
    )

    /**
     * [deleteSession] - method to delete a session object
     * @param sessionId - String id of the Session to delete
     * @return Result<String> - result with the id for the delete operation
     */
    suspend fun deleteSession(sessionId: String) = dataInteractor.deleteSession(sessionId)
}