/*
 * Copyright (c) 2020 The Pocter & Gamble Company, INC.  All rights reserved.
 *
 * This software in whole and in part is owned by The Pocter & Gamble Company, INC
 * and may not be sold, offered, excerpted, bartered, or in any way delivered
 * or made available to any third party without direct, explicit and written consent
 * of The Procter & Gamble Company or its assignees.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL THE
 * CONTRIBUTORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * WITH THE SOFTWARE.
 */

#include <BlueBitV2.h>

#undef USE_ARDUINO

#ifdef USE_ARDUINO
#include "Arduino.h"
#else
#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include "platform.h"
#include "gpio_generic.h"
#endif

#include "i2c_platform.h"

#include "byte_type_conv.h"

/******************************************************/
/*************     Local Variables      ***************/
/******************************************************/
static serialNum_t                hardwareSerialNum;
static bool                       blockingResReceived;
static messageData_t              receiveBuffer;
static messageData_t              sendBuffer;
static packet_t                   receivePacket;
static packet_t                   sendPacket;
static response_t                 response;
static swUnitsStatistics_t        stats[SUC_NUMBER_OF_SW_UNITS_LIST];
static char                       hardwareVersionStr[VERSION_STR_ARRAY_LENGTH];
static char                       firmwareVersionStr[VERSION_STR_ARRAY_LENGTH];
static splitBuffer_t              messageQueue;
static messageResponseCode_t      blockingResCode;
static uint8_t *                  blockingResData;
static size_t                     blockingResLen;
static uint8_t                    sbBuffer[MESSAGE_MAX_LEN * 2];
static packet_t                   rxPacket;
static response_t                 rxResponse;
static responseHandler_t          resHandlersQueue[SPLIT_BUFFER_MAX_ENTRIES + 1];
static size_t                     rhTail;
static size_t                     rhHead;
static transferState_t            writeState           = transferStateIdle;
static transferState_t            readState            = transferStateIdle;
static bool                       packetPending        = false;
static bool                       responsePending      = false;
static bool                       gpioState            = false;
static bool                       hasPacket            = false;
static bool                       hasResponse          = false;
static protocolState_t            state                = ProtocolStateIdle;
static bool                       sendInProgress       = false;
static uint8_t                    responseCode         = 0;
static bool                       responseCodeSet      = false;
static uint32_t                   timeoutStart         = 0;
static uint32_t                   messageDelayStart    = 0;
static uint32_t                   messageDelayDuration = 0;
static int                        writeRetryCount      = 0;
static version_t                  hardwareVersion      = {};
static version_t                  firmwareVersion      = {};
static const messageHandlerReg_t  messages[]           = {{ 0, NULL }};
static messageHandlerList_t       messageHandlerRoot   = { messages, NULL };
static const bleConfigVariables_t bleConfigVariables[] = {{ bleConfigIdAdvertOnTime,     2,     configIoctlGetBleAdvertOnTime },
                                                          { bleConfigIdAdvertOffTimeMin, 2, configIoctlGetBleAdvertOffTimeMin },
                                                          { bleConfigIdAdvertOffTimeMax, 2, configIoctlGetBleAdvertOffTimeMax },
                                                          { bleConfigIdAlwaysAdvertise,  1,  configIoctlGetBleAlwaysAdvertise },
                                                          { bleConfigIdAdvertInterval,   2,   configIoctlGetBleAdvertInterval }};
static uint16_t                   bleAdvertOnTime      = BLE_ADVERT_ON_TIME;
static uint16_t                   bleAdvertOffTimeMin  = BLE_ADVERT_OFF_TIME_MIN;
static uint16_t                   bleAdvertOffTimeMax  = BLE_ADVERT_OFF_TIME_MAX;
static uint8_t                    bleAlwaysAdvertise   = BLE_ALWAYS_ADVERTISE;
static uint16_t                   bleAdvertInterval    = BLE_ADVERT_INTERVAL;

// Define local response handler function (C legacy)

#ifdef USE_ARDUINO

#else
	#define write_pin(p_gpio_t, value)		HAL_GPIO_WritePin((GPIO_TypeDef*)p_gpio_t->port, p_gpio_t->pin, value)
	#define read_pin(p_gpio_t)				HAL_GPIO_ReadPin((GPIO_TypeDef*)p_gpio_t->port, p_gpio_t->pin)
#endif


extern "C"
{
  status_t blockingResHandler(responseHandlerArgs_t * args)
  {
    blockingResCode     = args->resCode;
    blockingResData     = args->data;
    blockingResLen      = args->len;
    blockingResReceived = true;

    return StatusOk;
  }
}

uint8_t BlueBit::is_rtc_message(void) {
	// Return if last indication was for an RTC callback.
}

status_t BlueBit::SendFakeBlobEvents(uint32_t sleep_time, uint8_t* summary_data,
                                     uint8_t* blob_data, uint16_t size) {
  //
  // Setup message
  //

  uint8_t* ptr = summary_data;
  byte_type_conv::uint16_t_to_bytes(0x02, ptr);        // number of events
  ptr += 2;

  //
  // Setup event 1 (uint32_t blob)
  //

  uint32_t* intPtr = (uint32_t*)blob_data;
  for (size_t i = 0; i < (size / sizeof(uint32_t)); i++) {
    memcpy(blob_data + (sizeof(uint32_t) * i), &i, sizeof(uint32_t));
  }

  byte_type_conv::uint16_t_to_bytes(0x03, ptr);        // summary id
  ptr += 2;
  byte_type_conv::uint32_t_to_bytes(sleep_time, ptr);  // timestamp
  ptr += 4;
  *ptr = size;                               // Data size
  ptr += 1;
  memcpy(ptr, blob_data, size);           // data
  ptr += size;

  //
  // Setup Event 2
  //

  float x = 0.0f;
  float* fPtr = (float*)blob_data;
  for (size_t i = 0; i < (size / sizeof(float)); i++) {
    memcpy(blob_data + (sizeof(float) * i), &x, sizeof(float));
    x += 1.1f;
  }

  byte_type_conv::uint16_t_to_bytes(0x04, ptr);         // summary id
  ptr += 2;
  byte_type_conv::uint32_t_to_bytes(sleep_time, ptr);   // timestamp
  ptr += 4;

  *ptr = size;                             // Data size
  ptr++;
  memcpy(ptr, blob_data,size);            // data
  ptr += size;

  BlueBits_SendSummaryData(summary_data, ptr - summary_data);
}

BlueBit::BlueBit(gpio_t *enable_pin, gpio_t *flow_ctrl_pin, uint8_t* twi)                                                                   // Class constructor
{
  _twi                = twi;
  _BlueBitEnablePin   = enable_pin;
  _BlueBitFlowCtrlPin = flow_ctrl_pin;
  rtc_msg_received_flag = 0;
}

status_t BlueBit::bluebitsInit()
{                                                                                                                                           // Main BlueBits initialization function
  status_t status = StatusOk;
  char buff[INIT_STATUS_SPRINTF_BUFF_LEN];

  hardwareVersion.major    = HARDWARE_MAJOR;
  hardwareVersion.minor    = HARDWARE_MINOR;
  hardwareVersion.revision = HARDWARE_REV;
  hardwareVersion.build    = HARDWARE_BUILD;

  firmwareVersion.major    = FIRMWARE_MAJOR;
  firmwareVersion.minor    = FIRMWARE_MINOR;
  firmwareVersion.revision = FIRMWARE_REV;
  firmwareVersion.build    = FIRMWARE_BUILD;

  DeviceInfo_Init();

  if(StatusOk == status)
  {
    status = ProtocolHal_Init(true);
  }
  if(StatusOk == status)
  {
    status = ProtocolHandler_Init();
  }
  if(StatusOk == status)
  {
    status = Messager_Init();
  }
  if(StatusOk == status)
  {
    status = BlueBits_Init();
  }

  return status;
}

void BlueBit::bluebitsHandler()
{
  ProtocolHal_Tick();
  ProtocolHandler_Tick();
  Messager_Tick();
}

status_t BlueBit::BlueBits_SendSummaryData(uint8_t * data, size_t len)
{
  status_t status = StatusOk;

  if(1)
  {
    sendMessageArgs_t args;

    args.messageId   = SUMMARY_DATA_MESSAGE_ID,
    args.messageData = data,
    args.dataLen     = len,
    args.timeoutMs   = SEND_BLOCKING_TIMEOUT,
    status           = Messager_SendMessage(&args);
    if(Status_IsOk(status))
    {
      status = Messager_ResCodeToStatus(args.resCode);
    }
  }

  return returnStatus(status, eSucWriteStatus);
}

status_t BlueBit::ProtocolHal_Tick()
{
  status_t status = StatusOk;

  if(1)
  {
    if(transferStateDone == readState)
    {
      if(packetPending)
      {
        // Read body
        uint8_t * readAddress = rxPacket.bytes + PACKET_HEADER_LEN;
        status = i2cRead(BB_I2C_ADDDR, readAddress, rxPacket.dataLen);
        packetPending = false;                                                                                                              // Read still in progress, when done we'll bump down to last else clause
      } else if(responsePending)
      {
        responsePending = false;
        hasResponse     = true;
        readState       = transferStateIdle;
      } else
      {
        hasPacket = true;
        readState = transferStateIdle;
      }
    } else if(gpioState != indicationPinStatus())
    {
      gpioState = !gpioState;                                                                                                               // Toggle state
      if(false != gpioState)                                                                                                                // Detect rising edge
      {
        if(responsePending)
        {
          // Read response
          status = i2cRead(BB_I2C_ADDDR, rxResponse.bytes, RESPONSE_LEN);
        } else
        {
          // Read packet header
          status = i2cRead(BB_I2C_ADDDR, rxPacket.bytes, PACKET_HEADER_LEN);
          packetPending = true;
        }
      }
    }
  }

  return returnStatus(status, eSucIoctlStatus);
}

status_t BlueBit::SwUnitControl_WriteStatus(SwUnitControlId_t suId, SwUnitControlStatusType_t statusType, status_t statusIn, uint16_t lineOfCode)
{
  status_t status;
  status = StatusOk;

  // Check parameter 1
  if(status == StatusOk)
  {
    if(suId >= SUC_NUMBER_OF_SW_UNITS_LIST)
    {
      status = StatusParameter1;
    }
  }

  // Check parameter 2
  if(status == StatusOk)
  {
    if(statusType >= SUC_NUMBER_OF_STATUS_TYPES)
    {
      status = StatusParameter2;
    }
  }

  // If OK, process status passed, into a statistic passed in
  if(status == StatusOk)
  {
    if(statusIn == StatusOk)
    {
      switch (statusType)
      {
        case eSucInitStatus:
          stats[suId].initStatusOk++;
          break;
        case eSucReadStatus:
          stats[suId].readStatusOk++;
          break;
        case eSucWriteStatus:
          stats[suId].writeStatusOk++;
          break;
        case eSucIoctlStatus:
					stats[suId].ioctlStatusOk++;
          break;
        default:
					break;
      }
    } else
    {
      // Status que empties are ignored (neither OK, nor not OK)
      if(statusIn != StatusQueueEmpty)
      {
        switch (statusType)
        {
          case eSucInitStatus:
            stats[suId].initNotStatusOk++;
            stats[suId].initNotOkLineOfCode = lineOfCode;
            stats[suId].initNotOkStatusCode = statusIn;
            break;
          case eSucReadStatus:
            stats[suId].readNotStatusOk++;
            stats[suId].readNotOkLineOfCode = lineOfCode;
            stats[suId].readNotOkStatusCode = statusIn;
            break;
          case eSucWriteStatus:
            stats[suId].writeNotStatusOk++;
            stats[suId].writeNotOkLineOfCode = lineOfCode;
            stats[suId].writeNotOkStatusCode = statusIn;
            break;
          case eSucIoctlStatus:
            stats[suId].ioctlNotStatusOk++;
            stats[suId].ioctlNotOkLineOfCode = lineOfCode;
            stats[suId].ioctlNotOkStatusCode = statusIn;
            break;
          default:
            break;
        }
      }
    }
  } else
  {
    return status;
  }

  return statusIn;                                                                                                                          // Status information processed, return input status.
}

status_t BlueBit::tryWhoami(uint32_t timeout)
{
  status_t status    = StatusCodePath;                                                                                                      // As long as retryLimit isn't 0, this will be overwritten. "StatusCodePath" = 31; part of the status enumerator
  uint32_t startTime = millis();

  while(!SysTime_IsElapsed(startTime, timeout) && !Status_IsOk(status))                                                                     // "SysTime_IsElapsed(startTime, timeout)" is a timer that starts at "startTime" and expires at startTime + timeout
	{
    status = sendWhoami();
  }

  return status;
}

status_t BlueBit::sendWhoami()
{
  status_t          status = StatusOk;
  sendMessageArgs_t args;
  
  args.messageId   = WHO_AM_I_MESSAGE_ID;
  args.messageData = NULL;
  args.dataLen     = 0;
  args.timeoutMs   = SEND_BLOCKING_TIMEOUT;

  status = Messager_SendMessage(&args);

  if(Status_IsOk(status))
  {
    status = Messager_ResCodeToStatus(args.resCode);
  }
  whoami_t whoami;
  if(Status_IsOk(status))
  {
    parseWhoami(args.resData, args.resLen, &whoami);
  }
  if(Status_IsOk(status))
  {
    if(whoami.deviceId != BLUEBITS_DEVICE_ID)
    {
      status = StatusDeviceId;
    }
  }

  return status;
}

status_t BlueBit::parseWhoami(const uint8_t * res, uint8_t resLen, whoami_t * whoamiOut)
{
  status_t status = StatusOk;

  if(resLen != sizeof(whoami_t))
  {
    status = StatusBufferLength;
  }

  if(Status_IsOk(status))
  {
    memcpy(whoamiOut, res, resLen);
  }

  return status;
}

status_t BlueBit::BlueBits_SendPowerState(publicState_t powerState)
{
  status_t status = StatusOk;
  uint16_t temp   = (uint16_t) powerState;

  if(1)
  {
    sendMessageArgs_t args;

    args.messageId   = SET_POWER_STATE_MESSAGE_ID;
    args.messageData = (uint8_t *) &temp;
    args.dataLen     = sizeof(temp);
    args.timeoutMs   = SEND_BLOCKING_TIMEOUT;
    status = Messager_SendMessage(&args);
    if(Status_IsOk(status))
    {
      status = Messager_ResCodeToStatus(args.resCode);
    }
  }

  return returnStatus(status, eSucWriteStatus);
}

status_t BlueBit::sendSetResbitInfo()
{
  status_t status = StatusOk;

  // Get device info
  resbitInfo_t resbitInfo;
  status = DeviceInfo_GetSerialNum(&resbitInfo.hardwareSerialNum);
  if(Status_IsOk(status))
  {
    status = DeviceInfo_GetHardwareVersion(&resbitInfo.hardwareVersion);
  }
  if(Status_IsOk(status))
  {
    status = DeviceInfo_GetFirmwareVersion(&resbitInfo.firmwareVersion);
  }

  // Send message
  if(Status_IsOk(status))
  {
    sendMessageArgs_t args;

    args.messageId   = SET_RESBIT_INFO_ID;
    args.messageData = (uint8_t *)&resbitInfo;
    args.dataLen     = sizeof(resbitInfo);
    args.timeoutMs   = SEND_BLOCKING_TIMEOUT;
    status = Messager_SendMessage(&args);
    if(Status_IsOk(status))
    {
      status = Messager_ResCodeToStatus(args.resCode);
    }
  }

  return status;
}

status_t BlueBit::DeviceInfo_GetSerialNum(serialNum_t *serialNum)
{
  *serialNum = hardwareSerialNum;
  return StatusOk;
}

status_t BlueBit::DeviceInfo_GetHardwareVersion(version_t *version)
{
  *version = hardwareVersion;
  return StatusOk;
}

status_t BlueBit::DeviceInfo_GetFirmwareVersion(version_t *version)
{
  *version = firmwareVersion;
  return StatusOk;
}

void BlueBit::makeVersionStr(version_t *version, char *str)
{
  sprintf(str, "v%d.%d.%d.%d", version->major, version->minor, version->revision, version->build);
}

void BlueBit::makeMajMinVersionStr(version_t *version, char *str)
{
  sprintf(str, "v%d.%d", version->major, version->minor);
}

bool BlueBit::BlueBits_IsEnabled()
{
  bool enabled = BLUEBIT_ENABLED;
  
	return (enabled);
}

status_t BlueBit::DeviceInfo_Init()
{
	status_t status = StatusOk;
	char    uuid[24];

	// Read UUID
	hardwareSerialNum.words[0] = U_ID_0;
	hardwareSerialNum.words[1] = U_ID_1;
	hardwareSerialNum.words[2] = U_ID_2;

  // Make char string from hardwareSerialNum.bytes[i]
   sprintf(uuid, "%.2x%.2x%.2x%.2x%.2x%.2x%.2x%.2x%.2x%.2x%.2x%.2x", hardwareSerialNum.bytes[0], hardwareSerialNum.bytes[1], hardwareSerialNum.bytes[2], 
           hardwareSerialNum.bytes[3], hardwareSerialNum.bytes[4], hardwareSerialNum.bytes[5], hardwareSerialNum.bytes[6], hardwareSerialNum.bytes[7], 
           hardwareSerialNum.bytes[8], hardwareSerialNum.bytes[9], hardwareSerialNum.bytes[10], hardwareSerialNum.bytes[11]);

  // Build strings
  makeVersionStr(&hardwareVersion, hardwareVersionStr);
  makeMajMinVersionStr(&firmwareVersion, firmwareVersionStr);

  return status;
}

status_t BlueBit::Messager_ResCodeToStatus(messageResponseCode_t resCode)
{
  status_t status = StatusOk;

  switch (resCode)
  {
    case messageResponseSuccess:
      // Stay at ok
      break;
    case messageResponseIdError:
      status = StatusMessageId;
      break;
    case messageResponseDataError:
      status = StatusMessageData;
      break;
    case messageResponseNotReceived:
      status = StatusMessageNotReceived;
      break;
    default:
      status = StatusCodePath;                                                                                                              // We should be covering every instance
      break;
	}

  return status;
}

status_t BlueBit::Messager_SendMessage(sendMessageArgs_t * args)
{
  status_t status = StatusOk;

  if(!args)
  {
    status = StatusNullParameter;
  }

  blockingResReceived = false;
  args->resCode       = messageResponseNotReceived;
  args->resData       = NULL;
  args->resLen        = 0;

  uint32_t startTime = millis();

  if(Status_IsOk(status))
  {
    sendMessageAsyncArgs_t asyncArgs =
    {
      .messageId   = args->messageId,
      .messageData = args->messageData,
      .dataLen     = args->dataLen,
      .resHandler  = blockingResHandler,
    };
    status = Messager_SendMessageAsync(&asyncArgs);                                                                                         // This will validate args
    status = Status_Preserve(status, Messager_FlushBuffer(args->timeoutMs));

    bool timedOut = false;
    while(!blockingResReceived && !timedOut)
    {
      callTickMethods();
      timedOut = SysTime_IsElapsed(startTime, args->timeoutMs);
    }

    if (Status_IsOk(status)) {
      if (timedOut && !blockingResReceived) {
      status = StatusComsSendTimeout;
        status = StatusComsSendTimeout;
      } else {
        args->resCode = blockingResCode;
        args->resData = blockingResData;
        args->resLen  = blockingResLen;
      }
    } else {

    }
  }

  return returnStatus(status, eSucWriteStatus);
}

status_t BlueBit::Messager_FlushBuffer(uint32_t timeoutMs)
{
  status_t status    = StatusOk;
  uint32_t startTime = millis();

  while (!SplitBuffer_IsEmpty(&messageQueue))
  {
    callTickMethods();
    if(SysTime_IsElapsed(startTime, timeoutMs))
    {
      // Reset queues
      SplitBuffer_Setup(&messageQueue, sbBuffer, sizeof(sbBuffer));
      resetResponseHandlers();  
      status = StatusComsSendTimeout;
      break;
    }
  }

  return returnStatus(status, eSucIoctlStatus);
}

void BlueBit::callTickMethods()
{
  ProtocolHal_Tick();
  ProtocolHandler_Tick();
  Messager_Tick();
}


status_t BlueBit::Messager_SendMessageAsync(sendMessageAsyncArgs_t * args)
{
  status_t status = StatusOk;

  if(args->dataLen > MESSAGE_MAX_DATA_LEN)
	{
    status = StatusBufferLength;
	}
  else if((args->dataLen != 0) && !args->messageData)
  {
    status = StatusNullParameter;
  }

  if(Status_IsOk(status))
  {
    status = responseHandlersEnqueue(args->resHandler);
    if(Status_IsError(status))
    {
      // Reset queues
      SplitBuffer_Setup(&messageQueue, sbBuffer, sizeof(sbBuffer));
      resetResponseHandlers();
      status = StatusCodePath;                                                                                                              // This is exceptional -- the code needs to be addressed if it happens
    }
    status = Status_Preserve(status, queueMessage(args->messageId, args->messageData, args->dataLen));
  }

    return returnStatus(status, eSucWriteStatus);
}

status_t BlueBit::responseHandlersEnqueue(responseHandler_t handler)
{
  status_t status = StatusOk;

  if(rhTail == SPLIT_BUFFER_MAX_ENTRIES)
  {
    if(rhHead == 0)
    {
      status = StatusBufferFull;
    } else
    {
      resHandlersQueue[rhTail] = handler;
      rhTail = 0;
    }
  } else
  {
    if(rhHead == rhTail + 1)
    {
      status = StatusBufferFull;
    } else
    {
      resHandlersQueue[rhTail] = handler;
      rhTail++;
    }
  }

  return status;
}
	
status_t BlueBit::ProtocolHal_Init(bool onStartup)
{
  status_t status = StatusOk;

  if(BlueBits_IsEnabled())
  {
    if(onStartup)
    {
      if(Status_IsOk(status))
      {
        //pinMode(_BlueBitEnablePin, OUTPUT);                                                                                                 // Sets up GPIO output pin to NRF52
        status = StatusOk;
      }
      if(Status_IsOk(status))
      {
        //pinMode(_BlueBitFlowCtrlPin, INPUT);                                                                                                //  Sets up GPIO input from NRF52
        status = StatusOk;
      }
    }
    if(Status_IsOk(status))
    {
      HAL_GPIO_WritePin((GPIO_TypeDef*)_BlueBitEnablePin->port, _BlueBitEnablePin->pin, (GPIO_PinState)1);

      //digitalWrite(_BlueBitEnablePin, HIGH);                                                                                                // Enable I2C communication
      status = StatusOk;
    }

    if(Status_IsOk(status))
    {
      writeState      = transferStateIdle;
      readState       = transferStateIdle;
      packetPending   = false;
      responsePending = false;
      gpioState       = indicationPinStatus();
      hasPacket       = false;
      hasResponse     = false;
    }
  }

  return returnStatus(status, eSucInitStatus);
}

status_t BlueBit::ProtocolHandler_Init()
{
  status_t status = StatusOk;

  if(Status_IsOk(status))
  {
    clearMessageDelay();
    state = ProtocolStateIdle;
  }

  return returnStatus(status, eSucInitStatus);
}

void BlueBit::clearMessageDelay()
{
  messageDelayStart    = 0;
  messageDelayDuration = 0;
}

status_t BlueBit::Messager_Init()
{
  status_t status = StatusOk;

  if(Status_IsOk(status))
  {
    status = SplitBuffer_Setup(&messageQueue, sbBuffer, sizeof(sbBuffer));
  }

  if(Status_IsOk(status))
  {
    resetResponseHandlers();
    messageHandlerRoot.next = NULL;                                                                                                         // Clear handlers
  }

  return returnStatus(status, eSucInitStatus);
}

void BlueBit::resetResponseHandlers()
{
  for(int i=0; i<(SPLIT_BUFFER_MAX_ENTRIES + 1); i++)
  {
    resHandlersQueue[i] = NULL;
  }
  rhHead = 0;
  rhTail = 0;
}

status_t BlueBit::SplitBuffer_Setup(splitBuffer_t * sb, uint8_t * bufferMem, size_t len)
{
  status_t status = StatusOk;

  if(!sb || !bufferMem)
  {
    status = StatusNullParameter;
  }
  else if(len < 2)
  {
    status = StatusBufferLength;
  }

  sb->buffer    = bufferMem;
  sb->bufferLen = len;
  sb->splitLen  = len / 2;

  sb->near.buffer = sb->buffer;
  sb->near.head   = 0;
  tailsClear(sb->near.tails);

  sb->far.buffer = &(sb->buffer[sb->splitLen]);
  sb->far.head   = 0;
  tailsClear(sb->far.tails);

  sb->write = &sb->near;
  sb->read  = &sb->near;

  return returnStatus(status, eSucIoctlStatus);
}

void BlueBit::tailsClear(uint16_t * tails)
{
  memset(tails, 0, sizeof(uint16_t) * SBMEMBER_MAX_ENTRIES);
}


status_t BlueBit::BlueBits_Init()
{
  status_t status = StatusOk;

  if(Status_IsOk(status))
  {
    if(BlueBits_IsEnabled())
    {
//      if(SetupMode)
//      {
//        Serial.println("Requesting 'Who Am I?' from BlueBit...");
//      }
      status = tryWhoami(WHOAMI_RETRY_TIMEOUT);
      if(Status_IsOk(status))
      {
//        if(SetupMode)
//        {
//          Serial.println("Sending BLE config to BlueBit...");
//        }
        status = sendConfig();
      }
      if(Status_IsOk(status))
      {
//        if(SetupMode)
//        {
//          Serial.println("Sending Snoopy power state to BlueBit...");
//        }
        status = BlueBits_SendPowerState(publicStateAwake);
      }
      if(Status_IsOk(status))
      {
//        if(SetupMode)
//        {
//          Serial.println("Sending Snoopy board info to BlueBit..."); Serial.println("");
//        }
        status = sendSetResbitInfo();
      }
    }
  }

  return returnStatus(status, eSucInitStatus);
}

status_t BlueBit::sendConfig()
{
  status_t status = StatusOk;

  for(int i=0; i<(sizeof(bleConfigVariables)/sizeof(*bleConfigVariables)); i++)
  {
    // Populate message data
    assert(bleConfigVariables[i].configDataLen <= CONFIG_DATA_MAX_SIZE);
    size_t configIdSize = sizeof(bleConfigVariables[i].id);

    uint8_t messageData[configIdSize + CONFIG_DATA_MAX_SIZE];

    memcpy(messageData, &bleConfigVariables[i].id, configIdSize);
    if(Status_IsOk(status))
    {
      status = Config_Ioctl(bleConfigVariables[i].configIoctlCode, messageData + configIdSize);
    }
    if(Status_IsOk(status))
    {
      sendMessageArgs_t args;

      args.messageId   = CONFIG_MESSAGE_ID;
      args.messageData = messageData;
      args.dataLen     = configIdSize + bleConfigVariables[i].configDataLen;
      args.timeoutMs   = SEND_BLOCKING_TIMEOUT;
      status           = Messager_SendMessage(&args);

      // Validate message success
      if(Status_IsOk(status))
      {
        status = Messager_ResCodeToStatus(args.resCode);
      }
      
      // Validate config variable update success
      if(Status_IsOk(status))
      {
        status = parseConfigResponse(args.resData, args.resLen, bleConfigVariables[i].id);
      }
    }
  }
    
  return status;
}

status_t BlueBit::parseConfigResponse(uint8_t *response, size_t len, bleConfigIds_t id)
{
  status_t status = StatusOk;
  uint8_t  stringBuff[80];
  uint8_t  configResponseCode = 0;
  
  if(sizeof(configResponseCode) == len)
  {
    memcpy(&configResponseCode, response, len);
    if(bleConfigResponsesSuccess != configResponseCode)
    {
//      if(SetupMode)
//      {
//        Serial.print("Bluebits sent config variable response code: "); Serial.print(configResponseCode);
//        Serial.print("on config ID: "); Serial.println(id);
//      }
      status = StatusSendConfig;
    }
  } else
  {
//    if(SetupMode)
//    {
//      Serial.print("Bluebits sent config variable bad response length "); Serial.print(len);
//      Serial.print("on config ID: "); Serial.println(id);
//    }
    status = StatusSendConfig;
  }
    
    return status;
}

status_t BlueBit::Config_Ioctl(configIoctl_t ioctlCode, uint8_t* outValue)
{
  status_t status = StatusOk;

  switch(ioctlCode)
  {
    case configIoctlGetBleAdvertOnTime:
      memcpy(outValue,&bleAdvertOnTime,sizeof(uint16_t));
      break;
    case configIoctlGetBleAdvertOffTimeMin:
      memcpy(outValue,&bleAdvertOffTimeMin,sizeof(uint16_t));
      break;
    case configIoctlGetBleAdvertOffTimeMax:
      memcpy(outValue,&bleAdvertOffTimeMax,sizeof(uint16_t));
      break;
    case configIoctlGetBleAlwaysAdvertise:
      memcpy(outValue,&bleAlwaysAdvertise,sizeof(uint8_t));
      break;
    case configIoctlGetBleAdvertInterval:
      memcpy(outValue,&bleAdvertInterval,sizeof(uint16_t));
      break;
    default:
      break;
  }

  return status;
}

bool BlueBit::indicationPinStatus()
{
	return HAL_GPIO_ReadPin((GPIO_TypeDef*)_BlueBitFlowCtrlPin->port, _BlueBitFlowCtrlPin->pin);
}

status_t BlueBit::ProtocolHandler_Tick()
{
  status_t status = StatusOk;

  switch(state)
	{
    case ProtocolStateIdle:
      status = handleIdleTick();
      break;
    case ProtocolStateReceive:
      status = handleReceiveTick();
      break;
    case ProtocolStateRespond:
      status = handleRespondTick();
      break;
    case ProtocolStateSend:
      status = handleSendTick();
      break;
    case ProtocolStateGetResponse:
      status = handleGetResponseTick();
      break;
    default:
      status = StatusCodePath;
      break;
  }

  return returnStatus(status, eSucIoctlStatus);
}

status_t BlueBit::handleIdleTick()
{
  status_t status = StatusOk;

  if(checkMessageDelay())
  {
    if(ProtocolHal_HasPacket())
    {
      resetMessageData(&receiveBuffer);
      state        = ProtocolStateReceive;
      timeoutStart = millis();
    } else if(sendInProgress)
    {
      status       = ProtocolHal_WritePacket(&sendPacket);
      state        = ProtocolStateSend;
      timeoutStart = millis();
    }
  }

  return status;
}

bool BlueBit::checkMessageDelay()
{
  return SysTime_IsElapsed(messageDelayStart, messageDelayDuration);
}

bool BlueBit::SysTime_IsElapsed(uint32_t start, uint32_t duration)
{
  return (SysTime_GetElapsed(start) >= duration);
}

uint32_t BlueBit::SysTime_GetElapsed(uint32_t start)
{
  return millis() - start;
}

bool BlueBit::ProtocolHal_HasPacket() 
{
  return hasPacket;
}

void BlueBit::resetMessageData(messageData_t * message)
{
  message->currentPacketNum = -1;
  message->tailIndex        = 0;
  message->lastTailIndex    = 0;
}

status_t BlueBit::ProtocolHal_WritePacket(packet_t * packet)
{
  status_t status = StatusOk;

  size_t len = PACKET_HEADER_LEN + packet->dataLen;
  status = i2cWrite(BB_I2C_ADDDR, packet->bytes, len);

  if(Status_IsOk(status))
  {
    responsePending = true;
  }

  return returnStatus(status, eSucWriteStatus);
}

status_t BlueBit::handleReceiveTick()
{
  status_t status = StatusOk;

  // Wait for full packet
  if(ProtocolHal_HasPacket())
  {
    status = handlePacketReceive();

    responseCode    = Packet_GetResponseCode(status);
    responseCodeSet = true;
    state           = ProtocolStateRespond;
    timeoutStart    = millis();
  } else if(checkTimeout())
  {
    resetAndReturnToIdle();
    status = StatusComsReceiveTimeout;
  }

  return status;
}

bool BlueBit::checkTimeout()
{
  return SysTime_IsElapsed(timeoutStart, COMS_TIMEOUT_MS);
}

uint8_t BlueBit::Packet_GetResponseCode(status_t status)
{
  uint8_t resCode = 0;

  switch(status)
  {
    case StatusOk:
      resCode = RES_CODE_SUCCESS;
      break;
    case StatusComsCRC:
      resCode = RES_CODE_CRC;
      break;
    case StatusComsInvalidNumPackets:
      resCode = RES_CODE_INVALID_NUM_PACKETS;
      break;
    case StatusComsInvalidPacketNum:
      resCode = RES_CODE_INVALID_PACKET_NUM;
      break;
    case StatusComsInvalidDataLen:
      resCode = RES_CODE_INVALID_DATA_LEN;
      break;
    case StatusComsPacketOrder:
      resCode = RES_CODE_PACKET_ORDER;
      break;
    case StatusComsDataLenMismatch:
      resCode = RES_CODE_DATA_LEN_MISMATCH;
      break;
    default:
      resCode = RES_CODE_UNKNOWN;
    break;
  }

  return resCode;
}

status_t BlueBit::Packet_GenerateResponse(response_t * dest, uint8_t responseCode)
{
  status_t status = StatusOk;

  if(dest == NULL)
  {
    status = StatusNullParameter;
  }

  if(Status_IsOk(status))
  {
    dest->code = responseCode;
    dest->crc  = CRC_SEED;
    status     = Crc_Calc(&dest->crc, &dest->code, 1);
  }

  return returnStatus(status, eSucIoctlStatus);
}

status_t BlueBit::handlePacketReceive()
{
  status_t status  = StatusOk;
  size_t packetLen = 0;

  status = ProtocolHal_GetPacket(&receivePacket, &packetLen);

  // Get packet header info
  int lastPacketNum = receiveBuffer.currentPacketNum;

  if(Status_IsOk(status))
  {
    status = Packet_ParseHeader(&receivePacket, packetLen);
  }
  if(Status_IsOk(status))
  {
    receiveBuffer.numPackets       = receivePacket.numPackets;                                                                              // Copy packet info to message data
    receiveBuffer.currentPacketNum = receivePacket.packetNum;
    if(lastPacketNum == receiveBuffer.currentPacketNum)                                                                                     // Validate packet order
    {
      receiveBuffer.tailIndex = receiveBuffer.lastTailIndex;
    } else if((lastPacketNum + 1) != receiveBuffer.currentPacketNum)
    {
      status = StatusComsPacketOrder;
    }
  }

  // Get packet body
  if(Status_IsOk(status))
  {
    status = Packet_ParseBody(&receiveBuffer.contents[receiveBuffer.tailIndex], MESSAGE_MAX_LEN - receiveBuffer.tailIndex, &receivePacket);
  }

  // Update message info
  if(Status_IsOk(status))
  {
    receiveBuffer.tailIndex += receivePacket.dataLen;
  }

  return status;
}

status_t BlueBit::Packet_ParseHeader(const packet_t * src, size_t len)
{
  status_t status = StatusOk;

  // Input validation
  if(src == NULL)
  {
    status = StatusNullParameter;
  }

  // Validate CRC
  if(Status_IsOk(status))
  {
    uint16_t        crc             = CRC_SEED;
    const uint8_t * crcStartAddress = src->bytes + PACKET_CRC_OFFSET;

    status = Crc_Calc(&crc, crcStartAddress, len - PACKET_CRC_OFFSET);
    if(Status_IsOk(status))
    {
      if(crc != src->crc)
      {
        status = StatusComsCRC;
      }
    }
  }

  // Validate number of packets
  if(Status_IsOk(status))
  {
    if(0 == src->numPackets)
    {
      status = StatusComsInvalidNumPackets;
    }
  }

  // Validate packet num
  if(Status_IsOk(status))
  {
    if(src->packetNum >= src->numPackets)
    {
      status = StatusComsInvalidPacketNum;
    }
  }
 
  // Validate data length
  if(Status_IsOk(status))
  {
    size_t expectedLen = len - PACKET_HEADER_LEN;
    if(0 == src->dataLen)
    {
      status = StatusComsInvalidDataLen;
    } else if(expectedLen != src->dataLen)
    {
      status = StatusComsDataLenMismatch;
    }
  }

  return returnStatus(status, eSucIoctlStatus);
}

status_t BlueBit::Packet_ParseBody(uint8_t * dest, size_t maxLen, const packet_t * src)
{
  status_t status = StatusOk;

  // Input validation
  if((dest == NULL) || (src == NULL))
  {
    status = StatusNullParameter;
  } else if(maxLen < 1)
  {
    status = StatusBufferLength;
  }

  // Make sure destination buffer has enough space
  if(Status_IsOk(status))
  {
    if(src->dataLen > maxLen)
    {
      status = StatusBufferLength;
    }
  }

  // Copy data to destination buffer
  if(Status_IsOk(status))
  {
    memcpy(dest, src->data, (size_t)src->dataLen);
  }

  return returnStatus(status, eSucIoctlStatus);
}

status_t BlueBit::Crc_Calc(uint16_t * crc, const uint8_t * values, size_t len)
{
  status_t status = StatusOk;

  if(len < 1)
  {
    status = StatusBufferLength;
  }
  if(crc == NULL || values == NULL)
  {
    status = StatusNullParameter;
  }

  if(Status_IsOk(status))
  {
    int            j;
    uint16_t       tempLen = len;
    const uint8_t* tempPtr = values;

    while(tempLen--)
    {
      *crc ^= (uint16_t)*tempPtr++;
      for(j=0; j<CRC_SHIFTS_NUM; j++)
      {
        if(*crc & 0x01)
        {
          *crc >>= 1;
          *crc ^= CRC_POLYNOMIAL;
        } else
        {
          *crc >>= 1;
        }
      }
    }
  }

  return returnStatus(status, eSucIoctlStatus);
}

status_t BlueBit::ProtocolHal_GetPacket(packet_t * out, size_t * outLen)
{
  status_t status = StatusOk;

  // Input validation
  if(out == NULL)
  {
    status = StatusNullParameter;
  }
  if(Status_IsOk(status))
  {
    *outLen = PACKET_HEADER_LEN + rxPacket.dataLen;
    memcpy(out->bytes, rxPacket.bytes, *outLen);
    hasPacket = false;
  }

  return returnStatus(status, eSucReadStatus);
}

status_t BlueBit::handleRespondTick()
{
  status_t status = StatusOk;

  if(responseCodeSet)
  {
    status = Packet_GenerateResponse(&response, responseCode);

    if(Status_IsOk(status))
    {
      status = ProtocolHal_WriteResponse(&response);
    }
    responseCodeSet = false;
  } else if(ProtocolHal_IsWriteDone())
  {
    // Respond finished
    if(receiveBuffer.numPackets == (receiveBuffer.currentPacketNum + 1))
    {
      // Message done
      state  = ProtocolStateIdle;
      status = Messager_HandleMessage(&receiveBuffer.contents[0], receiveBuffer.tailIndex);
      setMessageDelay(COMS_MESSAGE_INTERVAL);
    } else
    {
      state        = ProtocolStateReceive;
      timeoutStart = millis();
    }
  } else if(checkTimeout())
  {
    resetAndReturnToIdle();
    status = StatusComsReceiveTimeout;
  }

  return status;
}

void BlueBit::setMessageDelay(uint32_t delayMs)
{
  messageDelayStart    = millis();
  messageDelayDuration = delayMs;
}

status_t BlueBit::Messager_RegisterHandlers(messageHandlerList_t* handlers) {
  if (handlers == NULL) return StatusNullParameter;

  messageHandlerList_t* ptr = &messageHandlerRoot;

  while (ptr->next) {
    if (ptr = handlers) return StatusAlreadyLinked;
    ptr = ptr->next;
  }

  ptr->next = handlers;

  return StatusOk;
}

status_t BlueBit::Messager_HandleMessage(uint8_t * buffer, size_t len)
{
  status_t status = StatusOk;

  //Serial.println("Got Message");

  if(NULL == buffer)
  {
    status = StatusNullParameter;
  } else if(len < MESSAGE_DATA_OFFSET)
  {
    status = StatusBufferLength;
  }

  if(Status_IsOk(status))
  {
    // Determine message id, data
    uint16_t * messageIdField = (uint16_t *)&buffer[0];
    uint8_t *  messageDataField;
    size_t     dataLen;

    if(len > MESSAGE_DATA_OFFSET)
    {
      messageDataField = &buffer[MESSAGE_DATA_OFFSET];
      dataLen          = len - MESSAGE_DATA_OFFSET;
    } else {
      messageDataField = NULL;
      dataLen          = 0;
    }
    if(responseBitPresent(*messageIdField))
    {
      status = parseResponse(*messageIdField, messageDataField, dataLen);
    } else {
      status = parseMessage(*messageIdField, messageDataField, dataLen);
    }
  }

  return returnStatus(status, eSucReadStatus);
}

status_t BlueBit::callMessageHandler(uint16_t messageId, uint8_t * data, size_t len)
{
  status_t             status = StatusMessageId;                                                                                                        // Will mark as OK when we find it
  uint8_t              responseBuffer[MESSAGE_MAX_DATA_LEN];                                                                                // Response data
  messageHandlerArgs_t args;

  args.messageData = data;
  args.dataLen      = len;
  args.resCode      = messageResponseSuccess;                                                                                               // Default
  args.resBuffer    = responseBuffer + MESSAGE_RES_CODE_LEN;
  args.resBufferLen = MESSAGE_MAX_DATA_LEN - MESSAGE_RES_CODE_LEN;
  args.bytesWritten = 0;                                                                                                                    // Default

  // Traverse list
  messageHandlerList_t * current = &messageHandlerRoot;
  while(current)
  {
    messageHandlerReg_t * handlers = current->handlers;

    // Traverse array until found, or we hit null entry
    for(int i=0; handlers[i].handler; i++)
    {
      if(handlers[i].messageId == messageId)
      {
        status = handlers[i].handler(&args);
        break;
      }
    }

    // If found, exit, else proceed
    if(StatusMessageId != status)
    {
      break;
    } else
    {
      current = current->next;
    }
  }

  if(StatusMessageId == status)
  {
    uint8_t messageData = messageResponseIdError;

    status = Status_Preserve(status, queueMessage(messageId | RESPONSE_FLAG, &messageData, 1));
  } else
  {
    responseBuffer[0] = (uint8_t)args.resCode;
    status            = Status_Preserve(status, 
    queueMessage(messageId | RESPONSE_FLAG, responseBuffer, args.bytesWritten + 1));
  }

  return status;
}

status_t BlueBit::queueMessage(uint16_t messageId, const uint8_t * data, size_t len)
{
  status_t status = StatusOk;
  uint8_t  message[MESSAGE_MAX_LEN];

  // Prepare contents
  *((uint16_t *)message) = messageId;
  if(len != 0)
  {
    memcpy(&message[MESSAGE_DATA_OFFSET], data, len);
  }
  status = SplitBuffer_Enqueue(&messageQueue, message, len + MESSAGE_DATA_OFFSET);

  return status;
}

status_t BlueBit::SplitBuffer_Enqueue(splitBuffer_t * sb, uint8_t * dataIn, size_t len)
{
  status_t status = StatusOk;

  // Input validation
  if(!sb || !dataIn)
  {
    status = StatusNullParameter;
  } else if(len < 1)
  {
    status = StatusBufferLength;
  }

  uint16_t lastTail = 0;

  if(Status_IsOk(status))
  {
    status = tailsPushBack(sb->write->tails, len, sb->splitLen, &lastTail);
  }
  if(StatusBufferFull == status)
  {
    if(sb->write == sb->read)
    {
      // Attempt to place in other buffer
      splitMember_t * emptyBuff = (sb->write == &sb->near) ? &sb->far : &sb->near;
      status = tailsPushBack(emptyBuff->tails, len, sb->splitLen, &lastTail);
      if(Status_IsOk(status))
      {
        sb->write = emptyBuff;                                                                                                              // Op was successful, switch write buffer
      }
    }
  }
  if(Status_IsOk(status))
  {
    memcpy(&sb->write->buffer[lastTail], dataIn, len);
  }

  return returnStatus(status, eSucIoctlStatus);
}

status_t BlueBit::tailsPushBack(uint16_t * tails, size_t entryLen, size_t splitLen, uint16_t * lastTail)
{
  status_t status = StatusOk;
  bool     pushed = false;

  if(tails[0] == 0)
  {
    if(entryLen <= splitLen)
    {
      tails[0]  = entryLen;
      *lastTail = 0;
      pushed    = true;
    } else
    {
      status = StatusBufferFull;
    }
  }
  if(Status_IsOk(status) && !pushed)
  {
    // Look for empty read end index
    for(int i=0; i<(SBMEMBER_MAX_ENTRIES - 1); i++)
    {
      if(tails[i + 1] == 0)
      {
        uint16_t newIndex = tails[i] + entryLen;

        if(newIndex <= splitLen)
        {
          tails[i + 1] = newIndex;
          *lastTail = tails[i];
          pushed = true;
        }
        break;
      }
    }
    if(!pushed)
    {
      status = StatusBufferFull;
    }
  }

  return status;
}

status_t BlueBit::parseMessage(uint16_t messageId, uint8_t * data, size_t len)
{
  status_t status = StatusOk;

  status = callMessageHandler(messageId, data, len);
  return status;
}

status_t BlueBit::parseResponse(uint16_t messageId, uint8_t * data, size_t len)
{
  status_t          status = StatusOk;
  responseHandler_t responseHandler;

  status = responseHandlersDequeue(&responseHandler);
  if(Status_IsOk(status) && responseHandler)
  {
    if(len < MESSAGE_RES_CODE_LEN)
    {
      status = StatusBufferLength;
    } else
    {
      responseHandlerArgs_t args =
      {
        .resCode = (messageResponseCode_t)*data,                                                                                            // This won't scale if we make res code two bytes, but enum has no guaranteed size
        .data    = NULL,
        .len     = 0,
      };
      if(len > MESSAGE_RES_CODE_LEN)
      {
        args.data = data + MESSAGE_RES_CODE_LEN;
        args.len  = len - MESSAGE_RES_CODE_LEN;
      }
      status = responseHandler(&args);
    }
  } else
  {
    status = StatusCodePath;                                                                                                                // Should have validated response handler on send message call
  }

  return status;
}

status_t BlueBit::responseHandlersDequeue(responseHandler_t * handler)
{
  status_t status = StatusOk;

  if(rhHead == rhTail)
  {
    status = StatusBufferEmpty;
  }
  if(Status_IsOk(status))
  {
    *handler = resHandlersQueue[rhHead];
    if(rhHead == SPLIT_BUFFER_MAX_ENTRIES)
    {
      rhHead = 0;
    } else
    {
      rhHead++;
    }
  }

  return status;
}

bool BlueBit::responseBitPresent(uint16_t messageId)
{
  return ((messageId & RESPONSE_FLAG) == RESPONSE_FLAG);
}

bool BlueBit::ProtocolHal_IsWriteDone()
{
  return writeState == transferStateDone;
}

status_t BlueBit::ProtocolHal_WriteResponse(response_t * response)
{
  status_t status;
  status = i2cWrite(BB_I2C_ADDDR, response->bytes, RESPONSE_LEN);

  return returnStatus(status, eSucWriteStatus);
}

void BlueBit::resetAndReturnToIdle()
{
  ProtocolHal_Reset();
  clearMessageDelay();
  state          = ProtocolStateIdle;
  sendInProgress = false;
}

void BlueBit::ProtocolHal_Reset()
{
  // Reset internal state
  writeState      = transferStateIdle;
  readState       = transferStateIdle;
  packetPending   = false;
  responsePending = false;
  gpioState       = indicationPinStatus();
  hasPacket       = false;
  hasResponse     = false;
}

status_t BlueBit::handleSendTick()
{
  status_t status = StatusOk;

  if(ProtocolHal_IsWriteDone())
	{
    timeoutStart = millis();
    state = ProtocolStateGetResponse;
  } else if(checkTimeout())
	{
    // TODO: Message done callback
    resetAndReturnToIdle();
    status = StatusComsSendTimeout;
  }

  return status;
}

status_t BlueBit::handleGetResponseTick()
{
  status_t status = StatusOk;

  if(ProtocolHal_HasResponse())
	{
    status = handleResponseReceive();
    if(Status_IsOk(status))
    {
      if(sendBuffer.numPackets > (sendBuffer.currentPacketNum + 1))
      {
        status = generatePacket(&sendBuffer, &sendPacket);
        if(Status_IsOk(status))
        {
          ProtocolHal_WritePacket(&sendPacket);
          timeoutStart = millis();
          state        = ProtocolStateSend;
        } else
				{
          resetAndReturnToIdle();
          setMessageDelay(COMS_TIMEOUT_MS);
        }
      } else
		  {
        resetAndReturnToIdle();
        setMessageDelay(COMS_MESSAGE_INTERVAL);
      }
    } else if(StatusComsResponseError == status)
    {
      resetAndReturnToIdle();
      setMessageDelay(COMS_TIMEOUT_MS);
    } else
		{
      // Check retry
      if(writeRetryCount == COMS_RETRY_LIMIT)
      {
        resetAndReturnToIdle();
        setMessageDelay(COMS_TIMEOUT_MS);
      } else
			{
        ProtocolHal_WritePacket(&sendPacket);
        writeRetryCount++;
        timeoutStart = millis();
        state        = ProtocolStateSend;
      }
    }
  } else if(checkTimeout())
	{
    resetAndReturnToIdle();
    status = StatusComsSendTimeout;
  }

  return status;
}

status_t BlueBit::generatePacket(messageData_t * message, packet_t * packet)
{
  status_t status   = StatusOk;
  size_t  packetLen = message->tailIndex - message->lastTailIndex;

  packetLen = (packetLen > PACKET_MAX_DATA_LEN) ? PACKET_MAX_DATA_LEN : packetLen;
  message->currentPacketNum++;
  status = Packet_Pack(packet, &message->contents[message->lastTailIndex], packetLen, message->numPackets, message->currentPacketNum);
  message->lastTailIndex += packetLen;                                                                                                      // Update tail

  return status;
}

status_t BlueBit::Packet_Pack(packet_t * dest, const uint8_t * src, size_t len, int numPackets, int packetNum)
{
  status_t status = StatusOk;

  // Input validation
  if((dest == NULL) || (src == NULL))
  {
    status = StatusNullParameter;
  }
  if(len < 1)
  {
    status = StatusBufferLength;
  }
  if(Status_IsOk(status))
  {
    dest->numPackets = numPackets;
    dest->packetNum = packetNum;
    dest->dataLen = len;
    memcpy(dest->data, src, len);
    dest->crc = CRC_SEED;

    uint8_t * crcStartAddress = dest->bytes + PACKET_CRC_OFFSET;

    status = Crc_Calc(&dest->crc, crcStartAddress, len + PACKET_HEADER_LEN - PACKET_CRC_OFFSET);
  }

  return returnStatus(status, eSucIoctlStatus);
}

status_t BlueBit::handleResponseReceive()
{
  status_t status = StatusOk;

  status = ProtocolHal_GetResponse(&response);
  if(Status_IsOk(status))
  {
    status = Packet_ParseResponse(&response);
  }

  return status;
}

status_t BlueBit::ProtocolHal_GetResponse(response_t * out)
{
  status_t status = StatusOk;

  // Input validation
  if(out == NULL)
  {
    status = StatusNullParameter;
  }
  if(Status_IsOk(status))
  {
    memcpy(out->bytes, rxResponse.bytes, RESPONSE_LEN);
    hasResponse = false;
  }

  return returnStatus(status, eSucReadStatus);
}

status_t BlueBit::Packet_ParseResponse(const response_t * res)
{
  status_t status = StatusOk;
  uint16_t crc    = CRC_SEED;

  if(res == NULL)
  {
    status = StatusNullParameter;
  }
  if(Status_IsOk(status))
  {
    status = Crc_Calc(&crc, &res->code, 1);
  }
  if(Status_IsOk(status))
  {
    if(crc != res->crc)
    {
      status = StatusComsResponseError;
    }
  }
  if(Status_IsOk(status))
  {
    status = statusFromResCode(res->code);
  }

  return returnStatus(status, eSucIoctlStatus);
}

status_t BlueBit::statusFromResCode(uint8_t resCode)
{
  status_t status = StatusOk;

  switch (resCode)
  {
    case RES_CODE_SUCCESS:
      status = StatusOk;
      break;
    case RES_CODE_CRC:
      status = StatusComsCRC;
      break;
    case RES_CODE_INVALID_NUM_PACKETS:
      status = StatusComsInvalidNumPackets;
      break;
    case RES_CODE_INVALID_PACKET_NUM:
      status = StatusComsInvalidPacketNum;
      break;
    case RES_CODE_INVALID_DATA_LEN:
      status = StatusComsInvalidDataLen;
      break;
    case RES_CODE_PACKET_ORDER:
      status = StatusComsPacketOrder;
      break;
    case RES_CODE_DATA_LEN_MISMATCH:
      status = StatusComsDataLenMismatch;
      break;
    default:
      status = StatusComsUnknown;
      break;
  }

  return status;
}

bool BlueBit::ProtocolHal_HasResponse()
{
  return hasResponse;
}

status_t BlueBit::Messager_Tick()
{
  status_t status = StatusOk;

  if(!SplitBuffer_IsEmpty(&messageQueue) && ProtocolHandler_IsSendReady())
  {
    uint8_t * headPtr;
    size_t    headSize;

    status = SplitBuffer_GetHead(&messageQueue, &headPtr, &headSize);
    if(Status_IsOk(status))
    {
      status = ProtocolHandler_SendMessage(headPtr, headSize);
      SplitBuffer_FreeHead(&messageQueue);
    }
  }

  return returnStatus(status, eSucIoctlStatus);
}

bool BlueBit::SplitBuffer_IsEmpty(splitBuffer_t * sb)
{
  return (sb->read == sb->write) && (sb->read->tails[0] == 0);
}

bool BlueBit::ProtocolHandler_IsSendReady()
{
  return !sendInProgress;
}

status_t BlueBit::SplitBuffer_GetHead(splitBuffer_t * sb, uint8_t ** headPtr, size_t * headSize)
{
  status_t status = StatusOk;

  // Input validation
  if(!sb || !headPtr || !headSize)
  {
    status = StatusNullParameter;
  }

  int32_t entryLen;

  if(Status_IsOk(status))
  {
    if(SplitBuffer_IsEmpty(sb))
    {
      *headSize = 0;
      status    = StatusBufferEmpty;
    } else
    {
      if(sb->read->tails[0] == 0)
      {
        sb->read = (sb->read == &sb->near) ? &sb->far : &sb->near;
      }
      entryLen = sb->read->tails[0] - sb->read->head;                                                                                       // Put it in large, signed container so we can check for negatives
      if(entryLen < 0)
      {
        status = StatusCodePath;                                                                                                            // This is an error in the split buffer logic
      }
    }
  }

  if(Status_IsOk(status))
  {
    *headPtr = &sb->read->buffer[sb->read->head];
    *headSize = entryLen;
  }

  return returnStatus(status, eSucIoctlStatus);
}

status_t BlueBit::ProtocolHandler_SendMessage(const uint8_t * buff, size_t len)
{
  status_t status = StatusOk;

  // Input validation
  if(buff == NULL)
  {
    status = StatusNullParameter;
  } else if((len < 1) || (len > MESSAGE_MAX_LEN))
  {
    status = StatusBufferLength;
  }
  if(Status_IsOk(status))
  {
    // Setup message data
    resetMessageData(&sendBuffer);
    sendBuffer.numPackets = (len / PACKET_MAX_DATA_LEN) + 1;
    sendBuffer.tailIndex = len;                                                                                                             // For send data, this will just be used to mark the end of the data
    memcpy(sendBuffer.contents, buff, len);
    status = generatePacket(&sendBuffer, &sendPacket);
  }
  if(Status_IsOk(status))
  {
    sendInProgress  = true;
    writeRetryCount = 0;
  }

  return returnStatus(status, eSucWriteStatus);
}

status_t BlueBit::SplitBuffer_FreeHead(splitBuffer_t * sb)
{
  status_t status = StatusOk;

  // Input validation
  if(!sb)
  {
    status = StatusNullParameter;
  }
  if(Status_IsOk(status))
  {
    if(SplitBuffer_IsEmpty(sb))
    {
      status = StatusBufferEmpty;
    } else
    {
      uint16_t tailIndex = tailsPopFront(sb->read->tails);
      if(tailIndex == 0)
      {
        sb->read  = (sb->read == &sb->near) ? &sb->far : &sb->near;
        tailIndex = tailsPopFront(sb->read->tails);
      }

      // Move head
      if(sb->read->tails[0] == 0)
      {
        sb->read->head = 0;                                                                                                                 // Empty
      } else
      {
        sb->read->head = tailIndex;
      }
    }
  }

  return returnStatus(status, eSucIoctlStatus);
}

uint16_t BlueBit::tailsPopFront(uint16_t * tails)
{
  uint16_t ret = tails[0];

  // Shift left
  for(int i=0; (i<(SBMEMBER_MAX_ENTRIES - 1)) && (tails[i] != 0); i++)
  {
    tails[i] = tails[i + 1];
  }
  tails[SBMEMBER_MAX_ENTRIES - 1] = 0;                                                                                                      // Previous loop doesn't reach last element, and this is always 0 after pop..

  return ret;
}

status_t BlueBit::i2cRead(uint8_t address, uint8_t * buffer, uint8_t len)
{
  status_t status = StatusOk;

//  uint8_t i       = 0;
//  _twi->requestFrom(address, len);
//  while (_twi->available())
//  {
//    buffer[i] = _twi->read();
//    i++;
//  }

  uint16_t err = no_error;
  err = HAL_I2C_Master_Receive((I2C_HandleTypeDef *)_twi, address<<1, buffer, len, I2C_MAX_TIMEOUT);
  readState = transferStateDone;

  return returnStatus(status, eSucIoctlStatus);
}

status_t BlueBit::i2cWrite(uint8_t address, uint8_t * buffer, uint8_t len)
{
  status_t status = StatusOk;

//  _twi->beginTransmission(address);
//  for(uint8_t i=0; i < len; i++)
//  {
//    _twi->write((uint8_t)buffer[i]);
//  }
//  _twi->endTransmission();

  uint16_t err = no_error;
  err = HAL_I2C_Master_Transmit((I2C_HandleTypeDef *)_twi, address<<1, buffer, len, I2C_MAX_TIMEOUT);
  writeState = transferStateDone;

  return returnStatus(status, eSucIoctlStatus);
}
