/*
 * Copyright (c) 2020 The Pocter & Gamble Company, INC.  All rights reserved.
 *
 * This software in whole and in part is owned by The Pocter & Gamble Company, INC
 * and may not be sold, offered, excerpted, bartered, or in any way delivered
 * or made available to any third party without direct, explicit and written consent
 * of The Procter & Gamble Company or its assignees.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL THE
 * CONTRIBUTORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * WITH THE SOFTWARE.
 */

#undef USE_ARDUINO

#ifdef USE_ARDUINO
#include <Wire.h>
#include <assert.h>
#include "Config.h"
#else
#include <stdlib.h>
#include <stdint.h>
#endif

#include "byte_type_conv.h"

byte_type_conv::byte_type_conv()
{
}

void byte_type_conv::uint16_t_to_bytes(uint16_t temp, uint8_t * dest)                                // Function to decompose a uint16_t integer into bytes for storage
{
  union
  {
    uint16_t f;
    uint8_t comp[sizeof(uint16_t)];
  } u;

  u.f = temp;
  for (uint8_t i=0; i < sizeof(uint16_t); i++)
  {
    dest[i] = u.comp[i];
  }
}

void byte_type_conv::int16_t_to_bytes(int16_t temp, uint8_t * dest)                                  // Function to decompose a uint16_t integer into bytes for storage
{
  union
  {
    int16_t f;
    uint8_t comp[sizeof(uint16_t)];
  } u;

  u.f = temp;
  for (uint8_t i=0; i < sizeof(uint16_t); i++)
  {
    dest[i] = u.comp[i];
  }
}

void byte_type_conv::uint32_t_to_bytes(uint32_t temp, uint8_t * dest)                                // Function to decompose a uint132_t integer into bytes for storage
{
  union
  {
    uint32_t f;
    uint8_t comp[sizeof(uint32_t)];
  } u;

  u.f = temp;
  for (uint8_t i=0; i < sizeof(uint32_t); i++)
  {
    dest[i] = u.comp[i];
  }
}

void byte_type_conv::float_to_bytes(float temp, uint8_t * dest)                                      // Function to decompose an sp float into bytes for storage
{
  union
  {
    float f;
    uint8_t comp[sizeof(float)];
  } u;
  
  u.f = temp;
  for (uint8_t i=0; i < sizeof(float); i++)
  {
    dest[i] = u.comp[i];
  }
}

void byte_type_conv::float_to_int16_bytes(float temp, uint8_t * dest)                                // Function to round an sp float to an int16_t integer and decompose into bytes for storage
{
  union
  {
    uint16_t i;
    uint8_t comp[sizeof(uint16_t)];
  } u;
  
  u.i = (int16_t)(temp*50.0f);
  for (uint8_t i=0; i < sizeof(int16_t); i++)
  {
    dest[i] = u.comp[i];
  }
}

uint16_t byte_type_conv::bytes_to_uint16_t(uint8_t * temp)                                           // Function to reassemble a uint16_t integer from its stored component bytes
{
  union
  {
    uint8_t comp[sizeof(uint16_t)];
    uint16_t f;
  } u;

  u.comp[0] = temp[0];
  u.comp[1] = temp[1];
  return u.f;
}

int16_t byte_type_conv::bytes_to_int16_t(uint8_t * temp)                                             // Function to reassemble an int16_t integer from its stored component bytes
{
  union
  {
    uint8_t comp[sizeof(int16_t)];
    int16_t f;
  } u;

  u.comp[0] = temp[0];
  u.comp[1] = temp[1];
  return u.f;
}

uint32_t byte_type_conv::bytes_to_uint32_t(uint8_t * temp)                                           // Function to reassemble a uint32_t integer from its stored component bytes
{
  union
  {
    uint8_t comp[sizeof(uint32_t)];
    uint32_t f;
  } u;

  u.comp[0] = temp[0];
  u.comp[1] = temp[1];
  u.comp[2] = temp[2];
  u.comp[3] = temp[3];
  return u.f;
}

float byte_type_conv::bytes_to_float(uint8_t * temp)                                                 // Function to reassemble an sp float from its stored component bytes
{
  union
  {
    uint8_t comp[sizeof(float)];
    float f;
  } u;
  
  u.comp[0] = temp[0];
  u.comp[1] = temp[1];
  u.comp[2] = temp[2];
  u.comp[3] = temp[3];
  return u.f;
}
