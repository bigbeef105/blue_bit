/*
 * i2c_platform.h
 *
 *  Created on: Dec 12, 2020
 *      Author: shane
 */

#ifndef I2C_PLATFORM_H_
#define I2C_PLATFORM_H_

#include "platform.h"

#define I2C_DEFAULT_BUFFER_SIZE		64

typedef enum i2c_errors {
	no_error,
	timeout,
	incorrect_id
} I2C_ERROR_TYPE;

const static uint32_t I2C_MAX_TIMEOUT = 10000;

#endif /* I2C_PLATFORM_H_ */
