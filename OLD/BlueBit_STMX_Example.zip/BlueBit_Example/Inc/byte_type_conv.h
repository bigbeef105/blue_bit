/*
 * Copyright (c) 2020 The Pocter & Gamble Company, INC.  All rights reserved.
 *
 * This software in whole and in part is owned by The Pocter & Gamble Company, INC
 * and may not be sold, offered, excerpted, bartered, or in any way delivered
 * or made available to any third party without direct, explicit and written consent
 * of The Procter & Gamble Company or its assignees.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL THE
 * CONTRIBUTORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * WITH THE SOFTWARE.
 */

#ifndef byte_type_conv_h
#define byte_type_conv_h

class byte_type_conv
{
  public:
                  byte_type_conv();
  static void     uint16_t_to_bytes(uint16_t temp, uint8_t * dest);
  static void     int16_t_to_bytes(int16_t temp, uint8_t * dest);
  static void     uint32_t_to_bytes(uint32_t temp, uint8_t * dest);
  static void     float_to_bytes(float temp, uint8_t * dest);
  static void     float_to_int16_bytes(float temp, uint8_t * dest);
  static uint16_t bytes_to_uint16_t(uint8_t * temp);
  static int16_t  bytes_to_int16_t(uint8_t * temp);
  static uint32_t bytes_to_uint32_t(uint8_t * temp);
  static float    bytes_to_float(uint8_t * temp);
  private:
};

#endif // byte_type_conv_h
