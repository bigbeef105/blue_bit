/*
 * Copyright (c) 2020 The Pocter & Gamble Company, INC.  All rights reserved.
 *
 * This software in whole and in part is owned by The Pocter & Gamble Company, INC
 * and may not be sold, offered, excerpted, bartered, or in any way delivered
 * or made available to any third party without direct, explicit and written consent
 * of The Procter & Gamble Company or its assignees.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL THE
 * CONTRIBUTORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * WITH THE SOFTWARE.
 */

/*************************************************************************************************/
/*************                                                                     ***************/
/*************                            Configuration                            ***************/
/*************                                                                     ***************/
/*************************************************************************************************/

//#include "LSM6DSM.h"
//#include "BMA400.h"

// USB serial speed in setup mode (Uncomment one only)
#define USB_SERIAL_BAUD                 115200
//#define USB_SERIAL_BAUD                 230400

// BLE enable/disable (Uncomment one only)
#define BLUEBIT_ENABLED                 true
//#define BLUEBIT_ENABLED                 false

// BLE summary data type (Uncomment one only)
//#define BLUEBIT_WAKE_TRIG               true
//#define BLUEBIT_BLOB_TRANSFER           true
#define BLUEBIT_EAN_TRANSFER			true

// Data collection
#define COLLECT_IMU_DATA                true                                                         // Define as true to make IMU data collection the default at startup; define as false to disable at startup

// Wake on shake enable/disable (Uncomment one only)
#define WAKE_ON_SHAKE                   true                                                         // Define as true to make the board wake when motion is detected; define as false to disable
//#define WAKE_ON_SHAKE                   false

// Sleep/wake timing
#define NO_MOTION_DELAY_BEFORE_SLEEP    10                                                           // Continuous period of no motion before going back to sleep (in seconds)
#define ANALOG_IDLE_SLEEP_TIME          10000000                                                     // Maximum awake time since last analog trigger (us)
#define ANALOG_WAKEUP_THRESHOLD         20                                                           // In integer percent

// Protected sleep enable/disable (Uncomment one only)
#define PPROTECTED_SLEEP                true                                                         // Define as true to make "protected sleep" the default at startup; define as false to disable at startup
//#define PPROTECTED_SLEEP                false

// Protected/extended sleep mode parameters
#define BOGUS_WAKEUP_LIMIT              5                                                            // Maximum times woken up without analog sensor action before activating protected sleep
#define PROTECTED_SLEEP_TIME            300                                                          // Interval between wake-up checks on analog (Hall) sensor (ms)
#define PROT_SLEEP_EXIT_COUNT           1200                                                         // Exit time is ((PROTECTED_SLEEP_TIME)*(PROT_SLEEP_EXIT_COUNT))/1000 in seconds
#define EXT_SLEEP_DUR                   20                                                           // Extended sleep duration in days (Maximum of 48)
//#define ACCELERATE_EXT_SLEEP                                                                         // Uncomment to do accelerated extended sleep testing (1day = 1s)

// LED indicator always active enable/disable (Uncomment one only)
#define ALWAYS_BLINK_LED                true                                                         // Define as true to force the LED to bink in the main loop for both "Admin" and "Study" modes
//#define ALWAYS_BLINK_LED                false

// Wakeup LED blink enable/disable (Uncomment one only)
#define WAKE_UP_BLINK                   true                                                         // Define as true to get a 10ms LED blink upon wakeup
//#define WAKE_UP_BLINK                   false

// RTC offset (In seconds; 1hr = 3600s)
#define RTC_OFFSET                      40

// CPU clock speed (Uncomment one only)
//#define CPU_80MHZ
//#define CPU_72MHZ
//#define CPU_64MHZ
//#define CPU_48MHZ
//#define CPU_32MHZ
//#define CPU_24MHZ
//#define CPU_16MHZ
#define CPU_8MHZ
//#define CPU_4MHZ
//#define CPU_2MHZ
//#define CPU_1MHZ

// Data Rate (Uncomment one only)
//#define ODR_1HZ                                                                                      
//#define ODR_5HZ
//#define ODR_10HZ
#define ODR_104HZ
//#define ODR_208HZ
//#define ODR_416HZ

#define MOTION_THRESH                   0x04                                                         // 1LSB = 6.25mg

// Active analog channels (Uncomment all that apply)
#define ANALOG_SENSOR_0
//#define ANALOG_SENSOR_1                                                                              // DO NOT UNCOMMENT IF BLUEBIT MODULE IS ATTACHED!
//#define ANALOG_SENSOR_2

// Analog wakeup channel (Uncomment one only)
#define ANALOG_WAKEUP_CHANNEL_0
//#define ANALOG_WAKEUP_CHANNEL_1                                                                      // DO NOT UNCOMMENT IF BLUEBIT MODULE IS ATTACHED!
//#define ANALOG_WAKEUP_CHANNEL_2

// Sensor Orientation (Uncomment one only)
//#define HORIZONTAL_1                                                                                 // Board Horizontal, USB Left, Topside of Board Up
//#define HORIZONTAL_2                                                                                 // Board Horizontal, USB Left, Topside of Board Down
//#define VERTICAL_1                                                                                   // Board Vertical, USB Left, Topside of Board Forward
//#define VERTICAL_2                                                                                   // Board Vertical, USB Up, Topside of Board Left
#define VERTICAL_3                                                                                   // Board Vertical, USB Up, Topside of Board Right

/*************************************************************************************************/
/*************                                                                     ***************/
/*************                     Configuration Definitions                       ***************/
/*************                                                                     ***************/
/*************************************************************************************************/
// CPU speed definitions
#if defined(CPU_80MHZ)
  #define CPU_SPEED                     80000000
#elif defined(CPU_72MHZ)
  #define CPU_SPEED                     72000000
#elif defined(CPU_64MHZ)
  #define CPU_SPEED                     64000000
#elif defined(CPU_48MHZ)
  #define CPU_SPEED                     48000000
#elif defined(CPU_32MHZ)
  #define CPU_SPEED                     32000000
#elif defined(CPU_24MHZ)
  #define CPU_SPEED                     24000000
#elif defined(CPU_16MHZ)
  #define CPU_SPEED                     16000000
#elif defined(CPU_8MHZ)
  #define CPU_SPEED                     8000000
#elif defined(CPU_4MHZ)
  #define CPU_SPEED                     4000000
#elif defined(CPU_2MHZ)
  #define CPU_SPEED                     2000000
#elif defined(CPU_1MHZ)
  #define CPU_SPEED                     1000000
#else
  #define CPU_SPEED                     80000000
#endif

// ODR-related definitions
#if defined(ODR_1HZ)
  #define A_SAMPLE_RATE                 AODR_104Hz                                                   // LSM6DSM running at 104Hz
  #define G_SAMPLE_RATE                 GODR_104Hz
  #define DATA_SAVE_PERIOD              1000000
  #define SAMPLE_DIVISOR                104
  #define SERIAL_UPDATE_PERIOD          1000000
#elif defined(ODR_5HZ)
  #define A_SAMPLE_RATE                 AODR_104Hz                                                   // LSM6DSM running at 104Hz
  #define G_SAMPLE_RATE                 GODR_104Hz
  #define DATA_SAVE_PERIOD              200000
  #define SAMPLE_DIVISOR                21
  #define SERIAL_UPDATE_PERIOD          200000
#elif defined(ODR_10HZ)
  #define A_SAMPLE_RATE                 AODR_104Hz                                                   // LSM6DSM running at 104Hz
  #define G_SAMPLE_RATE                 GODR_104Hz
  #define DATA_SAVE_PERIOD              100000
  #define SAMPLE_DIVISOR                10
  #define SERIAL_UPDATE_PERIOD          200000
#elif defined(ODR_104HZ)
  #define A_SAMPLE_RATE                 AODR_104Hz                                                   // LSM6DSM running at 104Hz
  #define G_SAMPLE_RATE                 GODR_104Hz
  #define DATA_SAVE_PERIOD              9615
  #define SAMPLE_DIVISOR                1
  #define SERIAL_UPDATE_PERIOD          200000
#elif defined(ODR_208HZ)
  #define A_SAMPLE_RATE                 AODR_208Hz                                                   // LSM6DSM running at 208Hz
  #define G_SAMPLE_RATE                 GODR_208Hz
  #define DATA_SAVE_PERIOD              4900
  #define SERIAL_UPDATE_PERIOD          200000
  #define SAMPLE_DIVISOR                1
#elif defined(ODR_416HZ)
  #define A_SAMPLE_RATE                 AODR_416Hz                                                   // LSM6DSM running at 416Hz
  #define G_SAMPLE_RATE                 GODR_416Hz
  #define DATA_SAVE_PERIOD              2404                                                         // Data save period set a little shorter than LSM6DSM period
  #define SAMPLE_DIVISOR                1
  #define SERIAL_UPDATE_PERIOD          200000
#else
  #define A_SAMPLE_RATE                 AODR_416Hz                                                   // LSM6DSM running at 416Hz
  #define G_SAMPLE_RATE                 GODR_416Hz
  #define DATA_SAVE_PERIOD              2404
  #define SAMPLE_DIVISOR                1
  #define SERIAL_UPDATE_PERIOD          200000
#endif

// Unique device ID bytes
#define U_ID_0                          (*(uint32_t*)0x1FFF7590)
#define U_ID_1                          (*(uint32_t*)0x1FFF7594)
#define U_ID_2                          (*(uint32_t*)0x1FFF7598)

// Hardware revision (for BlueBit)
#define HARDWARE_MAJOR                  0
#define HARDWARE_MINOR                  2
#define HARDWARE_REV                    2                                                            // "b" = 2
#define HARDWARE_BUILD                  0                                                            // Not used presently

// Firmware revision (for BlueBit)
#define FIRMWARE_MAJOR                  0
#define FIRMWARE_MINOR                  1
#define FIRMWARE_REV                    11                                                           // "k" = 11
#define FIRMWARE_BUILD                  1                                                            // Sub-rev

// Utility and interrupt pin definitions
#define LED_PIN                         A0                                                           // Main indicator LED; define as NULL if you wish to use A0 as an analog input
#define BTN                             39

//BlueBit pin definitions
#define BLE_I2C_ENABLE_PIN              0
#define BLE_FLOW_CTRL_PIN               A3

// SPI Flash
#define FLASH_CS_PIN                    10                                                           // SPI Flash chip select pin

// LSM6DSM
#define LSM6DSM_INT_PIN1                4                                                            // Accel data ready interrupt
#define LSM6DSM_INT_PIN2                3                                                            // Gyro data ready interrupt

#define LIS2MDL_INT_PIN                 5                                                            // Mag data ready interrupt

// BMA400
#define BMA400_INT_PIN1                 9                                                            // Interrupt1 pin
#define BMA400_INT_PIN2                 8                                                            // Interrupt2 pin

// Battery voltage monitor
#define BATT_MON_PIN                    A4                                                           // v.02b HW
#define BATT_MON_CAL                    0.00080586f

// Analog pin definitions
#define ANALOG_PIN_0                    A2                                                           // v.02b HW
#define ANALOG_PIN_1                    A3                                                           // v.02b HW
#define ANALOG_PIN_2                    A4                                                           // v.02b HW
#define ANALOG_0_SLEEP_PIN              A1                                                           // v.02b HW
#define ANALOG_1_SLEEP_PIN              0                                                            // v.02b HW
#define ANALOG_2_SLEEP_PIN              1                                                            // v.02b HW
#if defined(ANALOG_WAKEUP_CHANNEL_0)
  #define ANALOG_WAKE_PIN               ANALOG_PIN_0
  #define ANALOG_SLEEP_PIN              ANALOG_0_SLEEP_PIN
#elif defined(ANALOG_WAKEUP_CHANNEL_1)
  #define ANALOG_WAKE_PIN               ANALOG_PIN_1
  #define ANALOG_SLEEP_PIN              ANALOG_1_SLEEP_PIN
#elif defined(ANALOG_WAKEUP_CHANNEL_2)
  #define ANALOG_WAKE_PIN               ANALOG_PIN_2
  #define ANALOG_SLEEP_PIN              ANALOG_2_SLEEP_PIN
#else
#endif

// BLE radio definitions
#define BLE_ADVERT_ON_TIME              60
#define BLE_ADVERT_OFF_TIME_MIN         60
#define BLE_ADVERT_OFF_TIME_MAX         3600
#define BLE_ALWAYS_ADVERTISE            0
#define BLE_ADVERT_INTERVAL             1000

/* Specify LSM6DSM accel/gyro sensor parameters
   Choices are:
     GSCALE: GFS_250 = 250 dps, GFS_500 DPS = 500 dps, GFS_1000 = 1000 dps, and GFS_2000DPS = 2000 degrees per second gyro full scale
     ASCALE: AFS_2G = 2 g, AFS_4G = 4 g, AFS_8G = 8 g, and AFS_16G = 16 g accelerometer full scale
     AODR:   AODR_12_5Hz = 12.5Hz, AODR_26Hz = 26Hz, AODR_52Hz = 52Hz, AODR_104Hz = 104Hz, AODR_208Hz = 208Hz,
             AODR_416Hz = 416Hz, AODR_833Hz = 833Hz, AODR_1660Hz = 1660Hz, AODR_3330Hz = 1660Hz and AODR_6660Hz = 6660Hz
     GODR:   GODR_12_5Hz = 12.5Hz, GODR_26Hz = 26Hz, GODR_52Hz = 52Hz, GODR_104Hz = 104Hz, GODR_208Hz = 208Hz,
             GODR_416Hz = 416Hz, GODR_833Hz = 833Hz, GODR_1660Hz = 1660Hz, GODR_3330Hz = 1660Hz and GODR_6660Hz = 6660Hz
 */
#define LSM6DSM_GSCALE                  GFS_2000DPS
#define LSM6DSM_ASCALE                  AFS_16G
#define LSM6DSM_AODR                    A_SAMPLE_RATE
#define LSM6DSM_GODR                    G_SAMPLE_RATE

/* Specify LIS2MDL magnetometer sensor parameters
   Choices are:
   MODR_10Hz, MODR_20Hz, MODR_50Hz, MODR_100Hz
 */
//#define LIS2MDL_MODR                    MODR_100Hz

/* BMA400 sensor parameters
   Choices are:
     A_SCALE: aFS_2G, aFS_4G, aFS_8G, aFS_16G  
     SAMPLERATE: SR_12_5Hz, SR_25Hz, SR_50Hz, SR_100Hz, SR_200Hz, SR_400Hz, SR_800Hz
     POWER_MODE: sleep_Mode, lowpower_Mode, normal_Mode
     OSR: osr0, osr1, osr2, osr3
     ACC_FILTER: acc_filt1, acc_filt2, acc_filt_lp
*/ 
#define A_SCALE                         aFS_2G
#define SAMPLERATE                      SR_100Hz
#define POWER_MODE                      lowpower_Mode
#define OSR                             osr0
#define ACC_FILTER                      acc_filt2

// Madgwick filter tuning constants
#define KP_DEF                          0.5f                                                         // Mahony filter proportional gain
#define KI_DEF                          0.0f                                                         // Mahony filter integral gain
#define GYRO_MEAS_ERROR                 1.0f                                                         // Madgewick gyro measurement error. Start at 1 deg/s; original: 2.5deg/s)
#define GYRO_MEAS_DRIFT                 0.0f                                                         // Madgewick gyro  drift. Sstart at 0.0 deg/s/s


#if defined(HORIZONTAL_1)
  #define Ax                            ay                                                           // EAST
  #define Ay                           -ax                                                           // NORTH
  #define Az                            az                                                           // UP
  #define Gx                            gy                                                           // EAST
  #define Gy                           -gx                                                           // NORTH
  #define Gz                            gz                                                           // UP
#elif defined(HORIZONTAL_2)
  #define Ax                            ay
  #define Ay                            ax
  #define Az                           -az
  #define Gx                            gy
  #define Gy                            gx
  #define Gz                           -gz
#elif defined(VERTICAL_1)
  #define Ax                            ay
  #define Ay                            az
  #define Az                            ax
  #define Gx                            gy
  #define Gy                            gz
  #define Gz                            gx
#elif defined(VERTICAL_2)
  #define Ax                           -az
  #define Ay                            ax
  #define Az                           -ay
  #define Gx                           -gz
  #define Gy                            gx
  #define Gz                           -gy
#elif defined(VERTICAL_3)
  #define Ax                            az
  #define Ay                           -ax
  #define Az                           -ay
  #define Gx                            gz
  #define Gy                           -gx
  #define Gz                           -gy
#else                                                                                                // "Horizontal 1" is default
  #define Ax                            ay
  #define Ay                           -ax
  #define Az                            az
  #define Gx                            gy
  #define Gy                           -gx
  #define Gz                            gz
#endif
