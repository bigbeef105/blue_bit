/*
 * Copyright (c) 2020 The Pocter & Gamble Company, INC.  All rights reserved.
 *
 * This software in whole and in part is owned by The Pocter & Gamble Company, INC
 * and may not be sold, offered, excerpted, bartered, or in any way delivered
 * or made available to any third party without direct, explicit and written consent
 * of The Procter & Gamble Company or its assignees.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL THE
 * CONTRIBUTORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * WITH THE SOFTWARE.
 */

#ifndef BlueBit_h_
#define BlueBit_h_

#undef USE_ARDUINO

#ifdef USE_ARDUINO
#include <Wire.h>
#include <assert.h>
#else
#include <stdlib.h>
#include <stdint.h>
#include "gpio_generic.h"
#endif

#include "Config.h"

#define BB_I2C_ADDDR                    0x08
#define SERIAL_NUM_WORDS                3
#define SEND_BLOCKING_TIMEOUT           500                                                                                                            // Milliseconds
#define SET_POWER_STATE_MESSAGE_ID      0x0001
#define WHO_AM_I_MESSAGE_ID             0x0002
#define SUMMARY_DATA_MESSAGE_ID         0x0100
#define CONFIG_MESSAGE_ID               0x0101
#define SET_RESBIT_INFO_ID              0x0102
#define BLUEBITS_DEVICE_ID              0x0001
#define CONFIG_DATA_MAX_SIZE            4
#define MESSAGE_MAX_LEN                 512
#define PACKET_LEN                      255
#define PACKET_HEADER_LEN               5
#define PACKET_MAX_DATA_LEN             (PACKET_LEN - PACKET_HEADER_LEN)
#define RESPONSE_LEN                    3
#define VERSION_STR_ARRAY_LENGTH        80
#define MESSAGE_DATA_OFFSET             2
#define MESSAGE_MAX_DATA_LEN            (MESSAGE_MAX_LEN - MESSAGE_DATA_OFFSET)
#define SBMEMBER_MAX_ENTRIES            6
#define SPLIT_BUFFER_MAX_ENTRIES        SBMEMBER_MAX_ENTRIES * 2
#define INIT_STATUS_SPRINTF_BUFF_LEN    50
#define CONFIG_RESPONSE_SUCCESS         0x00
#define CONFIG_RESPONSE_UNKNOWN_ID      0x01
#define CONFIG_RESPONSE_DATA_LENGTH     0x02
#define CONFIG_RESPONSE_DATA_VALUE      0x03
#define WHOAMI_RETRY_TIMEOUT            5000                                                                                                           // Milliseconds
#define Status_IsOk(status) (status == StatusOk)
#define returnStatus(__status__,__source__) SwUnitControl_WriteStatus(eSucBlueBitsSu,__source__,__status__,__LINE__)
#define Status_IsError(status) (status != StatusOk)
#define Status_Preserve(status, expr) ((StatusOk == (status)) ? (expr) : ((expr) == (status)) ? (status) : (status))
#define PACKET_CRC_OFFSET               2
#define CRC_SEED                        0xFFFF;
#define CRC_POLYNOMIAL                  0xA001
#define CRC_SHIFTS_NUM                  8
#define RES_CODE_SUCCESS                0x00
#define RES_CODE_CRC                    0x01
#define RES_CODE_INVALID_NUM_PACKETS    0x02
#define RES_CODE_INVALID_PACKET_NUM     0x03
#define RES_CODE_INVALID_DATA_LEN       0x04
#define RES_CODE_PACKET_ORDER           0x05
#define RES_CODE_DATA_LEN_MISMATCH      0x06
#define RES_CODE_UNKNOWN                0x7F
#define COMS_TIMEOUT_MS                 200
#define COMS_MESSAGE_INTERVAL           2
#define COMS_RETRY_LIMIT                3
#define RESPONSE_FLAG                   0x8000
#define MESSAGE_RES_CODE_LEN            1

// Kinetic Viaion legacy structures and enumerators, 95% claptrap. Leave it alone unless you are ready to drain the whole swamp...
typedef enum
{
	StatusOk = 0,                  //!< StatusOk
	StatusParameter1,              //!< StatusParameter1
	StatusParameter2,              //!< StatusParameter2
	StatusParameter3,              //!< StatusParameter3
	StatusParameter4,              //!< StatusParameter4
	StatusParameter5,              //!< StatusParameter5
	StatusParameter6,              //!< StatusParameter6
	StatusParameter7,              //!< StatusParameter7
	StatusParameter8,              //!< StatusParameter8
	StatusParameterValue,          //!< StatusParameterValue
	StatusNotInitialized = 10,     //!< StatusNotInitialized
	StatusAlreadyInitialized,      //!< StatusAlreadyInitialized
	StatusCarriageReturn,          //!< StatusCarriageReturn
	StatusAlreadyLinked,           //!< StatusAlreadyLinked
	StatusClosed,                  //!< StatusClosed
	StatusHal,                     //!< StatusHal
	StatusHalTimeout,              //!< StatusHalTimeout
	StatusCommandNotFound,         //!< StatusCommandNotFound
	StatusDeviceId,                //!< StatusDeviceId
	StatusSpi,                     //!< StatusSpi
	StatusTc58FlashTimeout = 20,   //!< StatusTc58FlashTimeout
	StatusParameterCount,          //!< StatusParameterCount
	StatusPageNumber,              //!< StatusPageNumber
	StatusNullParameter,           //!< StatusNullParameter
	StatusNotImplemented,          //!< StatusNotImplemented
	StatusPageOffset,              //!< StatusPageOffset
	StatusByteValue,               //!< StatusByteValue
	StatusWriteEnable,             //!< StatusWriteEnable
	StatusProgramFailed,           //!< StatusProgramFailed
	StatusBlockNumber,             //!< StatusBlockNumber
	StatusErase = 30,              //!< StatusErase
	StatusCodePath,                //!< StatusCodePath
	StatusImuChipId,               //!< StatusImuChipId
  StatusDiskNoInit,              // Maps to : #define STA_NOINIT		0x01 (Drive not initialized)
	StatusDiskNoDisk,              // Maps to : #define STA_NODISK		0x02 (No medium in the drive)
  StatusDiskProtect,             // Maps to : #define STA_PROTECT		0x04 (Write protected)
	StatusResultDiskError,         // Maps to: DRESULT (type), value: RES_ERROR = 1
	StatusResultWriteProtect,      // Maps to: DRESULT (type), value: RES_WRPRT = 2
	StatusResultNotReady,          // Maps to: DRESULT (type), value: RES_NOTRDY = 3
	StatusResultInvalidParameter,  // Maps to: DRESULT (type), value: RES_PARERR = 4
	StatusTooFewFlashSectors = 40, //!< StatusTooFewFlashSectors
  StatusErased,                  //!< StatusErased
	StatusNotErased,               //!< StatusNotErased
	StatusSwUnitEnabled,           //!< StatusSwUnitEnabled
	StatusSwUnitDisabled,          //!< StatusSwUnitDisabled
	StatusSwUnitControlId,         //!< StatusSwUnitControlId
	StautsAdcActiveChannel,        //!< StautsAdcActiveChannel
	StautsAdcNotActiveChannel,     //!< StautsAdcNotActiveChannel
	StautsAdcMaxActiveChannels,    //!< StautsAdcMaxActiveChannels
	StatusAdcNoActiveChannels,     //!< StatusAdcNoActiveChannels
	StatusDataFormat = 50,         //!< StatusDataFormat
	StatusQueueSetup,              //!< StatusQueueSetup
	StatusQueueEmpty,              //!< StatusQueueEmpty
	StatusQueueFull,               //!< StatusQueueFull
	StatusQueueActive,             //!< StatusQueueActive
	StatusCsvEndsInCrLf,           //!< StatusCsvEndsInCrLf
	StatusCsvLineLength,           //!< StatusCsvLineLength
	StatusSpaceAvailable,          //!< StatusSpaceAvailable
	StatusBufferLength,            //!< StatusBufferLength
	StatusNoFileFound,             //!< StatusNoFileFound
	StatusFatFsWrite = 60,         //!< StatusFatFsWrite
	StatusFatFsRead,               //!< StatusFatFsRead
	StatusFatFsOpen,               //!< StatusFatFsOpen
	StatusFatFsClose,              //!< StatusFatFsClose
	StatusFatFsSync,               //!< StatusFatFsSync
	StatusFatFsMount,              //!< StatusFatFsMount
	StatusFatFsVolume,             //!< StatusFatFsVolume
	StatusFatFsFull,               //!< StatusFatFsFull
	StatusFloatingPtError,         //!< StatusFloatingPtError
	StatusSpanningBlock,           //!< StatusSpanningBlock
	StatusUsbConnected = 70,       //!< StatusUsbConnected
	StatusUsbNotConnected,         //!< StatusUsbNotConnected
	StatusNotFormatted,            //!< StatusNotFormatted
	StatusConfigId,                //!< StatusConfigId
	StatusBufferSize,              //!< StatusBufferSize
	StatusFlashType,               //!< StatusFlashType
	StatusFlashBeginAddress,       //!< StatusFlashBeginAddress
	StatusFlashEndAddress,         //!< StatusFlashEndAddress
	StatusFirmwareLogic,           //!< StatusFirmwareLogic
	StatusRemapTable,              //!< StatusRemapTable
	StatusRemapTableSize = 80,     //!< StatusRemapTableSize
	StatusBlockRemapTable,         //!< StatusBlockRemapTable
	StatusFlashPageSize,           //!< StatusFlashPageSize
	StatusFlashBelowMinValidBlocks,//!< StatusFlashBelowMinValidBlocks
	StatusFlashScratchPadBlock,    //!< StatusFlashScratchPadBlock
	StatusFlashRamapTableBlock,    //!< StatusFlashRamapTableBlock
	StatusMakeFileSystem,          //!< StatusMakeFileSystem
	StatusFileSystemDriver,        //!< StatusFileSystemDriver
	StatusFileSystemMount,         //!< StatusFileSystemMount
	StatusConfigStringSize,        //!< StatusConfigStringSize
	StatusConfigStringValue = 90,  //!< StatusConfigStringValue
	StatusConfigSettings,          //!< StatusConfigSettings
	StatusHx711Timeout,            //!< StatusHx711Timeout
	StatusTooManyFiles,            //!< StatusTooManyFiles
	StatusImuAxisRemap,            //!< StatusImuAxisRemap
	StatusBlockPoolLimit,          //!< StatusBlockPoolLimit
	StatusTooManyBadBlocks,        //!< StatusTooManyBadBlocks
	StatusBlockOk,                 //!< StatusBlockOk
	StatusRemap,                   //!< StatusRemap
	StatusTc58ProgramLoad,         //!< StatusTc58ProgramLoad
	StatusBlockPoolFull = 100,     //!< StatusBlockPoolFull
	StatusFatFsBytesWritten,       //!< StatusFatFsBytesWritten
	StatusFatFsDismount,           //!< StatusFatFsDismount
	StatusSource,                  //!< StatusSource
	StatusDestination,             //!< StatusDestination
	StatusRemapBlock,              //!< StatusRemapBlock
	StatusFlashEcc,                //!< StatusFlashEcc
	StatusFlashMemComp,            //!< StatusFlashMemComp
	StatusImuDataNotRdy,           //!< StatusImuDataNotRdy
	StatusI2cChipId,               //!< StatusI2cChipId
	StatusI2cataNotRdy = 110,      //!< StatusI2cataNotRdy
	StatusInstancePoolFull,        //!< StatusInstancePoolFull
	StatusInstanceNotFound,        //!< StatusInstanceNotFound
	StatusAlreadyInProgress,       //!< StatusAlreadyInProgress
	StatusComsCRC = 120,           //!< StatusComsCRC
  StatusComsInvalidNumPackets,   //!< StatusComsInvalidNumPackets
  StatusComsInvalidPacketNum,    //!< StatusComsInvalidPacketNum
  StatusComsInvalidDataLen,      //!< StatusComsInvalidDataLen
  StatusComsPacketOrder,         //!< StatusComsPacketOrder
  StatusComsDataLenMismatch,     //!< StatusComsDataLenMismatch
  StatusComsReceiveTimeout,      //!< StatusComsReceiveTimeout
  StatusComsSendTimeout,         //!< StatusComsSendTimeout
  StatusComsUnknown,             //!< StatusComsUnknown
  StatusComsResponseError,       //!< StatusComsResponseError
  StatusMessageId = 130,         //!< StatusMessageId
	StatusMessageData,             //!< StatusMessageData
	StatusMessageNotReceived,      //!< StatusMessageNotReceived
	StatusBufferEmpty,             //!< StatusBufferEmpty
	StatusBufferFull,              //!< StatusBufferFull
	StatusSendConfig,              //!< StatusSendConfig
	StatusAlarmAlreadyElapsed = 140,
	StatusFlushTimeout,
	StatusInvalidState,
} status_t;

typedef enum
{
  eSucAdcSu,
  eSucConsoleSu,
  eSucDataAggregSu,
  eSucDataReceiverSu,
  eSucFifoSu,
  eSucGpioSu,
  eSucI2cSu,
  eSucBno055Su,
  eSucLis2de12Su,
  eSucMs5837,
  eSucRtcSu,

  // The TC58 Flash driver stackup consists the following software units
  eSucTc58FlashLogicalSu,
  eSucTc58FlashBufferSu,
  eSucTc58BlockSu,
  eSucTc58FlashPhysicalSu,
  eSucTc58FlashUtilitySu,
  eSucTimerSu,
  eSucUsartSu,
  eSucSwUnitControlSu,
  eSucPowerSu,
  eSucUserInterfaceSu,
  eSucNvPartitionSu,
  eSucBlueBitsSu,
  eSucCrcSu,
  eSucMessagerSu,
  eSucPacketSu,
  eSucProtocolHalSu,
  eSucProtocolHandlerSu,
  eSucSysTimeSu,
  eSucSplitBufferSu,
  eSucBase64Su,
  eSucSummaryDataSu,
  eSucWakeSummarySu,
  eSucHallThreshSummarySu,
  SUC_NUMBER_OF_SW_UNITS_LIST                                                                                                                          // Keep this element last in the list
} SwUnitControlId_t;

typedef enum
{
	eSucInitStatus,
	eSucReadStatus,
	eSucWriteStatus,
	eSucIoctlStatus,
	SUC_NUMBER_OF_STATUS_TYPES,                                                                                                                          // Keep this element last in the list
} SwUnitControlStatusType_t;

typedef enum
{
  messageResponseSuccess = 0,
  messageResponseIdError,
  messageResponseDataError,
  messageResponseNotReceived = 0x7F
} messageResponseCode_t;

typedef enum
{
  settingDisable,
  settingEnable,
  NUM_ENABLE_STATES,
  NULL_ENABLE_INIT
} configEnableState_t;

typedef enum
{
  configIoctlGetMode,
  configIoctlGetRtc,
  configIoctlGetLpAcc,
  configIoctlGetImu,
  configIoctlGetAcc,
  configIoctlGetGyr,
  configIoctlGetMag,
  configIoctlGetEuler,
  configIoctlGetQuat,
  configIoctlGetOrientation,
  configIoctlGetLed,
  configIoctlGetUart,
  configIoctlGetFreq,
  configIoctlGetWakeTrig,
  configIoctlGetStartStudyTrig,
  configIoctlGetProtectMode,
  configIoctlGetDeepSleepMode,
  configIoctlGetJ1,
  configIoctlGetJ2,
  configIoctlGetJ3,
  configIoctlGetJ4,
  configIoctlGetAnalogTrig,
  configIoctlGetThresholdType,
  configIoctlGetTrigThreshold,
  configIoctlGetBatteryOutput,
  configIoctlGetTemperatureOutput,
  configIoctlGetFixedSleep,
  configIoctlGetFixedWakeupDuration,
  configIoctlGetWakeDur,
  configIoctlGetNmSleep,
  configIoctlGetDeepSleepDur,
  configIoctlGetWakeLimit,
  configIoctlGetWakeTick,
  configIoctlGetWakeReset,
  configIoctlGetSleepDur,
  configIoctlGetDataSyncCounter,
  configIoctlGetFormatFileSys,
  configIoctlGetUsbSerialMode,
  configIoctlGetBinaryFileMode,
  configIoctlGetClockSpeed,
  configIoctlGetBluebitEnabled,
  configIoctlGetWakeSummaryEnabled,
  configIoctlGetTrigCountEnabled,
  configIoctlGetBatteryVoltage,
  configIoctlGetFileSize,
  configIoctlGetBleAdvertOnTime,
  configIoctlGetBleAdvertOffTimeMin,
  configIoctlGetBleAdvertOffTimeMax,
  configIoctlGetBleAlwaysAdvertise,
  configIoctlGetBleAdvertInterval,
  configIoctlGetConfigError,
  NUM_CONFIG_IOCTL
} configIoctl_t;

typedef enum
{
  bleConfigResponsesSuccess = 0,
  bleConfigResponsesUnknownId,
  bleConfigResponsesDataLength,
  bleConfigResponsesDataValue,
} bleConfigResponses_t;

typedef struct
{
  uint32_t initStatusOk;
  uint32_t initNotStatusOk;
  uint16_t initNotOkLineOfCode;
  status_t initNotOkStatusCode;
  uint32_t readStatusOk;
  uint32_t readNotStatusOk;
  uint16_t readNotOkLineOfCode;
  status_t readNotOkStatusCode;
  uint32_t writeStatusOk;
  uint32_t writeNotStatusOk;
  uint16_t writeNotOkLineOfCode;
  status_t writeNotOkStatusCode;
  uint32_t ioctlStatusOk;
  uint32_t ioctlNotStatusOk;
  uint16_t ioctlNotOkLineOfCode;
  status_t ioctlNotOkStatusCode;
} swUnitsStatistics_t;

typedef union
{
  uint32_t whole;
  struct
  {
    uint8_t build;
    uint8_t revision;
    uint8_t minor;
    uint8_t major;
  };
} version_t;

typedef struct
{
	uint16_t messageId;
	uint8_t * messageData;
	size_t dataLen;
	messageResponseCode_t resCode;
	uint8_t * resData;
	size_t resLen;
	uint32_t timeoutMs;
} sendMessageArgs_t;

typedef struct
{
	uint16_t deviceId;
	version_t hardwareVersion;
	version_t softwareVersion;
	version_t firmwareVersion;
} whoami_t;

typedef enum
{
	publicStateAwake = 0,
	publicStateSleep,
	publicStateProtected,
	publicStateDeepSleep,
} publicState_t;

typedef union
{
  uint8_t  bytes[SERIAL_NUM_WORDS * sizeof(uint32_t)];
  uint32_t words[SERIAL_NUM_WORDS];
} serialNum_t;

typedef struct
{
	serialNum_t hardwareSerialNum;
	version_t hardwareVersion;
	version_t firmwareVersion;
} resbitInfo_t;

typedef struct
{
  messageResponseCode_t resCode;
  uint8_t * data;
  size_t len;
} responseHandlerArgs_t;

typedef status_t (*responseHandler_t)(responseHandlerArgs_t * args);

typedef struct
{
	const uint16_t messageId;
	const uint8_t * messageData;
	const size_t dataLen;
	responseHandler_t resHandler;
} sendMessageAsyncArgs_t;

typedef enum
{
  ProtocolStateIdle = 0,
  ProtocolStateReceive,
  ProtocolStateRespond,
  ProtocolStateSend,
  ProtocolStateGetResponse,
} protocolState_t;

typedef enum
{
	transferStateIdle = 0,
	transferStateInProgress,
	transferStateDone,
} transferState_t;

typedef struct
{
  uint8_t contents[MESSAGE_MAX_LEN];
  int tailIndex;
  int lastTailIndex;
  int numPackets;
  int currentPacketNum;
} messageData_t;

typedef union
{
  uint8_t bytes[PACKET_LEN];
  struct
  {
    uint16_t crc;
    uint8_t numPackets;
    uint8_t packetNum;
    uint8_t dataLen;
    uint8_t data[PACKET_LEN - PACKET_HEADER_LEN];
  };
} packet_t;

typedef union
{
  uint8_t bytes[RESPONSE_LEN];
  struct
	{
    uint16_t crc;
    uint8_t code;
  };
} response_t;

typedef struct
{
  uint8_t * buffer;
  uint16_t head;
  uint16_t tails[SBMEMBER_MAX_ENTRIES];
} splitMember_t;

typedef struct
{
  uint8_t * buffer;
  size_t bufferLen;
  size_t splitLen;
  splitMember_t near;
  splitMember_t far;
  splitMember_t * write;
  splitMember_t * read;
} splitBuffer_t;

typedef struct
{
  uint8_t * messageData;
  size_t dataLen;
  messageResponseCode_t resCode;
  uint8_t * resBuffer;
  size_t resBufferLen;
  size_t bytesWritten;
} messageHandlerArgs_t;

typedef status_t (*messageHandler_t)(messageHandlerArgs_t * args);

typedef const struct
{
  uint16_t messageId;
  messageHandler_t handler;
} messageHandlerReg_t;

typedef struct messageHandlerList_s
{
  messageHandlerReg_t const * handlers; // must be null terminated
  struct messageHandlerList_s * next;
} messageHandlerList_t;

typedef enum
{
  bleConfigIdAdvertOnTime = 0,
  bleConfigIdAdvertOffTimeMin,
  bleConfigIdAdvertOffTimeMax,
  bleConfigIdAlwaysAdvertise,
  bleConfigIdAdvertInterval,
} bleConfigIds_t;

typedef struct
{
  bleConfigIds_t id;
  size_t configDataLen;
  configIoctl_t configIoctlCode;
} bleConfigVariables_t;

//extern uint8_t SetupMode;

class BlueBit                                                                                                                                          // Kinetic Vision legacy (wrapper functions in wrapper functions in wrapper functions...)
{
  public:

	BlueBit(gpio_t *enable_pin, gpio_t *flow_ctrl_pin, uint8_t* twi);
    status_t bluebitsInit();
    void     bluebitsHandler();
    status_t BlueBits_SendSummaryData(uint8_t * data, size_t len);
    status_t Messager_RegisterHandlers(messageHandlerList_t* handlers);   


    status_t SendFakeBlobEvents(uint32_t sleep_time, uint8_t* summary_data,
                                     uint8_t* blob_data, uint16_t size);
    uint8_t is_rtc_message(void);

  private:
    gpio_t*  _BlueBitEnablePin;
    gpio_t*  _BlueBitFlowCtrlPin;

    uint8_t* _twi;
    uint8_t rtc_msg_received_flag;

    status_t DeviceInfo_Init();                                                                                                                        // From "DeviceInfoSu"
    status_t DeviceInfo_GetSerialNum(serialNum_t *serialNum);                                                                                          //          .
    status_t DeviceInfo_GetHardwareVersion(version_t *version);                                                                                        //          .
    status_t DeviceInfo_GetFirmwareVersion(version_t *version);                                                                                        //          .
    void     makeVersionStr(version_t *version, char *str);                                                                                            //          .
    void     makeMajMinVersionStr(version_t *version, char *str);                                                                                      //          .
    status_t ProtocolHal_Init(bool onStartup);                                                                                                         // From "ProtocolHalSu"
    status_t ProtocolHal_Tick();                                                                                                                       //          .
    bool     ProtocolHal_HasPacket();                                                                                                                  //          .
    status_t ProtocolHal_WritePacket(packet_t * packet);                                                                                               //          .
    status_t ProtocolHal_GetPacket(packet_t * out, size_t * outLen);                                                                                   //          .
    bool     ProtocolHal_IsWriteDone();                                                                                                                //          .
    status_t ProtocolHal_WriteResponse(response_t * response);                                                                                         //          .
    void     ProtocolHal_Reset();                                                                                                                      //          .
    status_t ProtocolHal_GetResponse(response_t * out);                                                                                                //          .
    bool     ProtocolHal_HasResponse();                                                                                                                //          .
    bool     indicationPinStatus();                                                                                                                    //          .
    status_t i2cRead(uint8_t address, uint8_t * buffer, uint8_t len);                                                                                  //          .
    status_t i2cWrite(uint8_t address, uint8_t * buffer, uint8_t len);                                                                                 //          .
    status_t ProtocolHandler_Init();                                                                                                                   // From "ProtocolHandlerSu"
    status_t ProtocolHandler_Tick();                                                                                                                   //          .
    bool     ProtocolHandler_IsSendReady();                                                                                                            //          .
    status_t ProtocolHandler_SendMessage(const uint8_t * buff, size_t len);                                                                            //          .
    bool     checkTimeout();                                                                                                                           //          .
    void     clearMessageDelay();                                                                                                                      //          .
    status_t handleIdleTick();                                                                                                                         //          .
    bool     checkMessageDelay();                                                                                                                      //          .
    void     resetMessageData(messageData_t * message);                                                                                                //          .
    status_t handleReceiveTick();                                                                                                                      //          .
    status_t handlePacketReceive();                                                                                                                    //          .
    status_t handleRespondTick();                                                                                                                      //          .
    void     setMessageDelay(uint32_t delayMs);                                                                                                        //          .
    void     resetAndReturnToIdle();                                                                                                                   //          .
    status_t handleSendTick();                                                                                                                         //          .
    status_t handleGetResponseTick();                                                                                                                  //          .
    status_t generatePacket(messageData_t * message, packet_t * packet);                                                                               //          .
    status_t handleResponseReceive();                                                                                                                  //          .
    status_t Messager_Init();                                                                                                                          // From "MessagerSu"
    status_t Messager_Tick();                                                                                                                          //          .
    status_t Messager_ResCodeToStatus(messageResponseCode_t resCode);                                                                                  //          .
    status_t Messager_SendMessage(sendMessageArgs_t * args);                                                                                           //          .
    status_t Messager_FlushBuffer(uint32_t timeoutMs);                                                                                                 //          .
    void     callTickMethods();                                                                                                                        //          .
    status_t Messager_SendMessageAsync(sendMessageAsyncArgs_t * args);                                                                                 //          .
    status_t Messager_HandleMessage(uint8_t * buffer, size_t len);                                                                                     //          .
    status_t responseHandlersEnqueue(responseHandler_t handler);                                                                                       //          .
    void     resetResponseHandlers();                                                                                                                  //          .
    status_t callMessageHandler(uint16_t messageId, uint8_t * data, size_t len);                                                                       //          .
    status_t queueMessage(uint16_t messageId, const uint8_t * data, size_t len);                                                                       //          .
    status_t parseMessage(uint16_t messageId, uint8_t * data, size_t len);                                                                             //          .
    status_t parseResponse(uint16_t messageId, uint8_t * data, size_t len);                                                                            //          .
    status_t responseHandlersDequeue(responseHandler_t * handler);                                                                                     //          .
    bool     responseBitPresent(uint16_t messageId);                                                                                                   //          .
    status_t BlueBits_Init();                                                                                                                          // From "BlueBitsSu"
    status_t sendConfig();                                                                                                                             //          .
    status_t parseConfigResponse(uint8_t *response, size_t len, bleConfigIds_t id);                                                                    //          .
    status_t Config_Ioctl(configIoctl_t ioctlCode, uint8_t* outValue);                                                                                 //          .
    status_t BlueBits_SendPowerState(publicState_t powerState);                                                                                        //          .
    bool     BlueBits_IsEnabled();                                                                                                                     //          .
    status_t tryWhoami(uint32_t timeout);                                                                                                              //          .
    status_t sendWhoami();                                                                                                                             //          .
    status_t parseWhoami(const uint8_t * res, uint8_t resLen, whoami_t * whoamiOut);                                                                   //          .
    status_t sendSetResbitInfo();                                                                                                                      //          .
    uint8_t  Packet_GetResponseCode(status_t status);                                                                                                  // From "PacketSu"
    status_t Packet_GenerateResponse(response_t * dest, uint8_t responseCode);                                                                         //          .
    status_t Packet_ParseHeader(const packet_t * src, size_t len);                                                                                     //          .
    status_t Packet_ParseBody(uint8_t * dest, size_t maxLen, const packet_t * src);                                                                    //          .
    status_t Packet_Pack(packet_t * dest, const uint8_t * src, size_t len, int numPackets, int packetNum);                                             //          .
    status_t Packet_ParseResponse(const response_t * res);                                                                                             //          .
    status_t statusFromResCode(uint8_t resCode);                                                                                                       //          .
    bool     SplitBuffer_IsEmpty(splitBuffer_t * sb);                                                                                                  // From "SplitBufferSu"
    status_t SplitBuffer_GetHead(splitBuffer_t * sb, uint8_t ** headPtr, size_t * headSize);                                                           //          .
    status_t SplitBuffer_FreeHead(splitBuffer_t * sb);                                                                                                 //          .
    status_t SplitBuffer_Setup(splitBuffer_t * sb, uint8_t * bufferMem, size_t len);                                                                   //          .
    status_t SplitBuffer_Enqueue(splitBuffer_t * sb, uint8_t * dataIn, size_t len);                                                                    //          .
    void     tailsClear(uint16_t * tails);                                                                                                             //          .
    status_t tailsPushBack(uint16_t * tails, size_t entryLen, size_t splitLen, uint16_t * lastTail);                                                   //          .
    uint16_t tailsPopFront(uint16_t * tails);                                                                                                          //          .
    status_t Crc_Calc(uint16_t * crc, const uint8_t * values, size_t len);                                                                             // From "CrcSU"
    status_t SwUnitControl_WriteStatus(SwUnitControlId_t suId, SwUnitControlStatusType_t statusType, status_t statusIn, uint16_t lineOfCode);          // From "SwUnitControlSu"
    bool     SysTime_IsElapsed(uint32_t start, uint32_t duration);                                                                                     // From "SysTimeSu"
    uint32_t SysTime_GetElapsed(uint32_t start);                                                                                                       //          .
};

#endif // BlueBit_h_
