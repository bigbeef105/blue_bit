/*
 * gpio_generic.h
 *
 *  Created on: May 9, 2021
 *      Author: shane
 */

#ifndef INC_GPIO_GENERIC_H_
#define INC_GPIO_GENERIC_H_

typedef struct gpio_type {
	uint8_t *port;
	uint16_t pin;
} gpio_t;


#endif /* INC_GPIO_GENERIC_H_ */
