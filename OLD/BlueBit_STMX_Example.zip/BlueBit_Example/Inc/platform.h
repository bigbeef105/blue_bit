/*
 * platform.h
 *
 *  Created on: May 5, 2021
 *      Author: shane
 */

#ifndef INC_PLATFORM_H_
#define INC_PLATFORM_H_

#define STM32
//#define NRF52832

#define IS_ERROR(err)		(err==0)
#define IS_NULL(ptr)		(ptr==NULL)

#ifdef STM32
#include "stm32l4xx_hal.h"
#include "main.h"

#define write_pin(p_gpio_t, value)		HAL_GPIO_WritePin((GPIO_TypeDef*)p_gpio_t->port, p_gpio_t->pin, value)
#define read_pin(p_gpio_t)				HAL_GPIO_ReadPin((GPIO_TypeDef*)p_gpio_t->port, p_gpio_t->pin)


#define delay_ms		HAL_Delay
#define millis			HAL_GetTick
#endif

#ifdef NRF52832
#define write_pin(pin, value)			nrf_gpio_pin_write(pin, value)
#define read_pin(pin)					nrf_gpio_pin_read(pin)

#define delay_ms		delay_ms
#define millis			nrf_millis
#endif

#endif /* INC_PLATFORM_H_ */
