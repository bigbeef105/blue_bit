/**
  @file       SysTime.c

  @copyright  (C) 2020 Kinetic Vision, Cincinnati Ohio.
               This software is property of SAEC Kinetic Vision, Inc
               and is considered confidential.

  @brief      SysTime software unit "C" file.

  @author     Andrew Loebs

  @ingroup    SysTimeSoftwareUnit

  Configuration History
  =====================

  Config Item    | Value
  -------------- | -----
  Config #       | NA
  Revision       | NA
  Revised, Date  | NA
  QA, Date       | NA
  Approved, Date | NA
  Released, Date | NA

  Significant Modification History (Most recent at top)
  =====================================================

  Date         | Initials | Details
  ------------ | -------- | -------
  31 Jan 2020  | ASL      | Original

  Theory of Operation
  ===================
  Provides millisecond scale system time.

*/

// Includes ------------------------------------------------------------------

#include "SysTime.h"

#include "nrfx_timer.h" // nrfx_timer_* functions
#include "sdk_config.h"

#include "../SwUnitControlSu/SwUnitControl.h" // SwUnitControl_WriteStatus()
#include "../ConsoleSu/Console.h" // Console_* functions, consoleCommand_t

// Private function prototypes -----------------------------------------------
static void timerEventHandler(nrf_timer_event_t eventType, void * pContext);
static status_t cliGetMs(uint16_t argc, uint8_t **argv);

// Private macros ------------------------------------------------------------
#define returnStatus(__status__,__source__) SwUnitControl_WriteStatus(eSucSysTimeSu,__source__,__status__,__LINE__);

#define TIMEOUT_TICKS           1000

// Private constants ---------------------------------------------------------

// Private types -------------------------------------------------------------

// Private constants ---------------------------------------------------------
static const nrfx_timer_t timer = NRFX_TIMER_INSTANCE(4);

static const consoleCommand_t commandList[] = {

	{
		.pCommand = "get_ms",
		.pUsage = "usage: get_ms",
		.pHandlerFn = cliGetMs,
	},

	// Marks last element in the list
    { NULL, NULL, NULL },
};

// Private variables ---------------------------------------------------------
static bool initialized = false;
static volatile uint32_t ms = 0;

static consoleRegistration_t exportedReg = {
    (consoleCommand_t *) commandList, // .pList =
    NULL, // .pNext =
};

// Private function bodies ---------------------------------------------------
static void timerEventHandler(nrf_timer_event_t eventType, void * pContext)
{
    switch (eventType)
    {
        case NRF_TIMER_EVENT_COMPARE0:
            ms++;
            break;
        default:
            // Do nothing
            break;
    }
}

static status_t cliGetMs(uint16_t argc, uint8_t **argv)
{
	status_t status = StatusOk;

    Console_Printf("Milliseconds elapsed: %ld\r\n", SysTime_GetMsElapsed());

	return status;
}

// Public functions bodies ---------------------------------------------------
status_t SysTime_Init(void)
{
    status_t status = StatusOk;

    if (initialized)
        status = StatusAlreadyInitialized;

    if (Status_IsOk(status)) {
        nrfx_timer_config_t config = {
            .frequency = NRF_TIMER_FREQ_1MHz,
            .mode = NRF_TIMER_MODE_TIMER,
            .bit_width = NRF_TIMER_BIT_WIDTH_24,
            .interrupt_priority = NRFX_TIMER_DEFAULT_CONFIG_IRQ_PRIORITY,
            .p_context = NULL
        };
        ret_code_t err_code = nrfx_timer_init(&timer, &config, timerEventHandler);
        if (0 != err_code)
            status = StatusHal;
    }

    if (Status_IsOk(status)) {
        nrfx_timer_extended_compare(&timer, NRF_TIMER_CC_CHANNEL0, TIMEOUT_TICKS, NRF_TIMER_SHORT_COMPARE0_CLEAR_MASK, true);
        nrfx_timer_enable(&timer);

        ms = 0;
        initialized = true;

        status = Console_ExportCommandsToCli(&exportedReg, commandList);
    }

    return returnStatus(status, eSucInitStatus);
}

uint32_t SysTime_GetMsElapsed(void)
{
    return ms;
}

bool SysTime_IsElapsed(uint32_t start, uint32_t duration)
{
    uint32_t currentTime = SysTime_GetMsElapsed();
    uint32_t endTime = start + duration;
    if ((currentTime >= start) && (endTime >= start)) {
        // no overflow
        return (currentTime >= endTime);
    } else if ((currentTime < start) && (endTime < start)) {
        // both are overflowed
        return (currentTime >= endTime);
    } else {
        // only end time is overflowed
        return false; // won't be true until current time overflows + reaches end time
    }
}

status_t SysTime_SetEnabled(bool enable) {
    //TODO error
    if (enable) {
        nrfx_timer_enable(&timer);
    } else {
        nrfx_timer_disable(&timer);
    }

    return StatusOk;
}


/// SAEC Kinetic Vision, Inc. ----------- END OF FILE