/**
  @file       SwUnitControl.h

  @copyright  (C) 2019 Kinetic Vision, Cincinnati Ohio.
               This software is property of SAEC Kinetic Vision, Inc
               and is considered confidential.

  @brief      "SwUnitControl" is the vessel for the software unit config and status info.

  @author     Sherman Couch

  @defgroup   SwUnitControlSoftwareUnit The config and status vessel for the software unit information.

  Configuration History
  =====================

  Config Item    | Value
  -------------- | -----
  Config #       | NA
  Revision       | NA
  Revised, Date  | NA
  QA, Date       | NA
  Approved, Date | NA
  Released, Date | NA

  Significant Modification History (Most recent at top)
  =====================================================

  Date         | Initials | Details
  ------------ | -------- | -------
  28 Jan 2020  | ASL      | Porting from Resbit to Bluebit
  31 Jul 2019  | SC       | Original

  Theory of Operation
  ===================
  - Provides methods and data types for managing configuration of software units and (TBD) peripherals.
  - Provides methods and data types for obtaining status software units and (TBD) peripherals.
  - Presents a CLI interface for viewing and controlling (disabling) software units.

  Design Intent
  =============
  This SU is intended to be very lightweight it its client.  The heavy lifting is done internally to
  the SU itself, which is where the control and display operations take place.  Externally all that
  the client's of this SU need to do is report statuses of read / write and I/O control operations.

  Dependencies
  ============
  This software unit depends upon the "Tc58" flash software units (e.g. logical and physical).

  */

// Define to prevent recursive inclusion -------------------------------------
#ifndef __SW_UNIT_CONTROL_H
#define __SW_UNIT_CONTROL_H

#include <stdint.h> // int types

#include "../StatusSu/Status.h" // status_t

// Exported macro ------------------------------------------------------------

// Exported types ------------------------------------------------------------

typedef enum {
    eSucBle,
    eSucBleAdvert,
    eSucBleDeviceInfoService,
    eSucBleResbitInfoService,
    eSucBleSummaryProto,
    eSucBleSummaryService,
    eSucBleSummaryStore,
    eSucComsControlSu,
    eSucComsProtocolSu,
	eSucConsoleSu,
    eSucCrcSu,
    eSucI2cSlaveSu,
    eSucMessagerSu,
    eSucPacketSu,
    eSucProtocolHalSu,
    eSucProtocolHandlerSu,
    eSucSplitBufferSu,
	eSucSwUnitControlSu,
    eSucSysTimeSu,
	eSucUsartSu,

	// Keep this element last in the list
	SUC_NUMBER_OF_SW_UNITS_LIST

} SwUnitControlId_t;

typedef enum {
	eSucInitStatus,
	eSucReadStatus,
	eSucWriteStatus,
	eSucIoctlStatus,
    eSucTickStatus,

	// Keep this element last in the list
	SUC_NUMBER_OF_STATUS_TYPES,

} SwUnitControlStatusType_t;

// Exported constants --------------------------------------------------------

// Exported objects ----------------------------------------------------------

// Exported functions --------------------------------------------------------

/// @brief   Initializes the SwUnitControl software unit
/// @details This function will only return the values shown.
/// @return  StatusOk
status_t SwUnitControl_Init(void);

/// @brief   	 Writes status information to the SwUnit control
/// @pre     	 "SwUnitControl" must have been initialized.
/// @param[in]	 suId, of type: SwUnitControlId_t
/// @param[in]	 statusType, of type: SwUnitControlStatusType_t
/// @param[in]	 statusIn, of type: status_t
/// @param[in]   lineOfCode
/// @returns	 StatusOk, StatusInvalidIoctlCode, StatusNotInitialized, StatusParameter1, etc.
status_t SwUnitControl_WriteStatus(SwUnitControlId_t suId, SwUnitControlStatusType_t statusType, status_t statusIn, uint16_t lineOfCode);

#endif // __SW_UNIT_CONTROL_H

/// SAEC Kinetic Vision, Inc. ----------- END OF FILE

