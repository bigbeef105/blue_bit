/**
  @file       SplitBuffer.h

  @copyright  (C) 2020 Kinetic Vision, Cincinnati Ohio.
               This software is property of SAEC Kinetic Vision, Inc 
               and is considered confidential.

  @brief      SplitBuffer software unit "H" file.

  @author     Andrew Loebs

  @defgroup   SplitBufferSoftwareUnit

  Configuration History
  =====================

  Config Item    | Value
  -------------- | -----
  Config #       | NA
  Revision       | NA
  Revised, Date  | NA
  QA, Date       | NA
  Approved, Date | NA
  Released, Date | NA

  Significant Modification History (Most recent at top)
  =====================================================

  Date         | Initials | Details
  ------------ | -------- | -------
  29 Jan 2020  | ASL      | Original

  Theory of Operation
  ===================
  Manages a buffer of variable length memory blocks as a queue. Offers the advantage of giving
  each entry contiguous memory. Must be sized for at least 2*n where n is the maximum entry size.

  */

// Define to prevent recursive inclusion -------------------------------------
#ifndef __SPLIT_BUFFER_H
#define __SPLIT_BUFFER_H

#include <stdbool.h> // bool
#include <stdint.h> // int types
#include <stdio.h> // size_t

#include "../StatusSu/Status.h" // status_t

// Exported macro ------------------------------------------------------------

// Exported constants --------------------------------------------------------
#define SBMEMBER_MAX_ENTRIES            6
#define SPLIT_BUFFER_MAX_ENTRIES        SBMEMBER_MAX_ENTRIES * 2

// Exported types ------------------------------------------------------------
typedef struct {
    uint8_t * buffer;
    uint16_t head;
    uint16_t tails[SBMEMBER_MAX_ENTRIES];
} splitMember_t;

typedef struct {
    uint8_t * buffer;
    size_t bufferLen;
    size_t splitLen;

    splitMember_t near;
    splitMember_t far;

    splitMember_t * write;
    splitMember_t * read;
} splitBuffer_t;

// Exported objects ----------------------------------------------------------

// Exported functions --------------------------------------------------------

///  @brief Sets up a split buffer structure
///  @param args[in] sb - Pointer to allocated split buffer
///  @param args[in] bufferMem - pointer to allocated memory region to be used by buffer
///  @param args[in] len - length of buffer memory, should be at least 2 * n where n is max entry length
///  @return StatusOk, StatusNullParameter, StatusBufferLength
status_t SplitBuffer_Setup(splitBuffer_t * sb, uint8_t * bufferMem, size_t len);

///  @brief Attempts to enqueue item in split buffer
///  @param args[in] sb - Pointer to split buffer
///  @param args[in] dataIn - pointer to data to be written to split buffer
///  @param args[in] len - length of data to be written to split buffer
///  @return StatusOk, StatusNullParameter, StatusBufferLength, StatusBufferFull
status_t SplitBuffer_Enqueue(splitBuffer_t * sb, uint8_t * dataIn, size_t len);

///  @brief Attempts to dequeue an item from split buffer
///  @param args[in] sb - Pointer to split buffer
///  @param args[out] dataOut - pointer to buffer to write data out to
///  @param args[in] maxBytes - length of buffer to write data out to
///  @param args[out] bytesWritten - pointer to integer to write #bytes written to buffer
///  @return StatusOk, StatusNullParameter, StatusBufferLength, StatusBufferFull
status_t SplitBuffer_Dequeue(splitBuffer_t * sb, uint8_t * dataOut,
                             size_t maxBytes, size_t * bytesWritten);

///  @brief Returns address and size of head entry of split buffer
///  @param args[in] sb - Pointer to split buffer
///  @param args[out] headPtr - pointer to buffer to write data out to
///  @param args[in] headSize - length of buffer to write data out to
///  @return StatusOk, StatusNullParameter, StatusBufferEmpty
status_t SplitBuffer_GetHead(splitBuffer_t * sb, uint8_t ** headPtr,
                             size_t * headSize);

///  @brief Frees head entry of split buffer
///  @param args[in] sb - Pointer to split buffer
///  @return StatusOk, StatusNullParameter, StatusBufferEmpty
status_t SplitBuffer_FreeHead(splitBuffer_t * sb);

///  @brief Returns true when buffer is empty
bool SplitBuffer_IsEmpty(splitBuffer_t * sb);

#endif // __SPLIT_BUFFER_H

/// SAEC Kinetic Vision, Inc. ----------- END OF FILE
