/**
  @file       Status.h

  @copyright  (C) 2020 Kinetic Vision, Cincinnati Ohio.
               This software is property of SAEC Kinetic Vision, Inc
               and is considered confidential.

  @brief      Status software unit "H" file.

  @author     Andrew Loebs

  @defgroup   StatusSoftwareUnit Status software unit.

  Configuration History
  =====================

  Config Item    | Value
  -------------- | -----
  Config #       | NA
  Revision       | NA
  Revised, Date  | NA
  QA, Date       | NA
  Approved, Date | NA
  Released, Date | NA

  Significant Modification History (Most recent at top)
  =====================================================

  Date         | Initials | Details
  ------------ | -------- | -------
  24 Jan 2020  | ASL      | Original

  Theory of Operation
  ===================
  Exports status_t type

  */

// Define to prevent recursive inclusion -------------------------------------
#ifndef __STATUS_H
#define __STATUS_H

// Exported macro ------------------------------------------------------------

///
/// Returns if the status is ok
///
#define Status_IsOk(status) (status == StatusOk)

///
/// Returns if the status is an error status
///
#define Status_IsError(status) (status != StatusOk)

///
/// Does not overwrite status if already bad (pretty hacky, but it always preserves status & always calls expr)
/// 
#define Status_Preserve(status, expr) ((StatusOk == (status)) ? (expr) : ((expr) == (status)) ? (status) : (status))

// Exported types ------------------------------------------------------------
typedef enum {
	StatusOk = 0,
	StatusParameter1,
	StatusParameter2,
	StatusParameter3,
	StatusParameter4,
	StatusParameter5,
	StatusParameter6,
	StatusParameter7,
	StatusParameter8,
	StatusParameterValue,

	StatusNotInitialized = 10,
	StatusAlreadyInitialized,
	StatusCarriageReturn,
	StatusAlreadyLinked,
	StatusClosed,
	StatusHal,
	StatusHalTimeout,
	StatusCommandNotFound,
	StatusDeviceId,
    StatusCodePath,

    StatusComsCRC = 20,
    StatusComsInvalidNumPackets,
    StatusComsInvalidPacketNum,
    StatusComsInvalidDataLen,
    StatusComsPacketOrder,
    StatusComsDataLenMismatch,
    StatusComsReceiveTimeout,
    StatusComsSendTimeout,
    StatusComsUnknown,
    StatusComsResponseError,

    StatusBufferUndersized = 30,
    StatusBufferFull,
    StatusBufferEmpty,
    StatusNullParameter,
    StatusBufferLength,
    StatusWriteAlreadyPending,
    StatusInvalidSize,
    StatusInvalidState,
    StatusIndexOOR,    
    StatusNeedMoreTime,

    StatusNrfError = 50,
    StatusNrfNotQueueFull,
    
    StatusMessageId = 60,
	StatusMessageData,
	StatusMessageNotReceived,
    
    StatusDataCorruption = 70,

	StatusGenericError = 100, // TODO: replace uses of this with more descriptive errors


} status_t;

// Exported constants --------------------------------------------------------

// Exported objects ----------------------------------------------------------

// Exported functions --------------------------------------------------------


#endif // __STATUS_H

/// SAEC Kinetic Vision, Inc. ----------- END OF FILE


