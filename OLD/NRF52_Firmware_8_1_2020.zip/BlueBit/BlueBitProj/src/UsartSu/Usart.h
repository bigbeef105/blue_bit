/**
  @file       usart.h

  @copyright  (C) 2019 Kinetic Vision, Cincinnati Ohio.
               This software is property of SAEC Kinetic Vision, Inc
               and is considered confidential.

  @brief      USART software unit "H" file.

  @author     Sherman Couch

  @defgroup   UsartSoftwareUnit Software handler for sending and receiving usart data

  Configuration History
  =====================

  Config Item    | Value
  -------------- | -----
  Config #       | NA
  Revision       | NA
  Revised, Date  | NA
  QA, Date       | NA
  Approved, Date | NA
  Released, Date | NA

  Significant Modification History (Most recent at top)
  =====================================================

  Date         | Initials | Details
  ------------ | -------- | -------
  28 Jan 2020  | ASL      | Porting from Resbit to Bluebit
  22 Jul 2019  | SC       | Original

  Theory of Operation
  ===================
  Usart communication will be needed for handling console commands and responses.

  */

// Define to prevent recursive inclusion -------------------------------------
#ifndef __USART_SU_H
#define __USART_SU_H

#include <stdint.h> // int types

#include "../StatusSu/Status.h" // status_t

// Exported macro ------------------------------------------------------------

// Exported types ------------------------------------------------------------

// Exported constants --------------------------------------------------------

// Exported objects ----------------------------------------------------------

// Exported functions --------------------------------------------------------

///  @brief Initializes the usart software unit
///  @return StatusOk, StatusAlreadyInitialized, StatusHal
status_t Usart_Init(void);

///  @brief DeInitializes the usart software unit
///  @return StatusOk, StatusHal
status_t Usart_DeInit (void);

///  @brief Write to the usart buffer
///  @param args[out] pBuffer - Pointer to send buffer
///  @param args[in] length - number of bytes to write
///  @return StatusOk, StatusHal
status_t Usart_Write(uint8_t *pBuffer, uint16_t length);

///  @brief Read from the usart buffer
///  @param args[out] pBuffer - Pointer to receive buffer
///  @param args[in] length - number of bytes to read
///  @param args[out] pBytesRead - number of bytes read
///  @return StatusOk, StatusHal
status_t Usart_Read(uint8_t *pBuffer, uint16_t length, uint16_t *pBytesRead);

#endif // __USART_SU_H

/// SAEC Kinetic Vision, Inc. ----------- END OF FILE
