/**
  @file       ProtocolHal.c

  @copyright  (C) 2020 Kinetic Vision, Cincinnati Ohio.
               This software is property of SAEC Kinetic Vision, Inc
               and is considered confidential.

  @brief      ProtocolHal software unit "C" file.

  @author     Andrew Loebs

  @ingroup    ProtocolHalSoftwareUnit

  Configuration History
  =====================

  Config Item    | Value
  -------------- | -----
  Config #       | NA
  Revision       | NA
  Revised, Date  | NA
  QA, Date       | NA
  Approved, Date | NA
  Released, Date | NA

  Significant Modification History (Most recent at top)
  =====================================================

  Date         | Initials | Details
  ------------ | -------- | -------
  02 Feb 2020  | ASL      | Original

  Theory of Operation
  ===================
  Abstracts interaction with I2C/GPIO pin in Resbit/Bluebits coms

*/

// Includes ------------------------------------------------------------------

#include "ProtocolHal.h"

#include "nrf_gpio.h"
#include "nrfx_gpiote.h"

#include "../SwUnitControlSu/SwUnitControl.h" // SwUnitControl_WriteStatus()
#include "../I2cSlaveSu/I2cSlave.h" // I2cSlave_* functions

// Private function prototypes -----------------------------------------------
static status_t gpioPinInit(void);
static status_t indicationPinInit(void);
static void indicationPinSet(void);
static void indicationPinClear(void);

void gpioIntHandler(nrfx_gpiote_pin_t pin, nrf_gpiote_polarity_t action);

// Private macros ------------------------------------------------------------
#define returnStatus(__status__,__source__) SwUnitControl_WriteStatus(eSucProtocolHalSu,__source__,__status__,__LINE__);

// Private constants ---------------------------------------------------------
#define GPIO_PIN                    20
#define INDICATION_PIN              18

// Private types -------------------------------------------------------------

// Private constants ---------------------------------------------------------

// Private variables ---------------------------------------------------------
static bool initialized = false;
static bool writeInProgress = false;

// Private function bodies ---------------------------------------------------
static status_t gpioPinInit(void)
{
    status_t status = StatusOk;

    nrfx_gpiote_in_config_t inConfig = NRFX_GPIOTE_CONFIG_IN_SENSE_TOGGLE(true);
    uint32_t errCode = nrfx_gpiote_in_init(GPIO_PIN, &inConfig, gpioIntHandler);
    
    if (0 == errCode) {
        nrfx_gpiote_in_event_enable(GPIO_PIN, true);
    } else {
        status = StatusHal;
    }
    
    return status;
}

static status_t indicationPinInit(void)
{
    nrf_gpio_cfg_output(NRF_GPIO_PIN_MAP(0, INDICATION_PIN));
    indicationPinClear();

    return StatusOk; // HAL function returns void
}

static void indicationPinSet(void)
{
    nrf_gpio_pin_set(NRF_GPIO_PIN_MAP(0, INDICATION_PIN));
}

static void indicationPinClear(void)
{
    nrf_gpio_pin_clear(NRF_GPIO_PIN_MAP(0, INDICATION_PIN));
}

void gpioIntHandler(nrfx_gpiote_pin_t pin, nrf_gpiote_polarity_t action)
{
    uint32_t pinState = nrf_gpio_pin_read(GPIO_PIN);
    if (pinState != 0) {
        I2cSlave_Init();
    } else {
        I2cSlave_DeInit();
    }
}

// Public functions bodies ---------------------------------------------------
status_t ProtocolHal_Init(void)
{
    status_t status = StatusOk;

    if (initialized)
        status = StatusAlreadyInitialized;

    status = gpioPinInit();
    if (Status_IsOk(status)) {
        status = indicationPinInit();
    }
    if (Status_IsOk(status)) {
        initialized = true;
        writeInProgress = false;
    }

    return status;
}

status_t ProtocolHal_Tick(bool* needMoreTime)
{
    status_t status = StatusOk;

    if (initialized && writeInProgress) {
        if (I2cSlave_IsWriteReady()) {
            indicationPinClear();
            writeInProgress = false;
        }

        *needMoreTime = true;
    }

    return status;
}

bool ProtocolHal_HasPacket(void)
{
    return (I2cSlave_GetRxCount() > PACKET_HEADER_LEN);
}

status_t ProtocolHal_GetPacket(packet_t * out, size_t * outLen)
{
    status_t status = StatusOk;

    // Input validation
    if (out == NULL)
        status = StatusNullParameter;
    
    if (Status_IsOk(status)) {
        status = I2cSlave_GetRx(out->bytes, outLen, PACKET_LEN);
    }

    return status;
}

bool ProtocolHal_HasResponse(void)
{
    return (I2cSlave_GetRxCount() >= RESPONSE_LEN);
}

status_t ProtocolHal_GetResponse(response_t * out)
{
    status_t status = StatusOk;

    // Input validation
    if (out == NULL)
        status = StatusNullParameter;
    
    if (Status_IsOk(status)) {
        size_t lenCopied = 0;
        status = I2cSlave_GetRx(out->bytes, &lenCopied, RESPONSE_LEN);
    }

    return status;
}

bool ProtocolHal_IsWriteDone(void)
{
    return !writeInProgress;
}

status_t ProtocolHal_WritePacket(packet_t * packet)
{
    status_t status = StatusOk;

    I2cSlave_ClearWritePending();
    size_t len = PACKET_HEADER_LEN + packet->dataLen;
    status = I2cSlave_PrepareWrite(packet->bytes, len);

    if (Status_IsOk(status)) {
        indicationPinSet();
        writeInProgress = true;
    }

    return status;
}

status_t ProtocolHal_WriteResponse(response_t * response)
{
    status_t status = StatusOk;

    I2cSlave_ClearWritePending();
    status = I2cSlave_PrepareWrite(response->bytes, RESPONSE_LEN);

    if (Status_IsOk(status)) {
        indicationPinSet();
        writeInProgress = true;
    }

    return status;
}

void ProtocolHal_Reset(void)
{
    I2cSlave_ResetRx();
    I2cSlave_ClearWritePending();

    indicationPinClear();
    writeInProgress = false;
}

/// SAEC Kinetic Vision, Inc. ----------- END OF FILE