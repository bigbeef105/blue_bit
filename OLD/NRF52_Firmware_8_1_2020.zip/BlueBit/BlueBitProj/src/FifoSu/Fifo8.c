/**
 ******************************************************************************
 * @file    Fifo8.c
 * @brief   Fifo8 software unit's primary C module.
 * @author  Sherman Couch
 * @date    25 Oct 2018
 * @ingroup Fifo8SoftwareUnit
 ******************************************************************************
 *
 * @copyright COPYRIGHT (c) 2018 SAEC Kinetic Vision, Inc
 *            All Rights Reserved
 *
 * This software is property of SAEC Kinetic Vision, Inc and is considered
 * confidential.
 *
 ******************************************************************************
 *
 * Significant Modification History (Most Recent at top)
 * -----------------------------------------------------
 *
 * Date        | Initials | Description
 * ----------- | -------- | -----------
 * 12 Nov 2018 | SC       | Tried and true old school Fifo8 logic.
 *
 * Theory of Operation
 * -------------------
 * TBD
 *
 *
 *
 */

// Includes ------------------------------------------------------------------
#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>
#include <string.h>

#include "status.h"
#include "Fifo8.h"


// Private constants ---------------------------------------------------------

// Private macro -------------------------------------------------------------

#define SETUP_SIGNATURE 0x55AA

// Private types -------------------------------------------------------------

// Private variables ---------------------------------------------------------

// Private function prototypes -----------------------------------------------

// Private functions ---------------------------------------------------------

static void UpdateAvailable(Fifo8_t* q) {
    int32_t used = q->head - q->tail;
    if (used < 0) used += q->Size;
    q->Available = (q->Size - 1) - used;
}

static status_t Put(Fifo8_t* q, uint8_t value) {
    //
    // Insert at head.
    //

    q->Buffer[q->head] = value;

    //
    // Adjust head pointer, wrap pointer as required.
    //
    q->head++;
    if (q->head >= q->Size) q->head = 0;
    UpdateAvailable(q);
    return StatusOk;
}

static status_t Take(Fifo8_t* q, uint8_t* value) {
    //
    // Adjust tail pointer, wrap pointer as required.
    //

    uint16_t tail;
    tail = q->tail;
    *value = q->Buffer[tail];

    tail++;
    if (tail >= q->Size) {
        tail = 0;
    }

    q->tail = tail;
    UpdateAvailable(q);

    return StatusOk;
}

// Public functions --------------------------------------------------------

status_t Fifo8_FlushQueueByProducer(Fifo8_t *q) {
    if (NULL == q) return StatusNullParameter;
    if (Status_IsError(q->Status)) return q->Status;

    // Zaps all data in queue.
    q->head = q->tail;

    UpdateAvailable(q);

    return StatusOk;
}

status_t Fifo8_FlushQueueByConsumer(Fifo8_t *q) {
    if (NULL == q) return StatusNullParameter;
    if (Status_IsError(q->Status)) return q->Status;

    // Zaps all data in queue.
    q->tail = q->head;

    UpdateAvailable(q);

    return StatusOk;
}

status_t Fifo8_ReturnStatus(Fifo8_t *q) {
    if (NULL == q) return StatusNullParameter;
    if (Status_IsError(q->Status)) return q->Status;
    if ((q->head) == (q->tail)) return StatusBufferEmpty;

    if (q->Available) return StatusBufferFull;

    return StatusOk;
}

status_t Fifo8_ReturnAvailable(Fifo8_t *q, int32_t *pAvailable) {
    if (NULL == q || pAvailable == NULL) return StatusNullParameter;
    if (Status_IsError(q->Status)) return q->Status;

    *pAvailable = q->Available;

    return StatusOk;
}

status_t Fifo8_ReturnUsed(Fifo8_t *q, uint16_t *pUsed) {
    if (NULL == q || pUsed == NULL) return StatusNullParameter;
	if (Status_IsError(q->Status)) return q->Status;

    *pUsed = (uint16_t) (q->Size - 1) - q->Available;
    return StatusOk;
}

status_t Fifo8_Insert(Fifo8_t *q, uint8_t c) {
    if (NULL == q) return StatusNullParameter;
	if (Status_IsError(q->Status)) return q->Status;
    if (q->Available <= 0) return StatusBufferFull;

    Put(q, c);

    return StatusOk;
}

status_t Fifo8_Remove(Fifo8_t *q, uint8_t *c) {
    status_t status = Fifo8_PeekFront(q, c);
    if (Status_IsError(status)) return status;

    Take(q, c);

    return StatusOk;

} // Fifo8_Remove()

status_t Fifo8_PeekFront(Fifo8_t *q, uint8_t *c) {
    if (NULL == q) return StatusNullParameter;
    if (Status_IsError(q->Status)) return q->Status;

    //
    // Leave if no new data...
    //

    if ((q->head) == (q->tail)) return StatusBufferEmpty;

    //
    // remove from tail.
    //
    *c = q->Buffer[q->tail];

    return StatusOk;
} // fifi_PeekFront()

status_t Fifo8_PeekTail(Fifo8_t *q, uint8_t *c) {
    if (NULL == q || c == NULL) return StatusNullParameter;
    if (Status_IsError(q->Status)) return q->Status;

    //
    // Leave if no new data...
    //

    if ((q->head) == (q->tail)) return StatusBufferEmpty;

    //
    // grab value at head
    //

    uint16_t head;
    head = q->head;

    uint16_t idx = head == 0 ? q->Size : head;
    idx -= 1;

    *c = q->Buffer[idx];
    return StatusOk;
}

status_t Fifo8_SetupQueObject(Fifo8_t * q, uint8_t* data, uint16_t size) {
    if (NULL == q || data == NULL) return StatusNullParameter;
    if (q->Status != StatusNotInitialized) return StatusAlreadyInitialized;

    q->head = 0;
    q->tail = 0;
    q->Buffer = data;

    // Mark overflow signature
    q->Buffer[size - 1] = 0xAA;
    q->Buffer[size - 2] = 0x55;

    q->Size = size - 2;
    q->Status = StatusOk;
    q->Available = q->Size - 1;
    return StatusOk;
}

status_t Fifo8_Enqueue(Fifo8_t *q, const uint8_t* c, uint16_t numBytes) {
    if (NULL == q || c == NULL) return StatusNullParameter;
    if (Status_IsError(q->Status)) return q->Status;
    if (q->Available < numBytes) return StatusBufferFull;

    int i;
    for(i = 0; i < numBytes; i++) Put(q, c[i]);

    return StatusOk;
}

status_t Fifo8_Dequeue(Fifo8_t *q, uint16_t numBytes, uint8_t *c) {
    if (NULL == q || c == NULL) return StatusNullParameter;
    if (Status_IsError(q->Status)) return q->Status;

    uint16_t used;
    status_t ret = Fifo8_ReturnUsed(q, &used);
    if (Status_IsError(ret)) return ret;

    //TODO check this error
    if (used < numBytes) return StatusBufferEmpty;

    int i;
    for(i = 0; i < numBytes; i++) Take(q, c + i);

    return StatusOk;
}

status_t Fifo8_FlushBytes(Fifo8_t *q, uint16_t numBytes) {
    if (NULL == q) return StatusNullParameter;
    if (Status_IsError(q->Status)) return q->Status;

    status_t ret = StatusOk;

    uint16_t numToFlush = numBytes;
    uint16_t used;
    ret = Fifo8_ReturnUsed(q, &used);
    if (used < numBytes) {
        numToFlush = used;
    }

    while (numToFlush--) {
        uint8_t temp;
        ret = Fifo8_Remove(q, &temp);
    }

    return ret;
}

status_t Fifo8_Peek(Fifo8_t *q, uint8_t* data, uint16_t numBytes, uint16_t offset) {
    if (NULL == q || data == NULL) return StatusNullParameter;
    if (Status_IsError(q->Status)) return q->Status;

    uint16_t used;
    status_t ret = Fifo8_ReturnUsed(q, &used);

    uint16_t numPeek = numBytes;
    if (used < numBytes) {
        numPeek = used;
    }

    uint16_t start = q->tail + offset;

    if (start >= q->Size) {
        start -= q->Size;
    }

    if (start > q->head && start + numPeek >= q->Size) {
        uint16_t numCopied = q->Size - start;
        memcpy(data, q->Buffer + start, numCopied);
        memcpy(data + numCopied, q->Buffer, numPeek - numCopied);
    } else {
        memcpy(data, q->Buffer + start, numPeek);
    }

    return ret;
}
