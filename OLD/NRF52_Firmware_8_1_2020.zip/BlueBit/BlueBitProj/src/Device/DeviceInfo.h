/**
  @file       DeviceInfo.h

  @copyright  (C) 2020 Kinetic Vision, Cincinnati Ohio.
               This software is property of SAEC Kinetic Vision, Inc
               and is considered confidential.

  @brief      DeviceInfo software unit "H" file.

  @author     Jeffrey Hatton

  @defgroup   DeviceInfo Software unit for storing information about the device.

  Configuration History
  =====================

  Config Item    | Value
  -------------- | -----
  Config #       | NA
  Revision       | NA
  Revised, Date  | NA
  QA, Date       | NA
  Approved, Date | NA
  Released, Date | NA

  Significant Modification History (Most recent at top)
  =====================================================

  Date         | Initials | Details
  ------------ | -------- | -------
  03 FEB 2020  | JH       | Original

  Theory of Operation
  ===================
  TBD

  */

// Define to prevent recursive inclusion -------------------------------------
#ifndef __DEVICE_INFO_H
#define __DEVICE_INFO_H

#include <stdint.h>

#include "../StatusSu/Status.h"

// Exported macro ------------------------------------------------------------
#define SERIAL_NUM_SIZE			sizeof(serialNum_t)
#define SERIAL_NUM_WORDS		3

// Exported types ------------------------------------------------------------
typedef union {
  uint32_t whole;
  struct {
    uint8_t build;
    uint8_t revision;
    uint8_t minor;
    uint8_t major;
  };
} version_t;

typedef union {
	uint8_t bytes[SERIAL_NUM_WORDS * sizeof(uint32_t)];
	uint32_t words[SERIAL_NUM_WORDS];
} serialNum_t;

// Exported constants --------------------------------------------------------
#define MODEL_NUM                       "10"
#define SERIAL_NUM                      "22356"

#define DEVICE_NAME                     "ResBit"

//TODO should this be P&G
#define MANUFACTURER_NAME               "Kinetic Vision"

//TODO determine what these should be
#define MANUFACTURER_ID                 0x1122334455
#define ORG_UNIQUE_ID                   0x667788

// Exported objects ----------------------------------------------------------

// Exported functions --------------------------------------------------------

/// Initializes device info
status_t DeviceInfo_Init(void);

/// Returns pointer to numeric hardware version
/// @param args[out] version - version_t to modify
status_t DeviceInfo_GetHardwareVersion(version_t *version);

/// Returns pointer to numeric software version
/// @param args[out] version - version_t to modify
status_t DeviceInfo_GetSoftwareVersion(version_t *version);

/// Returns pointer to numeric firmware version
/// @param args[out] version - version_t to modify
status_t DeviceInfo_GetFirmwareVersion(version_t *version);

/// Returns pointer to hardware version string
/// @param args[out] str - pointer to write address of version string
status_t DeviceInfo_GetHardwareVersionStr(char **str);

/// Returns pointer to software version string
/// @param args[out] str - pointer to write address of version string
status_t DeviceInfo_GetSoftwareVersionStr(char **str);

/// Returns pointer to firmware version string
/// @param args[out] str - pointer to write address of version string
status_t DeviceInfo_GetFirmwareVersionStr(char **str);



#endif // __DEVICE_INFO_H

/// SAEC Kinetic Vision, Inc. ----------- END OF FILE


