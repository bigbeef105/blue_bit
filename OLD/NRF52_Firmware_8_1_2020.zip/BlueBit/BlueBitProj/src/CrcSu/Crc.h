/**
  @file       Crc.h

  @copyright  (C) 2020 Kinetic Vision, Cincinnati Ohio.
               This software is property of SAEC Kinetic Vision, Inc 
               and is considered confidential.

  @brief      Crc software unit "H" file.

  @author     Andrew Loebs

  @defgroup   CrcSoftwareUnit Calculates CRCs

  Configuration History
  =====================

  Config Item    | Value
  -------------- | -----
  Config #       | NA
  Revision       | NA
  Revised, Date  | NA
  QA, Date       | NA
  Approved, Date | NA
  Released, Date | NA

  Significant Modification History (Most recent at top)
  =====================================================

  Date         | Initials | Details
  ------------ | -------- | -------
  29 Jan 2020  | ASL      | Original

  Theory of Operation
  ===================
  Calculates CRCs

  */

// Define to prevent recursive inclusion -------------------------------------
#ifndef __CRC_H
#define __CRC_H

#include <stdint.h> // int types
#include <stdio.h> // size_t

#include "../StatusSu/Status.h" // status_t

// Exported macro ------------------------------------------------------------

// Exported types ------------------------------------------------------------

// Exported constants --------------------------------------------------------
#define CRC_SEED            0xFFFF;

// Exported objects ----------------------------------------------------------

// Exported functions --------------------------------------------------------
  
///  @brief Creates a packet with the specified data.
///  @param args[out] crc - crc value to be updated (should be set to CRC_SEED if new crc)
///  @param args[in] values - pointer to data buffer to calculate crc from
///  @param args[in] len - length of data buffer
///  @return StatusOk, StatusNullParameter, StatusBufferLength.
status_t Crc_Calc(uint16_t * crc, const uint8_t * values, size_t len);

#endif // __CRC_H

/// SAEC Kinetic Vision, Inc. ----------- END OF FILE
