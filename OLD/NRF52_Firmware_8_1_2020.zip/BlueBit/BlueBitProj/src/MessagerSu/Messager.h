/**
  @file       Messager.h

  @copyright  (C) 2020 Kinetic Vision, Cincinnati Ohio.
               This software is property of SAEC Kinetic Vision, Inc
               and is considered confidential.

  @brief      Messager software unit "H" file.

  @author     Andrew Loebs

  @defgroup   MessagerSoftwareUnit Handles 'message layer' of Resbit/Bluebits communication.

  Configuration History
  =====================

  Config Item    | Value
  -------------- | -----
  Config #       | NA
  Revision       | NA
  Revised, Date  | NA
  QA, Date       | NA
  Approved, Date | NA
  Released, Date | NA

  Significant Modification History (Most recent at top)
  =====================================================

  Date         | Initials | Details
  ------------ | -------- | -------
  24 Jan 2020  | ASL      | Original

  Theory of Operation
  ===================
  Handles 'message layer' of Resbit/Bluebits communication.

  */

// Define to prevent recursive inclusion -------------------------------------
#ifndef __MESSAGER_H
#define __MESSAGER_H

#include <stdint.h> // int types
#include <stdio.h> // size_t

#include "../StatusSu/Status.h"

// Exported macro ------------------------------------------------------------

// Exported types ------------------------------------------------------------
typedef enum {
	messageResponseSuccess = 0,
	messageResponseIdError,
	messageResponseDataError,

	messageResponseNotReceived = 0x7F
} messageResponseCode_t;

typedef struct {
	const uint8_t * messageData;
	const size_t dataLen;

	messageResponseCode_t resCode;
	uint8_t * resBuffer;
	const size_t resBufferLen;
	size_t bytesWritten;
} messageHandlerArgs_t;

typedef struct {
	messageResponseCode_t resCode;
	uint8_t * data;
	size_t len;
} responseHandlerArgs_t;

typedef status_t (*messageHandler_t)(messageHandlerArgs_t * args);

typedef status_t (*responseHandler_t)(responseHandlerArgs_t * args);

typedef struct {
	const uint16_t messageId;
	const uint8_t * messageData;
	const size_t dataLen;
	responseHandler_t resHandler;
} sendMessageAsyncArgs_t;

typedef const struct {
	uint16_t messageId;
	messageHandler_t handler;
} messageHandlerReg_t;

typedef struct messageHandlerList_s {
	messageHandlerReg_t const * handlers; // must be null terminated
	struct messageHandlerList_s * next;
} messageHandlerList_t;

// Exported constants --------------------------------------------------------
#define MESSAGE_DATA_OFFSET         	2
#define MESSAGE_MAX_DATA_LEN        	(MESSAGE_MAX_LEN - MESSAGE_DATA_OFFSET)
#define MESSAGE_RES_CODE_LEN			1

// Exported objects ----------------------------------------------------------

// Exported functions --------------------------------------------------------

///  @brief Initializes the Messager software unit
///  @return StatusOk, StatusAlreadyInitialized.
status_t Messager_Init();

///  @brief Gives foreground execution time to this software unit
status_t Messager_Tick();

///  @brief Registers handler functions for specified message Id's
///  @param args[in] messageHandlerList - Pointer to message list node structure
///   handlers - array of messageHandler_t structs, MUST BE NULL TERMINATED
///   next - ignored (will be overwritten)
///  @return StatusOk, StatusNullParameter
status_t Messager_Subscribe(messageHandlerList_t * messageHandlerList);

///  @brief Parses message data, calls handler function
///  @param args[in] buffer - pointer to message buffer
///  @param args[in] len - length of message
///  @return StatusOk, StatusNullParameter, StatusBufferLength
status_t Messager_HandleMessage(uint8_t * buffer, size_t len);

///  @brief Sends message through Resbit/Bluebit coms
///  @param args[in] args - pointer to sendMessageAsyncArgs structure
///   messageId - id associated with the message
///   messageData - pointer to message data buffer
///   dataLen - length of message data buffer
///   resHandler - pointer to response handler function
status_t Messager_SendMessageAsync(sendMessageAsyncArgs_t * args);

///  @brief Converts response code into a status_t
///  @param args[in] resCode - response code to be transformed
///  @return status
status_t Messager_ResCodeToStatus(messageResponseCode_t resCode);

#endif // __MESSAGER_H

/// SAEC Kinetic Vision, Inc. ----------- END OF FILE
