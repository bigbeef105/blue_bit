/**
  @file       ResBitSummaryDebugService.c

  @copyright  (C) 2020 Kinetic Vision, Cincinnati Ohio.
               This software is property of SAEC Kinetic Vision, Inc
               and is considered confidential.

  @brief      ResBitSummaryDebugService software unit "C" file.

  @author     Jeffrey Hatton

  @ingroup    BLE

  Configuration History
  =====================

  Config Item    | Value
  -------------- | -----
  Config #       | NA
  Revision       | NA
  Revised, Date  | NA
  QA, Date       | NA
  Approved, Date | NA
  Released, Date | NA

  Significant Modification History (Most recent at top)
  =====================================================

  Date         | Initials | Details
  ------------ | -------- | -------
  13 FEB 2020  | JH       | Original

  Theory of Operation
  ===================
  TBD

*/

// Includes ------------------------------------------------------------------

#include <string.h>
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <stdbool.h>

#include "../SwUnitControlSu/SwUnitControl.h"
#include "ResBitSummaryDebugService.h"
#include "BlueBitBle.h"
#include "SummaryProto.h"
#include "../ConsoleSu/Console.h"

// Private function prototypes -----------------------------------------------

//static status_t cliSetDataReady(uint16_t argc, uint8_t **argv);

// Private macros ------------------------------------------------------------

#define GET_VALUE_HANDLE(charIndex) (_SumaryService.CharHandles[charIndex].value_handle)

// Private constants ---------------------------------------------------------

///
/// Length of the data characteristic
///
#define DATA_LEN SUMMARY_PROTO_PACKET_TOTAL_SIZE

///
/// Length of the response characteristic
///
#define RESPONSE_LEN 20

// Private types -------------------------------------------------------------

typedef struct {
    ble_gatts_char_handles_t CharHandles[ResBitSummaryDebug_Count];
    uint16_t    service_handle;
} ResBitSummaryDebugService_t;

// Private constants ---------------------------------------------------------

// Private variables ---------------------------------------------------------

///
/// If the software unit is initialized
///
static bool _IsInitialized = false;

static ResBitSummaryDebugService_t _SumaryService;

// Private function bodies ---------------------------------------------------

static status_t SetupFakeDataChar(void) {
    status_t ret = StatusOk;
    uint32_t nrfRet;
    ble_add_char_params_t  charParams;

    ZERO_OBJECT(charParams);

    ret = Ble_GetVendorUuidType(&charParams.uuid_type);
    if (Status_IsError(ret)) return ret;

    charParams.uuid              = BLE_SUMMARY_DEBUG_SERVICE_FAKE_DATA_CHAR_UUID;
    charParams.max_len           = 1;
    charParams.init_len          = 1;
    charParams.p_init_value      = 0;

    charParams.char_props.write   = 1;
    charParams.cccd_write_access = SEC_OPEN;
    charParams.read_access       = SEC_OPEN;
    charParams.write_access = SEC_OPEN;

    nrfRet = characteristic_add(_SumaryService.service_handle,
                                  &charParams,
                                  _SumaryService.CharHandles + ResBitSummaryDebug_FakeDataSet);
    if (NRF_IS_ERROR(nrfRet)) {
        Console_PrintLine("NRF Error when setting up fake data Char: 0x%0.8x", nrfRet);
        ret = StatusNrfError;
    }

    return ret;
}

static status_t SetupNrfCharacteristics(void) {
    status_t ret = StatusOk;

    ret = SetupFakeDataChar();

    return ret;
}

static status_t SetupNrfService(void) {
    status_t ret = StatusOk;
    uint32_t nrfRet;
    ble_uuid_t serviceUuid;

    // Build the service UUID
    serviceUuid.uuid = BLE_SUMMARY_DEBUG_SERVICE_UUID;
    ret = Ble_GetVendorUuidType(&serviceUuid.type);
    if (Status_IsError(ret)) return ret;

    nrfRet = sd_ble_gatts_service_add(BLE_GATTS_SRVC_TYPE_PRIMARY,
                                      &serviceUuid,
                                      &_SumaryService.service_handle);
    if (NRF_IS_ERROR(nrfRet)) {
        Console_PrintLine("NRF Error when adding Summary Debug Service: 0x%0.8x", nrfRet);
        ret = StatusNrfError;
    }

    if (Status_IsOk(ret)) {
        ret = SetupNrfCharacteristics();
    }

    return ret;
}

static void BleWriteHandler(ble_evt_t const * p_ble_evt)
{
    ble_gatts_evt_write_t const * p_evt_write = &p_ble_evt->evt.gatts_evt.params.write;

    status_t ret = StatusOk;

    if (p_evt_write->handle == GET_VALUE_HANDLE(ResBitSummaryDebug_FakeDataSet)) {
        if (p_evt_write->len == 1) {
            ret = SummaryDataGen_FakeData(p_evt_write->data[0]);
                //TODO error checks
        }
    }
}

void SummaryDebug_BleWriteHandler(ble_evt_t const * p_ble_evt, void * p_context) {
    switch (p_ble_evt->header.evt_id)
    {
        case BLE_GATTS_EVT_WRITE:
            BleWriteHandler(p_ble_evt);
            break;
        default:
            // No implementation needed.
            break;
    }
}

// Public functions bodies ---------------------------------------------------

status_t ResBitSummaryDebugService_Init(void) {
    status_t ret = StatusOk;

    ret = SetupNrfService();
    if (Status_IsError(ret)) return ret;

    NRF_SDH_BLE_OBSERVER(ResBitDebugSummaryService_obs,
                     BLE_LBS_BLE_OBSERVER_PRIO,
                     SummaryDebug_BleWriteHandler, NULL);

    if (Status_IsOk(ret)) {
        _IsInitialized = true;
    }

    return ret;
}

/// SAEC Kinetic Vision, Inc. ----------- END OF FILE
