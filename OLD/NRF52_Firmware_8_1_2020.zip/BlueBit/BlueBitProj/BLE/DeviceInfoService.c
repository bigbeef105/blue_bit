/**
  @file       DeviceInfoService.c

  @copyright  (C) 2020 Kinetic Vision, Cincinnati Ohio.
               This software is property of SAEC Kinetic Vision, Inc
               and is considered confidential.

  @brief      DeviceInfoService software unit "C" file.

  @author     Jeffrey Hatton

  @ingroup    DeviceInfoService

  Configuration History
  =====================

  Config Item    | Value
  -------------- | -----
  Config #       | NA
  Revision       | NA
  Revised, Date  | NA
  QA, Date       | NA
  Approved, Date | NA
  Released, Date | NA

  Significant Modification History (Most recent at top)
  =====================================================

  Date         | Initials | Details
  ------------ | -------- | -------
  03 FEB 2020  | JH       | Original

  Theory of Operation
  ===================
  TBD

*/

// Includes ------------------------------------------------------------------

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

#include "ble_dis.h"

#include "../SwUnitControlSu/SwUnitControl.h"
#include "../ConsoleSu/Console.h"
#include "../Device/DeviceInfo.h"
#include "BlueBitBle.h"
#include "DeviceInfoService.h"

// Private function prototypes -----------------------------------------------

// Private macros ------------------------------------------------------------

#define returnStatus(__status__,__source__) SwUnitControl_WriteStatus(eSucBleDeviceInfoService,__source__,__status__,__LINE__);

// Private constants ---------------------------------------------------------

// Private types -------------------------------------------------------------

// Private constants ---------------------------------------------------------

// Private variables ---------------------------------------------------------

///
/// If the software unit has been initialized
///
static bool _IsInitialized = false;

// Private function bodies ---------------------------------------------------

///  @brief Initializes NRF components for the device info service
static status_t SetupNrfService(void) {
    status_t ret = StatusOk;
    uint32_t nrfRet;

    ble_dis_init_t     dis_init;
    ble_dis_sys_id_t   sys_id;
    ZERO_OBJECT(dis_init);

    ble_srv_ascii_to_utf8(&dis_init.manufact_name_str, MANUFACTURER_NAME);
    ble_srv_ascii_to_utf8(&dis_init.model_num_str, MODEL_NUM);
    ble_srv_ascii_to_utf8(&dis_init.serial_num_str, SERIAL_NUM);

    char * firmwareVersion;
    char * hardwareVersion;
    char * softwareVersion;
    ret = DeviceInfo_GetFirmwareVersionStr(&firmwareVersion);
    if (Status_IsOk(ret)) {
        ret =  DeviceInfo_GetHardwareVersionStr(&hardwareVersion);
    }
    if (Status_IsOk(ret)) {
        ret =  DeviceInfo_GetSoftwareVersionStr(&softwareVersion);
    }
    if (Status_IsOk(ret)) {
        ble_srv_ascii_to_utf8(&dis_init.fw_rev_str, firmwareVersion);
        ble_srv_ascii_to_utf8(&dis_init.hw_rev_str, hardwareVersion);
        ble_srv_ascii_to_utf8(&dis_init.sw_rev_str, softwareVersion);

        sys_id.manufacturer_id            = MANUFACTURER_ID;
        sys_id.organizationally_unique_id = ORG_UNIQUE_ID;
        dis_init.p_sys_id                 = &sys_id;

        dis_init.dis_char_rd_sec = SEC_OPEN;

        nrfRet = ble_dis_init(&dis_init);
    }
    if (NRF_IS_ERROR(nrfRet)) {
        Console_PrintLine("NRF Error when setting up Device Info Service: 0x%0.8x", nrfRet);
        ret = StatusNrfError;
    }

    return ret;
}

// Public functions bodies ---------------------------------------------------

status_t DeviceInfoService_Init(void) {
    status_t ret = StatusOk;

    ret = SetupNrfService();

    if (Status_IsOk(ret)) {
        _IsInitialized = true;
    }

    return returnStatus(ret, eSucInitStatus);
}

/// SAEC Kinetic Vision, Inc. ----------- END OF FILE


