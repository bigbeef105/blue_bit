/**
  @file       ResBitSummaryDebugService.h

  @copyright  (C) 2020 Kinetic Vision, Cincinnati Ohio.
               This software is property of SAEC Kinetic Vision, Inc
               and is considered confidential.

  @brief      ResBitSummaryDebugService software unit "H" file.

  @author     Jeffrey Hatton

  @defgroup   BLE Software unit for defining and interfacing with the ResBit
                  summary debug service

  Configuration History
  =====================

  Config Item    | Value
  -------------- | -----
  Config #       | NA
  Revision       | NA
  Revised, Date  | NA
  QA, Date       | NA
  Approved, Date | NA
  Released, Date | NA

  Significant Modification History (Most recent at top)
  =====================================================

  Date         | Initials | Details
  ------------ | -------- | -------
  13 FEB 2020  | JH       | Original

  Theory of Operation
  ===================
  TBD

  */

// Define to prevent recursive inclusion -------------------------------------
#ifndef __RESBIT_SUMMARY_DEBUG_SERVICE_H
#define __RESBIT_SUMMARY_DEBUG_SERVICE_H

#include "Status.h"

// Exported macro ------------------------------------------------------------

// Exported types ------------------------------------------------------------
typedef enum {
    ResBitSummaryDebug_FakeDataSet,
    ResBitSummaryDebug_Count,
} ResBitSummaryDebugCharacteristics_t;

// Exported constants --------------------------------------------------------

///
/// The UUID of the summary service
///
#define BLE_SUMMARY_DEBUG_SERVICE_UUID 0xAD00

#define BLE_SUMMARY_DEBUG_SERVICE_FAKE_DATA_CHAR_UUID 0xAD01

// Exported objects ----------------------------------------------------------

// Exported functions --------------------------------------------------------

///  @brief Initializes the ResBitSummary Service software unit
///  @return status.
status_t ResBitSummaryDebugService_Init(void);

#endif // __RESBIT_SUMMARY_DEBUG_SERVICE_H

/// SAEC Kinetic Vision, Inc. ----------- END OF FILE


