/**
  @file       Ble.c

  @copyright  (C) 2020 Kinetic Vision, Cincinnati Ohio.
               This software is property of SAEC Kinetic Vision, Inc
               and is considered confidential.

  @brief      Ble software unit "C" file.

  @author     Jeffrey Hatton

  @ingroup    BLE

  Configuration History
  =====================

  Config Item    | Value
  -------------- | -----
  Config #       | NA
  Revision       | NA
  Revised, Date  | NA
  QA, Date       | NA
  Approved, Date | NA
  Released, Date | NA

  Significant Modification History (Most recent at top)
  =====================================================

  Date         | Initials | Details
  ------------ | -------- | -------
  24 JAN 2020  | JH       | Original

  Theory of Operation
  ===================
  TBD

*/

// Includes ------------------------------------------------------------------

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <stdint.h>

#include "nrf_sdh.h"
#include "nrfx_rtc.h"

#include "../SwUnitControlSu/SwUnitControl.h"
#include "../Device/DeviceInfo.h"
#include "BlueBitBle.h"
#include "BlueBitsAdvertiser.h"
#include "DeviceInfoService.h"
#include "../MessagerSu/Messager.h"
#include "ResBitSummaryService.h"
#include "ResBitDeviceInfoService.h"
#include "ResBitSummaryDebugService.h"
#include "../ConsoleSu/Console.h"
#include "nrf_delay.h"
#include "SummaryStore.h"

// Private macros ------------------------------------------------------------
#define returnStatus(__status__,__source__) SwUnitControl_WriteStatus(eSucBle,__source__,__status__,__LINE__);

///
/// Converts config file units into soft device's units (ms -> 0.625ms)
///
#define CONFIG_ADVERT_INTERVAL_CONVERT(interval) (((interval) * 8U) / 5U)

// Private constants ---------------------------------------------------------

///
/// ID for the power state message
///
#define POWER_STATE_MESSAGE_ID      0x0001
///
/// ID for configuration message
///
#define CONFIG_MESSAGE_ID           0x0101
///
/// ID for the set resbit info message
///
#define SET_RESBIT_INFO_ID          0x0102

///
/// Rtc scale info
///
#define RTC_INTERVAL_MS                 125UL
#define RTC_FREQUENCY                   (1000UL / RTC_INTERVAL_MS)
#define RTC_PRESCALER                   ((32768UL * RTC_INTERVAL_MS) / 1000UL) - 1

///
/// Mask for getting 24-bit rtc count value
///
#define RTC_COUNT_MASK                  0xFFFFFF

///
/// Short advertisement timeout value in seconds
///
#define SHORT_ADVERT_TIME_DEFAULT       60
#define SHORT_ADVERT_TIME_MIN           10
#define SHORT_ADVERT_TIME_MAX           3600

///
/// Long advert delay in seconds
///
#define LONG_ADVERT_DELAY_DEFAULT       3600
#define LONG_ADVERT_DELAY_MIN           30
#define LONG_ADVERT_DELAY_MAX           36000

///
/// Advertisement interval limits in milliseconds (from sdk docs)
///
#define ADVERT_INTERVAL_MIN             20
#define ADVERT_INTERVAL_MAX             10240

///
/// Place holder
///
#define RESBIT_MODEL_NO                 0

// Private types -------------------------------------------------------------

typedef enum {
    ResBitPowerStates_Awake = 0,
    ResBitPowerStates_Sleep,
    ResBitPowerStates_Protected,
    ResBitPowerStates_DeepSleep,
    ResBitPowerStates_NA,
    ResBitPowerStates_Count,
} ResBitPowerStates_t;

typedef enum {
    AdvertiseStates_Inactive = 0,
    AdvertiseStates_Short,
    AdvertiseStates_Long,
    AdvertiseStates_AlwaysAdvert,
} AdvertiseStates_t;

typedef struct {
	serialNum_t hardwareSerialNum;
	version_t hardwareVersion;
	version_t firmwareVersion;
} ResbitInfo_t;

typedef enum {
    ConfigIds_ShortAdvertTime = 0,
    ConfigIds_LongAdvertDelay,
    ConfigIds_AlwaysAdvertise,
    ConfigIds_AdvertInterval,
} ConfigIds_t;

typedef enum {
    ConfigResponses_Success = 0,
    ConfigResponses_UnknownId,
    ConfigResponses_DataLength,
    ConfigResponses_DataValue,
} ConfigResponses_t;

typedef struct {
    ConfigIds_t configId;
    status_t (*setter)(const uint8_t *buffer, size_t len, ConfigResponses_t *response);
} ConfigVariableHandler_t;

// Private function prototypes -----------------------------------------------

static status_t powerStateMessageHandler(messageHandlerArgs_t * args);
static status_t configMessageHandler(messageHandlerArgs_t * args);
static status_t setResbitInfoHandler(messageHandlerArgs_t * args);

static status_t UpdateAdvertising(void);
static status_t RestartAdvertising(void);
static void SetupLongAdvertising(void);

static status_t RtcInit(void);
static status_t RtcSetupTimeout(uint32_t seconds, void (*callback)(void));
static status_t RtcCancelTimeout(void);
static void RtcEventHandler(nrfx_rtc_int_type_t intType);

static status_t configShortAdvertTimeHandler(const uint8_t *buffer, size_t len, ConfigResponses_t *response);
static status_t configLongAdvertDelayHandler(const uint8_t *buffer, size_t len, ConfigResponses_t *response);
static status_t configAlwaysAdvertiseHandler(const uint8_t *buffer, size_t len, ConfigResponses_t *response);
static status_t configAdvertIntervalHandler(const uint8_t *buffer, size_t len, ConfigResponses_t *response);

// Private constants ---------------------------------------------------------

///
/// Rtc driver instance
///
static const nrfx_rtc_t _Rtc = NRFX_RTC_INSTANCE(2);

///
/// List of messages and their handlers for this software unit
///
static const messageHandlerReg_t _MessageHandlers[] = {
    { POWER_STATE_MESSAGE_ID, powerStateMessageHandler },
    { CONFIG_MESSAGE_ID, configMessageHandler },
    { SET_RESBIT_INFO_ID, setResbitInfoHandler },
    // Marks last element in the list
    { 0, NULL },
};

///
/// Array of config variable handlers for config message
///
static const ConfigVariableHandler_t _ConfigVariableHandlers[] = {
    { ConfigIds_ShortAdvertTime, configShortAdvertTimeHandler },
    { ConfigIds_LongAdvertDelay, configLongAdvertDelayHandler },
    { ConfigIds_AlwaysAdvertise, configAlwaysAdvertiseHandler },
    { ConfigIds_AdvertInterval, configAdvertIntervalHandler },
};

// Private variables ---------------------------------------------------------

///
/// Node for the handlers
///
static messageHandlerList_t _MessageHandlerRoot = { _MessageHandlers, NULL };

///
/// If the software unit is initialized
///
static bool _IsInitialized = false;

///
/// Type for Vendor UUIDs
///
static uint8_t _UuidType;

///
/// Handle of the current connection
///
static uint16_t _ConnectionHandle = BLE_CONN_HANDLE_INVALID;

///
/// The current Service level
///
static BleServiceLevels_t _ServiceLevel = BleServiceLevels_Basic;

///
/// If the BLE stack is in the middle of reinitializing
///
static bool _Reinit = false;

///
/// The current resbit power state
///
static uint16_t _ResbitCurrentPowerState = ResBitPowerStates_NA;

///
/// Short advertise state timeout value
///
static uint16_t _ShortAdvertTime = SHORT_ADVERT_TIME_DEFAULT;

///
/// RTC delay value (in seconds) before long advertise state
///
static uint16_t _LongAdvertDelay = LONG_ADVERT_DELAY_DEFAULT;

///
/// The current advertising state
///
static AdvertiseStates_t _AdvertiseState = AdvertiseStates_Inactive;

///
/// Rtc callback function
///
static void (*_RtcCallback)(void) = NULL;

///
/// Struct for holding resbit info
///
static ResbitInfo_t _ResbitInfo = { { 0, 0, 0 }, 0, 0 };

///
/// Beacon info buffer
///
BeaconInfo_t _BeaconInfo;

// Public variables ---------------------------------------------------------

ble_uuid_t BleServiceUuids[BleServices_Count] =
{
    {BLE_UUID_DEVICE_INFORMATION_SERVICE, BLE_UUID_TYPE_BLE}
};

// Private function bodies ---------------------------------------------------

static status_t powerStateMessageHandler(messageHandlerArgs_t * args) {
    status_t status = StatusOk;

    if (args->dataLen < 2) {
        args->resCode = messageResponseDataError;
        status = StatusMessageData;
    } else {
        args->resCode = messageResponseSuccess;
        memcpy(&_ResbitCurrentPowerState, args->messageData, sizeof(_ResbitCurrentPowerState));
    }

    args->bytesWritten = 0;

    return status;
}

static status_t configMessageHandler(messageHandlerArgs_t * args) {
    status_t status = StatusOk;
    uint8_t configId;
    // If we don't find a handler, this config response will persist
    ConfigResponses_t configResponse = ConfigResponses_UnknownId;

    if (args->dataLen > sizeof(configId)) {
        memcpy(&configId, args->messageData, sizeof(configId));
        for (int i = 0; i < (sizeof(_ConfigVariableHandlers) / sizeof(*_ConfigVariableHandlers)); i++) {
            if (_ConfigVariableHandlers[i].configId == (ConfigIds_t)configId) {
                status = _ConfigVariableHandlers[i].setter(args->messageData + sizeof(configId), // offset pointer to access config data only
                                                           args->dataLen - sizeof(configId),
                                                           &configResponse);
                break; // exit for(..)
            }
        }
    } else {
        configResponse = ConfigResponses_DataLength;
    }

    // Generate response
    uint8_t responseAsByte = (uint8_t)configResponse; // enforce size
    if (args->resBufferLen >= sizeof(responseAsByte)) {
        args->resCode = messageResponseSuccess;
        memcpy(args->resBuffer, &responseAsByte, sizeof(responseAsByte));
        args->bytesWritten = sizeof(responseAsByte);
    } else {
        args->resCode = messageResponseDataError;
        args->bytesWritten = 0;
    }

    return status;
}

static status_t setResbitInfoHandler(messageHandlerArgs_t * args) {
    status_t status = StatusOk;

    if (args->dataLen == sizeof(_ResbitInfo)) {
        args->resCode = messageResponseSuccess;
    	memcpy(&_ResbitInfo, args->messageData, args->dataLen);
        // Update services
        status = ResBitSummaryService_UpdateSerialNum(&_ResbitInfo.hardwareSerialNum);
        if (Status_IsOk(status)) {
            status = ResBitDeviceInfoService_SetResbitInfo(&_ResbitInfo.firmwareVersion,
                                                           &_ResbitInfo.hardwareVersion,
                                                           &_ResbitInfo.hardwareSerialNum,
                                                           RESBIT_MODEL_NO);

            _BeaconInfo.MajorID = *(uint16_t*)(_ResbitInfo.hardwareSerialNum.bytes + 2);
            _BeaconInfo.MinorID = *(uint16_t*)(_ResbitInfo.hardwareSerialNum.bytes);

            status = BlueBitsAdvertiser_SetBeaconInfo(&_BeaconInfo);
        }
    } else {
        args->resCode = messageResponseDataError;
    	status = StatusBufferLength;
    }

    args->bytesWritten = 0;

    return status;
}

static void SetupLongAdvertising(void)
{
    _AdvertiseState = AdvertiseStates_Long;
    RestartAdvertising();
}

static status_t RtcInit(void)
{
    nrfx_rtc_config_t config = NRFX_RTC_DEFAULT_CONFIG;
    config.prescaler = RTC_PRESCALER;
    uint32_t nrfRet = nrfx_rtc_init(&_Rtc, &config, RtcEventHandler);

    if (0 == nrfRet) {
        return StatusOk;
    } else {
        return StatusNrfError;
    }
}

static status_t RtcSetupTimeout(uint32_t seconds, void (*callback)(void))
{
    RtcCancelTimeout();

    uint32_t actualDuration = (seconds * 1000) / RTC_INTERVAL_MS;
    uint32_t nrfRet = nrfx_rtc_cc_set(&_Rtc, 0, actualDuration, true);
    if (0 == nrfRet) {
        _RtcCallback = callback;
        nrfx_rtc_enable(&_Rtc);

        return StatusOk;
    } else {
        return StatusNrfError;
    }
}

static status_t RtcCancelTimeout(void)
{
    nrfx_rtc_cc_disable(&_Rtc, 0);
    nrfx_rtc_disable(&_Rtc);
    nrfx_rtc_counter_clear(&_Rtc);

    return StatusOk;
}

static void RtcEventHandler(nrfx_rtc_int_type_t intType)
{
    if (NRFX_RTC_INT_COMPARE0 == intType) {
        nrfx_rtc_cc_disable(&_Rtc, 0);
        if (_RtcCallback) {
            _RtcCallback();
            _RtcCallback = NULL; // reset function pointer
        }
    }
}

static status_t configShortAdvertTimeHandler(const uint8_t *buffer, size_t len, ConfigResponses_t *response) {
    status_t status = StatusOk;

    uint16_t temp = 0;
    if (sizeof(temp) == len) {
        memcpy(&temp, buffer, len);
        if ((temp >= SHORT_ADVERT_TIME_MIN) && (temp <= SHORT_ADVERT_TIME_MAX)) {
            _ShortAdvertTime = temp;
            *response = ConfigResponses_Success;
        } else {
            *response = ConfigResponses_DataValue;
        }
    } else {
        *response = ConfigResponses_DataLength;
        status = StatusBufferLength;
    }

    return status;
}

static status_t configLongAdvertDelayHandler(const uint8_t *buffer, size_t len, ConfigResponses_t *response) {
    status_t status = StatusOk;

    uint16_t temp = 0;
    if (sizeof(temp) == len) {
        memcpy(&temp, buffer, len);
        if ((temp >= LONG_ADVERT_DELAY_MIN) && (temp <= LONG_ADVERT_DELAY_MAX)) {
            _LongAdvertDelay = temp;
            *response = ConfigResponses_Success;
        } else {
            *response = ConfigResponses_DataValue;
        }
    } else {
        *response = ConfigResponses_DataLength;
        status = StatusBufferLength;
    }

    return status;
}

static status_t configAlwaysAdvertiseHandler(const uint8_t *buffer, size_t len, ConfigResponses_t *response) {
    status_t status = StatusOk;

    uint8_t temp = 0;
    if (sizeof(temp) == len) {
        RtcCancelTimeout(); // avoid any race conditions with _AdvertiseState variable

        memcpy(&temp, buffer, len);
        if (0 == temp) {
            _AdvertiseState = AdvertiseStates_Inactive;
        } else {
            _AdvertiseState = AdvertiseStates_AlwaysAdvert;
        }
        status = RestartAdvertising();
        *response = ConfigResponses_Success;
    } else {
        *response = ConfigResponses_DataLength;
        status = StatusBufferLength;
    }

    return status;
}

static status_t configAdvertIntervalHandler(const uint8_t *buffer, size_t len, ConfigResponses_t *response) {
    status_t status = StatusOk;

    uint16_t temp = 0;
    if (sizeof(temp) == len) {
        memcpy(&temp, buffer, len);
        if ((temp >= ADVERT_INTERVAL_MIN) && (temp <= ADVERT_INTERVAL_MAX)) {
            status = BlueBitsAdvertiser_SetAdvertInterval(CONFIG_ADVERT_INTERVAL_CONVERT(temp));
            if (Status_IsOk(status)) {
                status = RestartAdvertising();
            }
            *response = ConfigResponses_Success;
        } else {
            *response = ConfigResponses_DataValue;
        }
    } else {
        *response = ConfigResponses_DataLength;
        status = StatusBufferLength;
    }

    return status;
}


/**@brief Callback function for asserts in the SoftDevice.
 *
 * @details This function will be called in case of an assert in the SoftDevice.
 *
 * @warning This handler is an example only and does not fit a final product. You need to analyze
 *          how your product is supposed to react in case of Assert.
 * @warning On assert from the SoftDevice, the system can only recover on reset.
 *
 * @param[in] line_num   Line number of the failing ASSERT call.
 * @param[in] file_name  File name of the failing ASSERT call.
 */
void assert_nrf_callback(uint16_t line_num, const uint8_t * p_file_name)
{
    app_error_handler(DEAD_BEEF, line_num, p_file_name);
}


/**@brief Function for handling Peer Manager events.
 *
 * @param[in] p_evt  Peer Manager event.
 */
static void pm_evt_handler(pm_evt_t const * p_evt)
{
    pm_handler_on_pm_evt(p_evt);
    pm_handler_flash_clean(p_evt);

    switch (p_evt->evt_id)
    {
        case PM_EVT_PEERS_DELETE_SUCCEEDED:
            break;

        default:
            break;
    }
}

/**@brief Function for the GAP initialization.
 *
 * @details This function sets up all the necessary GAP (Generic Access Profile) parameters of the
 *          device including the device name, appearance, and the preferred connection parameters.
 */
static status_t gap_params_init(void)
{
    ret_code_t              err_code;
    ble_gap_conn_params_t   gap_conn_params;
    ble_gap_conn_sec_mode_t sec_mode;

    BLE_GAP_CONN_SEC_MODE_SET_OPEN(&sec_mode);

    err_code = sd_ble_gap_device_name_set(&sec_mode,
                                          (const uint8_t *)DEVICE_NAME,
                                          strlen(DEVICE_NAME));
    if (NRF_IS_ERROR(err_code)) {
        return StatusNrfError;
    }

    /* YOUR_JOB: Use an appearance value matching the application's use case.
       err_code = sd_ble_gap_appearance_set(BLE_APPEARANCE_);
       APP_ERROR_CHECK(err_code); */

    memset(&gap_conn_params, 0, sizeof(gap_conn_params));

    gap_conn_params.min_conn_interval = MIN_CONN_INTERVAL;
    gap_conn_params.max_conn_interval = MAX_CONN_INTERVAL;
    gap_conn_params.slave_latency     = SLAVE_LATENCY;
    gap_conn_params.conn_sup_timeout  = CONN_SUP_TIMEOUT;

    err_code = sd_ble_gap_ppcp_set(&gap_conn_params);
    if (NRF_IS_ERROR(err_code)) {
        return StatusNrfError;
    }

    return StatusOk;
}


/**@brief Function for initializing the GATT module.
 */
static status_t gatt_init(void)
{
    ret_code_t err_code = nrf_ble_gatt_init(&m_gatt, NULL);
    if (NRF_IS_ERROR(err_code)) {
        return StatusNrfError;
    }

    return StatusOk;
}


/**@brief Function for handling Queued Write Module errors.
 *
 * @details A pointer to this function will be passed to each service which may need to inform the
 *          application about an error.
 *
 * @param[in]   nrf_error   Error code containing information about what went wrong.
 */
static void nrf_qwr_error_handler(uint32_t nrf_error)
{
    APP_ERROR_HANDLER(nrf_error);
}


/**@brief Function for handling the YYY Service events.
 * YOUR_JOB implement a service handler function depending on the event the service you are using can generate
 *
 * @details This function will be called for all YY Service events which are passed to
 *          the application.
 *
 * @param[in]   p_yy_service   YY Service structure.
 * @param[in]   p_evt          Event received from the YY Service.
 *
 *
static void on_yys_evt(ble_yy_service_t     * p_yy_service,
                       ble_yy_service_evt_t * p_evt)
{
    switch (p_evt->evt_type)
    {
        case BLE_YY_NAME_EVT_WRITE:
            APPL_LOG("[APPL]: charact written with value %s. ", p_evt->params.char_xx.value.p_str);
            break;

        default:
            // No implementation needed.
            break;
    }
}
*/

/**@brief Function for handling the Connection Parameters Module.
 *
 * @details This function will be called for all events in the Connection Parameters Module which
 *          are passed to the application.
 *          @note All this function does is to disconnect. This could have been done by simply
 *                setting the disconnect_on_fail config parameter, but instead we use the event
 *                handler mechanism to demonstrate its use.
 *
 * @param[in] p_evt  Event received from the Connection Parameters Module.
 */
static void on_conn_params_evt(ble_conn_params_evt_t * p_evt)
{
    ret_code_t err_code;

    if (p_evt->evt_type == BLE_CONN_PARAMS_EVT_FAILED)
    {
        err_code = sd_ble_gap_disconnect(_ConnectionHandle, BLE_HCI_CONN_INTERVAL_UNACCEPTABLE);
        APP_ERROR_CHECK(err_code);
    }
}


/**@brief Function for handling a Connection Parameters error.
 *
 * @param[in] nrf_error  Error code containing information about what went wrong.
 */
static void conn_params_error_handler(uint32_t nrf_error)
{
    APP_ERROR_HANDLER(nrf_error);
}


/**@brief Function for initializing the Connection Parameters module.
 */
static status_t conn_params_init(void)
{
    ret_code_t             err_code;
    ble_conn_params_init_t cp_init;

    memset(&cp_init, 0, sizeof(cp_init));

    cp_init.p_conn_params                  = NULL;
    cp_init.first_conn_params_update_delay = FIRST_CONN_PARAMS_UPDATE_DELAY;
    cp_init.next_conn_params_update_delay  = NEXT_CONN_PARAMS_UPDATE_DELAY;
    cp_init.max_conn_params_update_count   = MAX_CONN_PARAMS_UPDATE_COUNT;
    cp_init.start_on_notify_cccd_handle    = BLE_GATT_HANDLE_INVALID;
    cp_init.disconnect_on_fail             = false;
    cp_init.evt_handler                    = on_conn_params_evt;
    cp_init.error_handler                  = conn_params_error_handler;

    err_code = ble_conn_params_init(&cp_init);
    if (NRF_IS_ERROR(err_code)) {
        return StatusNrfError;
    }

    return StatusOk;
}


/**@brief Function for handling BLE events.
 *
 * @param[in]   p_ble_evt   Bluetooth stack event.
 * @param[in]   p_context   Unused.
 */
static void ble_evt_handler(ble_evt_t const * p_ble_evt, void * p_context)
{
    ret_code_t err_code = NRF_SUCCESS;

    switch (p_ble_evt->header.evt_id)
    {
        case BLE_GAP_EVT_DISCONNECTED:
            Console_WriteLine("BLE Device Disconnected\r\n");
            _ConnectionHandle = BLE_CONN_HANDLE_INVALID;
            ResBitSummaryService_ClientDisconnected();
            break;

        case BLE_GAP_EVT_CONNECTED:
            Console_WriteLine("BLE Device Connected");
            err_code = bsp_indication_set(BSP_INDICATE_CONNECTED);
            APP_ERROR_CHECK(err_code);
            _ConnectionHandle = p_ble_evt->evt.gap_evt.conn_handle;
            err_code = nrf_ble_qwr_conn_handle_assign(&m_qwr, _ConnectionHandle);

            BlueBitsAdvertiser_Connected();
            APP_ERROR_CHECK(err_code);
            break;

        case BLE_GAP_EVT_PHY_UPDATE_REQUEST:
        {
            ble_gap_phys_t const phys =
            {
                .rx_phys = BLE_GAP_PHY_AUTO,
                .tx_phys = BLE_GAP_PHY_AUTO,
            };
            err_code = sd_ble_gap_phy_update(p_ble_evt->evt.gap_evt.conn_handle, &phys);
            APP_ERROR_CHECK(err_code);
        } break;

        case BLE_GATTC_EVT_TIMEOUT:
            // Disconnect on GATT Client timeout event.
            err_code = sd_ble_gap_disconnect(p_ble_evt->evt.gattc_evt.conn_handle,
                                             BLE_HCI_REMOTE_USER_TERMINATED_CONNECTION);
            APP_ERROR_CHECK(err_code);
            break;

        case BLE_GATTS_EVT_TIMEOUT:
            // Disconnect on GATT Server timeout event.
            err_code = sd_ble_gap_disconnect(p_ble_evt->evt.gatts_evt.conn_handle,
                                             BLE_HCI_REMOTE_USER_TERMINATED_CONNECTION);
            APP_ERROR_CHECK(err_code);
            break;

        default:
            // No implementation needed.
            break;
    }
}


/**@brief Function for initializing the BLE stack.
 *
 * @details Initializes the SoftDevice and the BLE event interrupt.
 */
static status_t ble_stack_init(void)
{
    ret_code_t err_code;

    err_code = nrf_sdh_enable_request();
    if (NRF_IS_ERROR(err_code)) {
        return StatusNrfError;
    }

    // Configure the BLE stack using the default settings.
    // Fetch the start address of the application RAM.
    uint32_t ram_start = 0;
    err_code = nrf_sdh_ble_default_cfg_set(APP_BLE_CONN_CFG_TAG, &ram_start);
    if (NRF_IS_ERROR(err_code)) {
        return StatusNrfError;
    }

    // Enable BLE stack.
    err_code = nrf_sdh_ble_enable(&ram_start);
    if (NRF_IS_ERROR(err_code)) {
        return StatusNrfError;
    }

    // Register a handler for BLE events.
    NRF_SDH_BLE_OBSERVER(m_ble_observer, APP_BLE_OBSERVER_PRIO, ble_evt_handler, NULL);

    return StatusOk;
}


/**@brief Function for the Peer Manager initialization.
 */
static status_t peer_manager_init(void)
{
    ble_gap_sec_params_t sec_param;
    ret_code_t           err_code;

    err_code = pm_init();
    if (NRF_IS_ERROR(err_code)) {
        return StatusNrfError;
    }

    memset(&sec_param, 0, sizeof(ble_gap_sec_params_t));

    // Security parameters to be used for all security procedures.
    sec_param.bond           = SEC_PARAM_BOND;
    sec_param.mitm           = SEC_PARAM_MITM;
    sec_param.lesc           = SEC_PARAM_LESC;
    sec_param.keypress       = SEC_PARAM_KEYPRESS;
    sec_param.io_caps        = SEC_PARAM_IO_CAPABILITIES;
    sec_param.oob            = SEC_PARAM_OOB;
    sec_param.min_key_size   = SEC_PARAM_MIN_KEY_SIZE;
    sec_param.max_key_size   = SEC_PARAM_MAX_KEY_SIZE;
    sec_param.kdist_own.enc  = 1;
    sec_param.kdist_own.id   = 1;
    sec_param.kdist_peer.enc = 1;
    sec_param.kdist_peer.id  = 1;

    err_code = pm_sec_params_set(&sec_param);
    if (NRF_IS_ERROR(err_code)) {
        return StatusNrfError;
    }

    err_code = pm_register(pm_evt_handler);
    if (NRF_IS_ERROR(err_code)) {
        return StatusNrfError;
    }

    return StatusOk;
}

static status_t InitAdvert(void) {
    status_t ret = StatusOk;
    if (AdvertiseStates_AlwaysAdvert != _AdvertiseState) _AdvertiseState = AdvertiseStates_Inactive;

    ret = BlueBitsAdvertiser_Init();
    if (Status_IsError(ret)) return ret;

    ret = BlueBitsAdvertiser_SetAdvertInterval(BLUEBITS_DEFAULT_ADV_INTERVAL);
    if (Status_IsError(ret)) return ret;

    uint8_t temp[16] = BLE_BEACON_DEFAULT_UUID;
    memcpy(_BeaconInfo.Uuid, temp, sizeof(_BeaconInfo.Uuid));

    _BeaconInfo.MajorID = BLE_BEACON_DEFAULT_MAJOR;
    _BeaconInfo.MinorID = BLE_BEACON_DEFAULT_MINOR;

    ret = BlueBitsAdvertiser_SetBeaconInfo(&_BeaconInfo);
    if (Status_IsError(ret)) return ret;

    return ret;
}

static status_t InitServices(void) {
    status_t ret = StatusOk;
    ret_code_t         err_code;
    nrf_ble_qwr_init_t qwr_init = {0};

    // Initialize Queued Write Module.
    qwr_init.error_handler = nrf_qwr_error_handler;

    if (!_IsInitialized) {
        err_code = nrf_ble_qwr_init(&m_qwr, &qwr_init);
        if (NRF_IS_ERROR(err_code)) {
            return StatusNrfError;
        }
    }

    if (_ServiceLevel >= BleServiceLevels_Debug) {
        ret = DeviceInfoService_Init();
        if (Status_IsError(ret)) return ret;

        ret = ResBitSummaryDebugService_Init();
        if (Status_IsError(ret)) return ret;
    }

    ret = ResBitSummaryService_Init();
    if (Status_IsError(ret)) return ret;

    ret = ResBitDeviceInfoService_Init();

    return ret;
}

static status_t SetBaseUUid(void) {
    status_t ret = StatusOk;

    ble_uuid128_t base_uuid = BLE_BASE_UUID;
    uint32_t nrfRet = sd_ble_uuid_vs_add(&base_uuid, &_UuidType);
    if (NRF_IS_ERROR(nrfRet)) {
        Console_PrintLine("NRF Error when setting up Base UUID: 0x%0.8x", nrfRet);
        ret = StatusNrfError;
    }

    return ret;
}

static status_t RestartAdvertising(void) {
    BlueBitsAdvertiser_StopAdvertise();
    return UpdateAdvertising();
}

static status_t UpdateAdvertising(void) {
    status_t ret = StatusOk;

    uint16_t used;
    ret = SummaryStore_GetUsed(&used);
    if (Status_IsError(ret)) return ret;

    bool advertising;
    ret = BlueBitsAdvertiser_GetAdvertising(&advertising);
    if (Status_IsError(ret)) return ret;

    if (!advertising) {
        if ((_ResbitCurrentPowerState != ResBitPowerStates_DeepSleep) &&
            (_ConnectionHandle == BLE_CONN_HANDLE_INVALID) && (used > 0))
        {
            if (AdvertiseStates_AlwaysAdvert == _AdvertiseState) {
                Console_WriteLine("Enabling indefinite advertisement");
                ret = BlueBitsAdvertiser_StartAdvertise(BLE_ADVERT_TIMEOUT_INF);
            } else if (AdvertiseStates_Long == _AdvertiseState) {
                Console_WriteLine("Enabling long advertisement due to data present and long pending timeout");
                ret = BlueBitsAdvertiser_StartAdvertise(BLE_ADVERT_TIMEOUT_INF);
            } else if (AdvertiseStates_Short == _AdvertiseState) {
                Console_WriteLine("Enabling short advertisement due to data present");
                ret = BlueBitsAdvertiser_StartAdvertise(_ShortAdvertTime);
            }
        }
    } else {
        if (_ResbitCurrentPowerState == ResBitPowerStates_DeepSleep) {
            Console_WriteLine("Ending advertisement due to deep sleep mode");
            ret = BlueBitsAdvertiser_StopAdvertise();
        } else if (used == 0) {
            Console_WriteLine("Ending advertisement due to no data present");
            ret = BlueBitsAdvertiser_StopAdvertise();
        }
    }

    return ret;
}

// Public functions bodies ---------------------------------------------------

status_t Ble_Init(void) {
    status_t ret = StatusOk;

    _ConnectionHandle = BLE_CONN_HANDLE_INVALID;

    ret = ble_stack_init();
    if (Status_IsError(ret)) return returnStatus(ret, eSucInitStatus);
    ret = gap_params_init();
    if (Status_IsError(ret)) return returnStatus(ret, eSucInitStatus);
    ret = gatt_init();
    if (Status_IsError(ret)) return returnStatus(ret, eSucInitStatus);

    ret = SetBaseUUid();
    if (Status_IsError(ret)) return returnStatus(ret, eSucInitStatus);

    ret = InitServices();
    if (Status_IsError(ret)) return returnStatus(ret, eSucInitStatus);
    ret = InitAdvert();
    if (Status_IsError(ret)) return returnStatus(ret, eSucInitStatus);

    ret = conn_params_init();
    if (Status_IsError(ret)) return returnStatus(ret, eSucInitStatus);
    ret = peer_manager_init();
    if (Status_IsError(ret)) return returnStatus(ret, eSucInitStatus);

    if (!_IsInitialized) {
        ret = RtcInit();
        if (Status_IsError(ret)) return returnStatus(ret, eSucInitStatus);

        ret = Messager_Subscribe(&_MessageHandlerRoot);
        if (Status_IsError(ret)) return returnStatus(ret, eSucInitStatus);
    }

    if (Status_IsOk(ret)) {
        _IsInitialized = true;
    }

    return returnStatus(ret, eSucInitStatus);
}

status_t Ble_Tick(bool* needMoreTime) {
    status_t ret = StatusOk;

    if (_Reinit) {
        ret = Ble_Init();
        _Reinit = false;
        *needMoreTime = true;
        if (Status_IsError(ret)) {
            Console_Printf("Ble Reinit Failed - Status: %d\r\n", ret);
        }
    }

    ret = UpdateAdvertising();

    if (Status_IsError(ret)) {
        Console_PrintLine("Error in BLE Tick: 0x%0.8x", ret);
        ret = StatusOk;
    }

    return returnStatus(ret, eSucTickStatus);
}

status_t Ble_GetVendorUuidType(uint8_t* type) {
    if (type == NULL) return returnStatus(StatusNullParameter, eSucWriteStatus);
    status_t ret = StatusOk;

    *type = _UuidType;

    return returnStatus(ret, eSucReadStatus);
}

status_t Ble_GetCurrentConnection(uint16_t* connection) {
    if (connection == NULL) return returnStatus(StatusNullParameter, eSucWriteStatus);
    status_t ret = StatusOk;

    *connection = _ConnectionHandle;

    return returnStatus(ret, eSucReadStatus);
}

status_t Ble_ReinitStack(void) {
    status_t ret = StatusOk;
    uint32_t nrfRet;

    //
    // Prep for reinitialization.
    //

    if (_ConnectionHandle != BLE_CONN_HANDLE_INVALID) {
        nrfRet = sd_ble_gap_disconnect(_ConnectionHandle, BLE_HCI_REMOTE_USER_TERMINATED_CONNECTION);
        if (NRF_IS_ERROR(nrfRet)) {
            ret = StatusNrfError;
        }
    } else {
        BlueBitsAdvertiser_StopAdvertise();
    }

    nrfRet = ble_conn_params_stop();
    if (NRF_IS_ERROR(nrfRet)) {
        ret = StatusNrfError;
    }

    nrf_delay_ms(500);

    // Shut down stack
    nrfRet = nrf_sdh_disable_request();
    if (NRF_IS_ERROR(nrfRet)) {
        ret = StatusNrfError;
    }

    if (Status_IsOk(ret)) {
        // Mark initialization process started
        _Reinit = true;
    }

    return returnStatus(ret, eSucWriteStatus);
}

status_t Ble_SetServiceLevel(BleServiceLevels_t serviceLevel) {
    status_t ret = StatusOk;
    BleServiceLevels_t level = serviceLevel;

    if (serviceLevel >= BleServiceLevels_Count) {
        level = BleServiceLevels_Count - 1;
    }

    _ServiceLevel = level;

    return returnStatus(ret, eSucWriteStatus);
}

status_t Ble_UpdateNotChar(uint8_t* data, uint16_t len, uint16_t handle) {
    status_t ret = StatusOk;
    uint32_t nrfRet;

    if (_ConnectionHandle != BLE_CONN_HANDLE_INVALID) {
        ble_gatts_hvx_params_t params;
        ZERO_OBJECT(params);
        params.type   = BLE_GATT_HVX_NOTIFICATION;
        params.handle = handle;
        params.p_data = data;
        params.p_len  = &len;

        nrfRet = sd_ble_gatts_hvx(_ConnectionHandle, &params);
        if (NRF_IS_ERROR(nrfRet)) {
            if (nrfRet == NRF_ERROR_RESOURCES) {
                ret = StatusNrfNotQueueFull;
            } else if (nrfRet == NRF_ERROR_INVALID_STATE) {
                ret = Ble_UpdateChar(data, len, handle);
            } else  if (nrfRet != BLE_ERROR_GATTS_SYS_ATTR_MISSING) {
                Console_PrintLine("NRF ERROR when sending notification: %x", nrfRet);
                ret = StatusNrfError;
            }
        }
    } else {
        ret = Ble_UpdateChar(data, len, handle);
    }

    return returnStatus(ret, eSucWriteStatus);
}

status_t Ble_UpdateChar(uint8_t* data, uint16_t len, uint16_t handle) {
    status_t ret = StatusOk;
    uint32_t nrfRet;

    ble_gatts_value_t params;
    ZERO_OBJECT(params);
    params.p_value = data;
    params.len  = len;

    nrfRet = sd_ble_gatts_value_set(_ConnectionHandle, handle, &params);
    if (NRF_IS_ERROR(nrfRet)) {
        Console_PrintLine("NRF ERROR when updating char value: %x", nrfRet);
        ret = StatusNrfError;
    }

    return ret;
}

status_t Ble_GetReiniting(bool* isReiniting) {
    if (isReiniting == NULL) return returnStatus(StatusNullParameter, eSucWriteStatus);
    status_t ret = StatusOk;

    *isReiniting = _Reinit;

    return returnStatus(ret, eSucReadStatus);
}

status_t Ble_NotifyTransferComplete(void) {
    if (AdvertiseStates_AlwaysAdvert != _AdvertiseState) {
        _AdvertiseState = AdvertiseStates_Inactive;
    }
    return StatusOk;
}

status_t Ble_NotifyAdvertTimeout(void) {
    status_t ret = StatusOk;

    Console_WriteLine("Advertising timed out\r\n");

    if ((AdvertiseStates_AlwaysAdvert != _AdvertiseState) && (AdvertiseStates_Long != _AdvertiseState)) {
        Console_WriteLine("Starting rtc timeout for long advertisement\r\n");
        _AdvertiseState = AdvertiseStates_Inactive;
        ret = RtcSetupTimeout(_LongAdvertDelay, SetupLongAdvertising);
    }

    return ret;
}

status_t Ble_NotifyNewSummaryData(void) {
    status_t ret = StatusOk;

    if ((AdvertiseStates_AlwaysAdvert != _AdvertiseState) && (AdvertiseStates_Long != _AdvertiseState)) {
        ret = RtcCancelTimeout();
        _AdvertiseState = AdvertiseStates_Short;
    }

    return ret;
}

/// SAEC Kinetic Vision, Inc. ----------- END OF FILE
