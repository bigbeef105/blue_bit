/**
  @file       SummaryDataGen.c

  @copyright  (C) 2020 Kinetic Vision, Cincinnati Ohio.
               This software is property of SAEC Kinetic Vision, Inc
               and is considered confidential.

  @brief      SummaryDataGen software unit "C" file.

  @author     Jeffrey Hatton

  @ingroup    SummaryDataGen

  Configuration History
  =====================

  Config Item    | Value
  -------------- | -----
  Config #       | NA
  Revision       | NA
  Revised, Date  | NA
  QA, Date       | NA
  Approved, Date | NA
  Released, Date | NA

  Significant Modification History (Most recent at top)
  =====================================================

  Date         | Initials | Details
  ------------ | -------- | -------
  13 FEB 2020  | JH       | Original

  Theory of Operation
  ===================
  TBD

*/

// Includes ------------------------------------------------------------------

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

#include "../SwUnitControlSu/SwUnitControl.h"
#include "SummaryDataGen.h"
#include "SummaryStore.h"
#include "../ConsoleSu/Console.h"

// Private function prototypes -----------------------------------------------

static status_t cliFakeData(uint16_t argc, uint8_t **argv);

// Private macros ------------------------------------------------------------

// Private constants ---------------------------------------------------------

// Private types -------------------------------------------------------------

// Private constants ---------------------------------------------------------

static const consoleCommand_t commandList[] = {
	{ "fakeData","Fakes a set of data into the store. usage sumStoreFakeData <data index>\r\n\t",cliFakeData},

	// Marks last element in the list
    { NULL, NULL, NULL },
};

// Private variables ---------------------------------------------------------

static consoleRegistration_t exportedReg = {
    (consoleCommand_t *) commandList, // .pList =
    NULL, // .pNext =
};

///
/// If the software unit has been initialized
///
static bool _IsInitialized = false;

// Private function bodies ---------------------------------------------------

static status_t Generate256Seq(void) {
    status_t ret = StatusOk;
    for (int i = 0; i < 256; i++) {
        ret = SummaryStore_StoreEvents((uint8_t*)&i, 1);
        if (Status_IsError(ret)) return ret;
    }

    return ret;
}

static status_t GenerateEvent(uint16_t id, uint32_t time, uint8_t* data, uint8_t dataSize) {
    uint8_t dataBuffer[20];
    uint8_t index = 0;

    memcpy(dataBuffer, &id, 2);
    index += 2;

    // Time
    memcpy(dataBuffer + index, &time, 4);
    index += 4;

    // Len
    dataBuffer[index++] = dataSize;

    // Data
    memcpy(dataBuffer + index, data, dataSize);
    index += dataSize;

    return SummaryStore_StoreEvents(dataBuffer, index);
}

static status_t GenerateRow(uint16_t seed) {
    status_t ret = StatusOk;
    uint32_t temp32;
    uint32_t time;
    uint16_t id;

    // ID
    id = 0;

    // Time
    time = seed;

    // Data
    temp32 = seed * 2;

    ret = GenerateEvent(id, time, (uint8_t*)&temp32, 4);
    if (Status_IsError(ret)) return ret;

    // ID
    id = 1;

    // Time
    time = seed;

    // Data
    temp32 = seed * 5;

    ret = GenerateEvent(id, time, (uint8_t*)&temp32, 4);
    if (Status_IsError(ret)) return ret;

    return ret;
}

static status_t Generate4kSeq(void) {
    status_t ret = StatusOk;

    uint16_t cap;
    ret = SummaryStore_GetCapacity(&cap);
    if (Status_IsError(ret)) return ret;

    for (int i = 0; i < cap - 2; i++) {
        uint8_t data = i;
        ret = SummaryStore_StoreEvents(&data, 1);
        if (Status_IsError(ret)) return ret;
    }
    return ret;
}

static status_t Generate200SumSet(void) {
    status_t ret = StatusOk;

    for (int i = 0; i < 100; i++) {
        ret = GenerateRow(i);
        if (Status_IsError(ret)) return ret;
    }

    return ret;
}

static status_t GenerateSmallSumSet(void) {
    status_t ret = StatusOk;

    for (int i = 0; i < 10; i++) {
        ret = GenerateRow(i);
        if (Status_IsError(ret)) return ret;
    }

    return ret;
}

static status_t GenerateSingleSumSet(void) {
    status_t ret = StatusOk;

    for (int i = 0; i < 1; i++) {
        ret = GenerateRow(i);
        if (Status_IsError(ret)) return ret;
    }

    return ret;
}

static status_t cliFakeData(uint16_t argc, uint8_t **argv) {
    uint8_t dataIndex = 0;

    if (argc > 1) {
        dataIndex = atoi(argv[1]);
    }

    return SummaryDataGen_FakeData(dataIndex);
}

// Public functions bodies ---------------------------------------------------

status_t SummaryDataGen_Init(void) {
    return Console_ExportCommandsToCli(&exportedReg, commandList);
}

status_t SummaryDataGen_FakeData(FakeDataSets_t dataSet) {
    status_t ret = SummaryStore_Flush();
    if (Status_IsError(ret)) return ret;

    switch(dataSet) {
    case FakeDataSets_256Seq:
        ret = Generate256Seq();
        break;
    case FakeDataSets_4kSeq:
        ret = Generate4kSeq();
        break;
    case FakeDataSets_200SumSet:
        ret = Generate200SumSet();
        break;
    case FakeDataSets_SingleSumSet:
        ret = GenerateSingleSumSet();
        break;
    case FakeDataSets_SmallSumSet:
        ret = GenerateSmallSumSet();
        break;
    default:
        Console_PrintLine("Unknown fake summary data set: %u", dataSet);
    }

    return ret;
}

/// SAEC Kinetic Vision, Inc. ----------- END OF FILE
