/**
  @file       SummaryProto.c

  @copyright  (C) 2020 Kinetic Vision, Cincinnati Ohio.
               This software is property of SAEC Kinetic Vision, Inc
               and is considered confidential.

  @brief      SummaryProto software unit "C" file.

  @author     Jeffrey Hatton

  @ingroup    SummaryProto

  Configuration History
  =====================

  Config Item    | Value
  -------------- | -----
  Config #       | NA
  Revision       | NA
  Revised, Date  | NA
  QA, Date       | NA
  Approved, Date | NA
  Released, Date | NA

  Significant Modification History (Most recent at top)
  =====================================================

  Date         | Initials | Details
  ------------ | -------- | -------
  07 FEB 2020  | JH       | Original

  Theory of Operation
  ===================
  TBD

*/

// Includes ------------------------------------------------------------------

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

#include "../ConsoleSu/Console.h"
#include "../SwUnitControlSu/SwUnitControl.h"
#include "SummaryProto.h"
#include "SummaryStore.h"
#include "ResBitSummaryService.h"
#include "../SysTimeSu/SysTime.h"
#include "BlueBitBle.h"

// Private function prototypes -----------------------------------------------

static status_t cliPrintStats(uint16_t argc, uint8_t **argv);

static status_t MoveToNextChunk(void);

// Private macros ------------------------------------------------------------

#define returnStatus(__status__,__source__) SwUnitControl_WriteStatus(eSucBleSummaryProto,__source__,__status__,__LINE__);

// Private constants ---------------------------------------------------------

static const consoleCommand_t commandList[] = {
	{ "sumProtoStats","prints the transfer stats for the summary proto\r\n\t",cliPrintStats},

	// Marks last element in the list
    { NULL, NULL, NULL },
};

// Private types -------------------------------------------------------------

typedef enum {
    SummaryProtoStates_Idle = 0,
    SummaryProtoStates_SendingPackets,
    SummaryProtoStates_ResendingPackets,
    SummaryProtoStates_WaitingForResponse,
    SummaryProtoStates_Count
} SummaryProtoStates_t;

typedef struct {
    uint32_t NumPacketsSent;
    uint32_t NumResentSent;
    uint32_t NumNacks;
    uint32_t NumNacksResend;
    uint32_t NumTransfers;
    uint32_t NumErrorStops;
    uint32_t NumChunksSent;
} ProtoStats_t;

// Private constants ---------------------------------------------------------

///
/// The max number of packets that can be in the chunk
///
#define MAX_PACKETS_PER_CHUNK 57

///
/// The max amount of data that can be in a chunk
///
#define MAX_DATA_PER_CHUNK (MAX_PACKETS_PER_CHUNK * SUMMARY_PROTO_PACKET_DATA_SIZE)

///
/// The max amount of time to wait for a response
///
#define WAIT_FOR_RESPONSE_TIMEOUT_MS 2000

// Private variables ---------------------------------------------------------

static consoleRegistration_t exportedReg = {
    (consoleCommand_t *) commandList, // .pList =
    NULL, // .pNext =
};

///
/// Buffer for the packet being sent
///
static uint8_t _PacketData[SUMMARY_PROTO_PACKET_TOTAL_SIZE];

///
/// The current Packet Index being sent
///
static uint8_t _CurrentPacket = 0;

///
/// If the software unit has been initialized
///
static bool _IsInitialized = false;

///
/// The current state of the summary protocol
///
static SummaryProtoStates_t _CurrentState;

///
/// Stores which packets need to be resent
///
static bool _ResendPackets[MAX_PACKETS_PER_CHUNK];

///
/// The number of packets in the current chunk
///
static uint8_t _PacketsInChunk = 0;

///
/// The current chunk idx
///
static uint8_t _CurrentChunk = 0;

///
/// The total amount of data to be sent in bytes
///
static uint16_t _RemainingData = 0;

///
/// The amount of data in the current chunk
///
static uint16_t _DataInChunk = 0;

///
/// If the transfer should move to the next chunk
///
static bool _MoveToNextChunk = false;

///
/// Stats for the protocol
///
static ProtoStats_t _Stats;

///
/// The time in MS that waiting began
///
static uint32_t _WaitStart;

///
/// The time in ms that the transfer started
///
static uint32_t _TransferStart;

// Private function bodies ---------------------------------------------------

static status_t cliPrintStats(uint16_t argc, uint8_t **argv) {
    return Console_Printf("Num Packets: %u \r\n"
                   "Num Packets Resent: %u \r\n"
                   "Num Nacks: %u \r\n"
                   "Num Resend Nacks: %u \r\n"
                   "Num Transfers: %u \r\n"
                   "Num Error Stops: %u \r\n"
                   "Num Chuncks Sent: %u \r\n",
                   _Stats.NumPacketsSent,
                   _Stats.NumResentSent,
                   _Stats.NumNacks,
                   _Stats.NumNacksResend,
                   _Stats.NumTransfers,
                   _Stats.NumErrorStops,
                   _Stats.NumChunksSent
                   );
}

static status_t SetupChunk() {
    status_t ret = StatusOk;

    _Stats.NumChunksSent++;
    _CurrentPacket = 0;
    ResBitSummaryService_UpdateTransfering(1);

    memset(_ResendPackets, 0, sizeof(_ResendPackets));

    _DataInChunk = _RemainingData;
    if (_RemainingData > MAX_DATA_PER_CHUNK) {
        ret = SummaryStore_GetAlignedSize(MAX_DATA_PER_CHUNK, &_DataInChunk);
        if (Status_IsError(ret)) {
            _DataInChunk = MAX_DATA_PER_CHUNK; // just fall back to non-aligned in case of error
        }
    }
    _PacketsInChunk = (_DataInChunk + SUMMARY_PROTO_PACKET_DATA_SIZE - 1) / SUMMARY_PROTO_PACKET_DATA_SIZE;

    Console_Printf("Setting Up Chunk %u, Size: %uB Packets: %u\r\n", _CurrentChunk, _DataInChunk, _PacketsInChunk);
    return ret;
}

static status_t MoveToWaitingForResponse(void) {
    status_t ret = StatusOk;

    _WaitStart = SysTime_GetMsElapsed();
    _CurrentState = SummaryProtoStates_WaitingForResponse;
    ret = ResBitSummaryService_UpdateTransfering(0);

    return ret;
}

static status_t SendCurrentPacket(uint8_t packetIdx, uint8_t totalPackets) {
    // Setup packet
    _PacketData[0] = totalPackets;
    _PacketData[1] = packetIdx;

    status_t ret = SummaryStore_CopyData(SUMMARY_PROTO_PACKET_DATA_SIZE * packetIdx,
                                SUMMARY_PROTO_PACKET_DATA_SIZE,
                                _PacketData + SUMMARY_PROTO_PACKET_HEADER_SIZE);
    if (Status_IsError(ret)) return ret;

    // Send packet
    ret = ResBitSummaryService_UpdateData(_PacketData, SUMMARY_PROTO_PACKET_TOTAL_SIZE);
    if (Status_IsError(ret)) return ret;

    _Stats.NumPacketsSent++;

    return ret;
}

static status_t HandleSending(void) {
    status_t ret = StatusOk;

    ret = SendCurrentPacket(_CurrentPacket, _PacketsInChunk);
    if (Status_IsError(ret)) {
        if (ret == StatusNrfNotQueueFull) return StatusOk;
        Console_Printf("Failed to send packet: %x\r\n", ret);
        ret = SummaryProto_Stop(SummaryProtoStopReasons_PacketSendError);
    } else {
        _CurrentPacket++;

        if (Status_IsOk(ret) && _CurrentPacket == _PacketsInChunk) {
            ret = MoveToWaitingForResponse();
        }
    }

    return ret;
}

static status_t HandleWaitingForResponse(void) {
    status_t ret = StatusOk;

    if (_MoveToNextChunk) {
        ret = MoveToNextChunk();
        _MoveToNextChunk = false;
    } else {
        if (SysTime_IsElapsed(_WaitStart, WAIT_FOR_RESPONSE_TIMEOUT_MS)){
            ret = SummaryProto_Stop(SummaryProtoStopReasons_Timeout);
        }
    }

    return ret;
}

static status_t HandleResending(void) {
    status_t ret = StatusOk;

    uint8_t packetCount = 0;
    for (int i = 0; i < _PacketsInChunk; i++) {
        if (_ResendPackets[i]) packetCount++;
    }

    // Find next resend packet
    while (true) {
        if (_CurrentPacket >= _PacketsInChunk) break;
        if (_ResendPackets[_CurrentPacket]) break;
        _CurrentPacket++;
    }

    // Exit out if end has been reached
    if (_CurrentPacket >= _PacketsInChunk) {
        ret = MoveToWaitingForResponse();
        return ret;
    }

    _Stats.NumResentSent++;

    ret = SendCurrentPacket(_CurrentPacket, _PacketsInChunk);

    if (Status_IsError(ret)) {
        if (ret == StatusNrfNotQueueFull) return StatusOk;

        ret = SummaryProto_Stop(SummaryProtoStopReasons_PacketSendError);
    } else {
        _CurrentPacket++;
    }

    return ret;
}

static status_t MoveToNextChunk(void) {
    status_t ret = StatusOk;

    _RemainingData -= _DataInChunk;
    ret = SummaryStore_Remove(_DataInChunk);
    if (Status_IsError(ret)) return ret;

    _CurrentChunk++;
    if (_RemainingData > 0) {
        ret = SetupChunk();
        _CurrentState = SummaryProtoStates_SendingPackets;
    } else {
        ret = SummaryProto_Stop(SummaryProtoStopReasons_Finished);
    }

    return ret;
}

static status_t HandleResendResponse(uint8_t* rspData, uint8_t len) {
    status_t ret = StatusOk;
    memset(_ResendPackets, 0, sizeof(_ResendPackets));

    _Stats.NumNacksResend++;

    if (len < 2) return SummaryProto_Stop(SummaryProtoStopReasons_InvalidResponse);

    uint8_t* parseData = rspData;

    uint8_t numResend = parseData[0];
    parseData++;

    if (len < 1 + numResend) return SummaryProto_Stop(SummaryProtoStopReasons_InvalidResponse);

    bool packetsToResend = false;

    Console_Printf("%u Packets Need to be resent\r\n", numResend);

    for (int i = 0; i < numResend; i++) {
        uint8_t packetIdx = parseData[i];

        if (packetIdx < _PacketsInChunk) {
            _ResendPackets[packetIdx] = true;
            packetsToResend = true;
        } else {
            //TODO error?
        }
    }

    if (Status_IsOk(ret)) {
        if (packetsToResend) {
            ResBitSummaryService_UpdateTransfering(1);
            _CurrentState = SummaryProtoStates_ResendingPackets;
            _CurrentPacket = 0;
        } else {
            Console_WriteString("No Packets need to be resent moving to next chunck\r\n");
            // Nothing to resend so just move on
            ret = MoveToNextChunk();
        }
    }

    return ret;
}

static status_t HandleNack(uint8_t* rspData, uint8_t len) {
    status_t ret = StatusOk;

    _Stats.NumNacks++;

    if (len == 0) {
        ret = SummaryProto_Stop(SummaryProtoStopReasons_InvalidResponse);
        return returnStatus(ret, eSucWriteStatus);
    }

    uint8_t* parseData = rspData;

    uint8_t nackReason = parseData[0];
    parseData++;

    switch(nackReason) {
    case SummaryProtoNacks_ResendData:
        ret = HandleResendResponse(parseData, len - 1);
        break;
    default:
        ret = StatusIndexOOR;
        break;
    }

    return ret;
}

// Public functions bodies ---------------------------------------------------

status_t SummaryProto_Init(void) {
    status_t ret = StatusOk;
    if (_IsInitialized) return ret;

    _CurrentState = SummaryProtoStates_Idle;

    ret = Console_ExportCommandsToCli(&exportedReg, commandList);

    if (Status_IsOk(ret)) {
        _IsInitialized = true;
    }

    return  returnStatus(ret, eSucInitStatus);
}

status_t SummaryProto_Tick(bool* needMoreTime) {
    status_t ret = StatusOk;

    // Jump out if there is nothing to process
    if (_CurrentState == SummaryProtoStates_Idle) return ret;

    *needMoreTime = true;

    switch (_CurrentState) {
    case SummaryProtoStates_SendingPackets:
        ret = HandleSending();
        break;
    case SummaryProtoStates_WaitingForResponse:
        ret = HandleWaitingForResponse();
        break;
    case SummaryProtoStates_ResendingPackets:
        ret = HandleResending();
        break;
    default:
        ret = StatusIndexOOR;
        break;
    }

    return  returnStatus(ret, eSucTickStatus);
}

status_t SummaryProto_Start(void) {
    status_t ret = StatusOk;

    if (_CurrentState != SummaryProtoStates_Idle) {
        ret = StatusInvalidState;
        return returnStatus(ret, eSucWriteStatus);
    }

    _TransferStart = SysTime_GetMsElapsed();

    Console_WriteString("Starting Summary Transfer\r\n");
    _CurrentState = SummaryProtoStates_SendingPackets;

    ret = SummaryStore_GetUsed(&_RemainingData);
    if (Status_IsError(ret)) return returnStatus(ret, eSucWriteStatus);

    // If no data exit the the process
    if (_RemainingData == 0) return SummaryProto_Stop(SummaryProtoStopReasons_NoData);

    _CurrentChunk = 0;

    Console_Printf("Transfering %uB of data\r\n", _RemainingData);
    _Stats.NumTransfers++;

    ret = SetupChunk();

    return returnStatus(ret, eSucWriteStatus);
}

status_t SummaryProto_Stop(SummaryProtoStopReasons_t stopReason) {
    status_t ret = StatusOk;

    // Ignore stop if proto is not running
    if (_CurrentState == SummaryProtoStates_Idle) return ret;

    if (stopReason != SummaryProtoStopReasons_Finished) {
        _Stats.NumErrorStops++;
    } else {
        Ble_NotifyTransferComplete();
    }

    Console_Printf("Stopping Summary Transfer: %x  Total Time: %u ms\r\n",
                   stopReason,
                   SysTime_GetMsElapsed() - _TransferStart);
    _CurrentState = SummaryProtoStates_Idle;

    // Update BLE characteristics
    ret = ResBitSummaryService_UpdateTransferSummary(0);
    ret = ResBitSummaryService_UpdateTransfering(0);
    ret = ResBitSummaryService_UpdateError(stopReason);

    return returnStatus(ret, eSucWriteStatus);
}

status_t SummaryProto_NotifyResponse(SummaryProtoResponses_t response, uint8_t* rspData, uint8_t len) {
    status_t ret = StatusOk;

    if (rspData == NULL) return returnStatus(StatusNullParameter, eSucWriteStatus);

    switch (response) {
        case SummaryProtoResponses_Ack:
            _MoveToNextChunk = true;
            break;
        case SummaryProtoResponses_Nack:
            ret = HandleNack(rspData, len);
            break;
        default:
            ret = SummaryProto_Stop(SummaryProtoStopReasons_InvalidResponse);
            break;
    }

    if (Status_IsError(ret)) {
        ret = SummaryProto_Stop(SummaryProtoStopReasons_InternalError);
    }

    return returnStatus(ret, eSucWriteStatus);
}

/// SAEC Kinetic Vision, Inc. ----------- END OF FILE
