/**
  @file       SummaryStore.c

  @copyright  (C) 2020 Kinetic Vision, Cincinnati Ohio.
               This software is property of SAEC Kinetic Vision, Inc
               and is considered confidential.

  @brief      SummaryStore software unit "C" file.

  @author     Jeffrey Hatton

  @ingroup    SummaryData

  Configuration History
  =====================

  Config Item    | Value
  -------------- | -----
  Config #       | NA
  Revision       | NA
  Revised, Date  | NA
  QA, Date       | NA
  Approved, Date | NA
  Released, Date | NA

  Significant Modification History (Most recent at top)
  =====================================================

  Date         | Initials | Details
  ------------ | -------- | -------
  DD MMM 2020  | JH       | Original

  Theory of Operation
  ===================
  TBD

*/

// Includes ------------------------------------------------------------------

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

#include "../ConsoleSu/Console.h"
#include "../SwUnitControlSu/SwUnitControl.h"
#include "../MessagerSu/Messager.h"
#include "../FifoSu/Fifo8.h"
#include "SummaryStore.h"

// Private function prototypes -----------------------------------------------

static status_t summaryMessageHandler(messageHandlerArgs_t * args);

// Private macros ------------------------------------------------------------

#define returnStatus(__status__,__source__) SwUnitControl_WriteStatus(eSucBleSummaryStore,__source__,__status__,__LINE__);

#define SUMMARY_DATA_HEADER_SIZE        7
#define SUMMARY_DATA_SIZE_FIELD_OFFSET  SUMMARY_DATA_HEADER_SIZE - 1
// Private types -------------------------------------------------------------

// Private constants ---------------------------------------------------------

///
/// ID for the summary message
///
#define SUMMARY_MESSAGE_ID 0x0100

///
/// List of messages and their handlers for this software unit
///
static const messageHandlerReg_t _MessageHandlers[] = {
    { SUMMARY_MESSAGE_ID, summaryMessageHandler },
    // Marks last element in the list
    { 0, NULL },
};

///
/// Node for the handlers
///
static messageHandlerList_t _MessageHandlerRoot = { _MessageHandlers, NULL };

///
/// The max capacity of the store
///
#define STORE_CAPACITY 4096

#define BUFFER_CAPACITY (STORE_CAPACITY + 3)

// Private variables ---------------------------------------------------------

///
/// If the software unit has been initialized
///
static bool _IsInitialized = false;

///
/// The buffer for the store
///
static uint8_t _Buffer[BUFFER_CAPACITY];

///
/// Fifo for the store
///
static Fifo8_t _SumFifo;

// Private function bodies ---------------------------------------------------

static status_t summaryMessageHandler(messageHandlerArgs_t * args) {
    status_t ret = StatusOk;

    uint16_t eventCount;
    if (args->dataLen <= sizeof(eventCount)) {
        args->resCode = messageResponseDataError;
        ret = StatusMessageData;
    } else {
        memcpy(&eventCount, args->messageData, sizeof(eventCount));

        const uint8_t * summaryData = args->messageData + sizeof(eventCount);
        size_t summaryLen = args->dataLen - sizeof(eventCount);
        ret = SummaryStore_StoreEvents(summaryData, summaryLen);
        
        // Respond with success regardless of our internal status (since the message itself was OK)
        args->resCode = messageResponseSuccess;
    }

    args->bytesWritten = 0;
    Console_PrintLine("Recieved %d events from message", eventCount);

    return ret;
}

// Public functions bodies ---------------------------------------------------

status_t SummaryStore_Init(void) {
    status_t ret = StatusOk;
    if (_IsInitialized) return ret;

    _SumFifo.Status = StatusNotInitialized;
    ret = Fifo8_SetupQueObject(&_SumFifo, _Buffer, BUFFER_CAPACITY);
    if (Status_IsError(ret)) return returnStatus(ret, eSucInitStatus);

    ret = Messager_Subscribe(&_MessageHandlerRoot);
    if (Status_IsError(ret)) return returnStatus(ret, eSucInitStatus);

    if (Status_IsOk(ret)) {
        _IsInitialized = true;
    }

    return returnStatus(ret, eSucInitStatus);
}

status_t SummaryStore_GetCapacity(uint16_t* capacity) {
    if (capacity == NULL) return returnStatus(StatusNullParameter, eSucReadStatus);

    *capacity = STORE_CAPACITY;

    return returnStatus(StatusOk, eSucReadStatus);
}

status_t SummaryStore_StoreEvents(const uint8_t* data, uint16_t len) {
    if (data == NULL) return returnStatus(StatusNullParameter, eSucReadStatus);

    status_t ret = Fifo8_Enqueue(&_SumFifo, data, len);
    if (Status_IsOk(ret)) {
        ret = Ble_NotifyNewSummaryData();
    }

    return returnStatus(ret, eSucWriteStatus);
}

status_t SummaryStore_GetUsed(uint16_t* usedBytes) {
    if (usedBytes == NULL) return returnStatus(StatusNullParameter, eSucReadStatus);

    status_t ret = Fifo8_ReturnUsed(&_SumFifo, usedBytes);

    return returnStatus(ret, eSucReadStatus);
}

status_t SummaryStore_GetAlignedSize(uint16_t maxSize, uint16_t* sizeOut) {
    if (sizeOut == NULL) return returnStatus(StatusNullParameter, eSucReadStatus);
    
    uint16_t currentSize = 0;
    uint16_t usedBytes;
    
    status_t ret = Fifo8_ReturnUsed(&_SumFifo, &usedBytes);
    if (Status_IsError(ret)) return returnStatus(ret, eSucReadStatus);
    
    while (1) {
        if ((usedBytes - currentSize) <= SUMMARY_DATA_HEADER_SIZE) {
            return returnStatus(StatusDataCorruption, eSucReadStatus);
        }
        
        uint8_t nextEventSize = 0;
        ret = Fifo8_Peek(&_SumFifo, &nextEventSize, sizeof(nextEventSize),
                         currentSize + SUMMARY_DATA_SIZE_FIELD_OFFSET);
        if (Status_IsError(ret)) return returnStatus(ret, eSucReadStatus);
        
        uint16_t nextSize = currentSize + SUMMARY_DATA_HEADER_SIZE + 
            nextEventSize;
        if (nextSize > usedBytes || nextSize > maxSize) {
            break;
        } else {
            currentSize = nextSize;
        }
    }
    
    *sizeOut = currentSize;
    return returnStatus(ret, eSucReadStatus);
}

status_t SummaryStore_CopyData(uint16_t offset, uint16_t numBytes, uint8_t* buffer) {
    if (buffer == NULL) return returnStatus(StatusNullParameter, eSucReadStatus);

    status_t ret = Fifo8_Peek(&_SumFifo, buffer, numBytes, offset);

    return returnStatus(ret, eSucReadStatus);
}

status_t SummaryStore_Remove(uint16_t numBytes) {
    status_t ret = StatusOk;

    ret = Fifo8_FlushBytes(&_SumFifo, numBytes);

    return returnStatus(ret, eSucWriteStatus);
}

status_t SummaryStore_Flush(void) {
    status_t ret = Fifo8_FlushQueueByConsumer(&_SumFifo);
    return returnStatus(ret, eSucWriteStatus);
}

/// SAEC Kinetic Vision, Inc. ----------- END OF FILE
