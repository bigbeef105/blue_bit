/**
  @file       ResBitSummaryService.h

  @copyright  (C) 2020 Kinetic Vision, Cincinnati Ohio.
               This software is property of SAEC Kinetic Vision, Inc
               and is considered confidential.

  @brief      ResBitSummaryService software unit "H" file.

  @author     Jeffrey Hatton

  @defgroup   BLE Software unit for defining and interfacing with the ResBit
                  summary service

  Configuration History
  =====================

  Config Item    | Value
  -------------- | -----
  Config #       | NA
  Revision       | NA
  Revised, Date  | NA
  QA, Date       | NA
  Approved, Date | NA
  Released, Date | NA

  Significant Modification History (Most recent at top)
  =====================================================

  Date         | Initials | Details
  ------------ | -------- | -------
  03 FEB 2020  | JH       | Original

  Theory of Operation
  ===================
  TBD

  */

// Define to prevent recursive inclusion -------------------------------------
#ifndef __RESBIT_SUMMARY_SERVICE_H
#define __RESBIT_SUMMARY_SERVICE_H

#include "Status.h"
#include "../Device/DeviceInfo.h"

// Exported macro ------------------------------------------------------------

// Exported types ------------------------------------------------------------
typedef enum {
    ResBitSummaryCharacteristics_Data,
    ResBitSummaryCharacteristics_TransferSummaryData,
    ResBitSummaryCharacteristics_Transfering,
    ResBitSummaryCharacteristics_AckNck,
    ResBitSummaryCharacteristics_Response,
    ResBitSummaryCharacteristics_EnableDebug,
    ResBitSummaryCharacteristics_SerialNumber,
    ResBitSummaryCharacteristics_TransferError,
    ResBitSummaryCharacteristics_Count,
} ResBitSummaryCharacteristics_t;

// Exported constants --------------------------------------------------------

///
/// The UUID of the summary service
///
#define BLE_SUMMARY_SERVICE_UUID 0xAA00

#define BLE_SUMMARY_SERVICE_DATA_CHAR_UUID 0xAA01

#define BLE_SUMMARY_SERVICE_TRANSFER_SUMMARY_DATA_CHAR_UUID 0xAA02

#define BLE_SUMMARY_SERVICE_TRANSFERING_CHAR_UUID 0xAA03

#define BLE_SUMMARY_SERVICE_ACK_NCK_CHAR_UUID 0xAA04

#define BLE_SUMMARY_SERVICE_RESPONSE_CHAR_UUID 0xAA05

#define BLE_SUMMARY_SERVICE_ENABLE_DEBUG_UUID 0xAA07

#define BLE_SUMMARY_SERVICE_RESBIT_SERIAL_UUID 0xAA08

#define BLE_SUMMARY_SERVICE_TRANSFER_ERROR_UUID 0xAA09

// Exported objects ----------------------------------------------------------

// Exported functions --------------------------------------------------------

///  @brief Initializes the ResBitSummary Service software unit
///  @return status.
status_t ResBitSummaryService_Init(void);

///  @brief Update the data characteristic
///  @return status.
status_t ResBitSummaryService_UpdateData(uint8_t* values, uint8_t dataLen);

///  @brief Update the serial number characteristic
///  @return status.
status_t ResBitSummaryService_UpdateSerialNum(serialNum_t *serialNum);

///  @brief Update the transfering chacteristic
///  @return status.
status_t ResBitSummaryService_UpdateTransfering(uint8_t value);

///  @brief Update the Transfer Summary chacteristic
///  @return status.
status_t ResBitSummaryService_UpdateTransferSummary(uint8_t value);

///  @brief Update the error characteristic
///  @return status.
status_t ResBitSummaryService_UpdateError(uint8_t value);

///  @brief Notifiy the service that the client has disconnected
///  @return status.
status_t ResBitSummaryService_ClientDisconnected(void);

#endif // __RESBIT_SUMMARY_SERVICE_H

/// SAEC Kinetic Vision, Inc. ----------- END OF FILE


