/**
  @file       BlueBitsAdvertiser.c

  @copyright  (C) 2020 Kinetic Vision, Cincinnati Ohio.
               This software is property of SAEC Kinetic Vision, Inc
               and is considered confidential.

  @brief      BlueBitsAdvertiser software unit "C" file.

  @author     Jeffrey Hatton

  @ingroup    BLE

  Configuration History
  =====================

  Config Item    | Value
  -------------- | -----
  Config #       | NA
  Revision       | NA
  Revised, Date  | NA
  QA, Date       | NA
  Approved, Date | NA
  Released, Date | NA

  Significant Modification History (Most recent at top)
  =====================================================

  Date         | Initials | Details
  ------------ | -------- | -------
  29 JAN 2020  | JH       | Original

  Theory of Operation
  ===================
  TBD

*/

// Includes ------------------------------------------------------------------

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <stdint.h>

#include "../SwUnitControlSu/SwUnitControl.h"
#include "../ConsoleSu/Console.h"
#include "BlueBitsAdvertiser.h"
#include "BleConfig.h"
#include "BlueBitBle.h"
#include "ResBitSummaryService.h"

// Private function prototypes -----------------------------------------------

// Private macros ------------------------------------------------------------
#define returnStatus(__status__,__source__) SwUnitControl_WriteStatus(eSucBleAdvert,__source__,__status__,__LINE__);
#define SECONDS_TO_ADV_TIMEOUT(seconds) ((seconds) * 100)

// Private constants ---------------------------------------------------------

#define APP_BEACON_INFO_LENGTH 0x17
#define APP_ADV_DATA_LENGTH             0x15
#define APP_DEVICE_TYPE                 0x02
#define APP_MEASURED_RSSI               0xC3

///
/// Compnay identifier for Beacon. 0x004C is Apple.
///
#define APP_COMPANY_IDENTIFIER          0x004C

// Private types -------------------------------------------------------------

// Private constants ---------------------------------------------------------

// Private variables ---------------------------------------------------------

///
/// If the unit is currently advertising
///
static bool _Advertising = false;

///
/// Buffer for the beacon data
///
static BeaconInfo_t _BeaconInfo;

///
/// The current advertisment interval
///
static uint32_t _AdvertInterval;

///
/// The value of _Adervisting before connection event
///
static bool _AdvertValueBeforeConnection;

// Private function bodies ---------------------------------------------------

/**@brief Function for handling advertising events.
 *
 * @details This function will be called for advertising events which are passed to the application.
 *
 * @param[in] ble_adv_evt  Advertising event.
 */
static void on_adv_evt(ble_adv_evt_t ble_adv_evt) {
    switch (ble_adv_evt)
    {
        case BLE_ADV_EVT_FAST:
            break;
        case BLE_ADV_EVT_IDLE:
            _Advertising = false;
            Ble_NotifyAdvertTimeout();
            break;

        default:
            break;
    }
}

static uint16_t adv_set_data_size_max_get(ble_advertising_t const * const p_advertising)
{
    uint16_t adv_set_data_size_max;

    if (m_advertising.adv_modes_config.ble_adv_extended_enabled == true)
    {
        #ifdef BLE_GAP_ADV_SET_DATA_SIZE_EXTENDED_CONNECTABLE_MAX_SUPPORTED
        adv_set_data_size_max = BLE_GAP_ADV_SET_DATA_SIZE_EXTENDED_CONNECTABLE_MAX_SUPPORTED;
        #else
        adv_set_data_size_max = BLE_GAP_ADV_SET_DATA_SIZE_MAX;
        #endif // BLE_GAP_ADV_SET_DATA_SIZE_EXTENDED_CONNECTABLE_MAX_SUPPORTED
    }
    else
    {
        adv_set_data_size_max = BLE_GAP_ADV_SET_DATA_SIZE_MAX;
    }

    return adv_set_data_size_max;
}

static status_t SetupManufactureData(ble_advdata_t* advData) {
    status_t ret = StatusOk;
    uint32_t nrfRet;
    ble_advdata_manuf_data_t manuf_specific_data;

    // Setup Buffers
    m_advertising.adv_data.adv_data.p_data = m_advertising.enc_advdata[0];
    m_advertising.adv_data.adv_data.len = adv_set_data_size_max_get(&m_advertising);

    // Apply Beacon Data
    manuf_specific_data.company_identifier = APP_COMPANY_IDENTIFIER;
    manuf_specific_data.data.p_data = (uint8_t *)&_BeaconInfo + BEACON_DATA_PADDING;
    manuf_specific_data.data.size   =  0x17;

    // Set reference to manufacture data
    advData->p_manuf_specific_data = &manuf_specific_data;

    nrfRet = ble_advdata_encode(advData, m_advertising.adv_data.adv_data.p_data, &m_advertising.adv_data.adv_data.len);
    if (NRF_IS_ERROR(nrfRet)) {
        Console_PrintLine("NRF Error when encoding manu data: 0x%0.8x", nrfRet);
        //TODO error
        ret = StatusNrfError;
    }

    return ret;
}

static status_t SetupScanResponse(void) {
    status_t ret = StatusOk;
    uint32_t nrfRet;
    ble_advdata_t srdata;
    memset(&srdata, 0, sizeof(srdata));

    uint8_t uuidType;
    Ble_GetVendorUuidType(&uuidType);
    ble_uuid_t adv_uuids[] = {{BLE_SUMMARY_SERVICE_UUID, uuidType}};

    // Setup mermory for scan response
    m_advertising.adv_data.scan_rsp_data.p_data = m_advertising.enc_scan_rsp_data[0];
    m_advertising.adv_data.scan_rsp_data.len = adv_set_data_size_max_get(&m_advertising);

    memset(&srdata, 0, sizeof(srdata));
    srdata.uuids_complete.uuid_cnt = sizeof(adv_uuids) / sizeof(adv_uuids[0]);
    srdata.uuids_complete.p_uuids  = adv_uuids;
    srdata.name_type = BLE_ADVDATA_FULL_NAME;

    nrfRet = ble_advdata_encode(&srdata,
                              m_advertising.adv_data.scan_rsp_data.p_data,
                             &m_advertising.adv_data.scan_rsp_data.len);
    if (NRF_IS_ERROR(nrfRet)) {
        Console_PrintLine("NRF Error when encoding scan reponse data: 0x%0.8x", nrfRet);
        ret = StatusNrfError;
    }

    return ret;
}

static status_t SetupAdvertData(uint32_t timeoutSeconds) {
    status_t ret = StatusOk;

    uint32_t nrfRet;
    ble_adv_modes_config_t config;
    ble_advdata_t           advdata;
    memset(&config, 0, sizeof(config));
    memset(&advdata, 0, sizeof(advdata));

    // Setup basic Advert data
    advdata.name_type               = BLE_ADVDATA_NO_NAME;
    advdata.flags                   = BLE_GAP_ADV_FLAGS_LE_ONLY_GENERAL_DISC_MODE;

    config.ble_adv_fast_enabled  = true;
    config.ble_adv_fast_interval = _AdvertInterval;
    config.ble_adv_fast_timeout  = SECONDS_TO_ADV_TIMEOUT(timeoutSeconds);
    config.ble_adv_on_disconnect_disabled = true;

    m_advertising.adv_mode_current               = BLE_ADV_MODE_IDLE;
    m_advertising.adv_modes_config               = config;
    m_advertising.conn_cfg_tag                   = BLE_CONN_CFG_TAG_DEFAULT;
    m_advertising.evt_handler                    = on_adv_evt;
    m_advertising.error_handler                  = NULL;
    m_advertising.current_slave_link_conn_handle = BLE_CONN_HANDLE_INVALID;
    m_advertising.p_adv_data                     = &m_advertising.adv_data;

    memset(&m_advertising.peer_address, 0, sizeof(m_advertising.peer_address));

    if (!m_advertising.initialized) {
        m_advertising.adv_handle = BLE_GAP_ADV_SET_HANDLE_NOT_SET;
    }

    //
    // Setup advanced advert data
    //

    ret = SetupManufactureData(&advdata);
    if (Status_IsError(ret)) return ret;

    ret = SetupScanResponse();
    if (Status_IsError(ret)) return ret;

    memset(&m_advertising.adv_params, 0, sizeof(m_advertising.adv_params));
    m_advertising.adv_params.primary_phy     = BLE_GAP_PHY_1MBPS;
    m_advertising.adv_params.duration        = m_advertising.adv_modes_config.ble_adv_fast_timeout;
    m_advertising.adv_params.properties.type = BLE_GAP_ADV_TYPE_CONNECTABLE_SCANNABLE_UNDIRECTED;
    m_advertising.adv_params.p_peer_addr     = NULL;
    m_advertising.adv_params.filter_policy   = BLE_GAP_ADV_FP_ANY;
    m_advertising.adv_params.interval        = m_advertising.adv_modes_config.ble_adv_fast_interval;

    nrfRet = sd_ble_gap_adv_set_configure(&m_advertising.adv_handle, &m_advertising.adv_data, &m_advertising.adv_params);
    if (NRF_IS_ERROR(nrfRet)) {
        ret = StatusNrfError;
        Console_PrintLine("NRF Error when setting up advert data: 0x%0.8x", nrfRet);
    }

    ble_advertising_conn_cfg_tag_set(&m_advertising, APP_BLE_CONN_CFG_TAG);
    m_advertising.initialized = true;

    return ret;
}

static status_t TurnOffAdvert(void) {
    status_t ret = StatusOk;

    Console_WriteLine("Ending Advertisment");
    sd_ble_gap_adv_stop(m_advertising.adv_handle);
    _Advertising = false;

    return ret;
}

static status_t TurnOnAdvert(uint32_t timeoutSeconds) {
    status_t ret = StatusOk;

    Console_WriteLine("Generating Advert Data");

    ret = SetupAdvertData(timeoutSeconds);
    if (Status_IsOk(ret)) {
        Console_WriteLine("Starting Advertisment");
        ret_code_t err_code = ble_advertising_start(&m_advertising, BLE_ADV_MODE_FAST);
        if (NRF_IS_ERROR(err_code)) {
            Console_PrintLine("NRF Error when starting advert: 0x%0.8x", err_code);
            return StatusNrfError;
        }
        _Advertising = true;
    } else {
        Console_PrintLine("Advert Data Failed 0x%x", ret);
    }

    return ret;
}

// Public functions bodies ---------------------------------------------------

status_t BlueBitsAdvertiser_Init(void) {
    status_t ret = StatusOk;
    _Advertising = false;
    return returnStatus(ret, eSucInitStatus);
}

status_t BlueBitsAdvertiser_StartAdvertise(uint32_t timeoutSeconds) {
    status_t ret = StatusOk;

    if (!_Advertising) {
        ret = TurnOnAdvert(timeoutSeconds);
    }

    return returnStatus(ret, eSucWriteStatus);
}

status_t BlueBitsAdvertiser_StopAdvertise(void) {
    status_t ret = StatusOk;

    if (_Advertising) {
        ret = TurnOffAdvert();
    }

    return returnStatus(ret, eSucWriteStatus);
}

status_t BlueBitsAdvertiser_SetBeaconInfo(BeaconInfo_t* info) {
    status_t ret = StatusOk;

    if (info != NULL) {
        memcpy(&_BeaconInfo, info, sizeof(BeaconInfo_t));
        _BeaconInfo.MeasuredRSSI = APP_MEASURED_RSSI;
        _BeaconInfo.DataLength = APP_ADV_DATA_LENGTH;
        _BeaconInfo.DeviceType = APP_DEVICE_TYPE;
    } else {
        ret = StatusParameter1;
    }

    return returnStatus(ret, eSucWriteStatus);
}

status_t BlueBitsAdvertiser_SetAdvertInterval(uint32_t advertInterval) {
    status_t ret = StatusOk;

    _AdvertInterval = advertInterval;

    return returnStatus(ret, eSucWriteStatus);
}

status_t BlueBitsAdvertiser_Connected(void) {
    // Cache old value and set the internal value to false
    // as the stack will automatically stop advertising on connection
    _AdvertValueBeforeConnection = _Advertising;
    _Advertising = false;

    return returnStatus(StatusOk, eSucWriteStatus);
}

status_t BlueBitsAdvertiser_GetAdvertising(bool* advertising) {
    if (advertising == NULL) return returnStatus(StatusNullParameter, eSucReadStatus);

    *advertising = _Advertising;

    return returnStatus(StatusOk, eSucReadStatus);
}

/// SAEC Kinetic Vision, Inc. ----------- END OF FILE
