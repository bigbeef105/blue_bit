/**
  @file       SummaryDataGen.h

  @copyright  (C) 2020 Kinetic Vision, Cincinnati Ohio.
               This software is property of SAEC Kinetic Vision, Inc
               and is considered confidential.

  @brief      SummaryDataGen software unit "H" file.

  @author     Jeffrey Hatton

  @defgroup   SummaryDataGen Generator for fake summary data. Used to make fake data
                             sets for the summary service.

  Configuration History
  =====================

  Config Item    | Value
  -------------- | -----
  Config #       | NA
  Revision       | NA
  Revised, Date  | NA
  QA, Date       | NA
  Approved, Date | NA
  Released, Date | NA

  Significant Modification History (Most recent at top)
  =====================================================

  Date         | Initials | Details
  ------------ | -------- | -------
  13 FEB 2020  | JH       | Original

  Theory of Operation
  ===================
  TBD

  */

// Define to prevent recursive inclusion -------------------------------------
#ifndef __SUMMARY_DATA_GEN_H
#define __SUMMARY_DATA_GEN_H

#include "Status.h"

// Exported macro ------------------------------------------------------------

// Exported types ------------------------------------------------------------

typedef enum {
    FakeDataSets_200SumSet = 0,
    FakeDataSets_256Seq,
    FakeDataSets_4kSeq,
    FakeDataSets_SingleSumSet,
    FakeDataSets_SmallSumSet,
    FakeDataSets_Count,
} FakeDataSets_t;

// Exported constants --------------------------------------------------------

// Exported objects ----------------------------------------------------------

// Exported functions --------------------------------------------------------

status_t SummaryDataGen_Init(void);

///  @brief Creates and stores a fake data set into the summary store
///  @param dataSet  The data set to create
///  @return status.
status_t SummaryDataGen_FakeData(FakeDataSets_t dataSet);

#endif // __SUMMARY_DATA_GEN_H

/// SAEC Kinetic Vision, Inc. ----------- END OF FILE
