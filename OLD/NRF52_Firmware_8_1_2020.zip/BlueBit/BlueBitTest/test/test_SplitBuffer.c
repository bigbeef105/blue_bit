#include "unity.h"

#include <stdint.h> // int types
#include <string.h> // memset

#include "SplitBuffer.h"
#include "Status.h"
#include "mock_Console.h"

// Force linkage
TEST_FILE("SwUnitControl.c");

// Constants
#define BUFFER_SIZE         1024

// types
typedef struct {
    uint8_t value;
    uint16_t size;
} valueAndSize;

// Private variables
splitBuffer_t sb;
uint8_t buffer[BUFFER_SIZE]; 

// Private function prototypes
static void enqueueBlock(uint8_t value, size_t testBuffSize);
static void loopThroughEnqueueDequeue(valueAndSize * valuesAndSizes, size_t numValuesAndSizes,
        size_t enqueueLeadBy, size_t numIterations);

// Private function definitions
static void enqueueBlock(uint8_t value, size_t testBuffSize)
{
    uint8_t buff[BUFFER_SIZE];
    memset(buff, value, testBuffSize);

    // Ensure it returns Ok
    TEST_ASSERT_EQUAL(StatusOk, SplitBuffer_Enqueue(&sb, buff, testBuffSize));
}

static void loopThroughEnqueueDequeue(valueAndSize * valuesAndSizes, size_t numValuesAndSizes,
        size_t enqueueLeadBy, size_t numIterations)
{
    TEST_ASSERT(numValuesAndSizes >= enqueueLeadBy);

    // Reset split buffer
    SplitBuffer_Setup(&sb, buffer, BUFFER_SIZE);

    for (int i = 0; i < enqueueLeadBy; i++) { 
        enqueueBlock(valuesAndSizes[i].value, valuesAndSizes[i].size);
    }

    uint8_t outBuffer[BUFFER_SIZE];
    size_t bytesWritten;
    size_t loopCount = numIterations * numValuesAndSizes;
    for (int i = enqueueLeadBy; i < (loopCount + enqueueLeadBy); i++) {
        size_t eIndex = i % numValuesAndSizes;
        size_t dIndex = (i - enqueueLeadBy) % numValuesAndSizes;

        // Dequeue and check
        memset(outBuffer, 0, sizeof(outBuffer));
        TEST_ASSERT_EQUAL(StatusOk, SplitBuffer_Dequeue(&sb, outBuffer, 
                sizeof(outBuffer), &bytesWritten));
        TEST_ASSERT_EQUAL(valuesAndSizes[dIndex].size, bytesWritten);
        TEST_ASSERT_EQUAL(valuesAndSizes[dIndex].value, outBuffer[0]);
        TEST_ASSERT_EQUAL(valuesAndSizes[dIndex].value, outBuffer[bytesWritten - 1]);

        // enqueue next
        enqueueBlock(valuesAndSizes[eIndex].value, valuesAndSizes[eIndex].size);
    }
}

static void loopThroughEnqueueGetFree(valueAndSize * valuesAndSizes, size_t numValuesAndSizes,
        size_t enqueueLeadBy, size_t numIterations)
{
    TEST_ASSERT(numValuesAndSizes >= enqueueLeadBy);

    // Reset split buffer
    SplitBuffer_Setup(&sb, buffer, BUFFER_SIZE);

    for (int i = 0; i < enqueueLeadBy; i++) { 
        enqueueBlock(valuesAndSizes[i].value, valuesAndSizes[i].size);
    }

    uint8_t outBuffer[BUFFER_SIZE];
    uint8_t * headPtr;
    size_t headSize;
    size_t loopCount = numIterations * numValuesAndSizes;
    for (int i = enqueueLeadBy; i < (loopCount + enqueueLeadBy); i++) {
        size_t eIndex = i % numValuesAndSizes;
        size_t dIndex = (i - enqueueLeadBy) % numValuesAndSizes;

        // Get and check
        TEST_ASSERT_EQUAL(StatusOk, SplitBuffer_GetHead(&sb, &headPtr, 
                &headSize));
        memcpy(outBuffer, headPtr, headSize);
        TEST_ASSERT_EQUAL(valuesAndSizes[dIndex].size, headSize);
        TEST_ASSERT_EQUAL(valuesAndSizes[dIndex].value, outBuffer[0]);
        TEST_ASSERT_EQUAL(valuesAndSizes[dIndex].value, outBuffer[headSize - 1]);

        // Free
        TEST_ASSERT_EQUAL(StatusOk, SplitBuffer_FreeHead(&sb));

        // enqueue next
        enqueueBlock(valuesAndSizes[eIndex].value, valuesAndSizes[eIndex].size);
    }
}

// Unity functions
void setUp()
{
    SplitBuffer_Setup(&sb, buffer, BUFFER_SIZE);
}

void tearDown()
{
}

// Test functions
void test_simpleEnqueue()
{
    size_t testBuffSize = 80;
    enqueueBlock(42, testBuffSize);

    // Verify head
    TEST_ASSERT_EQUAL(42, sb.read->buffer[0]);
    TEST_ASSERT_EQUAL(0, sb.read->head);

    // Verify tail
    TEST_ASSERT_EQUAL(42, sb.read->buffer[testBuffSize - 1]);
    TEST_ASSERT_EQUAL(testBuffSize, sb.read->tails[0]);
}

void test_maxSizeEnqueue()
{
    size_t testBuffSize = BUFFER_SIZE / 2;
    enqueueBlock(42, testBuffSize);
    
    // Verify head
    TEST_ASSERT_EQUAL(42, sb.read->buffer[0]);
    TEST_ASSERT_EQUAL(0, sb.read->head);

    // Verify tail
    TEST_ASSERT_EQUAL(42, sb.read->buffer[testBuffSize - 1]);
    TEST_ASSERT_EQUAL(testBuffSize, sb.read->tails[0]);
}

void test_maxSizePlusOneEnqueue()
{
    size_t testBuffSize = (BUFFER_SIZE / 2) + 1;
    uint8_t buff[testBuffSize];
    memset(buff, 13, testBuffSize);

    // Ensure it returns error
    TEST_ASSERT_EQUAL(StatusBufferFull, SplitBuffer_Enqueue(&sb, buff, testBuffSize));
}

void test_multiEnqueues()
{
    size_t len1 = 256;
    size_t len2 = 128;
    size_t len3 = 64;
    size_t len4 = 64;
    size_t len5 = 512;

    enqueueBlock(1, len1);
    enqueueBlock(2, len2);
    enqueueBlock(3, len3);
    enqueueBlock(4, len4);
    enqueueBlock(5, len5);

    // Verify first
    uint16_t head = 0;
    uint16_t tail = len1;
    TEST_ASSERT_EQUAL(1, sb.near.buffer[head]);
    TEST_ASSERT_EQUAL(1, sb.near.buffer[tail - 1]);
    TEST_ASSERT_EQUAL(tail, sb.near.tails[0]);

    // Verify second
    head += len1;
    tail += len2;
    TEST_ASSERT_EQUAL(2, sb.near.buffer[head]);
    TEST_ASSERT_EQUAL(2, sb.near.buffer[tail - 1]);
    TEST_ASSERT_EQUAL(tail, sb.near.tails[1]);

    // Verify third
    head += len2;
    tail += len3;
    TEST_ASSERT_EQUAL(3, sb.near.buffer[head]);
    TEST_ASSERT_EQUAL(3, sb.near.buffer[tail - 1]);
    TEST_ASSERT_EQUAL(tail, sb.near.tails[2]);

    // Verify fourth
    head += len3;
    tail += len4;
    TEST_ASSERT_EQUAL(4, sb.near.buffer[head]);
    TEST_ASSERT_EQUAL(4, sb.near.buffer[tail - 1]);
    TEST_ASSERT_EQUAL(tail, sb.near.tails[3]);

    // Verify fifth
    TEST_ASSERT_EQUAL(5, sb.far.buffer[0]);
    TEST_ASSERT_EQUAL(5, sb.far.buffer[len5 - 1]);
    TEST_ASSERT_EQUAL(len5, sb.far.tails[0]);
}

void test_simpleDequeue()
{
    size_t testBuffSize = 80;
    enqueueBlock(42, testBuffSize);

    uint8_t outBuff[testBuffSize];
    memset(outBuff, 0, testBuffSize);
    size_t bytesWritten = 0;
    TEST_ASSERT_EQUAL(StatusOk, SplitBuffer_Dequeue(&sb, outBuff, testBuffSize, &bytesWritten));

    // Make sure data copied out is correct
    TEST_ASSERT_EQUAL(testBuffSize, bytesWritten);
    TEST_ASSERT_EQUAL(42, outBuff[0]);
    TEST_ASSERT_EQUAL(42, outBuff[testBuffSize - 1]);

    // Make sure buffer is back to correct state
    TEST_ASSERT_EQUAL(0, sb.read->head);
    TEST_ASSERT_EQUAL(0, sb.read->tails[0]);
}

void test_multiEnqueuesDequeues()
{
    valueAndSize valuesAndSizes[] = {
        {1, 88},
        {2, 23},
        {3, 44},
        {4, 2},
        {5, 87},
    };

    loopThroughEnqueueDequeue(
        valuesAndSizes, 
        sizeof(valuesAndSizes) / sizeof(*valuesAndSizes),
        1,
        1000);

    loopThroughEnqueueDequeue(
        valuesAndSizes, 
        sizeof(valuesAndSizes) / sizeof(*valuesAndSizes),
        3,
        1000);

    loopThroughEnqueueDequeue(
        valuesAndSizes, 
        sizeof(valuesAndSizes) / sizeof(*valuesAndSizes),
        5,
        1000);
}

void test_multiEnqueuesGetsFrees()
{
    valueAndSize valuesAndSizes[] = {
        {1, 5},
        {2, 99},
        {3, 82},
        {4, 31},
        {5, 122},
    };

    loopThroughEnqueueGetFree(
        valuesAndSizes, 
        sizeof(valuesAndSizes) / sizeof(*valuesAndSizes),
        1,
        1000);

    loopThroughEnqueueGetFree(
        valuesAndSizes, 
        sizeof(valuesAndSizes) / sizeof(*valuesAndSizes),
        3,
        1000);

    loopThroughEnqueueGetFree(
        valuesAndSizes, 
        sizeof(valuesAndSizes) / sizeof(*valuesAndSizes),
        5,
        1000);
}