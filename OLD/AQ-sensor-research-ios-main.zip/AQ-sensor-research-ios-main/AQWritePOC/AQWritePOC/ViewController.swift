//
//  ViewController.swift
//  AQWritePOC
//
//  Created by Aaron on 11/5/19.
//  Copyright © 2019 Alchemy. All rights reserved.
//

import UIKit
import AWSMobileClient

class ViewController: UIViewController {

    @IBOutlet weak var statusText: UITextView!
    @IBOutlet weak var signInButton: UIButton!
    @IBOutlet weak var signOutButton: UIButton!
    @IBOutlet weak var testDeviceProvisioningButton: UIButton!
    @IBOutlet weak var testSendDataButton: UIButton!
    @IBOutlet weak var connectButton: UIButton!
    @IBOutlet weak var disconnectButton: UIButton!

    var logger: Logger?

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        _ = PGAuth.shared

        self.updateButtons()
        addToStatus("Auth State: \(PGAuth.shared.authState)")

        MultiLogger.shared.addLoggers(loggers: [self, ConsoleLogger()], clearAll: true)

        logger = MultiLogger.shared
        PGWrite.shared.configure(logger: logger!)
        PGAuth.shared.setLogger(logger: logger!)


    }

    func addToStatus(_ text: String) {
        DispatchQueue.main.async {
            var displayText = "[\(Date().stringWithFormat(format: "HH:mm:ss"))] \(text)"

            //Add newline characters to separate lines by an extra space
            if self.statusText.text.count > 0 {
                displayText = "\n\(displayText)"
            }
            self.statusText.text = "\(self.statusText.text ?? "")\(displayText)"

            //Scroll to bottom of the text
            if self.statusText.text.count > 0 {
                let location = self.statusText.text.count - 1
                let bottom = NSMakeRange(location, 1)
                self.statusText.scrollRangeToVisible(bottom)
            }
        }
    }

    func updateButtons() {
        switch PGAuth.shared.authState {
        case .signedIn:
            self.signInButton.isEnabled = false
            self.signOutButton.isEnabled = true
            self.testDeviceProvisioningButton.isEnabled = true
            self.testSendDataButton.isEnabled = true
        default:
            self.signInButton.isEnabled = true
            self.signOutButton.isEnabled = false
            self.testDeviceProvisioningButton.isEnabled = false
            self.testSendDataButton.isEnabled = false
        }
    }

    @IBAction func clearLog(_ sender: Any) {
        self.statusText.text = ""
    }

    @IBAction func signInTest(_ sender: Any) {
        PGAuth.shared.presentSignUpIn(navigationController: self.navigationController!) { (userState, error) in
            self.logger?.write("signIn Complete: ")
            self.logger?.write("* userState: \(String(describing: userState))")
            self.logger?.write("* error    : \(String(describing: error))")

            self.updateButtons()
        }
    }

    @IBAction func signOutTest(_ sender: Any) {
        PGAuth.shared.signOut() { error in
            self.logger?.write("signOut Complete: ")
            self.logger?.write("* error: \(String(describing: error))")

            self.updateButtons()

        }
    }

    @IBAction func testDeviceProvisioning(_ sender: Any) {
        logger?.write("Provisioning Device...")
        PGWrite.shared.provisionDevice(payload: ProvisioningPayload(deviceType: "research_bit", serialNumber: "test1")) {
            print("Done provisioning device.")
        }
    }

    @IBAction func testSendData(_ sender: Any) {
        logger?.write("Testing Send Data")
        PGWrite.shared.writeData(to: .getShadow(thingId: "research_bit_test1"), responseTopics: [.getShadowAccepted(thingId: "research_bit_test1"), .getShadowRejected(thingId: "research_bit_test1")], payload: DeviceDataPayload(deviceType: "abc", serialNumber: "def")) {
            print("Done writing data to device.")
        }
    }

    @IBAction func connect(_ sender: Any) {
        logger?.write("Testing Connect")
        PGWrite.shared.connect {
            logger?.write("Done connecting")
        }
    }

    @IBAction func disconnect(_ sender: Any) {
        logger?.write("Testing disconnect")
        PGWrite.shared.disconnect()
    }


}

extension ViewController: Logger {
    func write(_ text: String?) {
        addToStatus(text ?? "")
    }
}
