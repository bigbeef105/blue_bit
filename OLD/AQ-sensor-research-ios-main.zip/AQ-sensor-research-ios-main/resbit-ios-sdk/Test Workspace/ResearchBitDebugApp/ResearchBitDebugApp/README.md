# KV ResearchBIT Debug App
Stan Rosenbaum - Nov 2019

# Purpose

This is just an example project showing how the KV ResearchBIT framework can be used.

For more information on this project, view the README inside the ResearchBit.framework.
