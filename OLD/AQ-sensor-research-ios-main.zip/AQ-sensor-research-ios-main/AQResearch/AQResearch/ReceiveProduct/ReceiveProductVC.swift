//
//  ReceiveProductVC.swift
//  AQResearch
//
//  Created by Aaron on 1/29/20.
//  Copyright © 2020 Procter & Gamble. All rights reserved.
//

import UIKit
import ARKit
import Vision
import CoreBluetooth
import ResearchBit
import SVProgressHUD


class ReceiveProductVC: UIViewController {
    
    var textRecognitionRequest: Any?
    var recognizedText = ""
    var timer = Timer()
    var devices: [BLEDevice] = []
    var logger: Logger? = Constants.logger
    var savedImage: UIImage?

    var codeRegex = try! NSRegularExpression(pattern: "^[0-9ABCDEF]{8}$")
    
    @IBOutlet weak var scrollView: UIScrollView!
    @IBOutlet weak var instructionLabel: UILabel!
    @IBOutlet weak var scanView: ARSCNView!
    @IBOutlet weak var deviceCode: UITextField!
    @IBOutlet weak var tryAgainButton: UIButton!
    @IBOutlet weak var snapshotView: UIImageView!
    @IBOutlet weak var continueButton: UIButton!
    @IBOutlet weak var toggleScanCodeButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        registerKeyboardNotifications()
        
        if #available(iOS 13.0, *) {
            toggleScanCodeButton.isHidden = false
        } else {
            toggleScanCodeButton.isHidden = true
        }

        instructionLabel.text = Constants.Text.Onboarding.manualEntryInstructions
        tryAgainButton.isHidden = true
        scanView.isHidden = true
        snapshotView.isHidden = false
        snapshotView.image = Constants.Images.Onboarding.bottleWithLabel
        
        continueButton.isEnabled = false
        
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        if #available(iOS 13.0, *) {
            timer.invalidate()
        }
    }

    @available(iOS 13.0, *)
    func toggleScanScreen() {
        if(scanView.isHidden) {
            instructionLabel.text = Constants.Text.Onboarding.cameraInstructions
            tryAgainButton.isHidden = false
            scanView.isHidden = false
            snapshotView.isHidden = true
            toggleScanCodeButton.setTitle("Disable Code Scanning", for: .normal)
            setupTextObserver()
        } else {
            self.timer.invalidate()
            instructionLabel.text = Constants.Text.Onboarding.manualEntryInstructions
            tryAgainButton.isHidden = true
            scanView.isHidden = true
            snapshotView.isHidden = false
            snapshotView.image = Constants.Images.Onboarding.bottleWithLabel
            toggleScanCodeButton.setTitle("Enable Code Scanning", for: .normal)
        }
    }
    
    @available(iOS 13.0, *)
    func setupTextObserver() {
        scanView.delegate = self
        textRecognitionRequest = VNRecognizeTextRequest(completionHandler: { (request, error) in
            if let results = request.results, !results.isEmpty {
                if let requestResults = request.results as? [VNRecognizedTextObservation] {
                    self.recognizedText = ""
                    for observation in requestResults {
                        guard let candidate = observation.topCandidates(1).first else { return }

                        let range = NSRange(location: 0, length: candidate.string.utf16.count)

                        if self.codeRegex.firstMatch(in: candidate.string, options: [], range: range) != nil {
                            self.foundCode(code: String(candidate.string.prefix(8)))
                            return
                        }
                    }
                }
            }
        })
        startTimer()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
    }

    @available(iOS 13.0, *)
    func startTimer() {
        
        let configuration = ARWorldTrackingConfiguration()
        scanView.session.run(configuration)
        self.scanView.isHidden = false
        self.tryAgainButton.isHidden = true
        self.snapshotView.isHidden = true
        updateText()
        timer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(self.updateText), userInfo: nil, repeats: true)
    }
    
    func scanForDevices(withWaitIndicator wait: Bool, for deviceIds: [String], completion: @escaping () -> Void = {}) {
        
        if wait {
            SVProgressHUD.show(withStatus: "Adding Product...")
        }
        
        Scanner.shared.scan(scanTime: 5, for: deviceIds) { result in
            
            switch result {
            case let .failure(error):
                self.logger?.write("Error scanning for devices: \(error.localizedDescription)")
                if wait {
                    SVProgressHUD.showErrorAndDismiss(withStatus: "Error adding device!")
                } else {
                    SVProgressHUD.dismiss()
                }
                return
            case let .success(discoveredDevices):
                self.logger?.write("Done scanning. Found \(discoveredDevices.count) devices.")
                
                //Save devices to data source
                for device in discoveredDevices {
                    self.devices.append(device)
                }
                
                completion()
                
                Scanner.shared.logStatus()
                if wait {
                    SVProgressHUD.showSuccessAndDismiss(withStatus: "Done. Adding \(discoveredDevices.count) devices.")
                } else {
                    SVProgressHUD.dismiss()
                }
            }
        }
    }
    
    @available(iOS 13.0, *)
    func foundCode(code: String) {
        self.timer.invalidate()
        
        DispatchQueue.main.async {
            self.deviceCode.text = code
            self.checkCode(self.deviceCode)
        }
        self.snapshotView.image = self.savedImage
        self.snapshotView.isHidden = false
        self.scanView.stop(nil)
        self.scanView.isHidden = true
        self.tryAgainButton.isHidden = false
    }
    
    @available(iOS 13.0, *)
    @IBAction func tryAgain(_ sender: Any) {
        startTimer()
    }

    @available(iOS 13.0, *)
    @objc func updateText() {
        let currentFrame = self.scanView.snapshot()
        self.savedImage = currentFrame
        updateTextFor(image: self.savedImage!)
    }
    
    @available(iOS 13.0, *)
    @objc func updateTextFor(image: UIImage){

        let handler = VNImageRequestHandler(cgImage: image.cgImage!, options: [:])
        
        do {
            try handler.perform([self.textRecognitionRequest as! VNRecognizeTextRequest])
        } catch {
            print(error)
        }
    }
    
    @IBAction func processCode(_ sender: Any) {

        SVProgressHUD.show(withStatus: "Adding product...")
        
        let text = deviceCode.text ?? ""
        let range = NSRange(location: 0, length: text.count)
        
        guard codeRegex.firstMatch(in: text, options: [], range: range) != nil else {
            SVProgressHUD.showErrorAndDismiss(withStatus: "Invalid code")
            return
        }

        var deviceIdsToGet: [String] = []
        
        PGAuth.shared.getAssociatedDeviceIds { result in

            switch result {
            case let .success(deviceIds):
            
                DispatchQueue.main.async {
                    for id in deviceIds {
                        if id.starts(with: self.deviceCode.text ?? "") {
                            deviceIdsToGet.append(id)
                        }
                    }

                    self.logger?.write("Device IDs (\(deviceIdsToGet.count)):")
                    for id in deviceIdsToGet {
                        self.logger?.write("   \(id)")
                    }
                    guard deviceIdsToGet.count > 0 else {
                        self.logger?.write("Product code not assigned to user")
                        SVProgressHUD.showErrorAndDismiss(withStatus: "Invalid product")
                        return
                    }
                    
                    DispatchQueue.global(qos: .background).async {
                        self.scanForDevices(withWaitIndicator: true, for: deviceIdsToGet) {
                            self.dismissToList()
                        }
                    }
                }
            case let .failure(error):
                self.logger?.write("Error getting associated IDs: \(error.localizedDescription)")
            }

        }
    }
    
    @IBAction func checkCode(_ sender: UITextField) {
        
        sender.text = sender.text?.uppercased()
        
        let text = sender.text ?? ""
        
        let range = NSRange(location: 0, length: text.count)

        //Enable the Continue button if the code matches the regex, otherwise disable it
        continueButton.isEnabled = codeRegex.firstMatch(in: text, options: [], range: range) != nil
    }
    
    @IBAction func toggleScannerTapped(_ sender: Any) {
        if #available(iOS 13.0, *) {
            toggleScanScreen()
        }
    }
    
    func dismissToList() {
        DispatchQueue.main.async {
            
            self.logger?.write("Dismissing to list...")
            
            if let target = self.navigationController?.getLastViewController(with: SensorListTVC.self) as? SensorListTVC {
                if let ds = target.dataSource as? SensorListTVDataSource {
                    for device in self.devices {
                        ds.add(device: device)
                    }
                } else {
                    //Should never get here
                }
                
                self.navigationController?.popToViewController(target, animated: true)
                
            } else {
                //FIXME: Process error
            }
        }
    }
    
    //MARK: - Keyboard Interactions
    func registerKeyboardNotifications() {
        let notificationCenter = NotificationCenter.default
        notificationCenter.addObserver(self, selector: #selector(keyboardWillHide), name: UIResponder.keyboardWillHideNotification, object: nil)
        notificationCenter.addObserver(self, selector: #selector(keyboardWillShow), name: UIResponder.keyboardWillChangeFrameNotification, object: nil)    }
    
    @objc func keyboardWillShow(notification:NSNotification){
        let userInfo = notification.userInfo!
        var keyboardFrame:CGRect = (userInfo[UIResponder.keyboardFrameBeginUserInfoKey] as! NSValue).cgRectValue
        keyboardFrame = self.view.convert(keyboardFrame, from: nil)
        
        var contentInset:UIEdgeInsets = self.scrollView.contentInset
        contentInset.bottom = keyboardFrame.size.height
        scrollView.contentInset = contentInset
    }
    
    @objc func keyboardWillHide(notification:NSNotification){
        
        let contentInset:UIEdgeInsets = UIEdgeInsets.zero
        scrollView.contentInset = contentInset
    }
    
    @IBAction func dismissKeyboard(_ sender: Any) {
        print("Trying to dismiss keyboard...")
        deviceCode.resignFirstResponder()
    }
    
    
    
}

@available(iOS 13.0, *)
extension ReceiveProductVC: ARSCNViewDelegate {
    
}
