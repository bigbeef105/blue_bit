//
//  StatusCell.swift
//  AQResearch
//
//  Created by Aaron on 11/27/19.
//  Copyright © 2019 Procter & Gamble. All rights reserved.
//

import UIKit
import DateToolsSwift

class StatusCell: UITableViewCell {

    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var lastUpdatedLabel: UILabel!
    @IBOutlet weak var beaconLabel: UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()
    }

    func configure(with sensor: Sensor) {

        titleLabel?.text = "\(sensor.name ?? "Nordic") (\(sensor.uuid.uuidString.suffix(6)))"

        if let bp = sensor.beaconParams {
            beaconLabel?.text = "\(bp.shortDescription)"
            
            if Scanner.shared.isMonitoringForBeacon(with: bp) {
                beaconLabel?.textColor = Constants.Colors.success
            } else {
                beaconLabel?.textColor = Constants.Colors.danger
            }
            
        } else {
            beaconLabel?.text = ""
        }

        if let lastUpdate = sensor.lastAdvertisement?.timestamp {
            lastUpdatedLabel?.text = "Last Usage: \(lastUpdate.shortTimeAgoSinceNow)"
        } else {
            lastUpdatedLabel?.text = "Last Usage: None"
        }
    }
}
