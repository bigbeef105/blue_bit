//
//  TestData.swift
//  AQResearch
//
//  Created by Aaron on 12/3/19.
//  Copyright © 2019 Procter & Gamble. All rights reserved.
//

import Foundation
import CoreLocation

@available(*, deprecated, message: "Should not be using TestData in final app")
struct TestData {

    static let resbitBeacon: BeaconParameters = BeaconParameters(uuid: UUID(uuidString: "01122334-4556-6778-899a-abbccddeeff0")!, major: 513, minor: 1027, identifier: "ResBit")
    
    static let beaconList: [BeaconParameters] = [
        BeaconParameters(uuid: UUID(uuidString: "1F48215E-DFF1-41C1-8656-CD5D0E06A76D")!, major: 1, minor: 1, identifier: "AWT B2"),
        BeaconParameters(uuid: UUID(uuidString: "1F48215E-DFF1-41C1-8656-CD5D0E06A76D")!, major: 1, minor: 2, identifier: "AWT I2"),
        BeaconParameters(uuid: UUID(uuidString: "1F48215E-DFF1-41C1-8656-CD5D0E06A76D")!, major: 1, minor: 3, identifier: "AWT M2"),
        BeaconParameters(uuid: UUID(uuidString: "1F48215E-DFF1-41C1-8656-CD5D0E06A76D")!, major: 1, minor: 4, identifier: "AWT B1"),
        BeaconParameters(uuid: UUID(uuidString: "1F48215E-DFF1-41C1-8656-CD5D0E06A76D")!, major: 1, minor: 5, identifier: "AWT I1"),
        BeaconParameters(uuid: UUID(uuidString: "1F48215E-DFF1-41C1-8656-CD5D0E06A76D")!, major: 1, minor: 6, identifier: "AWT M1")
    ]
    
}
