//
//  SensorAdvertisement.swift
//  AQResearch
//
//  Created by Aaron on 11/26/19.
//  Copyright © 2019 Procter & Gamble. All rights reserved.
//

import Foundation
import ResearchBit

/// An advertisement from a BLEDevice
struct SensorAdvertisement: Codable {
    /// The UUID of the `Sensor`
    var uuid: String
    /// The status of the summary
    var summaryStatus: String
    /// The Timestamp the advertisement was received
    var timestamp = Date()
    /// The list of `SummaryData` items from the advertisement
    var summaryData: [SummaryData]?
}

