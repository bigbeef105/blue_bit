//
//  Sensor.swift
//  AQResearch
//
//  Created by Aaron on 11/26/19.
//  Copyright © 2019 Procter & Gamble. All rights reserved.
//

import Foundation
import ResearchBit
import CoreLocation
import DateToolsSwift

/// A sensor that includes properties from a `BLEDevice`, the beacon data, and last advertisement data
struct Sensor: Codable {
    /// The UUID of the `BLEDevice`
    var uuid: UUID
    /// The last advertisement data collected for this sensor
    var lastAdvertisement: SensorAdvertisement?
    /// The Beacon parameters for this device
    var beaconParams: BeaconParameters?
    /// A user-friendly name for the sensor
    var name: String?
    /// The SerialID of the BLEDevice
    var serialId: String?

    init(device: BLEDevice, beaconParameters params: BeaconParameters? = nil) {
        uuid = device.peripheral.identifier
        beaconParams = params
        name = device.deviceName
        serialId = device.serialID
    }

    init(deviceUuid: UUID, beaconParameters params: BeaconParameters? = nil, name: String? = nil) {
        uuid = deviceUuid
        beaconParams = params
        self.name = name
    }

    init(deviceUuid: String, beaconParameters params: BeaconParameters? = nil, name: String? = nil) {
        uuid = UUID(uuidString: deviceUuid)!
        beaconParams = params
        self.name = name
    }
    
    /// A description suitable for logging
    var debugDescription: String {
        return "\(uuid.uuidString.prefix(8)):\(name ?? "name nil"):\(lastAdvertisement?.timestamp.shortTimeAgoSinceNow ?? "nil"):\(beaconParams?.shortDescription ?? "nil")"
    }
}
