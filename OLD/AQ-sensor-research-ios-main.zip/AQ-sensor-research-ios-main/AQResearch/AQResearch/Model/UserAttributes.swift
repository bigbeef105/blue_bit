//
//  UserAttributes.swift
//  AQResearch
//
//  Created by Aaron on 2/3/20.
//  Copyright © 2020 Procter & Gamble. All rights reserved.
//

import Foundation

/// Stores UserAttributes stored on AWS Cognito to make them more accessible
struct UserAttributes {
    let phoneNumberVerified: Bool
    let participantId: String?
    let studyId: String?
    let emailVerified: Bool
    let email: String
    let sub: String
    let phoneNumber: String
    
    let attributesMap: [String: String]
    
    let knownKeys: [String] = [
        Constants.Keys.UserAttributes.phoneNumberVerified,
        Constants.Keys.UserAttributes.participantId,
        Constants.Keys.UserAttributes.studyId,
        Constants.Keys.UserAttributes.emailVerified,
        Constants.Keys.UserAttributes.email,
        Constants.Keys.UserAttributes.sub,
        Constants.Keys.UserAttributes.phoneNumber,
    ]
    
    init(attributes: [String: String]) {
        
        attributesMap = attributes
        
        phoneNumberVerified = attributes[Constants.Keys.UserAttributes.phoneNumberVerified] == "true"
        participantId = attributes[Constants.Keys.UserAttributes.participantId]
        studyId = attributes[Constants.Keys.UserAttributes.studyId]
        emailVerified = attributes[Constants.Keys.UserAttributes.emailVerified] == "true"
        email = attributes[Constants.Keys.UserAttributes.email] ?? ""
        sub = attributes[Constants.Keys.UserAttributes.sub] ?? ""
        phoneNumber = attributes[Constants.Keys.UserAttributes.phoneNumber] ?? ""
    }
    
    var debugDescription: String {
        var retStr = """
        Mapped Attributes:
            phoneNumberVerified: \(phoneNumberVerified)
            participantId: \(participantId ?? "nil")
            studyId: \(studyId ?? "nil")
            emailVerified: \(emailVerified)
            email: \(email)
            sub: \(sub)
            phoneNumber: \(phoneNumber)
        Unmapped Attributes:
        """

        var unmappedExist = false
        for key in attributesMap.keys where !knownKeys.contains(key) {
            retStr += "\n    \(key): \(attributesMap[key] ?? "nil")"
            unmappedExist = true
        }
        
        if !unmappedExist {
            retStr += "\n    No unmapped attributes."
        }
        
        return retStr
        
    }
    
}
