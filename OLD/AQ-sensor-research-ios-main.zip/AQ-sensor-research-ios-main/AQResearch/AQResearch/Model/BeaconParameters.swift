//
//  BeaconParameters.swift
//  AQResearch
//
//  Created by Aaron on 12/30/19.
//  Copyright © 2019 Procter & Gamble. All rights reserved.
//

import Foundation
import CoreLocation

/// Details of a Beacon that the app will monitor for
struct BeaconParameters: Codable {
    /// The Beacon's UUID
    let uuid: UUID
    /// The Beacon's Major value
    let major: CLBeaconMajorValue
    /// The Beacon's Minor value
    let minor: CLBeaconMinorValue
    /// A string identifier for the beacon
    let identifier: String?

    /// Returns a description suitable for logging
    var description: String {
        return """
        {"uuid": "\(uuid.uuidString)", "major": "\(major)", "minor": "\(minor)", "identifier": "\(identifier ?? "nil")", }"
        """
    }

    /// Returns a short description suitable for logging
    var shortDescription: String {
        return """
        \(uuid.uuidString.prefix(8))-\(major)-\(minor)\(identifier != nil ? "-\(identifier!)" : "")
        """
    }
    
    /// Determine whether this matches a `CLBeaconRegion`
    /// - Parameter region: The `CLBeaconRegion` to compare
    func matches(region: CLBeaconRegion) -> Bool {
        let rMajor = region.major
        let rMinor = region.minor
        let rUuid = region.proximityUUID
        
        if rUuid == uuid && rMajor == major as NSNumber? && rMinor == minor as NSNumber?  {
            return true
        }
        return false;
    }
}
