//
//  SVProgressHUD+showAndDismiss.swift
//  AQResearch
//
//  Created by Aaron on 1/24/20.
//  Copyright © 2020 Procter & Gamble. All rights reserved.
//

import Foundation
import SVProgressHUD

extension SVProgressHUD {
    
    /// Shows the SVProgressHUD as an error message with a given message and dismisses it after `delay` seconds
    /// - Parameters:
    ///   - status: Message to display
    ///   - delay: Number of seconds to display the message. Defaults to `2`
    static func showErrorAndDismiss(withStatus status: String, delay: TimeInterval = 2) {
        DispatchQueue.main.async {
            SVProgressHUD.showError(withStatus: status)
            SVProgressHUD.dismiss(withDelay: delay)
        }
    }

    /// Shows the SVProgressHUD as a success message with a given message and dismisses it after `delay` seconds
    /// - Parameters:
    ///   - status: Message to display
    ///   - delay: Number of seconds to display the message. Defaults to `2`
    static func showSuccessAndDismiss(withStatus status: String, delay: TimeInterval = 2) {
        DispatchQueue.main.async {
            SVProgressHUD.showSuccess(withStatus: status)
            SVProgressHUD.dismiss(withDelay: delay)
        }
    }

}
