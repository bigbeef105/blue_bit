//
//  CLBeaconRegion+debugDescription.swift
//  AQResearch
//
//  Created by Aaron on 3/11/20.
//  Copyright © 2020 Procter & Gamble. All rights reserved.
//

import Foundation
import CoreLocation

extension CLBeaconRegion {
    public override var debugDescription: String {
        return """
        {"uuid": "\(proximityUUID.uuidString)", "major": "\(major ?? -1)", "minor": "\(minor ?? -1)", "identifier": "\(identifier)", }"
        """
    }
}
