//
//  UIAlertController+createConfirmationDialog.swift
//  AQResearch
//
//  Created by Aaron on 12/4/19.
//  Copyright © 2019 Procter & Gamble. All rights reserved.
//

import Foundation
import UIKit

extension UIViewController {
    /// Presents a confirmation dialog with the provided information
    ///
    /// If 'OK' button is tapped, then the `okHandler` is executed. If "Cancel" is tapped, then the dialog is dismissed with no action.
    /// - Parameters:
    ///   - title: Dialog title
    ///   - message: Dialog message
    ///   - preferredStyle: Alert Style
    ///   - cancelButtonText: Text for cancel button. Default is "Cancel"
    ///   - okButtonText: Toxt for OK button. Default is "OK"
    ///   - okIsDestructive: Defines whether OK button is a destructive action so it can be styled accordingly
    ///   - cancelHandler: Defines whether Cancel button is a destructive action so it can be styled accordingly
    ///   - okHandler: Handler for the "OK" button
    func presentConfirmationDialog(title: String?, message: String?, preferredStyle: UIAlertController.Style = .alert,
                                         cancelButtonText: String = "Cancel", okButtonText: String = "OK", okIsDestructive: Bool = true,
                                         cancelHandler: ((UIAlertAction) -> Void)? = nil, okHandler: ((UIAlertAction) -> Void)?) {
        
        // Declare Alert message
        let confirmation = UIAlertController(title: title, message: message, preferredStyle: preferredStyle)
        
        // Create OK button with action handler
        let ok = UIAlertAction(title: "OK", style: okIsDestructive ? .destructive : .default, handler: okHandler)
        
        // Create Cancel button with action handlder
        let cancel = UIAlertAction(title: "Cancel", style: .cancel, handler: cancelHandler)
        
        //Add OK and Cancel button to dialog message
        confirmation.addAction(ok)
        confirmation.addAction(cancel)
        
        present(confirmation, animated: true, completion: nil)
    }
    
}
