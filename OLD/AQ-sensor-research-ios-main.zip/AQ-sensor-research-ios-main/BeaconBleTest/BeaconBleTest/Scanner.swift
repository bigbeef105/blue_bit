//
//  Scanner.swift
//  BeaconBleTest
//
//  Created by Aaron on 12/16/19.
//  Copyright © 2019 Atomic Robot. All rights reserved.
//

import Foundation
import CoreBluetooth
import ResearchBit
import UIKit

struct Scanner {

    fileprivate static var BG_TIMEOUT: TimeInterval = 20
    
    static var _connectQueue: OperationQueue?
    static var connectQueue: OperationQueue {
        if let cq = _connectQueue {
            return cq
        } else {
            _connectQueue = OperationQueue()
            _connectQueue!.maxConcurrentOperationCount = 1
            return _connectQueue!
        }
    }
    
    static let researchBit = ResearchBit()
    
    static let DeviceListKey = "DeviceList"
    
    static var devices: [String] {
        get {
            return UserDefaults.standard.array(forKey: DeviceListKey) as? [String] ?? []
        }
    }
    
    static func addDevice(with uuid: UUID) {
        var dList: [String] = UserDefaults.standard.array(forKey: DeviceListKey) as? [String] ?? []
        if !dList.contains(uuid.uuidString) {
            dList.append(uuid.uuidString)
            UserDefaults.standard.set(dList, forKey: DeviceListKey)
        }
    }

    static func connectToKnownDevices(logger: Logger?, completion: @escaping () -> Void = {}) {
        
        logger?.write("Attempting to connect to known devices...")
        DispatchQueue.global(qos: .background).async {
            
            let devices: [UUID] = Scanner.devices.compactMap({ return UUID(uuidString: $0) })

            logger?.write("Starting background task...")
            var connectTask = UIApplication.shared.beginBackgroundTask(withName: #function, expirationHandler: nil)

            if devices.count > 0 {

                let semaphore = DispatchSemaphore(value: 0)
                
                logger?.write("Saved Devices (\(devices.count)): ")
                for uuid in devices {
                    logger?.write("   \(uuid)")
                    Scanner.connect(toPeripheral: uuid, logger: logger) {
                        semaphore.signal()
                    }
                }
                let semaphoreResult = semaphore.wait(timeout: .now() + BG_TIMEOUT) //Force timeout after 9 minutes so .endBackgroundTask always gets executed
                logger?.write("Semaphore result: \(semaphoreResult)")

            } else {
                logger?.write("No devices saved")
            }

            completion()
            logger?.write("Background task complete.")
            UIApplication.shared.endBackgroundTask(connectTask)
            connectTask = .invalid
        }
    }

    static func connect(toPeripheral uuid: UUID, logger: Logger?, completion: @escaping () -> Void = { }) {
        
        logger?.write("Queuing connect to device: \(String(uuid.uuidString.prefix(8)))")
        let semaphore = DispatchSemaphore(value: 0) //We don't want to do anything else on the connectQueue until this connect completes.
        connectQueue.addOperation {
            logger?.write("Attempting to connect to device \(String(uuid.uuidString.prefix(8)))")
            researchBit.getBLEDeviceSummaryData(peripheralUUID: uuid) { (result, error) in
                defer {
                    semaphore.signal()  //Signal that this connect is done
                }
                
                if let theError = error {
                    logger?.write("    Error connecting to device \(String(uuid.uuidString.prefix(8))): \(theError.localizedFailureReason ?? "nil")")
                    return
                }
                
                if let summaryData = result {
                    logger?.write("   Found data [\(String(uuid.uuidString.prefix(8)))]: \(summaryData.count)")
                } else {
                    logger?.write("   No data found")
                }
            }
            _ = semaphore.wait(timeout: .now() + 10)    //Wait for this connect to complete before allowing next item in connectQueue to execute
            completion()
        }

    }

    static func scan(scanTime: TimeInterval? = nil, logger: Logger?, completion: @escaping ([BLEDevice]?, NSError?) -> Void = {_, _ in } ) {
        var intScanTime = 3
        if let scanTime = scanTime {
            intScanTime = Int(scanTime)
        }

        logger?.write("Scanning for new devices for \(intScanTime) seconds:")

        researchBit.scanForBLEDevices(scanTime: intScanTime) { (deviceList, error) in
            defer {
                completion(deviceList, error)
            }
            if let theError = error {
                logger?.write("BT Scan Error: \(theError.localizedFailureReason ?? "nil")")
            }

            logger?.write("Found \(String(describing: deviceList?.count)) devices.")
            
            if let deviceList = deviceList {
                for device in deviceList {
                    addDevice(with: device.peripheral.identifier)
                    logger?.write("   Found device: \(String(describing: device.deviceName)): \(device.peripheral.identifier)")
                }
            } else {
                logger?.write("   No devices found.")
            }
        }

    }
}
