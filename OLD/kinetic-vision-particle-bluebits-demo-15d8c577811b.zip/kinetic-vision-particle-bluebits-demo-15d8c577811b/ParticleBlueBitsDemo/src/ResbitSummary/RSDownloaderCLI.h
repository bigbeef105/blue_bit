/**
 ******************************************************************************
 * @file    SoftwareUnitManagerCli.h
 * @brief   CLI implementation for CLI manager
 * @author  Jeffrey Hatton
******************************************************************************
 *
 * @copyright COPYRIGHT (c) 2020 SAEC Kinetic Vision, Inc 
 *            All Rights Reserved
 *
 * This software is property of SAEC Kinetic Vision, Inc and is considered
 * confidential.
 *
 ******************************************************************************
 *
 * Significant Modification History (Most Recent at top)
 * -----------------------------------------------------
 *
 * Date        | Initials | Description
 * ----------- | -------- | -----------
 * 20 Aug 2020 |   JH     | Original
 *
 * Theory of Operation
 * -------------------
 * TBD
 *
 *
 *
 */

#ifndef SOFTWARE_UNIT_MANAGER_CLI_H
#define SOFTWARE_UNIT_MANAGER_CLI_H

#include "sys\Cli.h"
#include "RSDownloader.h"
#include "BlueBitsBle.h"
#include "BlueBitsSummaryComs.h"
#include "RSParticleFormater.h"

static BlueBitsSummaryComs_t* _ComsCLI;
static BlueBitsBle_t* _BleCLI;
static RSDownloader_t* _DownloaderCLI;
static RSParticleFormater_t* _FormaterCLI;

static StatusRet_t Ble_Scan(uint16_t argC, char** args) {

    if (argC > 2) {
        uint32_t conTime = atoi(args[2]);
        StatusRet_t ret = _BleCLI->SetConnectionTimeOut(conTime);
        if (Status_IsError(ret)) return ret;
    }

    if (argC > 1) {
        uint32_t timeout = 5000;
        timeout = atoi(args[1]);
        return _BleCLI->ScanForDevice(timeout);
    } else {
        return _BleCLI->ScanForDevice();
    }
}

static StatusRet_t Ble_Disconnect(uint16_t argC, char** args) {    
    return _BleCLI->DisconnectCurrentDevice();
}

static StatusRet_t Ble_Enable(uint16_t argC, char** args) {
    bool enable = 0;
    if (argC > 1) {
        enable = atoi(args[1]);
    }

    return _BleCLI->Enable(enable);
}

static StatusRet_t Ble_SetScanDelay(uint16_t argC, char** args) {
    uint32_t delay = 0;
    delay = atoi(args[1]);
    return _BleCLI->SetScanDelay(delay);
}

static StatusRet_t Coms_Download(uint16_t argC, char** args) {
    BlePeerDevice* device;
    StatusRet_t ret = _BleCLI->GetConnectedDevice(&device);
    if (Status_IsError(ret)) return ret;

    return _ComsCLI->StartDownload(device);
}

static StatusRet_t RSD_Start(uint16_t argC, char** args) {
    return _DownloaderCLI->Start();
}

static StatusRet_t RSD_Stop(uint16_t argC, char** args) {
    return _DownloaderCLI->Stop();
}

static StatusRet_t RSD_Clear(uint16_t argC, char** args) {
    return _DownloaderCLI->ClearCache();
}

static StatusRet_t RSD_Print(uint16_t argC, char** args) {
    RSEvent_t* events;
    uint16_t count = 0;

    char sumData[50];
    uint8_t* buf;
    StatusRet_t ret = _DownloaderCLI->GetSerial(&buf, &count);
    if (Status_IsError(ret)) return ret;

    for (uint16_t i = 0; i < count; i++) {
        sprintf(sumData + i * 2, "%.2x", buf[i]);
    }

    ret = _DownloaderCLI->GetEvents(&events, &count);
    if (Status_IsError(ret)) return ret;

    CLI::Printf("Printing %u Events for Device: %s\n", count, sumData);

    for (uint16_t i = 0; i < count; i++) {
        RSEvent_t* event = events + i;
        
        for (size_t i = 0; i < event->DataSize; i++)
        {
            uint16_t idx = i * 2;
            sprintf(sumData + idx, "%.2x", event->Data[i]);
        }        

        uint32_t delayTime = 5;
        switch (event->EventId)
        {
        case ResbitEvents_WakeUp:
            CLI::Printf("Wake Up Event: TimeStamp: %u, Total Time Awake: %u\n", event->Timestamp, *(uint32_t*)event->Data);
            break;
        case ResbitEvents_TriggerPull:
            CLI::Printf("Trigger Pull Angle Event: TimeStamp: %u, Num Pulls: %u\n", event->Timestamp, *(uint32_t*)event->Data);
            break;
        case ResbitEvents_TiltAngle:
            CLI::Printf("Tilt Angle Event: TimeStamp: %u, Start Angle: %0.2f Stop Angle: %0.2f, ", event->Timestamp, *(float*)event->Data, *(float*)(event->Data + 4));
            CLI::Printf("Min Angle: %0.2f, Max Angle: %0.2f\n",
            *(float*)(event->Data + 8), 
            *(float*)(event->Data + 12));
            delayTime = 5;
            break;
        default:
            CLI::Printf("Unkown Event: ID: %u, TimeStamp: %u, Data: %s\n", event->EventId, event->Timestamp, sumData);
            delayTime = 5;
            break;
        }

        // Particle stream can be slow so allow characters to get clocked out
        delay(delayTime);
    }
    
    return Status_Ok;
}

static StatusRet_t RSD_PrintJson(uint16_t argC, char** args) {
    char* ptr;

    StatusRet_t ret = _DownloaderCLI->GetEventJSON(&ptr);
    if (Status_IsError(ret)) return ret;

    int32_t len = strlen(ptr);

    while (len > 0) {
        CLI::Printf("%.300s\n", ptr);
        ptr += 300;
        len -= 300;
        delay(5);
    }

    CLI::Printf("\n");

    return ret;
}

static CliSuNode_t _RSNode = {
    .SuName = "Resbit Summary Downloader"
};

static CliCmdNode_t _RSCmdNodes[] = {
    {"scan","Scan for BlueBits Devices. args <timeout optional> the amount of time to scan in ms",&Ble_Scan, 0, 2},
    {"disconnect","Disconnect Current BlueBits Device.",&Ble_Disconnect, 0, 1},
    {"enableBle","Enable or disable the BLE Radio: args <enable> 0 to disable 1 to enable",&Ble_Enable, 1, 2},
    {"setScanDelay","Set the delay between scans: args <delay> the delay",&Ble_SetScanDelay, 1, 2},
    {"download","Download data form the connected device",&Coms_Download, 0, 1},
    {"start","Start the downloader",&RSD_Start, 0, 1},
    {"stop","Start the downloader",&RSD_Stop, 0, 1},
    {"clear","Clear the downloader",&RSD_Clear, 0, 1},
    {"print","Print the events that are cached",&RSD_Print, 0, 1},
    {"printJson","Print the json packet cached for particle", &RSD_PrintJson, 0, 1},
    {NULL,NULL,NULL},
};

/**
 * @brief Setup the CLI for the Device info 
 * 
 * @return StatusRet_t 
 */
static StatusRet_t RSDownloader_SetupCli(RSDownloader_t* downloader, BlueBitsBle_t* ble, BlueBitsSummaryComs_t* coms, RSParticleFormater_t* formater) {
    if (coms == NULL || ble == NULL || downloader == NULL || formater == NULL) return Status_Null_Ptr;

    _ComsCLI = coms;
    _BleCLI = ble;
    _DownloaderCLI = downloader;
    _FormaterCLI = formater;

    return CLI::RegisterNode(&_RSNode, _RSCmdNodes);
}

#endif
