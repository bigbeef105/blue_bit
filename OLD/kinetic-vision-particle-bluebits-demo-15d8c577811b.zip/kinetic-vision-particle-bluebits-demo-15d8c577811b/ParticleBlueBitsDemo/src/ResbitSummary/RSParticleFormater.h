/**
 ******************************************************************************
 * @file    RSParticleFormater.h
 * @brief   Module for formatting Resbit events into a particle packet
 * @author  Jeffrey Hatton
******************************************************************************
 *
 * @copyright COPYRIGHT (c) 2020 SAEC Kinetic Vision, Inc 
 *            All Rights Reserved
 *
 * This software is property of SAEC Kinetic Vision, Inc and is considered
 * confidential.
 *
 ******************************************************************************
 *
 * Significant Modification History (Most Recent at top)
 * -----------------------------------------------------
 *
 * Date        | Initials | Description
 * ----------- | -------- | -----------
 * 21 Sep 2020 |   JH     | Original
 *
 * Theory of Operation
 * -------------------
 * TBD
 *
 *
 *
 */

#ifndef R_S_PARTICLE_FORMATER_H
#define R_S_PARTICLE_FORMATER_H

#include "Status\DeviceStatus.h"
#include "ResbitEvents.h"
#include "SoftwareUnits\SoftwareUnit.h"
#include "RE_SDK_Config.h"

class RSParticleFormater_t : public SoftwareUnit_t {
    public:

    /**
     * @brief Init the software unit
     * 
     * @param id The id of the software unit
     * @return StatusRet_t 
     */
    StatusRet_t Init(SuId_t id);

    /**
     * @brief Start generating a series of packets for the given events.
     *  Call GenerateNextPacket when the next packet is needed.
     * 
     * @param events The events
     * @param eventCount The number of events
     * @param serial The serial number of the device that generated the events
     * @param serialCount The number of bytes in the serial number
     * @return StatusRet_t 
     */
    StatusRet_t StartPacketGen(RSEvent_t* events, uint16_t eventCount, uint8_t* serial, uint16_t serialCount);

    /**
     * @brief Generate the next packet for the cached events. 
     * Will return Status_BufferEmpty when all packets have been generated.
     * 
     * @return StatusRet_t 
     */
    StatusRet_t GenerateNextPacket();

    /**
     * @brief Clear the formater
     * 
     * @return StatusRet_t 
     */
    StatusRet_t Clear();

    /**
     * @brief Get the currently generate packet. Will be returned in a JSON formatted string.
     * 
     * @param ptr Buffer for the packet
     * @return StatusRet_t 
     */
    StatusRet_t GetPacket(char** ptr);

    private:

    /**
     * @brief If a packet has been generated in the buffer
     * 
     */
    bool _PacketGenerated;

    /**
     * @brief Buffer for the packet
     * 
     */
    char _Data[PARTICLE_FORMATER_BUFFER_SIZE];

    /**
     * @brief Buffer for generating strings
     * 
     */
    char _StrBuffer[RS_EVENT_DATA_SIZE * 2];

    /**
     * @brief The current event ready to be JSONed
     * 
     */
    uint16_t _CurrentEvent;

    /**
     * @brief Buffer of events to be JSONed
     * 
     */
    RSEvent_t* _Events;

    /**
     * @brief Number of events to be JSONed
     * 
     */
    uint16_t _EventCount;

    /**
     * @brief Serial number of the device the events are from
     * 
     */
    uint8_t* _Serial;

    /**
     * @brief The number of bytes in the serial number
     * 
     */
    uint16_t _SerialCount;
};

#endif
