/**
 ******************************************************************************
 * @file    BlueBitsSummaryComs.cpp
 * @brief   DESCRIPTION
 * @author  Jeffrey Hatton
******************************************************************************
 *
 * @copyright COPYRIGHT (c) 2020 SAEC Kinetic Vision, Inc 
 *            All Rights Reserved
 *
 * This software is property of SAEC Kinetic Vision, Inc and is considered
 * confidential.
 *
 ******************************************************************************
 *
 * Significant Modification History (Most Recent at top)
 * -----------------------------------------------------
 *
 * Date        | Initials | Description
 * ----------- | -------- | -----------
 * 16 Sep 2020 |   JH     | Original
 *
 * Theory of Operation
 * -------------------
 * TBD
 *
 *
 *
 */

#include "BlueBitsSummaryComs.h"

void onDataReceived(const uint8_t* data, size_t len, const BlePeerDevice& peer, void* context) {
    BlueBitsSummaryComs_t* coms = (BlueBitsSummaryComs_t*)context;

    if (len != 20) {
        Logger_t::Warn("Invalid packet size (%u). Ignoring", len);
    } else {
        coms->HeaderBuffer[data[1]] = data[0];
        memcpy(coms->DataBuffer + (PACKET_DATA_SIZE * data[1]), data + PACKET_HEADER_SIZE, PACKET_DATA_SIZE);
        coms->TotalPacket++;
    }
}

void onTransferingReceived(const uint8_t* data, size_t len, const BlePeerDevice& peer, void* context) {    
    if (data[0] == 0) {
        BlueBitsSummaryComs_t* coms = (BlueBitsSummaryComs_t*)context;
        if (coms->_CurrentProtoState == BlueBitsSummaryComs_t::BBProtocolStates_GettingPackets && !coms->SummaryDone) {
            coms->_CurrentProtoState = BlueBitsSummaryComs_t::BBProtocolStates_VerifyPackets;
        }
    }
}

void onTransferSumDataReceived(const uint8_t* data, size_t len, const BlePeerDevice& peer, void* context) {
    BlueBitsSummaryComs_t* coms = (BlueBitsSummaryComs_t*)context;
    coms->SummaryDone = data[0] == 0;
}

StatusRet_t BlueBitsSummaryComs_t::Init(SuId_t id) {
    _Status = SoftwareUnit_t::Init(id);

    DataChar.onDataReceived(onDataReceived, this);
    TransferingChar.onDataReceived(onTransferingReceived, this);
    TransferSumDataChar.onDataReceived(onTransferSumDataReceived, this);

    _DownloadTimeout = 5000;

    return _Status;
}

StatusRet_t BlueBitsSummaryComs_t::Tick() {
    StatusRet_t ret = Status_Ok;

    uint32_t time = millis();

    if (_CurrentSummaryState != BBSummaryStates_Idle) {
        if (!_BlueBitsDevice->connected()) {
            Logger_t::Warn("BlueBits has disconnected stopping coms");
            return Stop();
        }
    }

    switch (_CurrentSummaryState) {
        case BBSummaryStates_Downloading:
            if (time - _DownloadStartTime >= _DownloadTimeout) {
                Logger_t::Warn("Download has timed out. Stopping");
                ret = Stop();
                if (Status_IsError(ret)) return ret;
            } else {
                if (SummaryDone) {
                    Logger_t::Info("Summary Transfer Done");
                    _CurrentSummaryState = BBSummaryStates_HasData;
                }
            }
        break;
    }

    switch (_CurrentProtoState) {
        case BBProtocolStates_VerifyPackets:
            ret = VerifyPackets();
        break;
        case BBProtocolStates_Done:
        //TODO do anything here?
        break;
    }

    return ret;
}

StatusRet_t BlueBitsSummaryComs_t::ClearData() {
    if (Status_IsError(_Status)) return _Status;
    if (_CurrentProtoState != BBProtocolStates_Done) return Status_Ok;
    
    Logger_t::Info("Clearing Summary Coms Data");

    // Clear out old data
    memset(HeaderBuffer, 0, sizeof(HeaderBuffer));
    TotalPacket = 0;

    if (!SummaryDone) {
        _DownloadStartTime = millis();
        _CurrentProtoState = BBProtocolStates_GettingPackets;

        Logger_t::Info("Coms acking data packet");
        uint8_t ack = 1;
        int writeRes = AckChar.setValue(&ack, 1);
        if (writeRes > 0) {
            Logger_t::Error("Ack Error: %i", writeRes);
        }
    }

    return Status_Ok;
}

StatusRet_t BlueBitsSummaryComs_t::GetData(uint8_t** summaryBuffer, uint16_t* bytesRead) {
    if (Status_IsError(_Status)) return _Status;
    if (summaryBuffer == NULL || bytesRead == NULL) return Status_Pack(Status_Null_Ptr);

    if (_CurrentProtoState != BBProtocolStates_Done) return Status_Pack(Status_BufferEmpty);

    *summaryBuffer = DataBuffer;
    *bytesRead = TotalPacket * PACKET_DATA_SIZE;

    return Status_Ok;
}

StatusRet_t BlueBitsSummaryComs_t::VerifyPackets() {
    StatusRet_t ret = Status_Ok;

    if (TotalPacket == 0) {
        _CurrentProtoState = BBProtocolStates_Done;
        return ret;
    }

    // Get the first non 0 total packets
    uint16_t totalPackets = 0;
    for (uint16_t i = 0; i < TotalPacket; i++) {
        if (HeaderBuffer[i] != 0) {
            totalPackets = HeaderBuffer[i];
        }
    }

    Logger_t::Info("Verifying Packets. Received %u/%u Packets(%uB)", TotalPacket, totalPackets, TotalPacket * PACKET_SIZE);

    uint16_t counter = 0;
    for (uint16_t i = 0; i < TotalPacket; i++) {
        if (HeaderBuffer[i] != totalPackets) {
            if (HeaderBuffer[i] == 0) {
                counter++;
                Logger_t::Warn("Missing Packet %u", i);
            } else {
                counter++;
                Logger_t::Error("Packet Count incorrect %u", i);
            }
        } 
    }

    if (counter == 0) {
        _CurrentProtoState = BBProtocolStates_Done;
    } else {
        Logger_t::Warn("Packets missing");
        //TODO figure out resend
    }

    return ret;
}

StatusRet_t BlueBitsSummaryComs_t::Stop() {
    if (Status_IsError(_Status)) return _Status;

    Logger_t::Warn("Stopping Summary Coms");

    _CurrentSummaryState = BBSummaryStates_Idle;
    _CurrentProtoState = BBProtocolStates_Idle;

    return Status_Ok;
}

StatusRet_t BlueBitsSummaryComs_t::StartDownload(BlePeerDevice* device) {
    if (Status_IsError(_Status)) return _Status;    
    if (device == NULL) return Status_Pack(Status_Null_Ptr);

    Logger_t::Info("Starting Summary Data Download");

    StatusRet_t ret = Status_Ok;

    _BlueBitsDevice = device;
    _CurrentSummaryState = BBSummaryStates_Downloading;
    _CurrentProtoState = BBProtocolStates_GettingPackets;
    SummaryDone = false;
    memset(HeaderBuffer, 0, sizeof(HeaderBuffer));
    TotalPacket = 0;

    bool got = _BlueBitsDevice->getCharacteristicByUUID(ResBitSerialChar, "240FAA08-2498-4B36-BC0C-EDCCC32D0635");
    if (!got) return Status_Pack(Status_Item_Not_Found);
    
    got = _BlueBitsDevice->getCharacteristicByUUID(DataChar, "240FAA01-2498-4B36-BC0C-EDCCC32D0635");
    if (!got) {
        return Status_Pack(Status_Item_Not_Found);
    } else {
        DataChar.subscribe(true);
    }

    got = _BlueBitsDevice->getCharacteristicByUUID(TransferingChar, "240FAA03-2498-4B36-BC0C-EDCCC32D0635");
    if (!got) {
        return Status_Pack(Status_Item_Not_Found);
    } else {
        TransferingChar.subscribe(true);
    }

    got = _BlueBitsDevice->getCharacteristicByUUID(TransferSumDataChar, "240FAA02-2498-4B36-BC0C-EDCCC32D0635");
    if (!got) {
        return Status_Pack(Status_Item_Not_Found);
    } else {
        TransferSumDataChar.subscribe(true);
    }

    got = _BlueBitsDevice->getCharacteristicByUUID(ResponseChar, "240FAA05-2498-4B36-BC0C-EDCCC32D0635");
    if (!got) return Status_Pack(Status_Item_Not_Found);

    got = _BlueBitsDevice->getCharacteristicByUUID(AckChar, "240FAA04-2498-4B36-BC0C-EDCCC32D0635");
    if (!got) return Status_Pack(Status_Item_Not_Found);

    uint8_t buf[1] = {1};
    size_t x = TransferSumDataChar.setValue(buf, 1);
    if (x > 0) {
        //TODO figure out what this value actually means
        //TODO error
        Logger_t::Info("Set value: %u", x);
    }
    
    _DownloadStartTime = millis();

    return ret;
}

//TODO figure out how to handle device disconnecting

StatusRet_t BlueBitsSummaryComs_t::GetSerial(uint16_t bufferSize, uint8_t* buffer, uint16_t* bytesRead) {
    if (Status_IsError(_Status)) return _Status;    
    if (buffer == NULL || bytesRead == NULL) return Status_Pack(Status_Null_Ptr);   
    if (_CurrentSummaryState == BBSummaryStates_Idle) return Status_Pack(Status_BufferEmpty);

    *bytesRead = ResBitSerialChar.getValue(buffer, bufferSize);
    if (*bytesRead == 0) {
        Logger_t::Error("Error getting resbit serial number");
        //TODO real error
        return Status_Pack(Status_Invalid_Value);
    }

    return Status_Ok;
}