/**
 ******************************************************************************
 * @file    RSParticleFormater.cpp
 * @brief   Implementation for RSParticleFormater
 * @author  Jeffrey Hatton
******************************************************************************
 *
 * @copyright COPYRIGHT (c) 2020 SAEC Kinetic Vision, Inc 
 *            All Rights Reserved
 *
 * This software is property of SAEC Kinetic Vision, Inc and is considered
 * confidential.
 *
 ******************************************************************************
 *
 * Significant Modification History (Most Recent at top)
 * -----------------------------------------------------
 *
 * Date        | Initials | Description
 * ----------- | -------- | -----------
 * 21 Sep 2020 |   JH     | Original
 *
 * Theory of Operation
 * -------------------
 * TBD
 *
 *
 *
 */

#include "RSParticleFormater.h"

StatusRet_t RSParticleFormater_t::Init(SuId_t id) {
    _Status = SoftwareUnit_t::Init(id);

    _PacketGenerated = false;

    return _Status;
}

StatusRet_t RSParticleFormater_t::GenerateNextPacket() {
    if (Status_IsError(_Status)) return _Status;

    if (_CurrentEvent == _EventCount) return Status_Pack(Status_BufferEmpty);

    Logger_t::Info("Generating next JSON packet");

    uint16_t lastEventCount = _CurrentEvent;
    uint16_t lastGoodIdx = 0;
    uint temp;
    JSONBufferWriter writer(_Data, sizeof(_Data) - 1);
    writer.beginObject();
    writer.name("Events").beginArray();
    for (; _CurrentEvent < _EventCount; _CurrentEvent++) {
        RSEvent_t* event = _Events + _CurrentEvent;
        
        uint dataFormat;
        writer.beginObject();
        
        for (size_t x = 0; x < _SerialCount; x++) {                
            uint16_t idx = x * 2;
            sprintf(_StrBuffer + idx, "%.2x", _Serial[x]);
        }
        writer.name("deviceID").value(_StrBuffer);

        writer.name("data").beginObject();
        writer.name("eventFields").beginArray();

        //TODO this should be based on the data format field
        //TODO do this better
        switch (event->EventId)
        {
        case ResbitEvents_WakeUp:
            temp = *(uint32_t*)event->Data;
            writer.value(temp);
            dataFormat = 0;
            break;
        case ResbitEvents_TriggerPull:
            temp = *(uint32_t*)event->Data;
            writer.value(temp);
            dataFormat = 0;
            break;
        case ResbitEvents_TiltAngle:
            dataFormat = 2;
            writer.value(*(float*)(event->Data));
            writer.value(*(float*)(event->Data + 4));
            writer.value(*(float*)(event->Data + 8));
            writer.value(*(float*)(event->Data + 12));
            break;
        default:
            dataFormat = 3;
            for (size_t x = 0; x < event->DataSize; x++) {                
                uint16_t idx = x * 2;
                sprintf(_StrBuffer + idx, "%.2x", event->Data[x]);
            }
            
            writer.value(_StrBuffer);
            break;
        }
        writer.endArray();

        writer.name("eventType").value(event->EventId);
        writer.name("dataFormat").value(dataFormat);
        writer.name("eventDataSize").value(event->DataSize);
        temp = event->Timestamp;
        writer.name("eventWakeupTime").value(temp);

        writer.endObject();
        writer.endObject();

            // Add null terminator to packet
        uint32_t endIdx = writer.dataSize();
        if (writer.bufferSize() > endIdx) {
            lastGoodIdx = endIdx;
        } else {
            break;
        }
    }

    writer.buffer()[lastGoodIdx] = ']';
    writer.buffer()[lastGoodIdx + 1] = '}';
    writer.buffer()[lastGoodIdx + 2] = 0;

    Logger_t::Info("Generated next JSON packet for %u Events", _CurrentEvent - lastEventCount);

    _PacketGenerated = true;

    return Status_Ok;
}

StatusRet_t RSParticleFormater_t::StartPacketGen(RSEvent_t* events, uint16_t eventCount, uint8_t* serial, uint16_t serialCount) {
    if (Status_IsError(_Status)) return _Status;
    if (events == NULL || serial == NULL) return Status_Pack(Status_Null_Ptr);

    StatusRet_t ret = Status_Ok;
    if (eventCount == 0) return ret;

    _Serial =  serial;
    _Events = events;
    _EventCount = eventCount;
    _SerialCount = serialCount;
    _CurrentEvent = 0;

    Logger_t::Info("Starting Generation of JSON packets for %u Events", eventCount);

    return GenerateNextPacket();
}

StatusRet_t RSParticleFormater_t::Clear() {
    if (Status_IsError(_Status)) return _Status;

    _PacketGenerated = false;
    _CurrentEvent = 0;

    return Status_Ok;
}

StatusRet_t RSParticleFormater_t::GetPacket(char** ptr) {
    if (Status_IsError(_Status)) return _Status;
    if (ptr == NULL) return Status_Pack(Status_Null_Ptr);
    if (!_PacketGenerated) return Status_Pack(Status_BufferEmpty);

    StatusRet_t ret = Status_Ok;

    *ptr = _Data;

    return ret;
}
