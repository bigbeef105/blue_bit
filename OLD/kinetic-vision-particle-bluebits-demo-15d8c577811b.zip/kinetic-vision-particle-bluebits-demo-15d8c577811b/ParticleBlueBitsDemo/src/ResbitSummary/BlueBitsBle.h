/**
 ******************************************************************************
 * @file    BlueBitsBle.h
 * @brief   DESCRIPTION
 * @author  Jeffrey Hatton
******************************************************************************
 *
 * @copyright COPYRIGHT (c) 2020 SAEC Kinetic Vision, Inc 
 *            All Rights Reserved
 *
 * This software is property of SAEC Kinetic Vision, Inc and is considered
 * confidential.
 *
 ******************************************************************************
 *
 * Significant Modification History (Most Recent at top)
 * -----------------------------------------------------
 *
 * Date        | Initials | Description
 * ----------- | -------- | -----------
 * 16 Sep 2020 |   JH     | Original
 *
 * Theory of Operation
 * -------------------
 * TBD
 *
 *
 *
 */

#ifndef BLUE_BITS_BLE_H
#define BLUE_BITS_BLE_H

#include "Status\DeviceStatus.h"
#include "SoftwareUnits\SoftwareUnit.h"
#include "BLE.h"

class BlueBitsBle_t : public SoftwareUnit_t {
    public:

    enum BleStates_t {
        BleStates_Idle,
        BleStates_Scanning,
        BleStates_Found,
        BleStates_Connected,
        BleStates_Count,
    };

    /**
     * @brief Init the software unit
     * 
     * @param id The id of the software unit
     * @return StatusRet_t 
     */
    StatusRet_t Init(SuId_t id);

    /**
     * @brief Give processing time to the software unit
     * 
     * @return StatusRet_t 
     */
    StatusRet_t Tick();

    /**
     * @brief Enable the bluetooth module
     * 
     * @param enable If to enable or disable the module
     * @return StatusRet_t 
     */
    StatusRet_t Enable(bool enable);

    /**
     * @brief Set the max amount of time to stay connected to a device.
     * Timer can be refreshed with RefreshConnectionTimer.
     * 
     * @param timeout 
     * @return StatusRet_t 
     */
    StatusRet_t SetConnectionTimeOut(uint32_t timeout);

    /**
     * @brief Refreshes the connection timer to avoid a disconnect due to timeout
     * 
     * @return StatusRet_t 
     */
    StatusRet_t RefreshConnectionTimer();

    /**
     * @brief Scan for the first found BlueBits Device
     * 
     * @param timeout The amount of time to scan before timing out
     * @return StatusRet_t 
     */
    StatusRet_t ScanForDevice(uint32_t timeout = 5000);

    /**
     * @brief Get the current state of the BLE
     * 
     * @param state 
     * @return StatusRet_t 
     */
    StatusRet_t GetState(BleStates_t* state);

    /**
     * @brief Stop scanning
     * 
     * @return StatusRet_t 
     */
    StatusRet_t StopScan();

    /**
     * @brief Get currently connected to device. Will return Status_BufferEmpty if no 
     * device is connected
     * 
     * @param device 
     * @return StatusRet_t 
     */
    StatusRet_t GetConnectedDevice(BlePeerDevice** device);

    /**
     * @brief Disconnect the current device
     * 
     * @return StatusRet_t 
     */
    StatusRet_t DisconnectCurrentDevice();

    /**
     * @brief Returns if the system is connected to a device
     * 
     * @param connected buffer for connected
     * @return StatusRet_t 
     */
    StatusRet_t IsConnected(bool* connected);

    /**
     * @brief Set the delay between scans
     * 
     * @param delay 
     * @return StatusRet_t 
     */
    StatusRet_t SetScanDelay(uint32_t delay);

    private:

    /**
     * @brief Connect to the device with the id stored in _LastScanResult
     * 
     * @return StatusRet_t 
     */
    StatusRet_t ConnectToDevice();

    /**
     * @brief The device the module is currently connected too
     * 
     */
    BlePeerDevice _CurrentDevice;

    /**
     * @brief The time a scan started
     * 
     */
    uint32_t _StartScanTime;

    /**
     * @brief The amount of time to scan for
     * 
     */
    uint32_t _ScanTimeout = 5000;

    /**
     * @brief If the BLE module is enabled
     * 
     */
    bool _Enabled;

    /**
     * @brief The time a device was connected at
     * 
     */
    uint32_t _ConnectionTime;

    /**
     * @brief The amount of time to stay connected
     * 
     */
    uint32_t _ConnectionTimeout;


    /**
     * @brief The time the last scan ended
     * 
     */
    uint32_t _LastScanTime;

    /**
     * @brief The amount of time to wait in between scans
     * 
     */
    uint32_t _ScanDelay = 1000;

    //TODO figure this out
    public:

    /**
     * @brief The current state of the BlueBitsBle
     * 
     */
    BleStates_t _CurrentState;

    /**
     * @brief Address of the last found bluebits device
     * 
     */
    BleAddress _LastScanResult;
};

#endif
