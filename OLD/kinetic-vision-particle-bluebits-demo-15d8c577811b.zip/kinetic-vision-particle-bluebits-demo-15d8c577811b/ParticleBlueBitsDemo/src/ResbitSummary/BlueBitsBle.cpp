/**
 ******************************************************************************
 * @file    BlueBitsBle.cpp
 * @brief   DESCRIPTION
 * @author  Jeffrey Hatton
******************************************************************************
 *
 * @copyright COPYRIGHT (c) 2020 SAEC Kinetic Vision, Inc 
 *            All Rights Reserved
 *
 * This software is property of SAEC Kinetic Vision, Inc and is considered
 * confidential.
 *
 ******************************************************************************
 *
 * Significant Modification History (Most Recent at top)
 * -----------------------------------------------------
 *
 * Date        | Initials | Description
 * ----------- | -------- | -----------
 * 16 Sep 2020 |   JH     | Original
 *
 * Theory of Operation
 * -------------------
 * TBD
 *
 *
 *
 */

#include "BlueBitsBle.h"
#include "RE_SDK_Config.h"

static uint8_t BLUE_BITS_UUID[] = {0x15, 0x2a, 0xd1 ,0xe0 ,0x63 ,0xaf, 0x11, 0xea, 0xbc, 0x55, 0x02, 0x42, 0xac, 0x13, 0x00, 0x03};
static uint8_t AdvertBuf[31];

#define BLUE_BITS_UUID_SIZE sizeof(BLUE_BITS_UUID)
#define ADVERT_UUID_START_IDX 9

void scanResultCallback(const BleScanResult *scanResult, void *context) {
    
    size_t num = scanResult->advertisingData.get(AdvertBuf, 31);

    // Check if the amount of data in advert has at least enough to check for BlueBits
    if (num < ADVERT_UUID_START_IDX + BLUE_BITS_UUID_SIZE)

    // check if device type is a beacon
    if (AdvertBuf[2] != 6) return;

    // Check if the uuid matches expected    
    for (size_t i = 0; i < BLUE_BITS_UUID_SIZE; i++) {
        if (AdvertBuf[9 + i] != BLUE_BITS_UUID[i]) return;        
    }

    Logger_t::Info("Found BlueBits Device: MAC: %02X:%02X:%02X:%02X:%02X:%02X | RSSI: %dBm",
            scanResult->address[0], scanResult->address[1], scanResult->address[2],
            scanResult->address[3], scanResult->address[4], scanResult->address[5], scanResult->rssi);

    // Cache Device Address
    BlueBitsBle_t* ptr = (BlueBitsBle_t*)context;
    memcpy(&ptr->_LastScanResult, &(scanResult->address), sizeof(BleAddress));

    // Stop Scanning
    StatusRet_t ret = ptr->StopScan();
    if (Status_IsError(ret)) {
        Logger_t::Error("Error when stoping scan: 0x%0.8x", ret);
    }

    // Move onto the next state
    ptr->_CurrentState = BlueBitsBle_t::BleStates_Found;
}

StatusRet_t BlueBitsBle_t::Init(SuId_t id) {
    _Status = SoftwareUnit_t::Init(id);

    //TODO if system mode not automatic set to false
    _Enabled = false;
    _ConnectionTimeout = DEFAULT_CONNECTION_TIME_OUT;
    _CurrentState = BleStates_Idle;

    _LastScanTime = 0;

    return _Status;
}

StatusRet_t BlueBitsBle_t::Enable(bool enable) {
    if (Status_IsError(_Status)) return _Status;
    StatusRet_t ret = Status_Ok;

    if (enable == _Enabled) return ret;

    int result;

    if (enable) {
        Logger_t::Info("Turning on BLE radio");
        result = BLE.on();
        if (result > 0) {
            Logger_t::Error("Error when turning on BLE radio: %i", result);

            // Make sure ble is marked as disabled
            enable = false;
        }
    } else {
        if (_CurrentState == BleStates_Connected) {
            ret = DisconnectCurrentDevice();
            if (Status_IsError(ret)) {
                ret = Status_Ok;
                Logger_t::Error("Error when attempting to disconnect device: 0x%0.8x");
            }
        } else if (_CurrentState == BleStates_Scanning) {
            ret = StopScan();
            if (Status_IsError(ret)) {
                ret = Status_Ok;
                Logger_t::Error("Error when attempting to stop scan: 0x%0.8x");
            }
        }

        _CurrentState = BleStates_Idle;

        Logger_t::Info("Turning off BLE radio");
        result = BLE.off();
        if (result > 0) {
            Logger_t::Warn("Error when turning on BLE radio: %i", result);

            // Make sure ble is marked as enabled
            enable = true;
        }
    }

    _Enabled = enable;

    return ret;
}

StatusRet_t BlueBitsBle_t::Tick() {
    StatusRet_t ret = Status_Ok;

    uint32_t time = millis();
    int result;

    switch (_CurrentState) {
        case BleStates_Idle:
        // Do nothing
        break;
        case BleStates_Scanning:
            if (millis() - _LastScanTime > _ScanDelay) {
                result = BLE.scan(scanResultCallback, this);
                _LastScanTime = millis();
            }
        break;
        case BleStates_Found:
            ret = ConnectToDevice();            
            break;
        case BleStates_Connected:
            if (time - _ConnectionTime >= _ConnectionTimeout) {
                Logger_t::Warn("Max Connection time for Bluebit has been reachecd. Disconnecting Device");
                ret = DisconnectCurrentDevice();
            } else {
                if (!_CurrentDevice.connected()) {
                    Logger_t::Warn("BlueBits has disconnected");
                    DisconnectCurrentDevice();
                }
            }
        break;
        default: 
            return Status_Pack(Status_Invalid_Value);
    }

    return ret;
}

StatusRet_t BlueBitsBle_t::ConnectToDevice() {
    if (Status_IsError(_Status)) return _Status;
    StatusRet_t ret = Status_Ok;

    String addres = _LastScanResult.toString();
    Logger_t::Info("Connecting to BlueBits device: %s", addres.c_str());

    _CurrentDevice = BLE.connect(_LastScanResult);
    if (_CurrentDevice.connected()) {
        Logger_t::Info("Connected to BlueBits device");
        _CurrentState = BleStates_Connected;
        _ConnectionTime = millis();
    } else {
        Logger_t::Error("Connection to BlueBits Device Failed");
        _CurrentState = BleStates_Idle;
        ret = ScanForDevice(_ScanTimeout);
    }

    return ret;
}

StatusRet_t BlueBitsBle_t::ScanForDevice(uint32_t timeout) {
    if (Status_IsError(_Status)) return _Status;
    StatusRet_t ret = Status_Ok;
    if (_CurrentState != BleStates_Idle) return ret;

    if (!_Enabled) {
        ret = Enable(true);
        if (Status_IsError(ret)) return ret;
    }

    _ScanTimeout = timeout;
    int result = BLE.setScanTimeout(timeout / 10);
    //TODO check result

    Logger_t::Info("Starting BLE Scan");
    _StartScanTime = millis();

    _CurrentState = BleStates_Scanning;

    return ret;
}

StatusRet_t BlueBitsBle_t::StopScan() {
    if (Status_IsError(_Status)) return _Status;
    StatusRet_t ret = Status_Ok;

    if (_CurrentState != BleStates_Scanning) return ret;
    Logger_t::Info("Stopping BLE Scan");

    _CurrentState = BleStates_Idle;
    int result = BLE.stopScanning();
    if (result > 0) {
        Logger_t::Warn("Error when stopping scan: %i", result);
    }
    //TODO check result

    return ret;
}

StatusRet_t BlueBitsBle_t::GetConnectedDevice(BlePeerDevice** device) {
    if (Status_IsError(_Status)) return _Status;
    if (device == NULL) return Status_Pack(Status_Null_Ptr);
    if (_CurrentState != BleStates_Connected) return Status_Pack(Status_BufferEmpty);

    StatusRet_t ret = Status_Ok;

    *device = &_CurrentDevice;

    return ret;
}

StatusRet_t BlueBitsBle_t::DisconnectCurrentDevice() {
    if (Status_IsError(_Status)) return _Status;
    StatusRet_t ret = Status_Ok;

    if (_CurrentState != BleStates_Connected) return ret;

    Logger_t::Info("Disconnecting BlueBits Device");
    int result = BLE.disconnect(_CurrentDevice);
    //TODO check result

    _CurrentState = BleStates_Idle;

    return ret;
}

StatusRet_t BlueBitsBle_t::SetConnectionTimeOut(uint32_t timeout) {
    if (Status_IsError(_Status)) return _Status;

    _ConnectionTimeout = timeout;

    return Status_Ok;
}

StatusRet_t BlueBitsBle_t::RefreshConnectionTimer() {
    if (Status_IsError(_Status)) return _Status;

    if (_CurrentState != BleStates_Connected) return Status_Ok;

    _ConnectionTime = millis();

    return Status_Ok;  
}

StatusRet_t BlueBitsBle_t::GetState(BleStates_t* state) {
    if (Status_IsError(_Status)) return _Status;
    if (state == NULL) return Status_Pack(Status_Null_Ptr);

    *state = _CurrentState;

    return Status_Ok;  
}

StatusRet_t BlueBitsBle_t::IsConnected(bool* connected) {
    if (Status_IsError(_Status)) return _Status;
    if (connected == NULL) return Status_Pack(Status_Null_Ptr);

    if (_CurrentState != BleStates_Connected) {
        *connected = false;
    } else {
        *connected = _CurrentDevice.connected();
    }

    return Status_Ok;  
}

StatusRet_t BlueBitsBle_t::SetScanDelay(uint32_t delay) {
    if (Status_IsError(_Status)) return _Status;

    _ScanDelay = delay;

    return Status_Ok;
}
