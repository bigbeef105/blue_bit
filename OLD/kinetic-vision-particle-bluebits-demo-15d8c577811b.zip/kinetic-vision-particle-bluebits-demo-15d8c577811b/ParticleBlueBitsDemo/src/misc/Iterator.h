/**
 ******************************************************************************
 * @file    Iterator.h
 * @brief   Defines an interator class
 * @author  Jeffrey Hatton
******************************************************************************
 *
 * @copyright COPYRIGHT (c) 2020 SAEC Kinetic Vision, Inc 
 *            All Rights Reserved
 *
 * This software is property of SAEC Kinetic Vision, Inc and is considered
 * confidential.
 *
 ******************************************************************************
 *
 * Significant Modification History (Most Recent at top)
 * -----------------------------------------------------
 *
 * Date        | Initials | Description
 * ----------- | -------- | -----------
 * 03 Apr 2020 |   JH     | Original
 *
 * Theory of Operation
 * -------------------
 * TBD
 *
 *
 *
 */

#ifndef ITERATOR_H
#define ITERATOR_H

template <typename T>
class Iterator
{
private:
    T** _Data = NULL;

public:
    
    void SetData(T** data) {
        _Data = data;
    }

    T* operator *() {
        return  *_Data;
    }

    T* operator ->() {
        return  *_Data;
    }

    Iterator& operator++() {
        _Data++;
        return *this;
    }

    Iterator operator++(int) {
        Iterator temp = *this;
        ++*this;
        return temp;
    }

    Iterator& operator--() {
        _Data--;
        return *this;
    }

    Iterator operator--(int) {
        Iterator temp = *this;
        --*this;
        return temp;
    }    

    bool AtEnd() {
        return (_Data == NULL || *_Data == NULL);
    }

    T** GetPtr() {
        return _Data;
    }
};

#endif