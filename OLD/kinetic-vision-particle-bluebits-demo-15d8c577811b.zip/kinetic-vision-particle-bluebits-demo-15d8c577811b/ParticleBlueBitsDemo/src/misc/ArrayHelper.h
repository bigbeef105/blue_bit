/**
 ******************************************************************************
 * @file    ArrayHelper.h
 * @brief   Module that contains logic for helping with arrays
 * @author  Jeffrey Hatton
******************************************************************************
 *
 * @copyright COPYRIGHT (c) 2020 SAEC Kinetic Vision, Inc 
 *            All Rights Reserved
 *
 * This software is property of SAEC Kinetic Vision, Inc and is considered
 * confidential.
 *
 ******************************************************************************
 *
 * Significant Modification History (Most Recent at top)
 * -----------------------------------------------------
 *
 * Date        | Initials | Description
 * ----------- | -------- | -----------
 * 19 Aug 2020 |   JH     | Original
 *
 * Theory of Operation
 * -------------------
 * TBD
 *
 *
 *
 */

#ifndef ARRAY_HELPER_H
#define ARRAY_HELPER_H

#define HBOUND(_array_) (sizeof(_array_)/sizeof(_array_[0]))

#endif
