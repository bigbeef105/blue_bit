/**
 ******************************************************************************
 * @file    StringHelper.cpp
 * @brief   Implementation for StringHelper
 * @author  Jeffrey Hatton
******************************************************************************
 *
 * @copyright COPYRIGHT (c) 2020 SAEC Kinetic Vision, Inc 
 *            All Rights Reserved
 *
 * This software is property of SAEC Kinetic Vision, Inc and is considered
 * confidential.
 *
 ******************************************************************************
 *
 * Significant Modification History (Most Recent at top)
 * -----------------------------------------------------
 *
 * Date        | Initials | Description
 * ----------- | -------- | -----------
 * 19 Aug 2020 |   JH     | Original
 *
 * Theory of Operation
 * -------------------
 * TBD
 *
 *
 *
 */

#include "StringHelper.h"

StatusRet_t StrToLower(char* dest, char* src) {
    if (dest == NULL || src == NULL) return Status_Null_Ptr;

    int i = 0;
    while (src[i]) {
        dest[i] = tolower(src[i]);
        i++;
    }

    dest[i] = 0;

    return Status_Ok;
}
