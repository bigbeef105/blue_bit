/**
 ******************************************************************************
 * @file    DeviceStatus.h
 * @brief   Software unit that manages statuses for the device
 * @author  Jeffrey Hatton
******************************************************************************
 *
 * @copyright COPYRIGHT (c) 2020 SAEC Kinetic Vision, Inc 
 *            All Rights Reserved
 *
 * This software is property of SAEC Kinetic Vision, Inc and is considered
 * confidential.
 *
 ******************************************************************************
 *
 * Significant Modification History (Most Recent at top)
 * -----------------------------------------------------
 *
 * Date        | Initials | Description
 * ----------- | -------- | -----------
 * 03 APR 2020 |   JH     | Original
 *
 * Theory of Operation
 * -------------------
 * TBD
 *
 *
 *
 */

#ifndef DEVICESTATUS_H_
#define DEVICESTATUS_H_

// Includes ------------------------------------------------------------------

#include <stdint.h>

#include "Arduino.h"

// Private constants ---------------------------------------------------------

// Private variables ---------------------------------------------------------
// Private types -------------------------------------------------------------

/**
 * @brief Type for software unit ids
 * 
 */
typedef uint16_t SuId_t;

/**
 * @brief Type for statuses
 * 
 */
typedef uint16_t Status_t;

typedef enum{
    Status_Ok = 0,
    Status_Null_Ptr,
    Status_Not_Initialized,
    Status_Initialized,
    Status_Timeout,
    Status_SuIdSet,
    Status_InvalidSuId,
    
    Status_BufferOverflow,
    Status_BufferFull,
    Status_BufferEmpty,
    Status_BufferTooSmall,
    Status_BufferTooLarge,
    Status_BufferInvalid,
    Status_AlreadyLinked,
    Status_Item_Not_Found,
    Status_Unreachable,
    Status_Busy,
    Status_HardwareDoesNotExist,
    Status_InvalidOperation,
    Status_IncorrectDevice,
    Status_Invalid_Format,
    Status_Invalid_Value,
    Status_ValueOutOfBounds,
    Status_AlreadyInitialized,

    Status_InvalidState,
    Status_UnkownCommand,
    Status_NOP,
    Status_ResourceLocked,
    
    Status_Last_Common_Status,
} CommonStatus_t;

//Packed status object
typedef uint32_t StatusRet_t;

// Exported macro ------------------------------------------------------------

//Maximum number of peripheral devices allowed
#define STATUS_MAX_ID_NUM 0xFF00

///The number of bits for the status object
#define STATUS_NUM_BITS_STATUS 16

//The number of bits for the software unit Id
#define STATUS_NUM_BITS_SU_ID 16

//The total number of bits in a packed status result
#define STATUS_NUM_BITS_TOTAL (STATUS_NUM_BITS_STATUS + STATUS_NUM_BITS_SU_ID)

//Returns if the status is in an error status
#define Status_IsError(status) (status != 0)

//Returns if the status is an ok state
#define Status_IsGood(status) (!Status_IsError(status))

//Gets the state portion of the status
#define Status_GetStatus(_STATUS_) (_STATUS_ & 0xFFFF)

/**
 * @brief Get only the ID from the packed status
 * 
 */
#define Status_GetId(_STATUS_) (_STATUS_ >> STATUS_NUM_BITS_STATUS)

//Returns if the passed status is a common status
#define Status_IsStatus(packedStatus,__commonStatus__) ((Status_GetStatus(packedStatus)) == __commonStatus__)

//Pack Su ID 
#define Status_SuIdPack(SUI, STATUS) (((StatusRet_t) SUI << STATUS_NUM_BITS_SU_ID) |STATUS)

/**
 * @brief Pack a status with the local software unit id. Requires the software unit id to be stored in _SuId
 * 
 */
#define Status_Pack(STATUS) (((StatusRet_t) _SuId << STATUS_NUM_BITS_SU_ID) |STATUS)

// Public function prototypes -----------------------------------------------

///@brief Gets status enum name from int 
///@param status the packed status to get as a string
///@param statusString stores the returned enum name
StatusRet_t Status_GetStatusAsString(StatusRet_t status, const char** statusString);

/// SAEC Kinetic Vision, Inc  ----------- END OF FILE
#endif