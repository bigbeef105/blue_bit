/**
 ******************************************************************************
 * @file    Logger_t.c
 * @brief   Implementation for the Logging Software Unit
 * @author  Jeffrey Hatton
******************************************************************************
 *
 * @copyright COPYRIGHT (c) 2020 SAEC Kinetic Vision, Inc 
 *            All Rights Reserved
 *
 * This software is property of SAEC Kinetic Vision, Inc and is considered
 * confidential.
 *
 ******************************************************************************
 *
 * Significant Modification History (Most Recent at top)
 * -----------------------------------------------------
 *
 * Date        | Initials | Description
 * ----------- | -------- | -----------
 * 03 Apr 2020 |   JH     | Original
 *
 * Theory of Operation
 * -------------------
 * TBD
 *
 *
 *
 */

#include "Logger.h"
#include "CoreConfig.h"

static Logger_t _Instance;
Stream* Logger_t::_Serial;
char Logger_t::_Buf[200];

static const char* _LevelStrMap[LogLevels_Count] = {
    [LogLevels_Info] = "Info",
    [LogLevels_Warn] = "Warn",
    [LogLevels_Error] = "Error",
};

StatusRet_t Logger_t::Init(Stream* serial) {
    if (serial == NULL) return Status_Null_Ptr;

    Logger_t::_Serial = serial;

    return _Instance.Init();
}

StatusRet_t Logger_t::Log(LogLevels_t level, const char* fmt, ...) {
    va_list args;
    va_start(args,fmt);

    StatusRet_t ret = LogVa(level, fmt, args);
    va_end(args);

    return ret;
}

StatusRet_t Logger_t::LogVa(LogLevels_t level, const char* fmt, va_list args) {
    uint16_t charCount = vsnprintf(_Buf, 200, fmt, args);
    if (charCount == 200) return Status_BufferTooSmall;

    #ifdef ENABLE_LOGGING
        _Serial->printf("[%8.3f] %s: %s\n\r", millis() / 1000.0f, _LevelStrMap[level], _Buf);
        delay(2);
    #endif 

    return Status_Ok;
}

StatusRet_t Logger_t::Info(const char* fmt, ...) {
    va_list args;
    va_start(args,fmt);

    StatusRet_t ret = LogVa(LogLevels_Info, fmt, args);
    va_end(args);

    return ret;
}

StatusRet_t Logger_t::Warn(const char* fmt, ...) {
    va_list args;
    va_start(args,fmt);

    StatusRet_t ret = LogVa(LogLevels_Warn, fmt, args);

    va_end(args);

    return ret;
}

StatusRet_t Logger_t::Error(const char* fmt, ...) {
    va_list args;
    va_start(args,fmt);

    StatusRet_t ret = LogVa(LogLevels_Error, fmt, args);

    va_end(args);

    return ret;
}

StatusRet_t Logger_t::Init() {
    if (Logger_t::_Serial != NULL) {
        _Status = Status_Ok;
    }

    return _Status;
}
