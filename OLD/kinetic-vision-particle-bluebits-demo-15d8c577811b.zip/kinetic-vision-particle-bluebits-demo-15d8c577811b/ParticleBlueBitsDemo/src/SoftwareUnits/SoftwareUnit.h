/**
 ******************************************************************************
 * @file    SoftwareUnit.h
 * @brief   Base Class for software units
 * @author  Jeffrey Hatton
******************************************************************************
 *
 * @copyright COPYRIGHT (c) 2020 SAEC Kinetic Vision, Inc 
 *            All Rights Reserved
 *
 * This software is property of SAEC Kinetic Vision, Inc and is considered
 * confidential.
 *
 ******************************************************************************
 *
 * Significant Modification History (Most Recent at top)
 * -----------------------------------------------------
 *
 * Date        | Initials | Description
 * ----------- | -------- | -----------
 * 03 Apr 2020 |   JH     | Original
 *
 * Theory of Operation
 * -------------------
 * TBD
 *
 *
 *
 */

#ifndef SOFTWARE_UNIT_H
#define SOFTWARE_UNIT_H

#include "Status\DeviceStatus.h"
#include "Logging\Logger.h"

class SoftwareUnit_t {
    public:

    /**
     * @brief Init the unit and set the software unit id
     * 
     * @param suId The software unit id to set
     * @return StatusRet_t 
     */
    StatusRet_t Init(SuId_t suId);

    /**
     * @brief Get the Software Unit ID for the unit
     * 
     * @return SuId_t 
     */
    SuId_t GetSuId();

    /**
     * @brief Get the Status for the object
     * 
     * @param status 
     * @return StatusRet_t 
     */
    StatusRet_t GetStatus(StatusRet_t* status);

    /**
     * @brief Get the name for the unit
     * 
     * @param name 
     * @return StatusRet_t 
     */
    StatusRet_t GetName(const char** name);

    /**
     * @brief Set the name for the unit
     * 
     * @param name 
     * @return StatusRet_t 
     */
    StatusRet_t SetName(const char* name);

    /**
     * @brief Get the tick info for the software unit
     * 
     * @param totalTime 
     * @param count 
     * @return StatusRet_t 
     */
    StatusRet_t GetTickInfo(uint32_t* totalTime, uint32_t* count);

    /**
     * @brief Give processing time to the software unit
     * 
     * @return StatusRet_t 
     */
    virtual StatusRet_t Tick();

    /**
     * @brief Run any cbist functions for the software unit
     * 
     * @return StatusRet_t 
     */
    virtual StatusRet_t Cbist();

    protected:

    /**
     * @brief Set the Software unit if for the object
     * 
     * @param suId 
     * @return StatusRet_t 
     */
    StatusRet_t SetSuId(SuId_t suId);

    /**
     * @brief Internal method for tick. Subclasses should override this method
     *        to implement the tick method
     * 
     * @return StatusRet_t 
     */
    virtual StatusRet_t InternalTick();

    /**
     * @brief Internal method for cbist. Subclasses should override this method to 
     *        implement the cbist method
     * 
     * @return StatusRet_t 
     */
    virtual StatusRet_t InternalCbist();
    
    /**
     * @brief Buffer for the _SuId
     * 
     */
    SuId_t _SuId;

    /**
     * @brief Buffer for the status
     * 
     */
    StatusRet_t _Status = Status_Not_Initialized;

    /**
     * @brief The delay between ticks in milliseconds
     * 
     */
    uint32_t _TickDelay = 0;

    /**
     * @brief The delay between cbist in milliseconds
     * 
     */
    uint32_t _CbistDelay = 0;

    /**
     * @brief The name of the unit
     * 
     */
    const char* _Name = "";

    private:

    /**
     * @brief Last time the unit was ticked
     * 
     */
    uint32_t _LastTickTime = 0;

    /**
     * @brief Last time the cbist was ran
     * 
     */
    uint32_t _LastCbistTime = 0;

    /**
     * @brief The total time the unit has been in its tick handler
     * 
     */
    uint32_t _TotalTickTime = 0;

    /**
     * @brief The total times the unit has been ticked
     * 
     */
    uint32_t _TickCount = 0;
};

#endif
