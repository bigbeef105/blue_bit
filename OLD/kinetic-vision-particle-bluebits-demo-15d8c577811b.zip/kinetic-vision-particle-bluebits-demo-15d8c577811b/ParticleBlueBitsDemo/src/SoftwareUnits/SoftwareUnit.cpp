/**
 ******************************************************************************
 * @file    SoftwareUnit.cpp
 * @brief   Implementation for SoftwareUnit
 * @author  Jeffrey Hatton
******************************************************************************
 *
 * @copyright COPYRIGHT (c) 2020 SAEC Kinetic Vision, Inc 
 *            All Rights Reserved
 *
 * This software is property of SAEC Kinetic Vision, Inc and is considered
 * confidential.
 *
 ******************************************************************************
 *
 * Significant Modification History (Most Recent at top)
 * -----------------------------------------------------
 *
 * Date        | Initials | Description
 * ----------- | -------- | -----------
 * 03 Apr 2020 |   JH     | Original
 *
 * Theory of Operation
 * -------------------
 * TBD
 *
 *
 *
 */

#include "SoftwareUnit.h"

StatusRet_t SoftwareUnit_t::Init(SuId_t suId) {
    if (!Status_IsStatus(_Status, Status_Not_Initialized)) return Status_AlreadyInitialized;

    StatusRet_t ret = SetSuId(suId);
    if (Status_IsGood(_Status)) {
        _Status = ret;
    }

    return ret;
}

SuId_t SoftwareUnit_t::GetSuId() {
    return _SuId;
}

StatusRet_t SoftwareUnit_t::SetSuId(SuId_t suId) {
    if (suId != 0 && suId > STATUS_MAX_ID_NUM) return Status_Invalid_Value;

    _SuId = suId;

    return Status_Ok;
}

StatusRet_t SoftwareUnit_t::GetStatus(StatusRet_t* status) {
    if (status == NULL) return Status_Pack(Status_Null_Ptr);

    *status = _Status;

    return Status_Ok;
}

StatusRet_t SoftwareUnit_t::GetTickInfo(uint32_t* totalTime, uint32_t* count) {
    if (totalTime == NULL || count == NULL) return Status_Pack(Status_Null_Ptr);

    *count = _TickCount;
    *totalTime = _TotalTickTime;

    return Status_Ok;
}

StatusRet_t SoftwareUnit_t::Tick() {
    if (millis() - _LastTickTime < _TickDelay) return Status_NOP;

    uint32_t startTime = micros();
    _LastTickTime = millis();
    StatusRet_t ret = InternalTick();

    if (Status_IsError(ret)) {
        return ret;
    }

    //
    // Update tick tracking values
    //

    uint32_t newCount = _TickCount + 1;
      if (newCount < _TickCount) {
        _TotalTickTime = 0;
        _TickCount = 0;
    } else {
        _TickCount = newCount;
    }

    uint32_t delta = micros() - startTime;
    uint32_t newTime = _TotalTickTime + delta;
    if (newTime < _TotalTickTime) {
        _TotalTickTime = 0;
        _TickCount = 0;
    } else {
        _TotalTickTime = newTime;
    }

    return ret;
}

StatusRet_t SoftwareUnit_t::Cbist() {
    if (millis() - _LastCbistTime < _CbistDelay) return Status_Ok;
    _LastCbistTime = millis();

    return InternalCbist();
}

StatusRet_t SoftwareUnit_t::InternalCbist() {
    return Status_Ok;
}

StatusRet_t SoftwareUnit_t::InternalTick() {
    return Status_NOP;
}

StatusRet_t SoftwareUnit_t::GetName(const char** name) {
    if (Status_IsError(_Status)) return _Status;
    if (name == NULL) return Status_Pack(Status_Null_Ptr);

    *name = _Name;

    return Status_Ok;
}

StatusRet_t SoftwareUnit_t::SetName(const char* name) {
    if (Status_IsError(_Status)) return _Status;
    if (name == NULL) return Status_Pack(Status_Null_Ptr);

    _Name = name;

    return Status_Ok;
}
