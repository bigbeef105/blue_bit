# Readme for AQResearch/myHUB app

>##### NOTE: If you want to edit this file and it is not editable via Xcode, then rename `./AQResearch.xcworkspace/.xcodesamplecode.plist` to `./AQResearch.xcworkspace/.xcodesamplecode.plist.disabled`

---

## Project Summary

P&G performs consumer research activites to track how consumers use their products. Historically, this has been done by having participating consumers keep a product use diary, fill out surveys, or providing feedback in other ways.

A new method has been devised to provide a less intrusive experience to the consumer and to allow for greater accuracy in the study results. Study Participants will be given products with an embedded **sensor** (BLE Device) that will track **Key Events** and store them locally on the device. An iOS app will periodically connect to the sensor, pull the saved data, and send it to AWS's IoT services.

Though participants will be informed fully before the study begins about the tracking of the devices, in order to get the best research results possible the app should reduce any reminders that the user is being tracked. Reminding the user that she is being tracked can affect the user's use of the product.

---

## App Summary

myHUB is an app that communicates between custom BLE devices and AWS's IoT services. Communication with the BLE devices is accomplished through the ResearchBit SDK, provided by [Kinetic Vision](https://kinetic-vision.com/). The connection is initiated by entering the region of a **BLE Beacon**

---

## User Properties

User accounts will be added manually to the AWS Cognito service before a study is started, so no sign-up process is enabled in the app. Applicable user properties include:

>| Property      | Type   | Description                               | Format         |
>| :---          | :---   | :---                                      | :---           |
>| username      | String | The user's email address                  | `abc@def.com`  |
>| password      | String | The user's password                       | Must include length of 8+, number, special character, upper- and lowercase letters |
>| phoneNumber   | String | The user's phone number                   | `+12345678912` |
>| email         | String | The user's email address                  | `abc@def.com`  |
>| studyId       | String | The Study ID the user is participating in | `ABCD1234`     |
>| participantId | String | The user's Participant ID for the study   | `ABCD1234`     |

---

## Sensor Connection Process

In order to allow the app to connect to the sensors in the background, a BLE Beacon is integrated into the BLE device.

* Each **sensor** has an embedded **beacon**
* The app monitors for the beacon via the `CoreLocation` framework
* When the app enters the range of a beacon, it attempts to connect to the associated sensor
* When a connection is made, the app receives usage data from the sensor, and writes the data to AWS

---

## About Beacons

Beacons operate like a geofence for a small area. When monitoring for a beacon, an iOS app will execute an associated delegate method when the app enters the region of the beacon, providing the beacon's details.

Identifying information for a beacon contains:

>| Property | Description               | Format                                 |
>| :---     | :---                      | :---                                   |
>| UUID     | a 32-bit hex identifier   | `00000000-0000-0000-0000-000000000000` |
>| Major    | A 2-byte unsigned integer | `0 - 65535`                            |
>| Minor    | A 2-byte unsigned integer | `0 - 65535`                            |

---

## Sensor Information

The sensors are custom BLE devices, created by [Kinetic Vision](https://kinetic-vision.com/) for the purpose of tracking **Key Events**. 

Data from the sensors will be in a `Codable` class, `SummaryData`, which contains a collection of a `Codable` class, `EventField`, and will be provided by the SDK. The data will be sent in JSON format to the AWS IoT endpoint via MQTT. The sensor will maintain a collection of which key events have been sent to the app, and when the app connects to the sensor, only new key events will be sent to the app.

A sensor will have an identifier, and each product will have a label containing the device's UUID, or the first several characters of the device's UUID. This will be used when onboarding the user to add the product to the user's product list.

These classes have the following properties:

>#### `SummaryData` Properties
>| Property        | Type         | Description |
>| :---            | :---         | :--- |
>| eventType       | Int          | An integer defining the event type |
>| eventUUID       | String       | A unique identifier of the event. A 32-bit UUID in the format `00000000-0000-0000-0000-000000000000` |
>| eventDataSize   | Int          | Number of bytes in the data entry
>| eventWakeupTime | Date         | Time the event happened |
>| eventFields     | [EventField] | The custom fields detailing the event. Defined by the sensor, these will be serialized to JSON and sent to AWS as they come from the device. |

>#### `EventField` Properties
>| Property | Type   | Description                  |
>| :---     | :---   | :---                         |
>| name     | String | The name of the event field  |
>| value    | Int    | The value of the event field |

---

## Beacon Monitoring

The sensor will contain properties detailing the associated beacon information. All beacons will share a `UUID`, but with unique `major` and `minor` values. When the app scans for and adds the sensor to the app, the app will begin monitoring for the device's unique beacon.

---

## App Onboarding

Screens have been coded to provide the ability to sign-up, but have been disabled because user accounts will be added manually to the AWS Cognito service before a study is started. 

Users will log into the app upon first opening the app. After logging in, the user will tap the `Receive Product` button on the main product listing screen. If the user has a device with iOS v13.0+, the user can scan the label on the bottle. If the device is at an iOS version lower than 13.0, the label's text will be entered directly by the user.

When the user continues after scanning (or entering) the code on the bottle, the app will scan for bluetooth devices. For any devices discovered whose identifiers match those assigned to the user:
>1. The sensor will be registered with the app, so connections to the sensor will be attempted
>2. The Beacon information will be read from the sensor, and the app will begin monitoring for the beacon
