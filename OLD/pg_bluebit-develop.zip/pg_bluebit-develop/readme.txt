Notes


BlueBit: Firmware that runs on nRF52832

1) This code is derived from the ResBit IAR project that was developed by P&G, migrating the IAR project to SES.
2) This codebase does NOT follow Nordic's recommendation of placing user code in their SDK tree.  Instead, SES dynamic folders are used to
import the necessary SDK files into the project. 
3) IMPORTANT:  You MUST include a link named "sdk" to the Nordic SDK in the repository root for SES to find them.  See png files within docs
folder for details.
4) To change SDKs, switch the directory where the "sdk" link points to the desired SDK.
5) Last run and tested on Nordic's nRF5_SDK_16.0.0_98a08e2 running SoftDedvice 7.0.1.
6) See commit notes for changes from KV's codebase.