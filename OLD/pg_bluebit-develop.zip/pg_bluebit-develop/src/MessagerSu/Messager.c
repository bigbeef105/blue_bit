/**
  @file       Messager.c

  @copyright  (C) 2020 Kinetic Vision, Cincinnati Ohio.
               This software is property of SAEC Kinetic Vision, Inc
               and is considered confidential.

  @brief      Template software unit "C" file.

  @author     Andrew Loebs

  @ingroup    MessagerSoftwareUnit

  Configuration History
  =====================

  Config Item    | Value
  -------------- | -----
  Config #       | NA
  Revision       | NA
  Revised, Date  | NA
  QA, Date       | NA
  Approved, Date | NA
  Released, Date | NA

  Significant Modification History (Most recent at top)
  =====================================================

  Date         | Initials | Details
  ------------ | -------- | -------
  24 Jan 2020  | ASL      | Original

  Theory of Operation
  ===================
  Handles 'message layer' of Resbit/Bluebits communication.

*/

// Includes ------------------------------------------------------------------
#include <string.h>
#include <stdbool.h> // bool
#include <stdio.h> // size_t

#include "Messager.h"

#include "../SwUnitControlSu/SwUnitControl.h" // SwUnitControl_WriteStatus()
#include "../ConsoleSu/Console.h" // Console_* functions, consoleRegistration_t,
#include "../ProtocolHandlerSu/ProtocolHandler.h" // ProtocolHandler_* functions, MESSAGE_MAX_LEN
#include "../SplitBufferSu/SplitBuffer.h" // splitBuffer_t, SplitBuffer_* functions

// Private function prototypes -----------------------------------------------
static status_t queueMessage(uint16_t messageId, const uint8_t * data, size_t len);
static status_t parseMessage(uint16_t messageId, uint8_t * data, size_t len);
static status_t parseResponse(uint16_t messageId, uint8_t * data, size_t len);
static status_t callMessageHandler(uint16_t messageId, uint8_t * data, size_t len);

static void resetResponseHandlers(void);
static status_t responseHandlersDequeue(responseHandler_t * handler);
static status_t responseHandlersEnqueue(responseHandler_t handler);

static bool responseBitPresent(uint16_t messageId);

// Private macros ------------------------------------------------------------
#define returnStatus(__status__,__source__) SwUnitControl_WriteStatus(eSucMessagerSu,__source__,__status__,__LINE__);

// Private constants ---------------------------------------------------------
#define MESSAGE_UNKNOWN_ID          0x0
#define RESPONSE_FLAG               0x8000

// Private types ------------------------------------------------------------

// Private constants ---------------------------------------------------------
static const messageHandlerReg_t messages[] = {
    // Marks last element in the list
    { 0, NULL },
};

// Private variables ---------------------------------------------------------
static bool initialized = false;

static splitBuffer_t messageQueue;
static uint8_t sbBuffer[MESSAGE_MAX_LEN * 2];
static responseHandler_t resHandlersQueue[SPLIT_BUFFER_MAX_ENTRIES + 1];
static size_t rhHead;
static size_t rhTail;

static messageHandlerList_t messageHandlerRoot = { messages, NULL };

// Private function bodies ---------------------------------------------------
static status_t queueMessage(uint16_t messageId, const uint8_t * data, size_t len)
{
    status_t status = StatusOk;

    // Prepare contents
    uint8_t message[MESSAGE_MAX_LEN];
    *((uint16_t *)message) = messageId;
    if (len != 0) {
        memcpy(&message[MESSAGE_DATA_OFFSET], data, len);
    }
    status = SplitBuffer_Enqueue(&messageQueue, message,
                                 len + MESSAGE_DATA_OFFSET);

    return status;
}

static status_t parseMessage(uint16_t messageId, uint8_t * data, size_t len)
{
    status_t status = StatusOk;

    status = callMessageHandler(messageId, data, len);

    return status;
}

static status_t parseResponse(uint16_t messageId, uint8_t * data, size_t len)
{
    status_t status = StatusOk;

    responseHandler_t responseHandler;
    status = responseHandlersDequeue(&responseHandler);
    if (Status_IsOk(status) && responseHandler) {
    	if (len < MESSAGE_RES_CODE_LEN) {
    		status = StatusBufferLength;
    	} else {
    		responseHandlerArgs_t args = {
    				.resCode = (messageResponseCode_t)*data, // this won't scale if we make res code two bytes, but enum has no guaranteed size
					.data = NULL,
					.len = 0,
    		};
    		if (len > MESSAGE_RES_CODE_LEN) {
    			args.data = data + MESSAGE_RES_CODE_LEN;
    			args.len = len - MESSAGE_RES_CODE_LEN;
    		}
    		status = responseHandler(&args);
    	}

    } else {
        status = StatusCodePath; // should have validated response handler on send message call
    }

    return status;
}

static status_t callMessageHandler(uint16_t messageId, uint8_t * data, size_t len)
{
    status_t status = StatusMessageId; // will mark as OK when we find it

    // Response data
    uint8_t responseBuffer[MESSAGE_MAX_DATA_LEN];
    messageHandlerArgs_t args = {
			.messageData = data,
			.dataLen = len,
			.resCode = messageResponseSuccess, // default
			.resBuffer = responseBuffer + MESSAGE_RES_CODE_LEN,
			.resBufferLen = MESSAGE_MAX_DATA_LEN - MESSAGE_RES_CODE_LEN,
			.bytesWritten = 0, // default
	};

    // Traverse list
    messageHandlerList_t * current = &messageHandlerRoot;
    while (current) {
        messageHandlerReg_t * handlers = current->handlers;
        // Traverse array until found, or we hit null entry
        for (int i = 0; handlers[i].handler; i++) {
            if (handlers[i].messageId == messageId) {
                status = handlers[i].handler(&args);
                break;
            }
        }
        // If found, exit, else proceed
        if (StatusMessageId != status)
            break;
        else
            current = current->next;
    }

    if (StatusMessageId == status) {
    	uint8_t messageData = messageResponseIdError;
        status = Status_Preserve(status, queueMessage(messageId | RESPONSE_FLAG, &messageData, 1));
    } else {
    	responseBuffer[0] = (uint8_t)args.resCode;
        status = Status_Preserve(status, 
        		queueMessage(messageId | RESPONSE_FLAG, responseBuffer, args.bytesWritten + 1));
    }

    return status;
}

static void resetResponseHandlers()
{
    for (int i = 0; i < SPLIT_BUFFER_MAX_ENTRIES + 1; i++) {
        resHandlersQueue[i] = NULL;
    }
    rhHead = 0;
    rhTail = 0;
}

static status_t responseHandlersDequeue(responseHandler_t * handler)
{
    status_t status = StatusOk;

    if (rhHead == rhTail)
        status = StatusBufferEmpty;

    if (Status_IsOk(status)) {
        *handler = resHandlersQueue[rhHead];
        if (rhHead == SPLIT_BUFFER_MAX_ENTRIES) {
            rhHead = 0;
        } else {
            rhHead++;
        }
    }

    return status;
}

static status_t responseHandlersEnqueue(responseHandler_t handler)
{
    status_t status = StatusOk;

    if (rhTail == SPLIT_BUFFER_MAX_ENTRIES) {
        if (rhHead == 0) {
            status = StatusBufferFull;
        } else {
            resHandlersQueue[rhTail] = handler;
            rhTail = 0;
        }
    } else {
        if (rhHead == rhTail + 1) {
            status = StatusBufferFull;
        } else {
            resHandlersQueue[rhTail] = handler;
            rhTail++;
        }
    }

    return status;
}

static bool responseBitPresent(uint16_t messageId)
{
    return ((messageId & RESPONSE_FLAG) == RESPONSE_FLAG);
}

// Public functions bodies ---------------------------------------------------
status_t Messager_Init()
{
    status_t status = StatusOk;
    if (initialized) {
        status = StatusAlreadyInitialized;
    }

    if (Status_IsOk(status)) {
        status = SplitBuffer_Setup(&messageQueue, sbBuffer, MESSAGE_MAX_LEN * 2);
    }

    if (Status_IsOk(status)) {
        resetResponseHandlers();
        initialized = true;
        messageHandlerRoot.next = NULL; // clear handlers
    }

    return returnStatus(status, eSucInitStatus);
}

status_t Messager_Tick(bool* needMoreTime)
{
    status_t status = StatusOk;

    if (!SplitBuffer_IsEmpty(&messageQueue) && ProtocolHandler_IsSendReady()) {
        *needMoreTime = true;
        uint8_t * headPtr;
        size_t headSize;
        status = SplitBuffer_GetHead(&messageQueue, &headPtr, &headSize);
        if (Status_IsOk(status)) {
            status = ProtocolHandler_SendMessage(headPtr, headSize);
            SplitBuffer_FreeHead(&messageQueue);
        }
    }

    return returnStatus(status, eSucIoctlStatus);
}

status_t Messager_Subscribe(messageHandlerList_t * messageHandlerList)
{
    status_t status = StatusOk;

    if (!initialized)
        status = StatusNotInitialized;

    if (StatusOk == status) {
        // Seek message handler list's tail
        messageHandlerList_t * tail = &messageHandlerRoot;
        while (tail) {
            // Check if its already linked
            if (tail == messageHandlerList) {
                status = StatusAlreadyLinked;
                break;
            }
            // Check for empty next pointer
            if (!tail->next) {
                tail->next = messageHandlerList;
                messageHandlerList->next = NULL;
                break;
            } else {
                tail = tail->next;
            }
        }

        // Make sure it was linked
        if (tail->next != messageHandlerList)
            status = StatusCodePath; // there should be no way for this to happen
    }

    return returnStatus(status, eSucIoctlStatus);
}

status_t Messager_HandleMessage(uint8_t * buffer, size_t len)
{
    status_t status = StatusOk;

    if (NULL == buffer)
        status = StatusNullParameter;
    else if (len < MESSAGE_DATA_OFFSET)
        status = StatusBufferLength;

    if (Status_IsOk(status)) {
        // Determine message id, data
        uint16_t * messageIdField = (uint16_t *)&buffer[0];
        uint8_t * messageDataField;
        size_t dataLen;
        if (len > MESSAGE_DATA_OFFSET) {
            messageDataField = &buffer[MESSAGE_DATA_OFFSET];
            dataLen = len - MESSAGE_DATA_OFFSET;
        } else {
            messageDataField = NULL;
            dataLen = 0;
        }

        if (responseBitPresent(*messageIdField)) {
            status = parseResponse(*messageIdField, messageDataField, dataLen);
        } else {
            status = parseMessage(*messageIdField, messageDataField, dataLen);
        }
    }

    return returnStatus(status, eSucReadStatus);
}

status_t Messager_SendMessageAsync(sendMessageAsyncArgs_t * args)
{
    status_t status = StatusOk;

    if (args->dataLen > MESSAGE_MAX_DATA_LEN)
        status = StatusBufferLength;
    else if ((args->dataLen != 0) && !args->messageData)
        status = StatusNullParameter;

    if (Status_IsOk(status)) {
        status = responseHandlersEnqueue(args->resHandler);
        if (Status_IsError(status)) {
        	// TODO: Cleanup response handling -- this shouldn't be a queue, responses should be tagged by message Id
        	// reset queues
		    SplitBuffer_Setup(&messageQueue, sbBuffer, sizeof(sbBuffer));
        	resetResponseHandlers();
            status = StatusCodePath; // this is exceptional -- the code needs to be addressed if it happens
        }
        status = Status_Preserve(status, queueMessage(args->messageId, args->messageData, args->dataLen));
    }
    
    return returnStatus(status, eSucWriteStatus);
}

status_t Messager_ResCodeToStatus(messageResponseCode_t resCode)
{
	status_t status = StatusOk;

	switch (resCode) {
	case messageResponseSuccess:
		// stay at ok
		break;
	case messageResponseIdError:
		status = StatusMessageId;
		break;
	case messageResponseDataError:
		status = StatusMessageData;
		break;
	case messageResponseNotReceived:
		status = StatusMessageNotReceived;
		break;
	default:
		status = StatusCodePath; // we should be covering every instance
		break;
	}

	return status;
}

/// SAEC Kinetic Vision, Inc. ----------- END OF FILE

