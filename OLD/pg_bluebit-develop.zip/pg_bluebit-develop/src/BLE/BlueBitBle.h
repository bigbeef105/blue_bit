/**
  @file       Ble.h

  @copyright  (C) 2020 Kinetic Vision, Cincinnati Ohio.
               This software is property of SAEC Kinetic Vision, Inc
               and is considered confidential.

  @brief      Template software unit "H" file.

  @author     Jeffrey Hatton

  @defgroup   BLE Software unit for managing the initialize and entry point into
                  the BLE core

  Configuration History
  =====================

  Config Item    | Value
  -------------- | -----
  Config #       | NA
  Revision       | NA
  Revised, Date  | NA
  QA, Date       | NA
  Approved, Date | NA
  Released, Date | NA

  Significant Modification History (Most recent at top)
  =====================================================

  Date         | Initials | Details
  ------------ | -------- | -------
  24 JAN 2020  | JH       | Original

  Theory of Operation
  ===================
  TBD

  */

// Define to prevent recursive inclusion -------------------------------------
#ifndef __BLE_H
#define __BLE_H

#include "BleConfig.h"
#include "Status.h"

// Exported macro ------------------------------------------------------------

///
/// Zero out an object
///
#define ZERO_OBJECT(obj) memset(&obj, 0, sizeof(obj))

///
/// Simple macro for checking NRF statuses
///
#define NRF_IS_ERROR(statement) (statement != NRF_SUCCESS)

///
/// Base UUID for the device
///
#define BLE_BASE_UUID {0x35, 0x06, 0x2d, 0xc3, 0xcc, 0xed, 0x0c, 0xbc, 0x36, 0x4b, 0x98, 0x24, 0x6b, 0x22, 0x0f, 0x24}

// Exported types ------------------------------------------------------------

///
/// Enum defining the service ids
///
typedef enum {
    BleServices_DeviceInfo,
    BleServices_Count,
} BleServices_t;

typedef enum {
    BleServiceLevels_Basic,
    BleServiceLevels_Debug,
    BleServiceLevels_Count,
} BleServiceLevels_t;

// Exported constants --------------------------------------------------------

// Exported objects ----------------------------------------------------------

///
/// Collection of all Ble Service UUIDs
///
extern ble_uuid_t BleServiceUuids[BleServices_Count];

// Exported functions --------------------------------------------------------

///  @brief Initializes BLE
///  @return status.
status_t Ble_Init(void);

///  @brief Give execution time to the BLE software unit
///  @return status.
status_t Ble_Tick(bool* needMoreTime);

///
///  @brief Get the vendor UUID index for Bluebits
///
status_t Ble_GetVendorUuidType(uint8_t* type);

///
///  @brief Get the current connection handle
///
status_t Ble_GetCurrentConnection(uint16_t* connection);

///
///  @brief Get if BLE is currently reiniting
///
status_t Ble_GetReiniting(bool* isReiniting);

///
///  @brief Reinit the BLE stack. Must be called
///         if changes to the services are made
///
status_t Ble_ReinitStack(void);

///
///  @brief Set the service level. Requires a call to Ble_ReintiStaack
///         For changes to take affect.
///
status_t Ble_SetServiceLevel(BleServiceLevels_t serviceLevel);

///
///  @brief Update a characteristic's value and send a notification
///
status_t Ble_UpdateNotChar(uint8_t* data, uint16_t len, uint16_t handle);

///
///  @brief Update a characteristic's value
///
status_t Ble_UpdateChar(uint8_t* data, uint16_t len, uint16_t handle);

///
///  @brief Notifies ble software unit of data transfer completion
///
status_t Ble_NotifyTransferComplete(void);

///
///  @brief Notifies ble software unit of advertising timeout
/// 
status_t Ble_NotifyAdvertTimeout(void);

///
///  @brief Notifies ble software unit of new summary data
///
status_t Ble_NotifyNewSummaryData(void);

#endif // __TEMPLATE_H

/// SAEC Kinetic Vision, Inc. ----------- END OF FILE


