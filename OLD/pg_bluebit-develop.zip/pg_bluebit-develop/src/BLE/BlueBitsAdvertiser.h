/**
  @file       BlueBitsAdvertiser.h

  @copyright  (C) 2020 Kinetic Vision, Cincinnati Ohio.
               This software is property of SAEC Kinetic Vision, Inc
               and is considered confidential.

  @brief      BlueBitsAdvertiser software unit "H" file.

  @author     Jeffrey Hatton

  @defgroup   BLE Software unit for controlling the BLE advertisement

  Configuration History
  =====================

  Config Item    | Value
  -------------- | -----
  Config #       | NA
  Revision       | NA
  Revised, Date  | NA
  QA, Date       | NA
  Approved, Date | NA
  Released, Date | NA

  Significant Modification History (Most recent at top)
  =====================================================

  Date         | Initials | Details
  ------------ | -------- | -------
  28 JAN 2020  | JH       | Original

  Theory of Operation
  ===================
  TBD

  */

// Define to prevent recursive inclusion -------------------------------------
#ifndef __BLUEBITS_ADVERTISER_H
#define __BLUEBITS_ADVERTISER_H

#include "Status.h"

// Exported macro ------------------------------------------------------------

#define BEACON_DATA_PADDING 2

///
/// The value for have the device advertise infinitely
///
#define BLE_ADVERT_TIMEOUT_INF 0

// Exported types ------------------------------------------------------------

typedef struct {
    uint8_t Padding[BEACON_DATA_PADDING];
    uint8_t DeviceType;
    uint8_t DataLength;
    uint8_t Uuid[16];
    uint16_t MajorID;
    uint16_t MinorID;
    uint8_t MeasuredRSSI;
} BeaconInfo_t;

// Exported constants --------------------------------------------------------

// Exported objects ----------------------------------------------------------

// Exported functions --------------------------------------------------------

///  @brief Initializes the BlueBits Advertiser software unit
///  @return status.
status_t BlueBitsAdvertiser_Init(void);

///  @brief Starts advertising
///  @param timeoutSeconds Length of time to advertise, 0 if indefinite
///  @return status.
status_t BlueBitsAdvertiser_StartAdvertise(uint32_t timeoutSeconds);

///  @brief Stops advertising
///  @return status.
status_t BlueBitsAdvertiser_StopAdvertise(void);

///  @brief Sets the beacon info to advertise
///  @param info The beacon info use when advertising
///  @return status.
status_t BlueBitsAdvertiser_SetBeaconInfo(BeaconInfo_t* info);

///  @brief Sets the advertisement interval.
///  @param advertInterval The interval to use in units of 0.625 ms
///  @return status.
status_t BlueBitsAdvertiser_SetAdvertInterval(uint32_t advertInterval);

///  @brief Notify the adverstiser that a device has connected
///  @return status.
status_t BlueBitsAdvertiser_Connected(void);

///  @brief Get if the device is advertising
///  @param advertising Buffer for the result
///  @return status.
status_t BlueBitsAdvertiser_GetAdvertising(bool* advertising);

#endif // __TEMPLATE_H

/// SAEC Kinetic Vision, Inc. ----------- END OF FILE


