/**
  @file       SummaryStore.h

  @copyright  (C) 2020 Kinetic Vision, Cincinnati Ohio.
               This software is property of SAEC Kinetic Vision, Inc
               and is considered confidential.

  @brief      SummaryStore software unit for storing the summary data.

  @author     Jeffrey Hatton

  @defgroup   SummaryData

  Configuration History
  =====================

  Config Item    | Value
  -------------- | -----
  Config #       | NA
  Revision       | NA
  Revised, Date  | NA
  QA, Date       | NA
  Approved, Date | NA
  Released, Date | NA

  Significant Modification History (Most recent at top)
  =====================================================

  Date         | Initials | Details
  ------------ | -------- | -------
  11 FEB 2020  | JH       | Original

  Theory of Operation
  ===================
  TBD

  */

// Define to prevent recursive inclusion -------------------------------------
#ifndef __SUMMARY_STORE_H
#define __SUMMARY_STORE_H

#include "Status.h"

// Exported macro ------------------------------------------------------------

// Exported types ------------------------------------------------------------

// Exported constants --------------------------------------------------------

// Exported objects ----------------------------------------------------------

// Exported functions --------------------------------------------------------

///  @brief Initializes the SummaryStore software unit
///  @return status.
status_t SummaryStore_Init(void);

///
///  @brief Store a block of events into the store
///  @param data Buffer of the data to store
///  @param len The lenght of the data to store
///
status_t SummaryStore_StoreEvents(const uint8_t* data, uint16_t len);

///
///  @brief Get the max capacity of the store
///  @param capacity Buffer for the capacity
///
status_t SummaryStore_GetCapacity(uint16_t* capacity);

///
///  @brief Get the number of bytes stored
///  @param usedBytes Buffer for the number of bytes
///
status_t SummaryStore_GetUsed(uint16_t* usedBytes);

///
///  @brief Get an event-aligned size smaller than a given maximum size
///  @param maxSize Maximum size
///  @param sizeOut Buffer to write event-aligned size to
///
status_t SummaryStore_GetAlignedSize(uint16_t maxSize, uint16_t* sizeOut);

///
///  @brief Copy a block of data out of the store
///  @param offset Offset from the start of the store to copy
///  @param numBytes The number of bytes to copy
///  @param buffer Buffer to store the data
///
status_t SummaryStore_CopyData(uint16_t offset, uint16_t numBytes, uint8_t* buffer);

///
///  @brief Remove a number of bytes from the store
///  @param numBytes The number of bytes to remove
///
status_t SummaryStore_Remove(uint16_t numBytes);

///
///  @brief Flush all summary data
///
status_t SummaryStore_Flush(void);

#endif // __SUMMARY_STORE_H

/// SAEC Kinetic Vision, Inc. ----------- END OF FILE
