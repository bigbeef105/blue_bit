/**
  @file       ResBitDeviceInfoService.h

  @copyright  (C) 2020 Kinetic Vision, Cincinnati Ohio.
               This software is property of SAEC Kinetic Vision, Inc
               and is considered confidential.

  @brief      ResBitDeviceInfoService software unit "H" file.

  @author     Jeffrey Hatton

  @defgroup   ResBitDeviceInfoService Service for providing resbit device info
                                      to the user
  Configuration History
  =====================

  Config Item    | Value
  -------------- | -----
  Config #       | NA
  Revision       | NA
  Revised, Date  | NA
  QA, Date       | NA
  Approved, Date | NA
  Released, Date | NA

  Significant Modification History (Most recent at top)
  =====================================================

  Date         | Initials | Details
  ------------ | -------- | -------
  06 MAR 2020  | JH       | Original

  Theory of Operation
  ===================
  TBD

  */

// Define to prevent recursive inclusion -------------------------------------
#ifndef __RESBIT_DEVICE_INFO_SERVICE_H
#define __RESBIT_DEVICE_INFO_SERVICE_H

#include "Status.h"
#include "../Device/DeviceInfo.h"

// Exported macro ------------------------------------------------------------

// Exported types ------------------------------------------------------------

typedef enum {
    ResBitDeviceInfoCharacteristics_FirmwareVersion,
    ResBitDeviceInfoCharacteristics_HardwareVersion,
    ResBitDeviceInfoCharacteristics_ModelNumber,
    ResBitDeviceInfoCharacteristics_SerialNumber,
    ResBitDeviceInfoCharacteristics_Time,
    ResBitDeviceInfoCharacteristics_Count,
} ResBitDeviceInfoCharacteristics_t;

// Exported constants --------------------------------------------------------

#define BLE_RESBIT_DEVICEINFO_SERVICE_UUID 0xAC00

#define BLE_RESBIT_DEVICEINFO_SERVICE_FIRMWARE_VER_CHAR_UUID 0xAC01

#define BLE_RESBIT_DEVICEINFO_SERVICE_HARDWARE_VER_DATA_CHAR_UUID 0xAC02

#define BLE_RESBIT_DEVICEINFO_SERVICE_MODEL_NUM_CHAR_UUID 0xAC03

#define BLE_RESBIT_DEVICEINFO_SERVICE_SERIAL_NUM_CHAR_UUID 0xAC04

#define BLE_RESBIT_DEVICEINFO_SERVICE_TIME_CHAR_UUID 0xAC05

// Exported objects ----------------------------------------------------------

// Exported functions --------------------------------------------------------

///  @brief Initializes the ResBitDeviceInfoService software unit
///  @return status.
status_t ResBitDeviceInfoService_Init(void);

///
///  @brief Sets the resbit info
///  @param firmwareVer The firmware version
///  @param hardwareVer The hardware version
///  @param serialNumber The serial number
///  @param modelNumber The model number
///
status_t ResBitDeviceInfoService_SetResbitInfo(version_t* firmwareVer,
                                               version_t* hardwareVer,
                                               serialNum_t* serialNumber,
                                               uint64_t modelNumber);

#endif // __RESBIT_DEVICE_INFO_SERVICE_H

/// SAEC Kinetic Vision, Inc. ----------- END OF FILE
