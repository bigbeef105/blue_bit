/**
  @file       ResBitDeviceInfoService.c

  @copyright  (C) 2020 Kinetic Vision, Cincinnati Ohio.
               This software is property of SAEC Kinetic Vision, Inc
               and is considered confidential.

  @brief      ResBitDeviceInfoService software unit "C" file.

  @author     Jeffrey Hatton

  @ingroup    ResBitDeviceInfoService

  Configuration History
  =====================

  Config Item    | Value
  -------------- | -----
  Config #       | NA
  Revision       | NA
  Revised, Date  | NA
  QA, Date       | NA
  Approved, Date | NA
  Released, Date | NA

  Significant Modification History (Most recent at top)
  =====================================================

  Date         | Initials | Details
  ------------ | -------- | -------
  06 MAR 2020  | JH       | Original

  Theory of Operation
  ===================
  TBD

*/

// Includes ------------------------------------------------------------------

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

#include "BlueBitBle.h"
#include "../SwUnitControlSu/SwUnitControl.h"
#include "ResBitDeviceInfoService.h"
#include "../ConsoleSu/Console.h"
#include "../MessagerSu/Messager.h"
#include "../SysTimeSu/SysTime.h"

// Private function prototypes -----------------------------------------------

// Private macros ------------------------------------------------------------

#define returnStatus(__status__,__source__) SwUnitControl_WriteStatus(eSucBleResbitInfoService,__source__,__status__,__LINE__);

#define GET_VALUE_HANDLE(charIndex) (_InfoService.CharHandles[charIndex].value_handle)

// Private constants ---------------------------------------------------------

// Private types -------------------------------------------------------------

typedef struct {
    ble_gatts_char_handles_t CharHandles[ResBitDeviceInfoCharacteristics_Count];
    uint16_t    service_handle;
} ResBitInfoService_t;

// Private constants ---------------------------------------------------------

///
/// Size of the data in the Firmware Version Characteristic
///
#define FIRMWARE_SIZE sizeof(_FirmwareVer)

///
/// Size of the data in the Hardware Version Characteristic
///
#define HARDWARE_SIZE sizeof(_HardwareVer)

///
/// Size of the data in the Model Number Characteristic
///
#define MODEL_NUM_SIZE sizeof(_ModelNum)

///
/// The size of the time characterisitc
///
#define TIME_SIZE sizeof(_Time)

///
/// The max number of retries for the set time message
///
#define MAX_RETRIES 3

// Private variables ---------------------------------------------------------

///
/// If the software unit has been initialized
///
static bool _IsInitialized = false;

static ResBitInfoService_t _InfoService;
static uint32_t _FirmwareVer;
static uint32_t _HardwareVer;
static uint64_t _ModelNum;
static uint8_t _SerialNum[SERIAL_NUM_SIZE];
static uint32_t _Time;
static uint8_t retryCount = 0;

// Private function bodies ---------------------------------------------------

static status_t SetupFirmwareVerChar(void) {
    status_t ret = StatusOk;
    uint32_t nrfRet;
    ble_add_char_params_t  charParams;

    ZERO_OBJECT(charParams);

    ret = Ble_GetVendorUuidType(&charParams.uuid_type);
    if (Status_IsError(ret)) return ret;

    charParams.uuid              = BLE_RESBIT_DEVICEINFO_SERVICE_FIRMWARE_VER_CHAR_UUID;
    charParams.max_len           = FIRMWARE_SIZE;
    charParams.init_len          = FIRMWARE_SIZE;
    charParams.p_init_value      = (uint8_t*)&_FirmwareVer;

    charParams.char_props.read   = 1;
    charParams.cccd_write_access = SEC_OPEN;
    charParams.read_access       = SEC_OPEN;

    nrfRet = characteristic_add(_InfoService.service_handle,
                                  &charParams,
                                  _InfoService.CharHandles + ResBitDeviceInfoCharacteristics_FirmwareVersion);
    if (NRF_IS_ERROR(nrfRet)) {
        Console_PrintLine("NRF Error when setting up Firmware Ver Char: 0x%0.8x", nrfRet);
        ret = StatusNrfError;
    }

    return ret;
}

static status_t SetupHardwareChar(void) {
    status_t ret = StatusOk;
    uint32_t nrfRet;
    ble_add_char_params_t  charParams;

    ZERO_OBJECT(charParams);

    ret = Ble_GetVendorUuidType(&charParams.uuid_type);
    if (Status_IsError(ret)) return ret;

    charParams.uuid              = BLE_RESBIT_DEVICEINFO_SERVICE_HARDWARE_VER_DATA_CHAR_UUID;
    charParams.max_len           = HARDWARE_SIZE;
    charParams.init_len          = HARDWARE_SIZE;
    charParams.p_init_value      = (uint8_t*)&_HardwareVer;

    charParams.char_props.read   = 1;
    charParams.cccd_write_access = SEC_OPEN;
    charParams.read_access       = SEC_OPEN;

    nrfRet = characteristic_add(_InfoService.service_handle,
                                  &charParams,
                                  _InfoService.CharHandles + ResBitDeviceInfoCharacteristics_HardwareVersion);
    if (NRF_IS_ERROR(nrfRet)) {
        Console_PrintLine("NRF Error when setting up Hardware Ver Char: 0x%0.8x", nrfRet);
        ret = StatusNrfError;
    }

    return ret;
}

static status_t SetupModelNumChar(void) {
    status_t ret = StatusOk;
    uint32_t nrfRet;
    ble_add_char_params_t  charParams;

    ZERO_OBJECT(charParams);

    ret = Ble_GetVendorUuidType(&charParams.uuid_type);
    if (Status_IsError(ret)) return ret;

    charParams.uuid              = BLE_RESBIT_DEVICEINFO_SERVICE_MODEL_NUM_CHAR_UUID;
    charParams.max_len           = MODEL_NUM_SIZE;
    charParams.init_len          = MODEL_NUM_SIZE;
    charParams.p_init_value      = (uint8_t*)&_ModelNum;

    charParams.char_props.read   = 1;
    charParams.cccd_write_access = SEC_OPEN;
    charParams.read_access       = SEC_OPEN;

    nrfRet = characteristic_add(_InfoService.service_handle,
                                  &charParams,
                                  _InfoService.CharHandles + ResBitDeviceInfoCharacteristics_ModelNumber);
    if (NRF_IS_ERROR(nrfRet)) {
        Console_PrintLine("NRF Error when setting up Model Number Char: 0x%0.8x", nrfRet);
        ret = StatusNrfError;
    }

    return ret;
}

static status_t SetupSerialNumberChar(void) {
    status_t ret = StatusOk;
    uint32_t nrfRet;
    ble_add_char_params_t  charParams;

    ZERO_OBJECT(charParams);

    ret = Ble_GetVendorUuidType(&charParams.uuid_type);
    if (Status_IsError(ret)) return ret;

    charParams.uuid              = BLE_RESBIT_DEVICEINFO_SERVICE_SERIAL_NUM_CHAR_UUID;
    charParams.max_len           = SERIAL_NUM_SIZE;
    charParams.init_len          = SERIAL_NUM_SIZE;
    charParams.p_init_value      = _SerialNum;

    charParams.char_props.read   = 1;
    charParams.cccd_write_access = SEC_OPEN;
    charParams.read_access       = SEC_OPEN;
    charParams.write_access = SEC_OPEN;

    nrfRet = characteristic_add(_InfoService.service_handle,
                                  &charParams,
                                  _InfoService.CharHandles + ResBitDeviceInfoCharacteristics_SerialNumber);
    if (NRF_IS_ERROR(nrfRet)) {
        Console_PrintLine("NRF Error when setting up Serial Num Char: 0x%0.8x", nrfRet);
        ret = StatusNrfError;
    }

    return ret;
}

static status_t SetupTimeCharacteristics(void) {
    status_t ret = StatusOk;
    uint32_t nrfRet;
    ble_add_char_params_t  charParams;

    ZERO_OBJECT(charParams);

    ret = Ble_GetVendorUuidType(&charParams.uuid_type);
    if (Status_IsError(ret)) return ret;

    charParams.uuid              = BLE_RESBIT_DEVICEINFO_SERVICE_TIME_CHAR_UUID;
    charParams.max_len           = TIME_SIZE;
    charParams.init_len          = TIME_SIZE;
    charParams.p_init_value      = (uint8_t*)&_Time;

    charParams.char_props.write  = 1;
    charParams.cccd_write_access = SEC_OPEN;
    charParams.write_access = SEC_OPEN;

    nrfRet = characteristic_add(_InfoService.service_handle,
                                  &charParams,
                                  _InfoService.CharHandles + ResBitDeviceInfoCharacteristics_Time);
    if (NRF_IS_ERROR(nrfRet)) {
        Console_PrintLine("NRF Error when setting up Time Char: 0x%0.8x", nrfRet);
        ret = StatusNrfError;
    }

    return ret;
}

static status_t SetupNrfCharacteristics(void) {
    status_t ret = StatusOk;

    ret = SetupFirmwareVerChar();
    if (Status_IsError(ret)) return ret;

    ret = SetupHardwareChar();
    if (Status_IsError(ret)) return ret;

    ret = SetupModelNumChar();
    if (Status_IsError(ret)) return ret;

    ret = SetupSerialNumberChar();
    if (Status_IsError(ret)) return ret;

    ret = SetupTimeCharacteristics();
    if (Status_IsError(ret)) return ret;

    return ret;
}

static status_t SetupNrfService(void) {
    status_t ret = StatusOk;
    uint32_t nrfRet;
    ble_uuid_t serviceUuid;

    // Build the service UUID
    serviceUuid.uuid = BLE_RESBIT_DEVICEINFO_SERVICE_UUID;
    ret = Ble_GetVendorUuidType(&serviceUuid.type);
    if (Status_IsError(ret)) return ret;

    nrfRet = sd_ble_gatts_service_add(BLE_GATTS_SRVC_TYPE_PRIMARY,
                                      &serviceUuid,
                                      &_InfoService.service_handle);
    if (NRF_IS_ERROR(nrfRet)) {
        Console_PrintLine("NRF Error when adding Resbit Info Service: 0x%0.8x", nrfRet);
        ret = StatusNrfError;
    }

    if (Status_IsOk(ret)) {
        ret = SetupNrfCharacteristics();
    }

    return ret;
}

static status_t SetTimeResponseHandler(responseHandlerArgs_t * args) {
    status_t ret = StatusOk;

    if (args->resCode != messageResponseSuccess) {
        if (retryCount++ < MAX_RETRIES) {
            sendMessageAsyncArgs_t args = {
                .messageId = MESSAGE_IDS_SETRESBITTIME,
                .messageData = (uint8_t*)&_Time,
                .dataLen = 4,
                .resHandler = SetTimeResponseHandler,
            };

            ret = Messager_SendMessageAsync(&args);
        } else {
            Console_Printf("Set Time message Failed: 0x%0.8x", args->resCode);
        }
    } else {
        retryCount = 0;
    }

    return ret;
}

static void BleWriteHandler(ble_evt_t const * p_ble_evt)
{
    ble_gatts_evt_write_t const * p_evt_write = &p_ble_evt->evt.gatts_evt.params.write;

    status_t ret = StatusOk;

    if (p_evt_write->handle == GET_VALUE_HANDLE(ResBitDeviceInfoCharacteristics_Time)) {
        if (p_evt_write->len == TIME_SIZE) {
            memcpy(&_Time, p_evt_write->data, TIME_SIZE);

            retryCount = 0;
            sendMessageAsyncArgs_t args = {
                .messageId = MESSAGE_IDS_SETRESBITTIME,
                .messageData = (uint8_t*)&_Time,
                .dataLen = 4,
                .resHandler = SetTimeResponseHandler,
            };

            ret = Messager_SendMessageAsync(&args);
        }
    }
}

void RBDIS_BleEventHandler(ble_evt_t const * p_ble_evt, void * p_context) {
    switch (p_ble_evt->header.evt_id)
    {
    case BLE_GATTS_EVT_WRITE:
        BleWriteHandler(p_ble_evt);
        break;
    default:
        // no implementation needed.
    break;
    }
}

// Public functions bodies ---------------------------------------------------

status_t ResBitDeviceInfoService_Init(void) {
    status_t ret = StatusOk;

    ret = SetupNrfService();
    if (Status_IsError(ret)) return returnStatus(ret, eSucInitStatus);

    NRF_SDH_BLE_OBSERVER(ResBitSummaryService_obs,
                 BLE_LBS_BLE_OBSERVER_PRIO,
                 RBDIS_BleEventHandler, NULL);

	_IsInitialized = true;
    return  returnStatus(ret, eSucInitStatus);
}

status_t ResBitDeviceInfoService_SetResbitInfo(version_t* firmwareVer,
                                               version_t* hardwareVer,
                                               serialNum_t* serialNumber,
                                               uint64_t modelNumber)
{
    if (firmwareVer == NULL || hardwareVer == NULL || serialNumber == NULL) {
        return returnStatus(StatusNullParameter, eSucWriteStatus);
    }

    status_t ret = StatusOk;

    _FirmwareVer = firmwareVer->whole;
    _HardwareVer = hardwareVer->whole;
    _ModelNum = modelNumber;

    memcpy(_SerialNum, serialNumber, SERIAL_NUM_SIZE);

    if (_IsInitialized) {
        ret = Ble_UpdateChar((uint8_t*)&_FirmwareVer, FIRMWARE_SIZE, GET_VALUE_HANDLE(ResBitDeviceInfoCharacteristics_FirmwareVersion));
        if (Status_IsError(ret)) return ret;
        ret = Ble_UpdateChar((uint8_t*)&_HardwareVer, HARDWARE_SIZE, GET_VALUE_HANDLE(ResBitDeviceInfoCharacteristics_HardwareVersion));
        if (Status_IsError(ret)) return ret;
        ret = Ble_UpdateChar((uint8_t*)&_ModelNum, MODEL_NUM_SIZE, GET_VALUE_HANDLE(ResBitDeviceInfoCharacteristics_ModelNumber));
        if (Status_IsError(ret)) return ret;
        ret = Ble_UpdateChar(_SerialNum, SERIAL_NUM_SIZE, GET_VALUE_HANDLE(ResBitDeviceInfoCharacteristics_SerialNumber));
        if (Status_IsError(ret)) return ret;
        ret = Ble_UpdateChar((uint8_t*)&_Time, sizeof(_Time), GET_VALUE_HANDLE(ResBitDeviceInfoCharacteristics_Time));
        if (Status_IsError(ret)) return ret;
    }

    return returnStatus(ret, eSucWriteStatus);
}

/// SAEC Kinetic Vision, Inc. ----------- END OF FILE
