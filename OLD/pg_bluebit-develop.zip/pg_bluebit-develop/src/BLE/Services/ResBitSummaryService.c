/**
  @file       ResBitSummaryService.c

  @copyright  (C) 2020 Kinetic Vision, Cincinnati Ohio.
               This software is property of SAEC Kinetic Vision, Inc
               and is considered confidential.

  @brief      ResBitSummaryService software unit "C" file.

  @author     Jeffrey Hatton

  @ingroup    BLE

  Configuration History
  =====================

  Config Item    | Value
  -------------- | -----
  Config #       | NA
  Revision       | NA
  Revised, Date  | NA
  QA, Date       | NA
  Approved, Date | NA
  Released, Date | NA

  Significant Modification History (Most recent at top)
  =====================================================

  Date         | Initials | Details
  ------------ | -------- | -------
  03 FEB 2020  | JH       | Original

  Theory of Operation
  ===================
  TBD

*/

// Includes ------------------------------------------------------------------

#include <string.h>
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <stdbool.h>

#include "../SwUnitControlSu/SwUnitControl.h"
#include "ResBitSummaryService.h"
#include "BlueBitBle.h"
#include "SummaryProto.h"
#include "../ConsoleSu/Console.h"
#include "BlueBitsAdvertiser.h"

// Private function prototypes -----------------------------------------------

//static status_t cliSetDataReady(uint16_t argc, uint8_t **argv);

// Private macros ------------------------------------------------------------
#define returnStatus(__status__,__source__) SwUnitControl_WriteStatus(eSucBleSummaryService,__source__,__status__,__LINE__);

#define GET_VALUE_HANDLE(charIndex) (_SumaryService.CharHandles[charIndex].value_handle)

// Private constants ---------------------------------------------------------

///
/// Length of the data characteristic
///
#define DATA_LEN SUMMARY_PROTO_PACKET_TOTAL_SIZE

///
/// Length of the response characteristic
///
#define RESPONSE_LEN 20

// Private types -------------------------------------------------------------

typedef struct {
    ble_gatts_char_handles_t CharHandles[ResBitSummaryCharacteristics_Count];
    uint16_t    service_handle;
} ResBitSummaryService_t;

// Private constants ---------------------------------------------------------

// Private variables ---------------------------------------------------------

///
/// If the software unit is initialized
///
static bool _IsInitialized = false;

static ResBitSummaryService_t _SumaryService;

static uint8_t _DataBuffer[DATA_LEN];

static uint8_t _AckNck;

static uint8_t _TransferSummaryData;

static bool _SendNotTransferSummaryData = false;

static uint8_t _Transfering;

static bool _SendNotTransfering = false;

static uint8_t _Response[RESPONSE_LEN];

static uint8_t _LastResponseLen;

static uint8_t _EnableDebug;

static uint8_t _Registered;

static uint8_t _ResBitSerial[SERIAL_NUM_SIZE];

static uint8_t _Error;

static bool _SendNotError = false;

// Private function bodies ---------------------------------------------------

static status_t SetupDataChar(void) {
    status_t ret = StatusOk;
    uint32_t nrfRet;
    ble_add_char_params_t  charParams;

    ZERO_OBJECT(charParams);

    ret = Ble_GetVendorUuidType(&charParams.uuid_type);
    if (Status_IsError(ret)) return ret;

    charParams.uuid              = BLE_SUMMARY_SERVICE_DATA_CHAR_UUID;
    charParams.max_len           = DATA_LEN;
    charParams.init_len          = DATA_LEN;
    charParams.p_init_value      = _DataBuffer;

    charParams.char_props.notify = 1;
    charParams.char_props.read   = 1;
    charParams.cccd_write_access = SEC_OPEN;
    charParams.read_access       = SEC_OPEN;

    nrfRet = characteristic_add(_SumaryService.service_handle,
                                  &charParams,
                                  _SumaryService.CharHandles + ResBitSummaryCharacteristics_Data);
    if (NRF_IS_ERROR(nrfRet)) {
        Console_PrintLine("NRF Error when setting up Data Char: 0x%0.8x", nrfRet);
        ret = StatusNrfError;
    }

    return ret;
}

static status_t SetupAckNckChar(void) {
    status_t ret = StatusOk;
    uint32_t nrfRet;
    ble_add_char_params_t  charParams;

    ZERO_OBJECT(charParams);

    charParams.uuid              = BLE_SUMMARY_SERVICE_ACK_NCK_CHAR_UUID;
    charParams.max_len           = sizeof(_AckNck);
    charParams.init_len          = sizeof(_AckNck);
    charParams.p_init_value      = &_AckNck;

    ret = Ble_GetVendorUuidType(&charParams.uuid_type);
    if (Status_IsError(ret)) return ret;

    charParams.char_props.write = 1;
    charParams.cccd_write_access = SEC_OPEN;
    charParams.write_access = SEC_OPEN;

    nrfRet = characteristic_add(_SumaryService.service_handle,
                                  &charParams,
                                  _SumaryService.CharHandles + ResBitSummaryCharacteristics_AckNck);
    if (NRF_IS_ERROR(nrfRet)) {
        Console_PrintLine("NRF Error when setting up Ack Nack Char: 0x%0.8x", nrfRet);
        ret = StatusNrfError;
    }

    return ret;
}

static status_t SetupTransferSummaryDataChar(void) {
    status_t ret = StatusOk;
    uint32_t nrfRet;
    ble_add_char_params_t  charParams;

    ZERO_OBJECT(charParams);

    charParams.uuid              = BLE_SUMMARY_SERVICE_TRANSFER_SUMMARY_DATA_CHAR_UUID;
    charParams.max_len           = sizeof(_TransferSummaryData);
    charParams.init_len          = sizeof(_TransferSummaryData);
    charParams.p_init_value      = &_TransferSummaryData;

    ret = Ble_GetVendorUuidType(&charParams.uuid_type);
    if (Status_IsError(ret)) return ret;

    charParams.char_props.notify = 1;
    charParams.char_props.read   = 1;
    charParams.char_props.write = 1;
    charParams.cccd_write_access = SEC_OPEN;
    charParams.read_access       = SEC_OPEN;
    charParams.write_access = SEC_OPEN;

    nrfRet = characteristic_add(_SumaryService.service_handle,
                                  &charParams,
                                  _SumaryService.CharHandles + ResBitSummaryCharacteristics_TransferSummaryData);
    if (NRF_IS_ERROR(nrfRet)) {
        Console_PrintLine("NRF Error when setting up Trans Sum Char: 0x%0.8x", nrfRet);
        ret = StatusNrfError;
    }

    return ret;
}

static status_t SetupTransferingChar(void) {
    status_t ret = StatusOk;
    uint32_t nrfRet;
    ble_add_char_params_t  charParams;

    ZERO_OBJECT(charParams);

    charParams.uuid              = BLE_SUMMARY_SERVICE_TRANSFERING_CHAR_UUID;
    charParams.max_len           = sizeof(_Transfering);
    charParams.init_len          = sizeof(_Transfering);
    charParams.p_init_value      = &_Transfering;

    ret = Ble_GetVendorUuidType(&charParams.uuid_type);
    if (Status_IsError(ret)) return ret;

    charParams.char_props.notify = 1;
    charParams.char_props.read   = 1;
    charParams.cccd_write_access = SEC_OPEN;
    charParams.read_access       = SEC_OPEN;

    nrfRet = characteristic_add(_SumaryService.service_handle,
                                  &charParams,
                                  _SumaryService.CharHandles + ResBitSummaryCharacteristics_Transfering);
    if (NRF_IS_ERROR(nrfRet)) {
        Console_PrintLine("NRF Error when setting up Transfer Char: 0x%0.8x", nrfRet);
        ret = StatusNrfError;
    }

    return ret;
}

static status_t SetupResponseChar(void) {
    status_t ret = StatusOk;
    uint32_t nrfRet;
    ble_add_char_params_t  charParams;

    ZERO_OBJECT(charParams);

    charParams.uuid              = BLE_SUMMARY_SERVICE_RESPONSE_CHAR_UUID;
    charParams.max_len           = RESPONSE_LEN;
    charParams.init_len          = RESPONSE_LEN;
    charParams.p_init_value      = _Response;

    ret = Ble_GetVendorUuidType(&charParams.uuid_type);
    if (Status_IsError(ret)) return ret;

    charParams.char_props.write   = 1;
    charParams.cccd_write_access = SEC_OPEN;
    charParams.read_access       = SEC_OPEN;
    charParams.write_access = SEC_OPEN;

    nrfRet = characteristic_add(_SumaryService.service_handle,
                                  &charParams,
                                  _SumaryService.CharHandles + ResBitSummaryCharacteristics_Response);
    if (NRF_IS_ERROR(nrfRet)) {
        Console_PrintLine("NRF Error when setting up Response Char: 0x%0.8x", nrfRet);
        ret = StatusNrfError;
    }

    return ret;
}

static status_t SetupEnableDebugChar(void) {
    status_t ret = StatusOk;
    uint32_t nrfRet;
    ble_add_char_params_t  charParams;

    ZERO_OBJECT(charParams);

    ret = Ble_GetVendorUuidType(&charParams.uuid_type);
    if (Status_IsError(ret)) return ret;

    charParams.uuid              = BLE_SUMMARY_SERVICE_ENABLE_DEBUG_UUID;
    charParams.max_len           = sizeof(_EnableDebug);
    charParams.init_len          = sizeof(_EnableDebug);
    charParams.p_init_value      = &_EnableDebug;

    charParams.char_props.write = 1;
    charParams.char_props.read   = 1;
    charParams.cccd_write_access = SEC_OPEN;
    charParams.read_access       = SEC_OPEN;
    charParams.write_access = SEC_OPEN;

    nrfRet = characteristic_add(_SumaryService.service_handle,
                                  &charParams,
                                  _SumaryService.CharHandles + ResBitSummaryCharacteristics_EnableDebug);
    if (NRF_IS_ERROR(nrfRet)) {
        Console_PrintLine("NRF Error when setting up Enable Debug Char: 0x%0.8x", nrfRet);
        ret = StatusNrfError;
    }

    return ret;
}

static status_t SetupSerialChar(void) {
    status_t ret = StatusOk;
    uint32_t nrfRet;
    ble_add_char_params_t  charParams;

    ZERO_OBJECT(charParams);

    ret = Ble_GetVendorUuidType(&charParams.uuid_type);
    if (Status_IsError(ret)) return ret;

    charParams.uuid              = BLE_SUMMARY_SERVICE_RESBIT_SERIAL_UUID;
    charParams.max_len           = SERIAL_NUM_SIZE;
    charParams.init_len          = SERIAL_NUM_SIZE;
    charParams.p_init_value      = _ResBitSerial;

    charParams.char_props.read   = 1;
    charParams.char_props.write   = 1;
    charParams.cccd_write_access = SEC_OPEN;
    charParams.read_access       = SEC_OPEN;
    charParams.write_access = SEC_OPEN;

    nrfRet = characteristic_add(_SumaryService.service_handle,
                                  &charParams,
                                  _SumaryService.CharHandles + ResBitSummaryCharacteristics_SerialNumber);
    if (NRF_IS_ERROR(nrfRet)) {
        Console_PrintLine("NRF Error when setting up Serial Num Char: 0x%0.8x", nrfRet);
        ret = StatusNrfError;
    }

    return ret;
}

static status_t SetupTransferError(void) {
    status_t ret = StatusOk;
    uint32_t nrfRet;
    ble_add_char_params_t  charParams;

    ZERO_OBJECT(charParams);

    ret = Ble_GetVendorUuidType(&charParams.uuid_type);
    if (Status_IsError(ret)) return ret;

    uint8_t initialValue = 0;

    charParams.uuid              = BLE_SUMMARY_SERVICE_TRANSFER_ERROR_UUID;
    charParams.max_len           = 1;
    charParams.init_len          = 1;
    charParams.p_init_value      = &initialValue;

    charParams.char_props.read   = 1;
    charParams.char_props.notify = 1;
    charParams.cccd_write_access = SEC_OPEN;
    charParams.read_access       = SEC_OPEN;

    nrfRet = characteristic_add(_SumaryService.service_handle,
                                  &charParams,
                                  _SumaryService.CharHandles + ResBitSummaryCharacteristics_TransferError);
    if (NRF_IS_ERROR(nrfRet)) {
        Console_PrintLine("NRF Error when setting up Trans Error Char: 0x%0.8x", nrfRet);
        ret = StatusNrfError;
    }

    return ret;
}

static status_t SetupNrfCharacteristics(void) {
    status_t ret = StatusOk;

    ret = SetupDataChar();
    if (Status_IsError(ret)) return ret;

    ret = SetupTransferSummaryDataChar();
    if (Status_IsError(ret)) return ret;

    ret = SetupTransferingChar();
    if (Status_IsError(ret)) return ret;

    ret = SetupAckNckChar();
    if (Status_IsError(ret)) return ret;

    ret = SetupResponseChar();
    if (Status_IsError(ret)) return ret;

    ret = SetupEnableDebugChar();
    if (Status_IsError(ret)) return ret;

    ret = SetupSerialChar();
    if (Status_IsError(ret)) return ret;

    ret = SetupTransferError();

    return ret;
}

static status_t SetupNrfService(void) {
    status_t ret = StatusOk;
    uint32_t nrfRet;
    ble_uuid_t serviceUuid;

    // Build the service UUID
    serviceUuid.uuid = BLE_SUMMARY_SERVICE_UUID;
    ret = Ble_GetVendorUuidType(&serviceUuid.type);
    if (Status_IsError(ret)) return ret;

    nrfRet = sd_ble_gatts_service_add(BLE_GATTS_SRVC_TYPE_PRIMARY,
                                      &serviceUuid,
                                      &_SumaryService.service_handle);
    if (NRF_IS_ERROR(nrfRet)) {
        Console_PrintLine("NRF Error when adding Summary Service: 0x%0.8x", nrfRet);
        ret = StatusNrfError;
    }

    if (Status_IsOk(ret)) {
        ret = SetupNrfCharacteristics();
    }

    return ret;
}

static status_t BleWriteHandler(ble_evt_t const * p_ble_evt)
{
    ble_gatts_evt_write_t const * p_evt_write = &p_ble_evt->evt.gatts_evt.params.write;

    status_t ret = StatusOk;

    if (p_evt_write->handle == GET_VALUE_HANDLE(ResBitSummaryCharacteristics_EnableDebug)) {
        if (p_evt_write->len == 1) {
            ret = Ble_SetServiceLevel(p_evt_write->data[0]);
            ret = Ble_ReinitStack();
            //TODO error checks
        }
    } else if (p_evt_write->handle == GET_VALUE_HANDLE(ResBitSummaryCharacteristics_TransferSummaryData)) {
        if (p_evt_write->len == 1) {
            if (p_evt_write->data[0]) {
                ret = SummaryProto_Start();
            } else {
                ret = SummaryProto_Stop(SummaryProtoStopReasons_CanceledByClient);
            }
            //TODO error checks
        }
    } else if (p_evt_write->handle == GET_VALUE_HANDLE(ResBitSummaryCharacteristics_AckNck)) {
        if (p_evt_write->len == 1) {
            ret = SummaryProto_NotifyResponse(p_evt_write->data[0], _Response, _LastResponseLen);
            //TODO error checks
        }
    } else if (p_evt_write->handle == GET_VALUE_HANDLE(ResBitSummaryCharacteristics_Response)) {
        if (p_evt_write->len <= RESPONSE_LEN) {
            memcpy(_Response, p_evt_write->data, RESPONSE_LEN);
            _LastResponseLen = p_evt_write->len;
            //TODO error checks
        }
    } else if (p_evt_write->handle == GET_VALUE_HANDLE(ResBitSummaryCharacteristics_SerialNumber)) {
            uint8_t serialNumber[4 * 3];
            memcpy(serialNumber, p_evt_write->data, p_evt_write->len);

            BeaconInfo_t beacon;

            uint8_t temp[16] = BLE_BEACON_DEFAULT_UUID;
            memcpy(beacon.Uuid, temp, sizeof(beacon.Uuid));

            beacon.MajorID = *(uint16_t*)(serialNumber + 2);
            beacon.MinorID = *(uint16_t*)(serialNumber);

            ret = BlueBitsAdvertiser_SetBeaconInfo(&beacon);

            //TODO error checks
    }

    return ret;
}

static status_t SendNots(void) {
    status_t ret = StatusOk;
    if (_SendNotTransferSummaryData) {
        ret = Ble_UpdateNotChar(&_TransferSummaryData,
                                         sizeof(_TransferSummaryData),
                                         GET_VALUE_HANDLE(ResBitSummaryCharacteristics_TransferSummaryData));
        if (Status_IsError(ret)) {
            if (ret == StatusNrfNotQueueFull) {
                return ret;
            } else {
                Console_Printf("Error while sending transfer summary data not: %x\r\n", ret);
            }
        } else {
            _SendNotTransferSummaryData = false;
        }
    }

    if (_SendNotTransfering) {
        Console_Printf("Sending Transfer not \r\n");
        status_t ret = Ble_UpdateNotChar(&_Transfering,
                                         sizeof(_Transfering),
                                         GET_VALUE_HANDLE(ResBitSummaryCharacteristics_Transfering));
        if (Status_IsError(ret)) {
            if (ret == StatusNrfNotQueueFull) {
                return ret;
            } else {
                Console_Printf("Error while sending transfering not: %x\r\n", ret);
            }
        } else {
            _SendNotTransfering = false;
        }
    }

    if (_SendNotError) {
        status_t ret = Ble_UpdateNotChar(&_Error,
                                         sizeof(_Error),
                                         GET_VALUE_HANDLE(ResBitSummaryCharacteristics_TransferError));
        if (Status_IsError(ret)) {
            if (ret == StatusNrfNotQueueFull) {
                return ret;
            } else {
                Console_Printf("Error while sending transfer error not: %x\r\n", ret);
            }
        } else {
            _SendNotError = false;
        }
    }

    return ret;
}

void RBSS_BleEventHandler(ble_evt_t const * p_ble_evt, void * p_context) {
    switch (p_ble_evt->header.evt_id)
    {
        case BLE_GATTS_EVT_WRITE:
            BleWriteHandler(p_ble_evt);
            break;
        case BLE_GATTS_EVT_HVN_TX_COMPLETE:
            SendNots();
            break;
        default:
            // No implementation needed.
            break;
    }
}

// Public functions bodies ---------------------------------------------------

status_t ResBitSummaryService_Init(void) {
    status_t ret = StatusOk;

    ZERO_OBJECT(_DataBuffer);

    ret = SetupNrfService();
    if (Status_IsError(ret)) return returnStatus(ret, eSucInitStatus);

    NRF_SDH_BLE_OBSERVER(ResBitSummaryService_obs,
                     BLE_LBS_BLE_OBSERVER_PRIO,
                     RBSS_BleEventHandler, NULL);

    if (Status_IsOk(ret)) {
        ret = SummaryProto_Init();

        //todo better check return
        ret = SummaryStore_Init();
    }

    if (Status_IsOk(ret)) {
        _IsInitialized = true;
    }

    return returnStatus(ret, eSucInitStatus);
}

status_t ResBitSummaryService_UpdateStartSend(uint8_t value) {
    status_t ret = Ble_UpdateNotChar(&value,
                                  sizeof(value),
                                  GET_VALUE_HANDLE(ResBitSummaryCharacteristics_TransferSummaryData));

    return returnStatus(ret, eSucWriteStatus);
}

status_t ResBitSummaryService_UpdateData(uint8_t* values, uint8_t dataLen) {
    if (dataLen > DATA_LEN)  {
        return returnStatus(StatusBufferUndersized, eSucWriteStatus);
    } else if (values == NULL) {
        return returnStatus(StatusNullParameter, eSucWriteStatus);
    }

    status_t ret = Ble_UpdateNotChar(values,
                                  dataLen,
                                  GET_VALUE_HANDLE(ResBitSummaryCharacteristics_Data));

    return returnStatus(ret, eSucWriteStatus);
}

status_t ResBitSummaryService_UpdateSerialNum(serialNum_t *serialNum) {
    if (serialNum == NULL) {
        return returnStatus(StatusNullParameter, eSucWriteStatus);
    }

    memcpy(_ResBitSerial, serialNum, SERIAL_NUM_SIZE);
    status_t ret = Ble_UpdateChar(_ResBitSerial,
                                  SERIAL_NUM_SIZE,
                                  GET_VALUE_HANDLE(ResBitSummaryCharacteristics_SerialNumber));

    return returnStatus(ret, eSucWriteStatus);
}

status_t ResBitSummaryService_ClientDisconnected(void) {
    status_t ret = SummaryProto_Stop(SummaryProtoStopReasons_ClientDisconnected);

    return returnStatus(ret, eSucWriteStatus);
}

status_t ResBitSummaryService_UpdateTransfering(uint8_t value) {
    status_t ret = Ble_UpdateNotChar(&value,
                              sizeof(value),
                              GET_VALUE_HANDLE(ResBitSummaryCharacteristics_Transfering));

    if (ret == StatusNrfNotQueueFull) {
        _SendNotTransfering = true;
        _Transfering = value;
        ret = StatusOk;
    }

    return returnStatus(ret, eSucWriteStatus);
}


status_t ResBitSummaryService_UpdateTransferSummary(uint8_t value) {
    status_t ret = Ble_UpdateNotChar(&value,
                                  sizeof(value),
                                  GET_VALUE_HANDLE(ResBitSummaryCharacteristics_TransferSummaryData));

    if (ret == StatusNrfNotQueueFull) {
        _SendNotTransferSummaryData = true;
        _TransferSummaryData = value;
        ret = StatusOk;
    }

    return returnStatus(ret, eSucWriteStatus);
}

status_t ResBitSummaryService_UpdateError(uint8_t value) {
    status_t ret = Ble_UpdateNotChar(&value,
                                  sizeof(value),
                                  GET_VALUE_HANDLE(ResBitSummaryCharacteristics_TransferError));

    if (ret == StatusNrfNotQueueFull) {
        _SendNotError = true;
        _Error = value;
        ret = StatusOk;
    }

    return returnStatus(ret, eSucWriteStatus);
}

/// SAEC Kinetic Vision, Inc. ----------- END OF FILE
