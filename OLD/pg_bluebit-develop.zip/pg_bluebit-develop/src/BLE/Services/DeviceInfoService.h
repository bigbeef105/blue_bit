/**
  @file       DeviceInfoService.h

  @copyright  (C) 2020 Kinetic Vision, Cincinnati Ohio.
               This software is property of SAEC Kinetic Vision, Inc
               and is considered confidential.

  @brief      DeviceInfoService software unit "H" file.

  @author     Jeffrey Hatton

  @defgroup   BLE Software unit for defining and interfacing with the Device Info
                  Service.

  Configuration History
  =====================

  Config Item    | Value
  -------------- | -----
  Config #       | NA
  Revision       | NA
  Revised, Date  | NA
  QA, Date       | NA
  Approved, Date | NA
  Released, Date | NA

  Significant Modification History (Most recent at top)
  =====================================================

  Date         | Initials | Details
  ------------ | -------- | -------
  03 FEB 2020  | JH       | Original

  Theory of Operation
  ===================
  TBD

  */

// Define to prevent recursive inclusion -------------------------------------
#ifndef __DEVICE_INFO_SERVICE_H
#define __DEVICE_INFO_SERVICE_H

#include "Status.h"

// Exported macro ------------------------------------------------------------

// Exported types ------------------------------------------------------------

// Exported constants --------------------------------------------------------

// Exported objects ----------------------------------------------------------

// Exported functions --------------------------------------------------------

///  @brief Initializes the DeviceInfoService software unit
status_t DeviceInfoService_Init(void);

#endif // __DEVICE_INFO_SERVICE_H

/// SAEC Kinetic Vision, Inc. ----------- END OF FILE


