/**
  @file       SummaryProto.h

  @copyright  (C) 2020 Kinetic Vision, Cincinnati Ohio.
               This software is property of SAEC Kinetic Vision, Inc
               and is considered confidential.

  @brief      SummaryProto Software module for handling transfering summary data

  @author     Jeffrey Hatton

  @defgroup   ResbitSummary

  Configuration History
  =====================

  Config Item    | Value
  -------------- | -----
  Config #       | NA
  Revision       | NA
  Revised, Date  | NA
  QA, Date       | NA
  Approved, Date | NA
  Released, Date | NA

  Significant Modification History (Most recent at top)
  =====================================================

  Date         | Initials | Details
  ------------ | -------- | -------
  07 FEB 2020  | JH       | Original

  Theory of Operation
  ===================
  TBD

  */

// Define to prevent recursive inclusion -------------------------------------
#ifndef __SUMMARY_PROTO_H
#define __SUMMARY_PROTO_H

#include "Status.h"

// Exported macro ------------------------------------------------------------

// Exported types ------------------------------------------------------------

typedef enum {
    SummaryProtoResponses_None = 0,
    SummaryProtoResponses_Ack,
    SummaryProtoResponses_Nack,
    SummaryProtoResponses_Count
} SummaryProtoResponses_t;

typedef enum {
    SummaryProtoNacks_ResendData = 0,
    SummaryProtoNacks_Count
} SummaryProtoNacks_t;

typedef enum {
    SummaryProtoStopReasons_Finished = 0,
    SummaryProtoStopReasons_NoData,
    SummaryProtoStopReasons_Timeout,
    SummaryProtoStopReasons_InvalidResponse,
    SummaryProtoStopReasons_CanceledByClient,
    SummaryProtoStopReasons_ClientDisconnected,
    SummaryProtoStopReasons_PacketSendError,
    SummaryProtoStopReasons_InternalError,
    SummaryProtoStopReasons_Count
} SummaryProtoStopReasons_t;

// Exported constants --------------------------------------------------------

///
/// Size of the packet header for summary data
///
#define SUMMARY_PROTO_PACKET_HEADER_SIZE 2

///
/// Total size of each summary data packet
///
#define SUMMARY_PROTO_PACKET_TOTAL_SIZE 20

///
/// Size of the data payload in the summary data packet
///
#define SUMMARY_PROTO_PACKET_DATA_SIZE (SUMMARY_PROTO_PACKET_TOTAL_SIZE - SUMMARY_PROTO_PACKET_HEADER_SIZE)

// Exported objects ----------------------------------------------------------

// Exported functions --------------------------------------------------------

///  @brief Initializes the Summary Protocol software unit
///  @return status.
status_t SummaryProto_Init(void);

///  @brief Tick method fo rthe Summary Protocol software unit
///  @return status.
status_t SummaryProto_Tick(bool* needMoreTime);

///  @brief Start a transfer
///  @return status.
status_t SummaryProto_Start(void);

///  @brief Notify the SU of a response
///  @param response The major response type of the response
///  @param rspData Any additional response data
///  @param len Length of the additional data
///  @return status.
status_t SummaryProto_NotifyResponse(SummaryProtoResponses_t response, uint8_t* rspData, uint8_t len);

///  @brief Stop a transfer
///  @param stopReason The reason for stopping the transfer
///  @return status.
status_t SummaryProto_Stop(SummaryProtoStopReasons_t stopReason);

#endif // __SUMMARY_TRANSFER_PROTO_H

/// SAEC Kinetic Vision, Inc. ----------- END OF FILE


