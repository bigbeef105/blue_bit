/**
  @file       I2cSlave.h

  @copyright  (C) 2020 Kinetic Vision, Cincinnati Ohio.
               This software is property of SAEC Kinetic Vision, Inc 
               and is considered confidential.

  @brief      I2cSlave software unit "H" file.

  @author     Andrew Loebs

  @defgroup   I2cSlaveSoftwareUnit I2C slave abstraction layer.

  Configuration History
  =====================

  Config Item    | Value
  -------------- | -----
  Config #       | NA
  Revision       | NA
  Revised, Date  | NA
  QA, Date       | NA
  Approved, Date | NA
  Released, Date | NA

  Significant Modification History (Most recent at top)
  =====================================================

  Date         | Initials | Details
  ------------ | -------- | -------
  24 Jan 2020  | ASL      | Original

  Theory of Operation
  ===================
  I2C slave abstraction layer.

  */

// Define to prevent recursive inclusion -------------------------------------
#ifndef __I2C_SLAVE_H
#define __I2C_SLAVE_H

#include <stdbool.h> // bool
#include <stdio.h> // size_t
#include <stdint.h> // int types
#include "../StatusSu/Status.h" // status_t

// Exported macro ------------------------------------------------------------

// Exported types ------------------------------------------------------------

// Exported constants --------------------------------------------------------

// Exported objects ----------------------------------------------------------

// Exported functions --------------------------------------------------------
///  @brief Initializes the I2C slave software unit
///  @return StatusOk, StatusAlreadyInitialized, StatusGenericError.
status_t I2cSlave_Init();

///  @brief Uninitializes the I2C slave software unit
///  @return StatusOk
status_t I2cSlave_DeInit();

///  @brief Returns number of bytes in the receive buffer
size_t I2cSlave_GetRxCount();

///  @brief Copies I2C receive buffer to specified memory location
///  @param args[out] out - destination buffer being written to
///  @param args[out] outLen - memory location to report number of bytes copied 
///  @param args[out] maxLen - maximum number of bytes to be written to out buff
///  @return StatusOk, StatusNullParameter, StatusBufferLength
status_t I2cSlave_GetRx(uint8_t * out, size_t * outLen, size_t maxLen);

///  @brief Clears receive buffer
void I2cSlave_ResetRx();

///  @brief Prepares buffer for next I2C Master Read
///  @param args[in] buffer - pointer to buffer to write data from
///  @param args[in] len - length of data to be written
///  @return StatusOk, StatusWriteAlreadyPending, StatusNullParameter, StatusBufferLength
status_t I2cSlave_PrepareWrite(uint8_t * buffer, size_t len);

///  @brief Returns true if no write is pending
bool I2cSlave_IsWriteReady();

///  @brief Clears write pending to allow for specifying a new write buffer
void I2cSlave_ClearWritePending();
                    

#endif // __I2C_SLAVE_H

/// SAEC Kinetic Vision, Inc. ----------- END OF FILE


