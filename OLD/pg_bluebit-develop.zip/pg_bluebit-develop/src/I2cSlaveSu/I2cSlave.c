/**
  @file       I2cSlave.c

  @copyright  (C) 2020 Kinetic Vision, Cincinnati Ohio.
               This software is property of SAEC Kinetic Vision, Inc 
               and is considered confidential.

  @brief      I2cSlave software unit "C" file.

  @author     Andrew Loebs

  @ingroup    I2cSlaveSoftwareUnit

  Configuration History
  =====================

  Config Item    | Value
  -------------- | -----
  Config #       | NA
  Revision       | NA
  Revised, Date  | NA
  QA, Date       | NA
  Approved, Date | NA
  Released, Date | NA

  Significant Modification History (Most recent at top)
  =====================================================

  Date         | Initials | Details
  ------------ | -------- | -------
  24 Jan 2020  | ASL      | Original

  Theory of Operation
  ===================
  I2C slave abstraction layer.

*/

// Includes ------------------------------------------------------------------

#include "I2cSlave.h"

#include <string.h> // memcpy

#include "nrfx_twis.h"

#include "../SwUnitControlSu/SwUnitControl.h" // SwUnitControl_WriteStatus()

// Private function prototypes -----------------------------------------------
void twiEventHandler(nrfx_twis_evt_t const * pEvent);
void twiReadReqHandler(nrfx_twis_evt_t const * pEvent);
void twiReadDoneHandler(nrfx_twis_evt_t const * pEvent);
void twiWriteReqHandler(nrfx_twis_evt_t const * pEvent);
void twiWriteDoneHandler(nrfx_twis_evt_t const * pEvent);
void twiErrorHandler(nrfx_twis_evt_t const * pEvent);

void shiftHeadDown(int currentHead, size_t len);
void resetTxData();
void resetRxData();

// Private macros ------------------------------------------------------------
#define returnStatus(__status__,__source__) SwUnitControl_WriteStatus(eSucI2cSlaveSu,__source__,__status__,__LINE__);

// Private constants ---------------------------------------------------------
#define TWI_INSTANCE_ID     1
#define SLAVE_ADDRESS       0x08
#define SCL_PORT_NUM        0x04
#define SDA_PORT_NUM        0x03

#define BUFFER_LEN          255

// Private types -------------------------------------------------------------
typedef enum {
    I2cStateNotInitialized = 0,
    I2cStateIdle,
    I2cStateRxInProgress,
    I2cStateError,
} I2cState_t;

// Private constants ---------------------------------------------------------
static const nrfx_twis_t twi = NRFX_TWIS_INSTANCE(TWI_INSTANCE_ID);

// Private variables ---------------------------------------------------------
static I2cState_t state = I2cStateNotInitialized;

static uint8_t rxBuff[BUFFER_LEN];
static int rxTailIndex = 0;
static bool rxResetPending = false;
static int rxTailAtReset = 0;

static bool writePending = false;
static uint8_t txBuffDefault = 0; // used when master requests read but no write buffer is specified
static uint8_t * txBuffPointer = &txBuffDefault;
static size_t txBuffLen = 0;

// Private variables ---------------------------------------------------------

// Private function bodies ---------------------------------------------------
void twiEventHandler(nrfx_twis_evt_t const * pEvent)
{
    switch (pEvent->type)
    {
        case NRFX_TWIS_EVT_READ_REQ:
            twiReadReqHandler(pEvent);
            break;
        case NRFX_TWIS_EVT_READ_DONE:
            twiReadDoneHandler(pEvent);
            break;
        case NRFX_TWIS_EVT_WRITE_REQ:
            twiWriteReqHandler(pEvent);
            break;
        case NRFX_TWIS_EVT_WRITE_DONE:
            twiWriteDoneHandler(pEvent);
            break;
        case NRFX_TWIS_EVT_READ_ERROR:
        case NRFX_TWIS_EVT_WRITE_ERROR:
        case NRFX_TWIS_EVT_GENERAL_ERROR:
            twiErrorHandler(pEvent);
            break;
        default:
            break;
    }
}

void twiReadReqHandler(nrfx_twis_evt_t const * pEvent)
{
    nrfx_twis_tx_prepare(&twi, txBuffPointer, txBuffLen);
}

void twiReadDoneHandler(nrfx_twis_evt_t const * pEvent)
{
    uint32_t readLen = pEvent->data.tx_amount;
    if (readLen >= txBuffLen) {
        resetTxData();
    } else {
        txBuffPointer += readLen;
        txBuffLen -= readLen;
        nrfx_twis_tx_prepare(&twi, txBuffPointer, txBuffLen);
    }
}

void twiWriteReqHandler(nrfx_twis_evt_t const * pEvent)
{
    nrfx_twis_rx_prepare(&twi, &rxBuff[rxTailIndex], BUFFER_LEN - rxTailIndex);
    state = I2cStateRxInProgress;
}

void twiWriteDoneHandler(nrfx_twis_evt_t const * pEvent)
{
    if (rxResetPending) {
        size_t shiftLen = rxTailIndex - rxTailAtReset;
        shiftHeadDown(rxTailAtReset, shiftLen);
        rxTailIndex = shiftLen;
        rxResetPending = false;
    } else {
        rxTailIndex += pEvent->data.rx_amount;
    }
    
    state = I2cStateIdle;
}

void twiErrorHandler(nrfx_twis_evt_t const * pEvent)
{
    state = I2cStateError;
}

void shiftHeadDown(int currentHead, size_t len)
{
    for (int i = 0; i < len; i++) {
        rxBuff[i] = rxBuff[i + currentHead];
    }
}

void resetTxData()
{
    writePending = false;
    txBuffPointer = &txBuffDefault;
    txBuffLen = 0;
}

void resetRxData()
{
    if (I2cStateRxInProgress == state) {
        rxTailAtReset = rxTailIndex;
        rxResetPending = true;
    } else {
        rxTailIndex = 0;
    }
}

// Public functions bodies ---------------------------------------------------
status_t I2cSlave_Init()
{
    status_t status = StatusOk;
    if (I2cStateNotInitialized != state) {
        status = StatusAlreadyInitialized;
    }
    
    if (Status_IsOk(status)) {
        ret_code_t err_code;

        const nrfx_twis_config_t config = {
           .addr               = { SLAVE_ADDRESS, 0 },
           .scl                = SCL_PORT_NUM,
           .sda                = SDA_PORT_NUM,
           .scl_pull           = NRF_GPIO_PIN_PULLUP,
           .sda_pull           = NRF_GPIO_PIN_PULLUP,
           .interrupt_priority = APP_IRQ_PRIORITY_HIGH,
        };

        err_code = nrfx_twis_init(&twi, &config, twiEventHandler);
        if (0 != err_code) {
            status = StatusHal;
        }
    }
    
    if (Status_IsOk(status)) {
        nrfx_twis_enable(&twi);
        state = I2cStateIdle;
    }

    return returnStatus(status, eSucInitStatus);
}

status_t I2cSlave_DeInit()
{
    status_t status = StatusOk;
    
    nrfx_twis_disable(&twi);
    nrfx_twis_uninit(&twi);
    state = I2cStateNotInitialized;
    
    return status;
}

size_t I2cSlave_GetRxCount()
{
    return (size_t)rxTailIndex;
}

status_t I2cSlave_GetRx(uint8_t * out, size_t * outLen, size_t maxLen)
{
    status_t status = StatusOk;
    
    // Input validation
    if ((out == NULL) || (outLen == NULL))
        status = StatusNullParameter;
    else if (maxLen < 1)
        status = StatusBufferLength;
    
    if (Status_IsOk(status)) {
        *outLen = (rxTailIndex > maxLen) ? maxLen : rxTailIndex;
        memcpy(out, rxBuff, *outLen);
        
        resetRxData();
    }
    
    return returnStatus(status, eSucReadStatus);
}

void I2cSlave_ResetRx()
{
    resetRxData();
}

status_t I2cSlave_PrepareWrite(uint8_t * buffer, size_t len)
{
    status_t status = StatusOk;
    
    // Input validation
    if (buffer == NULL)
        status = StatusNullParameter;
    else if (len < 1)
        status = StatusBufferLength;
    
    if (Status_IsOk(status)) {
        status = writePending ? StatusWriteAlreadyPending : StatusOk;
    }
    if (Status_IsOk(status)) {
        writePending = true;
        txBuffPointer = buffer;
        txBuffLen = len;
    }
    
    return returnStatus(status, eSucWriteStatus);
}

bool I2cSlave_IsWriteReady()
{
    return !writePending;
}

void I2cSlave_ClearWritePending()
{
    resetTxData();
}

/// SAEC Kinetic Vision, Inc. ----------- END OF FILE