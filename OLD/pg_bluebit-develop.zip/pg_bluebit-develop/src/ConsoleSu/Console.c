/**
  @file       Console.c

  @copyright  (C) 2019 Kinetic Vision, Cincinnati Ohio.
               This software is property of SAEC Kinetic Vision, Inc
               and is considered confidential.

  @brief      Console software unit "C" file.

  @author     Sherman Couch

  @defgroup   ConsoleSoftwareUnit


  Configuration History
  =====================

  Config Item    | Value
  -------------- | -----
  Config #       | NA
  Revision       | NA
  Revised, Date  | NA
  QA, Date       | NA
  Approved, Date | NA
  Released, Date | NA

  Significant Modification History (Most recent at top)
  =====================================================

  Date        | Initials | Details
  ----------- | -------- | -------
  28 Jan 2020 | ASL      | Porting from Resbit to Bluebit
  05 Jun 2019 | SRC      | Import

  Theory of Operation
  -------------------
  Operationally, this is a rather conventional command line interface.
  CLI commands are exported by client software units (to the CLI) using
  the "console_ExportCommands( )" function.

  After initialization the client must "open" a uart. If the client wishes
  to cease using a uart, or change usart assingments, the the uart must be
  first "closed".

  */

// Includes ------------------------------------------------------------------

#include "Console.h"

#include <stddef.h>
#include <stdbool.h>
#include <stdio.h>
#include <string.h>
#include <stdint.h>
#include <stdarg.h>

#include "nrf_nvic.h"

#include "../UsartSu/Usart.h"
#include "../SwUnitControlSu/SwUnitControl.h"

// Private function prototypes -----------------------------------------------

// Private macros ------------------------------------------------------------
#define returnStatus(__status__,__source__) SwUnitControl_WriteStatus(eSucConsoleSu,__source__,__status__,__LINE__);


#define MAX_ARGS 10
#define HBOUND(_array_) (sizeof(_array_)/sizeof(_array_[0]))

#define ASCII_CR '\r'
#define ASCII_LF '\n'
#define ASCII_TAB '\t'
#define ASCII_BS 8
#define ASCII_DEL 0x7f
#define ASCII_WHITE_SPACE(_c_) ((_c_==' ')||(_c_=='\t')||(_c_=='\r')||(_c_=='\n'))

#define ASCII_NEW_LINE_STR "\x0d\x0a"

#define CLI_PRINTF_BUFFER_SIZE 512

// Private constants ---------------------------------------------------------
static const char szPrompt[] = ASCII_NEW_LINE_STR "> ";

// Private types -------------------------------------------------------------

// Private function prototypes -----------------------------------------------
static status_t helpCommand(uint16_t argc, uint8_t **argv);
static status_t versionCommand(uint16_t argc, uint8_t **argv);
static status_t resetCommand(uint16_t argc, uint8_t **argv);
static status_t parseIntoArcArv(void);
static status_t executeCmdFromArgcArgv(int16_t argc, uint8_t *argv[]);

// Private constants ---------------------------------------------------------

static const consoleCommand_t commandList[] = {
    { "version", "usage: version", versionCommand },
    { "help", "usage: help partial-name", helpCommand },
	{ "reset", "usage: reset", resetCommand },
    { NULL, NULL, NULL },
};

// Private types -------------------------------------------------------------

// Private variables ---------------------------------------------------------

static volatile bool initialized = false;
static volatile consoleRegistration_t consoleRegistrationRoot = {
    (consoleCommand_t *) commandList, // .pList =
    NULL, // .pNext =
};
static volatile uint16_t RxBufferIdx = 0;
static volatile uint8_t RxBuffer[512];
static volatile uint8_t *argv[MAX_ARGS];
static volatile int16_t argc;

///
/// Buffer for printF operations. Not Thread Safe.
///
static uint8_t _PrintfBuffer[CLI_PRINTF_BUFFER_SIZE];

// Private function bodies ---------------------------------------------------
static status_t write (void *pString, uint16_t length)
{

	status_t status;

	status = Usart_Write(pString, length);

	return status;
}

static status_t writeString(void *pString)
{
	uint16_t length;
	status_t status;

	length = strlen(pString);

	status = write(pString, length);

	return status;
}

static status_t processRxInConsoleMode(void)
{
    uint16_t sizeRead;
    uint8_t c;

    status_t status;

    status = StatusOk;

    // Read from the console usart and buffer each byte one at a time.  Look
    // for ASCII <CR> while processing

    do {
        status = Usart_Read(&c, 1, &sizeRead);

        if (StatusOk != status) {
        	break;
        }

        if (0 == sizeRead) {
            break;
        }

        // Process carriage return
        if (ASCII_CR == c) {
            RxBuffer[RxBufferIdx] = 0;
            status = StatusCarriageReturn;
            break;
        }

        // Backspace?
        else if ( (ASCII_BS == c) || (ASCII_DEL == c) ) {

            if (RxBufferIdx) {
                writeString("\x08 \x08");
                RxBufferIdx--;
                RxBuffer[RxBufferIdx] = 0;
                RxBuffer[RxBufferIdx+1] = 0;
            }
        }

        // else, store RX character
        else if (RxBufferIdx+1 < sizeof(RxBuffer)) {

            // Echo to console
            write(&c, 1);

            // Store character, put null terminator after char
            RxBuffer[RxBufferIdx++] = c;
            RxBuffer[RxBufferIdx] = 0;
        }

    } while (sizeRead);

    return status;

} // processRxInConsoleMode


static status_t parseIntoArcArv(void)
{
    uint16_t i;

    // Default all "argv" parameters to be a null string
    for (i = 0; i < HBOUND(argv); i++) {
        argv[i] = 0;
    }

    // Parse RxBuffer
    argc = 0;
    for (i = 0; i < RxBufferIdx; i++) {

        // Remove leading white space
        if (ASCII_WHITE_SPACE(RxBuffer[i])) {
            continue;
        }

        // Protect array "pArg"
        if (argc >= HBOUND(argv)) {
            break;
        }

        // Prepare argument pointer
        argv[argc++] = &RxBuffer[i++];

        // Scan forward in "RxBuffer" looking for end of parameter
        for (; i < RxBufferIdx; i++) {

            // Keep processing this parameter until white space
            if (!ASCII_WHITE_SPACE(RxBuffer[i])) {
                continue;
            }

            // Null terminate this parameter by replacing the white space with a null terminator
            RxBuffer[i] = 0;

            // This parameter is setup, continue with the next one
            break;
        }
    }

    return StatusOk;

} // parseIntoArcArv

static status_t helpCommand(uint16_t argc, uint8_t **argv)
{
    status_t status;
    consoleRegistration_t *pReg;

	// Pass through the list of registered commands
    status = StatusOk;
	pReg = (void *) &consoleRegistrationRoot;
	while (pReg) {

		// Pass through the current command list
		consoleCommand_t *pList;
		pList = pReg->pList;

		while (pList && (pList->pUsage)) {

			// Print usage on console
			uint16_t partialCmdLength;
			partialCmdLength = strlen((char *) argv[1]);
			if ((argc <= 1) || (0 == strncmp((char *) pList->pCommand, (char *) argv[1], (size_t) partialCmdLength))) {

				status = writeString(pList->pCommand);
				if (StatusOk != status) {
					break;
				}

				writeString("\t");
				writeString(pList->pUsage);
				// writeString(ASCII_NEW_LINE_STR);
				writeString(ASCII_NEW_LINE_STR "===============================================" ASCII_NEW_LINE_STR);
			}

			// Continue with the next element in the command list
			pList++;

		} // while ...

		if (StatusOk != status) {
			break;
		}

		pReg = pReg->pNext;

	} // while...


    return status;

} // help

static status_t resetCommand(uint16_t argc, uint8_t **argv)
{
	while (1) {
		sd_nvic_SystemReset();
	}

	// We should never reach this point
	return StatusCodePath;
} // resetCommand



static status_t versionCommand(uint16_t argc, uint8_t **argv)
{
    status_t status = StatusOk;

	status = writeString("v0.00.00\r\n");

    return status;

} // versionCommand

static status_t executeCmdFromArgcArgv(int16_t argc, uint8_t *argv[])
{
    consoleCommand_t *pList;
    consoleRegistration_t *pReg;

    status_t status;

    // If a command was specified, this assumes the command has not been found.  Otherwise,
	// no command was specified, assume status will be OK.
	if (argc) {
		status = StatusCommandNotFound;

		// Start the external command handler on a new line
		Console_WriteString("\r\n");
	} else {
		status = StatusOk;
	}

    // Pass through the list of registered command list, looking to handle the
    // command indicated in argv[0]
    pReg = (void *) &consoleRegistrationRoot;
    while (pReg) {

        // Pass through the current command list, looking for the command in argv[0]
        // consoleCommand_t *pList;
        pList = pReg->pList;
        while (pList && (pList->pCommand)) {

            // Does the command in argv[0], match the current command in the list?
            if (0 == strcmp((char *) argv[0], (char *)pList->pCommand)) {

                // If there is an external handler function attached
                // to this external command string, then call that
                // external handler.
                if (NULL != pList->pHandlerFn) {

                    // status_t (*pHandlerFn)(uint16_t argc, uint8_t **argv);
                    // pHandlerFn = pList->p;

                    // Call the external command handler
                    status = (pList->pHandlerFn)(argc, argv);

                    break;
                }
            }

            // Continue with the next element in the command list
            pList++;
        }
        pReg = pReg->pNext;

    }

    return status;

} // executeCmdFromArgcArgv

// Public functions bodies ---------------------------------------------------

status_t Console_ExportCommandsToCli (consoleRegistration_t *pExportedReg, consoleCommand_t *pCommandList)
{
    consoleRegistration_t *pReg;
    status_t status;

    // Initialize status return
    status = StatusOk;
    if (!initialized) {
        status = StatusNotInitialized;
    }

    // Pass through the list of registered commands, looking to insert
    if (Status_IsOk(status)) {

		pReg = (void *) &consoleRegistrationRoot;
		while (pReg) {

			// Insert exported registration
			if (NULL == pReg->pNext) {
				pExportedReg->pList = pCommandList;
				pReg->pNext = pExportedReg;

				// Be sure the new next pointer is null
				pReg = pReg->pNext;
				pReg->pNext = NULL;

				// Note: "status" return is already initialized
				break;
			}

			// Exported registration already linked?
			if (pExportedReg == pReg->pNext) {
				status = StatusAlreadyLinked;
				break;
			}

			// Continue with next
			pReg = pReg->pNext;
		}
    }

    // We care about tracking this status, use macro to feed status to SW Unit control.
    return returnStatus(status, eSucReadStatus);
} // Console_ExportCommandsToCli


status_t Console_Tick(bool* needMoreTime)
{
	status_t status;

	status = StatusOk;

    if (!initialized) {
        status = StatusNotInitialized;
    }

    if (Status_IsOk(status)) {
		status = processRxInConsoleMode ();

		// Now execute command using argc / argv
		if (StatusCarriageReturn == status) {

            *needMoreTime = true;

			parseIntoArcArv();

			status = executeCmdFromArgcArgv(argc, (void *) argv);
			if (StatusOk != status) {
				char buff[80];
				sprintf(buff, "Status: %u", status);
				Console_WriteString(buff);
			}

			// Reset the callback variables
			RxBufferIdx = 0;

			// Show Console Prompt. Note remap of status variable.
			status = writeString((void *) szPrompt);
		}
    }

    // We care about tracking this status, use macro to feed status to SW Unit control.
    return returnStatus(status, eSucTickStatus);
} // Console_Tick

status_t Console_WriteString(void *pString)
{
	status_t status;

	status = StatusOk;
    if (!initialized) {
        status = StatusNotInitialized;
    }

    if (Status_IsOk(status)) {
    	status = writeString(pString);
    }

    // We care about tracking this status, use macro to feed status to SW Unit control.
    return returnStatus(status, eSucWriteStatus);
} // Console_WriteString


status_t Console_WriteLine(void *pString)
{
    status_t ret = Console_WriteString(pString);
    Console_WriteString("\r\n");

    return ret;
} // Console_WriteString

status_t Console_Init(void)
{
    status_t status;
    status = StatusOk;

    if (initialized) {
        status = StatusAlreadyInitialized;
    }

    if (Status_IsOk(status)) {
        consoleRegistrationRoot.pList = commandList;
        consoleRegistrationRoot.pNext = NULL;

        RxBufferIdx = 0;
    	initialized = true;

        Console_WriteString("(C) 2019 Procter and Gamble\r\n");

        uint8_t buff[80];
        sprintf((char *) buff, "Build: %s %s\r\n", __DATE__, __TIME__);
        Console_WriteString(buff);

		Console_WriteString((void *) szPrompt);
    }

    // We care about tracking this status, use macro to feed status to SW Unit control.
    return returnStatus(status, eSucInitStatus);
} // Console_Init

status_t Console_Printf(const char* format, ...) {
    status_t ret = StatusOk;

    if (format == NULL) {
        ret = StatusNullParameter;
    }

    va_list args;
    va_start(args, format);

    if (Status_IsOk(ret)) {
        // Convert formatted string
        uint32_t numChars = vsnprintf((char*)_PrintfBuffer,
                                      CLI_PRINTF_BUFFER_SIZE,
                                      format,
                                      args);

        if (numChars >= CLI_PRINTF_BUFFER_SIZE) {
            ret = StatusBufferUndersized;
        } else {
            ret = Console_WriteString(_PrintfBuffer);
        }
    }

    va_end(args);

    return returnStatus(ret, eSucWriteStatus);
}

status_t Console_PrintLine(const char* format, ...) {
    status_t ret = StatusOk;

    if (format == NULL) {
        ret = StatusNullParameter;
    }

    va_list args;
    va_start(args, format);

    if (Status_IsOk(ret)) {
        // Convert formatted string
        uint32_t numChars = vsnprintf((char*)_PrintfBuffer,
                                      CLI_PRINTF_BUFFER_SIZE,
                                      format,
                                      args);

        if (numChars >= CLI_PRINTF_BUFFER_SIZE) {
            ret = StatusBufferUndersized;
        } else {
            ret = Console_WriteString(_PrintfBuffer);
        }
    }

    va_end(args);

    ret = Console_WriteString("\r\n");

    return returnStatus(ret, eSucWriteStatus);
}

/// SAEC Kinetic Vision, Inc  ----------- END OF FILE
