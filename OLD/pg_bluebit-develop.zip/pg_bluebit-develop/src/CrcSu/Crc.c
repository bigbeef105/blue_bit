/**
  @file       Crc.c

  @copyright  (C) 2020 Kinetic Vision, Cincinnati Ohio.
               This software is property of SAEC Kinetic Vision, Inc 
               and is considered confidential.

  @brief      Crc software unit "C" file.

  @author     Andrew Loebs

  @ingroup    CrcSoftwareUnit

  Configuration History
  =====================

  Config Item    | Value
  -------------- | -----
  Config #       | NA
  Revision       | NA
  Revised, Date  | NA
  QA, Date       | NA
  Approved, Date | NA
  Released, Date | NA

  Significant Modification History (Most recent at top)
  =====================================================

  Date         | Initials | Details
  ------------ | -------- | -------
  29 Jan 2020  | ASL      | Original

  Theory of Operation
  ===================
  Calculates CRC's

*/

// Includes ------------------------------------------------------------------

#include "Crc.h"

#include "../SwUnitControlSu/SwUnitControl.h" // SwUnitControl_WriteStatus()

// Private function prototypes -----------------------------------------------

// Private macros ------------------------------------------------------------
#define returnStatus(__status__,__source__) SwUnitControl_WriteStatus(eSucCrcSu,__source__,__status__,__LINE__);

// Private constants ---------------------------------------------------------
#define CRC_POLYNOMIAL                      0xA001
#define CRC_SHIFTS_NUM                      8

// Private types -------------------------------------------------------------

// Private constants ---------------------------------------------------------

// Private variables ---------------------------------------------------------

// Private function bodies ---------------------------------------------------

// Public functions bodies ---------------------------------------------------
status_t Crc_Calc(uint16_t * crc, const uint8_t * values, size_t len)
{
    status_t status = StatusOk;
    if (len < 1)
        status = StatusBufferLength;
    if (crc == NULL || values == NULL)
        status = StatusNullParameter;
    
    if (Status_IsOk(status)) {
        int j;
        uint16_t tempLen = len;
        const uint8_t* tempPtr = values;

        while (tempLen--) {
            *crc ^= (uint16_t)*tempPtr++;
            for(j = 0; j < CRC_SHIFTS_NUM; j++) {
                if(*crc & 0x01) {
                    *crc >>= 1;
                    *crc ^= CRC_POLYNOMIAL;
                } else {
                    *crc >>= 1;
                }
            }
        }
    }
    
    return returnStatus(status, eSucIoctlStatus);
}

/// SAEC Kinetic Vision, Inc. ----------- END OF FILE