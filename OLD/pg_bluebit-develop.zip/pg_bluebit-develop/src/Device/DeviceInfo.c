/**
  @file       DeviceInfo.c

  @copyright  (C) 2020 Kinetic Vision, Cincinnati Ohio.
               This software is property of SAEC Kinetic Vision, Inc
               and is considered confidential.

  @brief      DeviceInfo software unit "C" file.

  @author     Andrew Loebs

  @ingroup    DeviceInfoSoftwareUnit

  Configuration History
  =====================

  Config Item    | Value
  -------------- | -----
  Config #       | NA
  Revision       | NA
  Revised, Date  | NA
  QA, Date       | NA
  Approved, Date | NA
  Released, Date | NA

  Significant Modification History (Most recent at top)
  =====================================================

  Date         | Initials | Details
  ------------ | -------- | -------
  25 Feb 2020  | ASL      | Original

  Theory of Operation
  ===================
  TBD

*/

// Includes ------------------------------------------------------------------

#include "DeviceInfo.h"

#include <string.h>
#include <stdio.h>

#include "../MessagerSu/Messager.h" // Messager_* functions
// Private macros ------------------------------------------------------------

// Private constants ---------------------------------------------------------
#define VERSION_STR_ARRAY_LENGTH    80
#define WHOAMI_ID                   0x0002

#define BLUEBITS_DEVICE_ID          0x0001 // used in Resbit/Bluebits messaging

// Private types -------------------------------------------------------------
typedef struct {
	uint16_t deviceId;
	version_t hardwareVersion;
	version_t softwareVersion;
	version_t firmwareVersion;
} whoami_t;

// Private constants ---------------------------------------------------------

// Private function prototypes -----------------------------------------------
static void makeVersionStr(version_t *version, char *str);
static status_t whoamiHandler(messageHandlerArgs_t * args);

// Private variables ---------------------------------------------------------
static version_t hardwareVersion = {
    .major = 0,
    .minor = 0,
    .revision = 1,
    .build = 0};
static version_t softwareVersion = {
    .major = 16,
    .minor = 0,
    .revision = 0,
    .build = 0x98}; // first two digits of the hash
static version_t firmwareVersion = {
    .major = 0,
    .minor = 8,
    .revision = 0,
    .build = 1};

// Initialize this in Init() since we may at some point read version info at run time
static whoami_t whoami = { 0, 0, 0, 0 };

static char hardwareVersionStr[VERSION_STR_ARRAY_LENGTH];
static char softwareVersionStr[VERSION_STR_ARRAY_LENGTH];
static char firmwareVersionStr[VERSION_STR_ARRAY_LENGTH];

static const messageHandlerReg_t messages[] = {
    { WHOAMI_ID, whoamiHandler },
    // Marks last element in the list
    { 0, NULL },
};

static messageHandlerList_t messageHandlerList = { messages, NULL };

// Private function bodies ---------------------------------------------------
static void makeVersionStr(version_t *version, char *str)
{
    sprintf(str, "v%d.%d.%d.%d", version->major, version->minor,
            version->revision, version->build);
}

static status_t whoamiHandler(messageHandlerArgs_t * args)
{
	status_t status = StatusOk;

    if (args->resBufferLen >= sizeof(whoami)) {
        args->resCode = messageResponseSuccess;
    	memcpy(args->resBuffer, &whoami, sizeof(whoami));
    	args->bytesWritten = sizeof(whoami);
    } else {
        args->resCode = messageResponseDataError;
        args->bytesWritten = 0;
    	status = StatusBufferLength;
    }

    return status;
}

// Public functions bodies ---------------------------------------------------
status_t DeviceInfo_Init(void)
{
    // populate whoami
    whoami.deviceId = BLUEBITS_DEVICE_ID;
    whoami.hardwareVersion = hardwareVersion;
    whoami.softwareVersion = softwareVersion;
    whoami.firmwareVersion = firmwareVersion;
    // register whoami
    status_t status = Messager_Subscribe(&messageHandlerList);
    // build strings
    makeVersionStr(&hardwareVersion, hardwareVersionStr);
    makeVersionStr(&softwareVersion, softwareVersionStr);
    makeVersionStr(&firmwareVersion, firmwareVersionStr);

    return status;
}

status_t DeviceInfo_GetHardwareVersion(version_t *version)
{
    *version = hardwareVersion;
    return StatusOk;
}

status_t DeviceInfo_GetSoftwareVersion(version_t *version)
{
    *version = softwareVersion;
    return StatusOk;
}

status_t DeviceInfo_GetFirmwareVersion(version_t *version)
{
    *version = firmwareVersion;
    return StatusOk;
}

status_t DeviceInfo_GetHardwareVersionStr(char **str)
{
    *str = hardwareVersionStr;
    return StatusOk;
}

status_t DeviceInfo_GetSoftwareVersionStr(char **str)
{
    *str = softwareVersionStr;
    return StatusOk;
}

status_t DeviceInfo_GetFirmwareVersionStr(char **str)
{
    *str = firmwareVersionStr;
    return StatusOk;
}

/// SAEC Kinetic Vision, Inc. ----------- END OF FILE