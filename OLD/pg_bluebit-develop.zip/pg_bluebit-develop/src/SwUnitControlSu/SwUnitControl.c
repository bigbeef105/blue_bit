/**
  @file       SwUnitControl.c

  @copyright  (C) 2019 Kinetic Vision, Cincinnati Ohio.
               This software is property of SAEC Kinetic Vision, Inc
               and is considered confidential.

  @brief      "SwUnitControl", software unit "C" file.

  @author     Sherman Couch

  @ingroup    SwUnitControlSoftwareUnit

  Configuration History
  =====================

  Config Item    | Value
  -------------- | -----
  Config #       | NA
  Revision       | NA
  Revised, Date  | NA
  QA, Date       | NA
  Approved, Date | NA
  Released, Date | NA

  Significant Modification History (Most recent at top)
  =====================================================

  Date         | Initials | Details
  ------------ | -------- | -------
  28 Jan 2020  | ASL      | Porting from Resbit to Bluebit
  01 Aug 2019  | SC       |

  Theory of Operation
  ===================
  - Provides methods and data types for managing configuration of software units.
  - Provides methods and data types for obtaining status software units.

  */

// Includes ------------------------------------------------------------------

#include "SwUnitControl.h"

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

#include "../ConsoleSu/Console.h"

// Private macros ------------------------------------------------------------
#define ARRAY_DIMENSION(__a__) (sizeof(__a__)/sizeof(__a__[0]))

///
/// The max length for software unit names. This only affects formating
///
#define MAX_SU_NAME_LEN "20"

// Private types -------------------------------------------------------------

typedef struct {
	uint32_t StatusOk;
	uint32_t NotStatusOk;
	uint16_t NotOkLineOfCode;
	status_t NotOkStatusCode;

} swUnitStats_t;

typedef struct {
    swUnitStats_t Stats[SUC_NUMBER_OF_STATUS_TYPES];
} swUnitsStatistics_t;


// Private function prototypes -----------------------------------------------
static status_t cliEnable(uint16_t argc, uint8_t **argv);
static status_t cliStats(uint16_t argc, uint8_t **argv);
static status_t cliLineOfCode(uint16_t argc, uint8_t **argv);

// Private constants ---------------------------------------------------------
static const consoleCommand_t commandList[] = {

	{
		.pCommand = "enable",
		.pUsage = "enable software unit\r\n\t" "usage: enable [swuNumber] [0|1]",
		.pHandlerFn = cliEnable,
	},


	{
		.pCommand = "loc",
		.pUsage = "line of code with status not OK. Format: line/XX.  XX = 2 digit status code.\r\n\t" "usage: loc [zero]",
		.pHandlerFn = cliLineOfCode,
	},


    {
		.pCommand = "stats",
		.pUsage = "statistics software units\r\n\t"	"usage: stats [zero]",
		.pHandlerFn = cliStats,
    },

	// Marks last element in the list
    { NULL, NULL, NULL },
};

static const uint8_t *pSuNames[SUC_NUMBER_OF_SW_UNITS_LIST] = {
	[eSucConsoleSu] = "Console",
	[eSucCrcSu] = "CRC",
    [eSucI2cSlaveSu] = "I2C Slave",
    [eSucMessagerSu] = "Messager",
    [eSucPacketSu] = "Packet",
    [eSucProtocolHalSu] = "Protocol HAL",
    [eSucProtocolHandlerSu] = "Protocol Handler",
    [eSucSplitBufferSu] = "Split Buffer",
	[eSucSwUnitControlSu] = "Su Ctrl",
	[eSucSysTimeSu] = "Sys Time",
	[eSucUsartSu] = "Usart",
    [eSucBle] = "BLE",
    [eSucBleAdvert] = "BLE Advert",
    [eSucBleDeviceInfoService] = "Dev Info Ser",
    [eSucBleSummaryService] = "Summary Ser",
    [eSucBleSummaryProto] = "Summary Proto",
    [eSucBleSummaryStore] = "Summary Store",
    [eSucBleResbitInfoService] = "Resbit Info",
};

static const uint8_t *pStateNames[SUC_NUMBER_OF_STATUS_TYPES] = {
    [eSucInitStatus] = "Init",
    [eSucReadStatus] = "Read",
	[eSucWriteStatus] = "Write",
	[eSucIoctlStatus] = "Ioctl",
    [eSucTickStatus] = "Tick",
};

// Private constants ---------------------------------------------------------

// Private variables ---------------------------------------------------------

static bool initialized = false;

static consoleRegistration_t exportedReg = {
    (consoleCommand_t *) commandList, // .pList =
    NULL, // .pNext =
};

// Statistics are stored in this "stats" structure.
static swUnitsStatistics_t stats[SUC_NUMBER_OF_SW_UNITS_LIST];

// Private function bodies ---------------------------------------------------

static status_t cliLineOfCode(uint16_t argc, uint8_t **argv)
{
	status_t status;

	status = StatusOk;

	// Stats can be displayed or zeroized.  Which one are we doing?
	if (argc > 1) {
		if (0 == strcmp("zero", argv[1])) {
			for (uint16_t i = 0; i < ARRAY_DIMENSION(pSuNames); i++) {
                for (uint16_t x = 0; x < SUC_NUMBER_OF_STATUS_TYPES; x++) {
                    stats[i].Stats[x].NotOkLineOfCode = 0;
                    stats[i].Stats[x].NotOkStatusCode = 0;
                    stats[i].Stats[x].NotStatusOk = 0;
                    stats[i].Stats[x].StatusOk = 0;
                }
			}

		} else {
			status = StatusParameter1;
		}
	} else {

        Console_Printf("%-" MAX_SU_NAME_LEN "s", "SW");
        for (int i = 0; i < SUC_NUMBER_OF_STATUS_TYPES; i++){
            Console_Printf("%13s", pStateNames[i]);
        }
        Console_WriteString("\r\n");

		for (uint16_t i = 0; i < ARRAY_DIMENSION(pSuNames); i++) {
            Console_Printf("%-" MAX_SU_NAME_LEN "s", pSuNames[i]);

            for (uint16_t x = 0; x < SUC_NUMBER_OF_STATUS_TYPES; x++) {
                Console_Printf("%10u/%02u",
                               stats[i].Stats[x].NotOkLineOfCode,
                               stats[i].Stats[x].NotOkStatusCode);
            }


			Console_WriteString("\r\n");
		}
	}

	return status;

} // cliLineOfCode

static status_t cliStats(uint16_t argc, uint8_t **argv)
{
	status_t status;

	status = StatusOk;

	// Stats can be displayed or zeroized.  Which one are we doing?
	if (argc > 1) {
		if (0 == strcmp("zero", argv[1])) {
			uint8_t *p;
			uint16_t sizeofStats;

			sizeofStats = sizeof(stats);
			p = (uint8_t *) &stats;

			while (sizeofStats--) {
				*p++ = 0;
			}
		} else {
			status = StatusParameter1;
		}
	} else {

        Console_Printf("%-" MAX_SU_NAME_LEN "s", "SW");
        Console_Printf("%13s", pStateNames[0]);
        for (int i = 1; i < SUC_NUMBER_OF_STATUS_TYPES; i++){
            Console_Printf("%16s", pStateNames[i]);
        }
        Console_WriteString("\r\n");


        Console_Printf("%-" MAX_SU_NAME_LEN "s", "Unit");
        for (uint16_t x = 0; x < SUC_NUMBER_OF_STATUS_TYPES; x++) {
            Console_Printf("%8s%8s", "Ok", "NotOk");
        }
        Console_WriteString("\n\r");

		for (uint16_t i = 0; i < ARRAY_DIMENSION(pSuNames); i++) {
            Console_Printf("%-" MAX_SU_NAME_LEN "s", pSuNames[i]);

            for (uint16_t x = 0; x < SUC_NUMBER_OF_STATUS_TYPES; x++) {
                Console_Printf("%8lu%8lu",
                               stats[i].Stats[x].StatusOk,
                               stats[i].Stats[x].NotStatusOk);
            }

			Console_WriteString("\r\n");
		}
	}

	return status;

} // cliStats

static status_t cliEnable(uint16_t argc, uint8_t **argv)
{
	return StatusOk;

} // cliEnable

// Public functions bodies ---------------------------------------------------

status_t SwUnitControl_Init(void)
{
    status_t status;
    status = StatusOk;

    if (initialized) {
        status = StatusAlreadyInitialized;
    }

    if (status == StatusOk) {
    	status = Console_ExportCommandsToCli (&exportedReg, commandList);
    }

    if (status == StatusOk) {

    	// Record a successful initialization
    	initialized = true;
    }

	return status;

} // SwUnitControl_Init


// Note: by design, this function reflects the input status "statusIn", back to the caller.
status_t SwUnitControl_WriteStatus(SwUnitControlId_t suId, SwUnitControlStatusType_t statusType, status_t statusIn, uint16_t lineOfCode)
{
    status_t status;
    status = StatusOk;

    // Note: By design, "writing status" does not "care" regarding initialization status.
    //       Do not check initializaton status.

    // Check parameter 1
    if (status == StatusOk) {
        if (suId >= SUC_NUMBER_OF_SW_UNITS_LIST) {
        	status = StatusParameter1;
        }
    }

    // Check parameter 2
    if (status == StatusOk) {
		if (statusType >= SUC_NUMBER_OF_STATUS_TYPES) {
        	status = StatusParameter2;
		}
    }

    // If OK, process status passed, into a statistic passed in
    if (status == StatusOk)
    {
    	if (statusIn == StatusOk) {
            if (statusType < SUC_NUMBER_OF_STATUS_TYPES) {
                stats[suId].Stats[statusType].StatusOk++;
            }
		} else {
            if (statusType < SUC_NUMBER_OF_STATUS_TYPES) {
                stats[suId].Stats[statusType].NotStatusOk++;
                stats[suId].Stats[statusType].NotOkLineOfCode = lineOfCode;
                stats[suId].Stats[statusType].NotOkStatusCode = statusIn;
            }
        }
    } else {
        // If the input parameters are faulty, the programmer needs to fix this. Although
        // this is technically an out of band error, return this status so that the
        // programmer finds the defect.

    	return status;
    }

    // Status information processed, return input status.
	return statusIn;

} // SwUnitControl_WriteStatus


/// SAEC Kinetic Vision, Inc  ----------- END OF FILE
