/**
  @file       Packet.h

  @copyright  (C) 2020 Kinetic Vision, Cincinnati Ohio.
               This software is property of SAEC Kinetic Vision, Inc 
               and is considered confidential.

  @brief      Packet software unit "H" file.

  @author     Andrew Loebs

  @defgroup   PacketSoftwareUnit Exports packet data type, handles packing and unpacking messages between the Resbit and BLE MCU

  Configuration History
  =====================

  Config Item    | Value
  -------------- | -----
  Config #       | NA
  Revision       | NA
  Revised, Date  | NA
  QA, Date       | NA
  Approved, Date | NA
  Released, Date | NA

  Significant Modification History (Most recent at top)
  =====================================================

  Date         | Initials | Details
  ------------ | -------- | -------
  24 Jan 2020  | ASL      | Original

  Theory of Operation
  ===================
  Exports packet data type, handles packing and unpacking messages between the Resbit and BLE MCU.

  */

// Define to prevent recursive inclusion -------------------------------------
#ifndef __PACKET_H
#define __PACKET_H

#include <stdint.h> // int types
#include <stdio.h> // size_t

#include "../StatusSu/Status.h" // status_t

// Exported macro ------------------------------------------------------------
#define PACKET_LEN              255
#define PACKET_HEADER_LEN       5
#define PACKET_MAX_DATA_LEN     (PACKET_LEN - PACKET_HEADER_LEN)

#define RESPONSE_LEN            3

#define COMS_TIMEOUT_MS         100
#define COMS_MESSAGE_INTERVAL   2

#define COMS_RETRY_LIMIT        3

// Exported types ------------------------------------------------------------
typedef union {
  uint8_t bytes[PACKET_LEN];
  struct {
    uint16_t crc;
    uint8_t numPackets;
    uint8_t packetNum;
    uint8_t dataLen;
    uint8_t data[PACKET_LEN - PACKET_HEADER_LEN];
  };
} packet_t;

typedef union {
    uint8_t bytes[RESPONSE_LEN];
    struct {
        uint16_t crc;
        uint8_t code;
    };
} response_t;
    

// Exported constants --------------------------------------------------------

// Exported objects ----------------------------------------------------------

// Exported functions --------------------------------------------------------
  
///  @brief Creates a packet with the specified data.
///  @param args[out] dest - destination packet being written to
///  @param args[in] src - pointer to data buffer to be packed
///  @param args[in] len - length of data buffer to be packed
///  @param args[in] numPackets - number of packets in message to be encoded in packet
///  @param args[in] packetNum - packet number to be encoded in packet
///  @return StatusOk, StatusNullParameter, StatusBufferLength
status_t Packet_Pack(packet_t * dest, const uint8_t * src, size_t len, 
                     int numPackets, int packetNum);

///  @brief Extracts header data from a packet.
///  @param args[in] src - pointer to packet to be unpacked
///  @param args[in] len - length of packet
///  @return StatusOk, StatusNullParameter, StatusComsCRC, 
///          StatusComsInvalidNumPackets, StatusComsInvalidPacketNum
///          StatusComsInvalidDataLen, StatusComsDataLenMismatch.
status_t Packet_ParseHeader(const packet_t * src, size_t len);

///  @brief Extracts contents from packet.
///  @param args[out] dest - destination buffer being written to
///  @param args[out] maxLen - maximum number of bytes to be written to out buff
///  @param args[in] src - pointer to packet to be unpacked
///  @param args[out] numPackets - number of packets in message specified by packet
///  @param args[out] packetNum - packet number encoded in packet
///  @return  StatusOk, StatusNullParameter, StatusBufferLength, StatusBufferUndersized.
status_t Packet_ParseBody(uint8_t * dest, size_t maxLen, const packet_t * src);

///  @brief Maps status_t to I2C coms response codes
///  @param args[in] status - status code associated with current coms status
///  @return Byte-encoded response code
uint8_t Packet_GetResponseCode(status_t status);

///  @brief Generates response from response code
///  @param args[out] dest - response_t being written to
///  @param args[in] responseCode - Byte-encoded response code
///  @return StatusOk, StatusNullParameter
status_t Packet_GenerateResponse(response_t * dest, uint8_t responseCode);

///  @brief Gets status from response
///  @return StatusOk, StatusNullParameter, StatusComsCRC, 
///          StatusComsInvalidNumPackets, StatusComsInvalidPacketNum, 
///          StatusComsInvalidDataLen, StatusComsPacketOrder, 
///          StatusComsDataLenMismatch, StatusComsUnknown, 
///          StatusComsResponseError
status_t Packet_ParseResponse(const response_t * res);

#endif // __PACKET_H

/// SAEC Kinetic Vision, Inc. ----------- END OF FILE


