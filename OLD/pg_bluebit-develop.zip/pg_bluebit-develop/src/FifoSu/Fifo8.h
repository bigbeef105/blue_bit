/**
  *****************************************************************************
  *
  * @file     Fifo8.h
  * @brief    The 8 bit fifo software unit's header module.
  * @author   Sherman Couch
  * @defgroup fifoSoftwareUnit 8 Bit First In First Out Ring buffer
  *
  ******************************************************************************
  *
  * @copyright COPYRIGHT (c) 2019 SAEC Kinetic Vision, Inc.
  *            All Rights Reserved
  *
  * This software is property of SAEC Kinetic Vision, Inc and is considered
  * confidential.
  *
  ******************************************************************************
  *
  * Theory of Operation
  * -------------------
  *
  * Significant Modification History (Most Recent at top)
  * -----------------------------------------------------
  *
  * Date        | Initials | Description
  * ----------- | -------- | -----------
  * 28 Mar 2019 | SRC      | Old school fifo interface, imported from Pleistocene.
  */

// Define to prevent recursive inclusion -------------------------------------
#ifndef __FIFO_8_H
#define __FIFO_8_H

#include "stdint.h"
#include "stdio.h"
#include "Status.h"

// Exported macro ------------------------------------------------------------

// Exported types ------------------------------------------------------------

typedef struct {
    int32_t head;
    int32_t tail;
    uint16_t Size;
    uint8_t* Buffer;
    int32_t Available;
    status_t Status;
} Fifo8_t;

// Exported constants --------------------------------------------------------

// Exported objects ----------------------------------------------------------

// Exported functions --------------------------------------------------------

status_t Fifo8_SetupQueObject(Fifo8_t * q, uint8_t* data, uint16_t size);

///
/// Set the software unit id
/// \param id The ID to assign to the software unit
///
status_t Fifo8_FlushQueueByConsumer(Fifo8_t *pIn);
status_t Fifo8_FlushQueueByProducer(Fifo8_t *pIn);
status_t Fifo8_ReturnStatus(Fifo8_t *q);
status_t Fifo8_ReturnAvailable(Fifo8_t *q, int32_t* pAvailable);
status_t Fifo8_ReturnUsed(Fifo8_t *q, uint16_t* pUsed);
status_t Fifo8_Insert(Fifo8_t *q, uint8_t c);
status_t Fifo8_Remove(Fifo8_t *q, uint8_t *c);
status_t Fifo8_Enqueue(Fifo8_t *q, const uint8_t* c, uint16_t numBytes);
status_t Fifo8_Dequeue(Fifo8_t *q, uint16_t numBytes, uint8_t *c);
status_t Fifo8_PeekFront(Fifo8_t *q, uint8_t *c);
status_t Fifo8_PeekTail(Fifo8_t *q, uint8_t *c);

status_t Fifo8_FlushBytes(Fifo8_t *q, uint16_t numBytes);
status_t Fifo8_Peek(Fifo8_t *q, uint8_t* data, uint16_t numBytes, uint16_t offset);



#endif // __FIFO_8_H

/// SAEC Kinetic Vision, Inc. ----------- END OF FILE
