/**
  @file       SysTime.h

  @copyright  (C) 2020 Kinetic Vision, Cincinnati Ohio.
               This software is property of SAEC Kinetic Vision, Inc
               and is considered confidential.

  @brief      SysTime software unit "H" file.

  @author     Andrew Loebs

  @defgroup   SysTimeSoftwareUnit Provides millisecond scale system time

  Configuration History
  =====================

  Config Item    | Value
  -------------- | -----
  Config #       | NA
  Revision       | NA
  Revised, Date  | NA
  QA, Date       | NA
  Approved, Date | NA
  Released, Date | NA

  Significant Modification History (Most recent at top)
  =====================================================

  Date         | Initials | Details
  ------------ | -------- | -------
  31 Jan 2020  | ASL      | Original

  Theory of Operation
  ===================
  Provides millisecond scale system time.

  */

// Define to prevent recursive inclusion -------------------------------------
#ifndef __SYS_TIME_H
#define __SYS_TIME_H

#include <stdbool.h> // bool
#include <stdint.h> // int types

#include "../StatusSu/Status.h" // status_t

// Exported macro ------------------------------------------------------------

// Exported types ------------------------------------------------------------

// Exported constants --------------------------------------------------------

// Exported objects ----------------------------------------------------------

// Exported functions --------------------------------------------------------

///  @brief Initializes the system time software unit.
///  @return StatusOk, StatusAlreadyInitialized, StatusHal.
status_t SysTime_Init(void);

///  @brief Returns milliseconds since system time was initialized.
uint32_t SysTime_GetMsElapsed(void);

///  @brief SpinLock for the passed number of milliseconds
void SysTime_Delay(uint32_t delayMs);

///  @brief Enable/Disable the sys tick timer
///  @param args[in] enable - If to enable or disable the sys tick timer
status_t SysTime_SetEnabled(bool enable);

///  @brief Returns true if current system time is greater than start time + duration.
///  @param args[in] start - start time to compare against
///  @param args[in] duration - duration from start to test
bool SysTime_IsElapsed(uint32_t start, uint32_t duration);

#endif // __SYS_TIME_H

/// SAEC Kinetic Vision, Inc. ----------- END OF FILE


