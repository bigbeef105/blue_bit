/**
  @file       usart.c

  @copyright  (C) 2019 Kinetic Vision, Cincinnati Ohio.
               This software is property of SAEC Kinetic Vision, Inc
               and is considered confidential.

  @brief      USART software unit "C" file.

  @author     Sherman Couch

  @ingroup    UsartSu

  Configuration History
  =====================

  Config Item    | Value
  -------------- | -----
  Config #       | NA
  Revision       | NA
  Revised, Date  | NA
  QA, Date       | NA
  Approved, Date | NA
  Released, Date | NA

  Significant Modification History (Most recent at top)
  =====================================================

  Date         | Initials | Details
  ------------ | -------- | -------
  28 Jan 2020  | ASL      | Porting from Resbit to Bluebit
  22 Jul 2019  | SC       | Original

  Theory of Operation
  ===================
  Usart communication will be needed for handling console commands and responses.

*/

// Includes ------------------------------------------------------------------

#include "Usart.h"
#include "app_timer.h"

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

#include "app_error.h"
#include "app_uart.h"
#include "nrf_uart.h"
#include "nrf_drv_gpiote.h"

#include "../SwUnitControlSu/SwUnitControl.h"

// Private function prototypes -----------------------------------------------
void uartErrorHandle(app_uart_evt_t * pEvent);

static status_t Enable(void);
static status_t Disable(void);

// Private macros ------------------------------------------------------------
#define returnStatus(__status__,__source__) SwUnitControl_WriteStatus(eSucUsartSu,__source__,__status__,__LINE__);

// Private constants ---------------------------------------------------------
//#define HARD_DISABLE
#define KEEP_ALIVE

#define RX_PIN_NUMBER  8
#define TX_PIN_NUMBER  6
#define CTS_PIN_NUMBER 7
#define RTS_PIN_NUMBER 5

#define UART_TX_BUF_SIZE            1024
#define UART_RX_BUF_SIZE            256

#define UART_WRITE_RETRY_COUNT      1000
#define INPUT_TIMEOUT_MS 45000

// Private types -------------------------------------------------------------

// Private constants ---------------------------------------------------------

// Private variables ---------------------------------------------------------
static bool initialized = false;
static volatile bool fifoEmpty = false;
static volatile bool uartError = false;
static volatile bool  _Input = false;
static volatile bool  _Enabled = false;

APP_TIMER_DEF(m_usart_timer_id);

// Private function bodies ---------------------------------------------------
void uartErrorHandle(app_uart_evt_t * pEvent) {
    if (pEvent->evt_type == APP_UART_COMMUNICATION_ERROR) {
        uartError = true;
    } else if (pEvent->evt_type == APP_UART_FIFO_ERROR) {
        uartError = true;
    } else if (pEvent->evt_type == APP_UART_TX_EMPTY) {
        fifoEmpty = true;
    }
}

static void single_shot_timer_handler(void * p_context) {
    if (!_Input) {
#ifndef KEEP_ALIVE
        Disable();
#endif
    } else {
        _Input = false;
        app_timer_start(m_usart_timer_id, APP_TIMER_TICKS(INPUT_TIMEOUT_MS), NULL);
    }
}

static void in_pin_handler(nrf_drv_gpiote_pin_t pin, nrf_gpiote_polarity_t action) {
    Enable();
}

static status_t EnableGpioInt(void) {
    nrf_drv_gpiote_in_config_t in_config = GPIOTE_CONFIG_IN_SENSE_TOGGLE(true);
    in_config.sense = NRF_GPIOTE_POLARITY_HITOLO;

    nrf_drv_gpiote_in_init(RX_PIN_NUMBER, &in_config, in_pin_handler);

    nrf_drv_gpiote_in_event_enable(RX_PIN_NUMBER, true);

    return StatusOk;
}

static status_t Disable(void) {
    if (!_Enabled) return StatusOk;

    // Wait for uart to empty before closing
    while (!fifoEmpty && !uartError);

    status_t ret;

    app_uart_flush();
    uint32_t err = app_uart_close(); // TODO: Check if this works
    if(0 != err){
        ret = StatusHal;
        return ret;

    } else {
        _Enabled = false;
    }

    EnableGpioInt();

    return StatusOk;
}

static status_t Enable(void) {
    if (_Enabled) return StatusOk;

    status_t status = StatusOk;

    nrfx_gpiote_in_event_disable(RX_PIN_NUMBER);
    nrf_drv_gpiote_in_uninit(RX_PIN_NUMBER);

    const app_uart_comm_params_t params =
    {
        RX_PIN_NUMBER,
        TX_PIN_NUMBER,
        RTS_PIN_NUMBER,
        CTS_PIN_NUMBER,
        APP_UART_FLOW_CONTROL_DISABLED,
        false,
        NRF_UART_BAUDRATE_115200
    };

    uint32_t err;
    APP_UART_FIFO_INIT(&params,
                       UART_RX_BUF_SIZE,
                       UART_TX_BUF_SIZE,
                       uartErrorHandle,
                       APP_IRQ_PRIORITY_LOWEST,
                       err);
    if (0 != err) {
        status = StatusHal;
    } else {
        app_uart_flush();
        _Enabled = true;
        app_timer_start(m_usart_timer_id, APP_TIMER_TICKS(INPUT_TIMEOUT_MS), NULL);
    }

    _Input = false;

    return status;
}

// Public functions bodies ---------------------------------------------------
status_t Usart_Init(void) {
	status_t status;
    status = StatusOk;

	if (initialized) {
		status = StatusAlreadyInitialized;
	}
    
#ifndef HARD_DISABLE
	if (Status_IsOk(status)) {
        app_timer_create(&m_usart_timer_id, APP_TIMER_MODE_SINGLE_SHOT, single_shot_timer_handler);
        EnableGpioInt();
	}

#ifdef KEEP_ALIVE
    Enable();
#endif // KEEP_ALIVE
#endif // HARD_DISABLE

	if (Status_IsOk(status)) {
		initialized = true;
	}

	return returnStatus(status, eSucInitStatus);
}

status_t Usart_DeInit(void) {
	status_t status = StatusOk;

	if(initialized){
        if (_Enabled) {
            app_uart_flush();
            uint32_t err = app_uart_close(); // TODO: Check if this works
            if(0 != err){
                status = StatusHal;
            }
        } else {
            nrfx_gpiote_in_event_disable(RX_PIN_NUMBER);
            nrf_drv_gpiote_in_uninit(RX_PIN_NUMBER);
        }

        initialized = false;
	}

	return status;
}

status_t Usart_Write(uint8_t *pBuffer, uint16_t length) {
    // If the usart is not initialized just ignore writes
    if(!_Enabled) return StatusOk;

	status_t status = StatusOk;

	uint32_t retryCount = 0;
    uint16_t bytesSent = 0;

    uartError = false; // clear this from previous writes
    while (1) {
        uint32_t err = app_uart_put(*pBuffer);
        if (4 == err) {
            while (!fifoEmpty && !uartError);
        } else if (0 == err) {
            pBuffer++;
            bytesSent++;
            fifoEmpty = false;
            if (bytesSent == length) {
                break;
            }
        } else {
            retryCount++;
            if (retryCount > UART_WRITE_RETRY_COUNT) {
                status = StatusHal;
                break;
            }
        }
    }

	return returnStatus(status, eSucWriteStatus);
}

status_t Usart_Read(uint8_t *pBuffer, uint16_t length, uint16_t *pBytesRead)
{
	status_t status = StatusOk;
    *pBytesRead = 0;
    while (*pBytesRead <= length) {
        uint32_t err = app_uart_get(pBuffer);
        if (0 != err) {
            break; // non-zero return means there were no bytes in the rx
        } else {
            _Input = true;
            (*pBytesRead)++;
            pBuffer++;
        }
    }

	return returnStatus(status, eSucReadStatus);
}

/// SAEC Kinetic Vision, Inc. ----------- END OF FILE
