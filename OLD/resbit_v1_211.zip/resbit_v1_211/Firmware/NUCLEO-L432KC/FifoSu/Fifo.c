/**
  @file       csvFifo_.h

  @copyright  (C) 2019 Kinetic Vision, Cincinnati Ohio.
               This software is property of SAEC Kinetic Vision, Inc
               and is considered confidential.

  @brief      CSV FIFO software unit "H" file.

  @author     Sherman Couch

  @ingroup    csvFifo_SoftwareUnit

  Configuration History
  =====================

  Config Item    | Value
  -------------- | -----
  Config #       | NA
  Revision       | NA
  Revised, Date  | NA
  QA, Date       | NA
  Approved, Date | NA
  Released, Date | NA

  Significant Modification History (Most recent at top)
  =====================================================

  Date        | Initials | Details
  ----------- | -------- | -------
  02 Aug 2019 | SRC      | Old school csvFifo_ interface, techniques from Pleistocene.

  Theory of Operation
  ===================
  Buffers CSV data.  The buffer size is tuned inside the software unit. The "write" caller
  should expect data to be buffered (no fragmentation is expected by the caller).
  The "read" caller must deal with fragmentation.  This allows the "writer" to operate at
  elevated IRQL, and not block.  Whereas the "reader" can operate at foreground IRQL and
  can be interrupted.

  */


// Includes ------------------------------------------------------------------

#include "Fifo.h"

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

#include "../StatusSu/Status.h"
#include "../ConsoleSu/Console.h"
#include "../SwUnitControlSu/SwUnitControl.h"

// Private constants ---------------------------------------------------------

// Private macro -------------------------------------------------------------

// This macro feeds status information for tracking purposes to software unit control.
#define returnStatus(__status__,__source__) SwUnitControl_WriteStatus(eSucFifoSu,__source__,__status__,__LINE__);

#define SETUP_SIGNATURE     0x55AAaa55
#define MAGIC_NUMBER        0x01201961

#define FIFO_LEN            10000

// Private types -------------------------------------------------------------
typedef struct {
    uint32_t magicNumber;
    uint16_t minAvailable;
    uint16_t head;
    uint16_t tail;
    uint8_t buffer[FIFO_LEN];
    uint32_t setupSignature;
} fifo_t;

// Private function prototypes -----------------------------------------------
static status_t fifoCli(uint16_t argc, uint8_t **argv);

static void reset(fifo_t *q);

static uint16_t getUsed(fifo_t *q);
static uint16_t getAvailable(fifo_t *q);
static bool validateSetup(fifo_t *q);


// Private constants ---------------------------------------------------------
static const consoleCommand_t commandList[] = {
	{
		.pCommand = "fifo",
		.pUsage = "Fifo statistics\r\n\t"	"usage: fifo [zero]",
		.pHandlerFn = fifoCli,
	},

	// Marks last element in the list
	{ NULL, NULL, NULL },
};

// Private variables ---------------------------------------------------------
static fifo_t fifo;
static bool initialized = false;

static consoleRegistration_t exportedReg = {
    (consoleCommand_t *) commandList, // .pList =
    NULL, // .pNext =
};

// Private functions ---------------------------------------------------------
static status_t fifoCli(uint16_t argc, uint8_t **argv)
{
	uint8_t buff[132];
	status_t status;

	status = StatusOk;

	// Stats can be displayed or zeroized.  Which one are we doing?
	if (argc > 1) {
		if (0 == strcmp("zero", argv[1])) {
			fifo.minAvailable = 0xffff;
		}
	} else {

		sprintf(buff, "magicNumber: %lu\r\n", fifo.magicNumber);
		Console_WriteString(buff);

		sprintf(buff, "minAvailable: %u\r\n", fifo.minAvailable);
		Console_WriteString(buff);

		sprintf(buff, "allocated sizeof buffer: %u\r\n", sizeof(fifo.buffer));
		Console_WriteString(buff);

		sprintf(buff, "Percent Used: %lu%%\r\n", (100l*((uint32_t) fifo.minAvailable))/sizeof(fifo.buffer));
		Console_WriteString(buff);

		sprintf(buff, "head: %u\r\n", fifo.head);
		Console_WriteString(buff);

		sprintf(buff, "tail: %u\r\n", fifo.tail);
		Console_WriteString(buff);

		sprintf(buff, "setupSignature: %lu\r\n", fifo.setupSignature);
		Console_WriteString(buff);

	}

	return status;

}

static void reset(fifo_t *q)
{
    q->setupSignature = SETUP_SIGNATURE;
    q->magicNumber = MAGIC_NUMBER;
    q->head = q->tail = 0;
    q->minAvailable = 0xFFFF;
}

static uint16_t getUsed(fifo_t *q)
{
    int32_t used = q->tail - q->head;
    // handle wrap
    if (used < 0) used += sizeof(q->buffer);
    return (uint16_t)used;
}

static uint16_t getAvailable(fifo_t *q)
{
    // We have to leave the head/tail separated by 1 when we're full
    // to differentiate between full/empty, so our capacity is 1 less
    // than the buffer length
    return (uint16_t)((sizeof(q->buffer) - 1) - getUsed(q));
}

static bool validateSetup(fifo_t *q)
{
    if ((q->setupSignature != SETUP_SIGNATURE) || (q->magicNumber != MAGIC_NUMBER)) {
        return false;
    } else {
        return true;
    }
}


// Public functions --------------------------------------------------------
status_t Fifo_Init(void)
{
    status_t status;
    status = StatusOk;

    if (initialized) {
        status = StatusAlreadyInitialized;
    }

    if (StatusOk == status) {
        reset(&fifo);
        status = Console_ExportCommandsToCli (&exportedReg, commandList);
    }

    if (StatusOk == status) {
        // Record a successful initialization
        initialized = true;
    }

    return returnStatus(status, eSucInitStatus);
}

status_t Fifo_Reset(void)
{
    reset(&fifo);
    
    return returnStatus(StatusOk, eSucIoctlStatus);
}

status_t Fifo_Write(uint8_t * data, uint16_t len)
{
    status_t status = StatusOk;
    
    // Validate state, input
    if (!initialized) {
        status = StatusNotInitialized;
    } else if (!validateSetup(&fifo)) {
        status = StatusQueueSetup;
    } else if (!data) {
        status = StatusNullParameter;
    }
    
    // Make sure we have room to insert
    uint16_t available = 0;
    if (StatusOk == status) {
        available = getAvailable(&fifo);
        if (available < len) {
            status = StatusSpaceAvailable;
        }
    }
    
    // Insert
    if (StatusOk == status) {
        uint16_t remaining = len;
        
        // Insert as many as possible before wrap-around
        uint16_t bytesToBufferEnd = sizeof(fifo.buffer) - fifo.tail;
        uint16_t writeLen = (bytesToBufferEnd > remaining) ? remaining : bytesToBufferEnd;
        
        memcpy(&fifo.buffer[fifo.tail], data, writeLen);
        remaining -= writeLen;
        
        // Update tail pointer
        fifo.tail += writeLen;
        if (fifo.tail >= sizeof(fifo.buffer)) {
            fifo.tail -= sizeof(fifo.buffer); // handle wrap-around
        }
            
        // Write the rest at front of buffer if needed
        if (remaining > 0) {
            memcpy(&fifo.buffer[0], &data[writeLen], remaining);
            // Update tail pointer
            fifo.tail += remaining;
        }
    }

    // Update statistic
    if (StatusOk == status) {
        available = getAvailable(&fifo);
        if (available < fifo.minAvailable) {
            fifo.minAvailable = available;
        }
    }
    
#ifdef SWO_PROFILE_BUILD
    // Make it so that fifo never overflows
    fifo.head = fifo.tail;
#endif

    return returnStatus(status, eSucWriteStatus);
}

status_t Fifo_Read(uint8_t * out, uint16_t len)
{
    status_t status = StatusOk;
    
    // Validate state, input
    if (!initialized) {
        status = StatusNotInitialized;
    } else if (!validateSetup(&fifo)) {
        status = StatusQueueSetup;
    } else if (!out) {
        status = StatusNullParameter;
    }
    
    // Make sure we have enough bytes to write out
    uint16_t used = 0;
    if (StatusOk == status) {
        used = getUsed(&fifo);
        if (used < len) {
            status = StatusSpaceAvailable;
        }
    }
    
    // Remove
    if (StatusOk == status) {
        uint16_t remaining = len;
        
        // Remove as many as possible before wrap-around
        uint16_t bytesToBufferEnd = sizeof(fifo.buffer) - fifo.head;
        uint16_t readLen = (bytesToBufferEnd > remaining) ? remaining : bytesToBufferEnd;
        
        memcpy(out, &fifo.buffer[fifo.head], readLen);
        remaining -= readLen;
        
        // Update head pointer
        fifo.head += readLen;
        if (fifo.head >= sizeof(fifo.buffer)) {
            fifo.head -= sizeof(fifo.buffer); // handle wrap-around
        }
            
        // Read the rest from front of buffer if needed
        if (remaining > 0) {
            memcpy(&out[readLen], &fifo.buffer[0], remaining);
            // Update head pointer
            fifo.head += remaining;
        }
    }

    return returnStatus(status, eSucReadStatus);
}

status_t Fifo_GetCount(uint16_t * numBytes)
{
    status_t status = StatusOk;
    
    // Validate state, input
    if (!initialized) {
        status = StatusNotInitialized;
    } else if (!validateSetup(&fifo)) {
        status = StatusQueueSetup;
    } else if (!numBytes) {
        status = StatusNullParameter;
    }
    
    if (StatusOk == status) {
        *numBytes = getUsed(&fifo);
    }

    return returnStatus(status, eSucIoctlStatus);
}

status_t Fifo_GetAvailable(uint16_t * numBytes)
{
    status_t status = StatusOk;
    
    // Validate state, input
    if (!initialized) {
        status = StatusNotInitialized;
    } else if (!validateSetup(&fifo)) {
        status = StatusQueueSetup;
    } else if (!numBytes) {
        status = StatusNullParameter;
    }
    
    if (StatusOk == status) {
        *numBytes = getAvailable(&fifo);
    }

    return returnStatus(status, eSucIoctlStatus);
}
