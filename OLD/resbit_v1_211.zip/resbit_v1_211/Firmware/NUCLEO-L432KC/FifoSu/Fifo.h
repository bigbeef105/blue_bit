/**
  @file       Fifo_.h

  @copyright  (C) 2019 Kinetic Vision, Cincinnati Ohio.
               This software is property of SAEC Kinetic Vision, Inc
               and is considered confidential.

  @brief      FIFO software unit "H" file.

  @author     Sherman Couch

  @defgroup   Fifo_SoftwareUnit This software unit buffers lines of CSV data.

  Configuration History
  =====================

  Config Item    | Value
  -------------- | -----
  Config #       | NA
  Revision       | NA
  Revised, Date  | NA
  QA, Date       | NA
  Approved, Date | NA
  Released, Date | NA

  Significant Modification History (Most recent at top)
  =====================================================

  Date        | Initials | Details
  ----------- | -------- | -------
  07 May 2020 | ASL      | Updated to hold binary (not yet CSV) data
  02 Aug 2019 | SRC      | Old school csvFifo_ interface, techniques from Pleistocene.

  Theory of Operation
  ===================
  Buffers data.  The buffer size is tuned inside the software unit. The "write" caller
  should expect data to be buffered (no fragmentation is expected by the caller).
  The "read" caller must deal with fragmentation.  This allows the "writer" to operate at
  elevated IRQL, and not block.  Whereas the "reader" can operate at foreground IRQL and
  can be interrupted.

  */


// Define to prevent recursive inclusion -------------------------------------
#ifndef __FIFO_H
#define __FIFO_H

#include <stdint.h>
#include "../StatusSu/Status.h"

// Exported macro ------------------------------------------------------------

// Exported types ------------------------------------------------------------

// Exported constants --------------------------------------------------------

// Exported objects ----------------------------------------------------------

// Exported functions --------------------------------------------------------

///  @brief Initializes the software unit
///  @return StatusOK when properly initialized
status_t Fifo_Init(void);

///  @brief Resets the head/tail pointers & re-writes magic numbers
///  @return StatusOk
status_t Fifo_Reset(void);

///  @brief Writes a block of data to the FIFO (buffer).
///  @details If not successful, the caller should accumulate a statistic, but is not to retry.
///  @param[in] data - pointer to data to be written to fifo
///  @param[in] len - number of bytes to be written to fifo
///  @return StatusOK when written. Any other status return indicates the data was not buffered.
status_t Fifo_Write(uint8_t * data, uint16_t len);

///  @brief Reads data from the buffer.
///  @param[out] out - buffer to receive read data
///  @param[in] len - number of bytes to read
///  @return StatusOK when data was read successfully
status_t Fifo_Read(uint8_t * out, uint16_t len);

///  @brief Returns the number of bytes stored in the fifo.
///  @param[out] numBytes - number of bytes stored.
///  @return StatusOK
status_t Fifo_GetCount(uint16_t * numBytes);

///  @brief Returns the number of bytes available in the fifo.
///  @param[out] numBytes - number of bytes available.
///  @return StatusOK
status_t Fifo_GetAvailable(uint16_t * numBytes);

#endif // _FIFO_H

/// SAEC Kinetic Vision, Inc. ----------- END OF FILE

