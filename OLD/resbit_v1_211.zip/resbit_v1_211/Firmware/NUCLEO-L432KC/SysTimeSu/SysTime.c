/**
  @file       SysTime.c

  @copyright  (C) 2020 Kinetic Vision, Cincinnati Ohio.
               This software is property of SAEC Kinetic Vision, Inc
               and is considered confidential.

  @brief      SysTime software unit "C" file.

  @author     Andrew Loebs

  @ingroup    SysTimeSoftwareUnit

  Configuration History
  =====================

  Config Item    | Value
  -------------- | -----
  Config #       | NA
  Revision       | NA
  Revised, Date  | NA
  QA, Date       | NA
  Approved, Date | NA
  Released, Date | NA

  Significant Modification History (Most recent at top)
  =====================================================

  Date         | Initials | Details
  ------------ | -------- | -------
  31 Jan 2020  | ASL      | Original

  Theory of Operation
  ===================
  Provides millisecond scale system time.

*/

// Includes ------------------------------------------------------------------

#include "SysTime.h"

#include "stm32l4xx_hal.h"

#include "../SwUnitControlSu/SwUnitControl.h" // SwUnitControl_WriteStatus()
#include "../ConsoleSu/Console.h" // Console_* functions, consoleCommand_t

// Private function prototypes -----------------------------------------------

// Private macros ------------------------------------------------------------
#define returnStatus(__status__,__source__) SwUnitControl_WriteStatus(eSucSysTimeSu,__source__,__status__,__LINE__);

// Private constants ---------------------------------------------------------

// Private types -------------------------------------------------------------

// Private constants ---------------------------------------------------------

// Private variables ---------------------------------------------------------
static bool initialized = false;

// Private function bodies ---------------------------------------------------

// Public functions bodies ---------------------------------------------------
status_t SysTime_Init(void)
{
    status_t status = StatusOk;

    if (initialized)
        status = StatusAlreadyInitialized;

    return returnStatus(status, eSucInitStatus);
}

uint32_t SysTime_GetMs(void)
{
    return HAL_GetTick();
}

bool SysTime_IsElapsed(uint32_t start, uint32_t duration)
{
	return (SysTime_GetElapsed(start) >= duration);
}

uint32_t SysTime_GetElapsed(uint32_t start)
{
	return SysTime_GetMs() - start;
}

/// SAEC Kinetic Vision, Inc. ----------- END OF FILE
