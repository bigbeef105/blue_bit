/**
 @file       BlueBits.c

 @copyright  (C) 2020 Kinetic Vision, Cincinnati Ohio.
 This software is property of SAEC Kinetic Vision, Inc
 and is considered confidential.

 @brief      BlueBits software unit "C" file.

 @author     aloebs

 @ingroup    BlueBitsSoftwareUnit

 Configuration History
 =====================

 Config Item    | Value
 -------------- | -----
 Config #       | NA
 Revision       | NA
 Revised, Date  | NA
 QA, Date       | NA
 Approved, Date | NA
 Released, Date | NA

 Significant Modification History (Most recent at top)
 =====================================================

 Date         | Initials | Details
 ------------ | -------- | -------
 Feb 20, 2020 | ASL      | Original

 Theory of Operation
 ===================
 In the view of many colonists, British rule suppressed political, economic, and
 religious freedoms. Many of those that hesitated to support independence were soon convinced
 by the passionate words of THOMAS PAINE, SAMUEL ADAMS, PATRICK HENRY, and eventually JOHN
 ADAMS and Thomas Jefferson. Crispus Attucks ( c. 1723 – March 5, 1770) widely regarded as the
 first person killed in the Boston Massacre and thus the first American killed in the
 American Revolution. The Declaration of Independence in 1776, the American Revolution,
 and the creation of the Articles of Confederation represent the American colonies' first
 attempt to become a nation.

 */

// Includes ------------------------------------------------------------------
#include "BlueBits.h"

#include <assert.h>
#include <string.h>

#include "../SwUnitControlSu/SwUnitControl.h" // SwUnitControl_WriteStatus, eSucs
#include "../ConfigSu/Config.h" // Config_* functions
#include "../MessagerSu/Messager.h" // Messager_* functions
#include "../SysTimeSu/SysTime.h" // SysTime_* functions
#include "../ConsoleSu/Console.h" // Console_WriteString()
#include "../PowerSu/power.h" // pubPowerStateId_t
#include "../DeviceInfoSu/DeviceInfo.h" // version_t, uuid_t, DeviceInfo_* functions

// Private macros ------------------------------------------------------------
#define returnStatus(__status__,__source__) SwUnitControl_WriteStatus(eSucBlueBitsSu,__source__,__status__,__LINE__)

// Private constants ---------------------------------------------------------
#define SEND_BLOCKING_TIMEOUT			500 // ms

#define SET_POWER_STATE_MESSAGE_ID		0x0001
#define WHO_AM_I_MESSAGE_ID				0x0002
#define SUMMARY_DATA_MESSAGE_ID			0x0100
#define CONFIG_MESSAGE_ID               0x0101
#define SET_RESBIT_INFO_ID				0x0102

#define BLUEBITS_DEVICE_ID				0x0001

#define CONFIG_DATA_MAX_SIZE            4

#define CONFIG_RESPONSE_SUCCESS         0x00
#define CONFIG_RESPONSE_UNKNOWN_ID      0x01
#define CONFIG_RESPONSE_DATA_LENGTH     0x02
#define CONFIG_RESPONSE_DATA_VALUE      0x03

#define WHOAMI_RETRY_TIMEOUT            5000 // ms

// Private types -------------------------------------------------------------

typedef struct {
	uint16_t deviceId;
	version_t hardwareVersion;
	version_t softwareVersion;
	version_t firmwareVersion;
} whoami_t;

typedef struct {
	serialNum_t hardwareSerialNum;
	version_t hardwareVersion;
	version_t firmwareVersion;
} resbitInfo_t;

typedef enum {
    bleConfigIdAdvertOnTime = 0,
    bleConfigIdAdvertOffTimeMin,
    bleConfigIdAdvertOffTimeMax,
    bleConfigIdAlwaysAdvertise,
    bleConfigIdAdvertInterval,
} bleConfigIds_t;

typedef enum {
    bleConfigResponsesSuccess = 0,
    bleConfigResponsesUnknownId,
    bleConfigResponsesDataLength,
    bleConfigResponsesDataValue,
} bleConfigResponses_t;

typedef struct {
    bleConfigIds_t id;
    size_t configDataLen;
    configIoctl_t configIoctlCode;
} bleConfigVariables_t;

// Private constants ---------------------------------------------------------
static const bleConfigVariables_t bleConfigVariables[] = {
        { bleConfigIdAdvertOnTime, 2, configIoctlGetBleAdvertOnTime },
        { bleConfigIdAdvertOffTimeMin, 2, configIoctlGetBleAdvertOffTimeMin },
        { bleConfigIdAdvertOffTimeMax, 2, configIoctlGetBleAdvertOffTimeMax },
        { bleConfigIdAlwaysAdvertise, 1, configIoctlGetBleAlwaysAdvertise },
        { bleConfigIdAdvertInterval, 2, configIoctlGetBleAdvertInterval },
};

// Private variables ---------------------------------------------------------
static bool initialized = false;

// Private function prototypes -----------------------------------------------
static status_t sendPowerStateResHandler(responseHandlerArgs_t * args);
static status_t tryWhoami(uint32_t timeout);
static status_t sendWhoami(void);
static status_t parseWhoami(const uint8_t * res, uint8_t resLen,
		whoami_t * whoamiOut);
static status_t sendSetResbitInfo(void);
static status_t sendConfig(void);
static status_t parseConfigResponse(uint8_t *response, size_t len, bleConfigIds_t id);

// Private function bodies ---------------------------------------------------
static status_t sendPowerStateResHandler(responseHandlerArgs_t * args) {
	return Messager_ResCodeToStatus(args->resCode);
}

static status_t tryWhoami(uint32_t timeout) {
    status_t status = StatusCodePath; // as long as retryLimit isn't 0, this will be overwritten
    
    uint32_t startTime = SysTime_GetMs();
    while (!SysTime_IsElapsed(startTime, timeout) && !Status_IsOk(status)) {
        status = sendWhoami();
    }
    
    return status;
}

static status_t sendWhoami(void) {
	status_t status = StatusOk;

	sendMessageArgs_t args = {
			.messageId = WHO_AM_I_MESSAGE_ID,
			.messageData = NULL,
			.dataLen = 0,
			.timeoutMs = SEND_BLOCKING_TIMEOUT,
	};
	status = Messager_SendMessage(&args);

	if (Status_IsOk(status)) {
		status = Messager_ResCodeToStatus(args.resCode);
	}
	whoami_t whoami;
	if (Status_IsOk(status)) {
		parseWhoami(args.resData, args.resLen, &whoami);
	}

	if (Status_IsOk(status)) {
		if (whoami.deviceId != BLUEBITS_DEVICE_ID) {
			status = StatusDeviceId;
		}
	}

	// TODO: Delete, for testing
	if (Status_IsOk(status)) {
		char outBuffer[140];
		sprintf(outBuffer,
				"BlueBits found:\r\nHardware version: %d.%d.%d.%d\r\nSoftware version: %d.%d.%d.%d\r\nFirmware version: %d.%d.%d.%d\r\n\r\n> ",
				whoami.hardwareVersion.major, whoami.hardwareVersion.minor,
				whoami.hardwareVersion.revision, whoami.hardwareVersion.build,
				whoami.softwareVersion.major, whoami.softwareVersion.minor,
				whoami.softwareVersion.revision, whoami.softwareVersion.build,
				whoami.firmwareVersion.major, whoami.firmwareVersion.minor,
				whoami.firmwareVersion.revision, whoami.firmwareVersion.build);

		Console_WriteString(outBuffer);
	}

	return status;
}

static status_t parseWhoami(const uint8_t * res, uint8_t resLen,
		whoami_t * whoamiOut) {
	status_t status = StatusOk;

	if (resLen != sizeof(whoami_t)) {
		status = StatusBufferLength;
	}

	if (Status_IsOk(status)) {
		memcpy(whoamiOut, res, resLen);
	}

	return status;
}

static status_t sendSetResbitInfo(void) {
	status_t status = StatusOk;

	// Get device info
	resbitInfo_t resbitInfo;
	status = DeviceInfo_GetSerialNum(&resbitInfo.hardwareSerialNum);
	if (Status_IsOk(status))
		status = DeviceInfo_GetHardwareVersion(&resbitInfo.hardwareVersion);
	if (Status_IsOk(status))
		status = DeviceInfo_GetFirmwareVersion(&resbitInfo.firmwareVersion);
	
	// Send message
	if (Status_IsOk(status)) {
		sendMessageArgs_t args = {
				.messageId = SET_RESBIT_INFO_ID,
				.messageData = (uint8_t *)&resbitInfo,
				.dataLen = sizeof(resbitInfo),
				.timeoutMs = SEND_BLOCKING_TIMEOUT,
		};
		status = Messager_SendMessage(&args);
		if (Status_IsOk(status)) {
			status = Messager_ResCodeToStatus(args.resCode);
		}
	}

	return status;
}

static status_t sendConfig(void) {
    status_t status = StatusOk;
    
    for (int i = 0; i < (sizeof(bleConfigVariables) / sizeof (*bleConfigVariables)); i++) {
        // Populate message data
        assert(bleConfigVariables[i].configDataLen <= CONFIG_DATA_MAX_SIZE);
        size_t configIdSize = sizeof(bleConfigVariables[i].id);
        uint8_t messageData[configIdSize + CONFIG_DATA_MAX_SIZE];
        memcpy(messageData, &bleConfigVariables[i].id, configIdSize);
        if (Status_IsOk(status)) {
            status = Config_Ioctl(bleConfigVariables[i].configIoctlCode, 
                    messageData + configIdSize);
        }
        
        if (Status_IsOk(status)) {
            sendMessageArgs_t args = {
                    .messageId = CONFIG_MESSAGE_ID,
                    .messageData = messageData,
                    .dataLen = configIdSize + bleConfigVariables[i].configDataLen,
                    .timeoutMs = SEND_BLOCKING_TIMEOUT,
            };
            status = Messager_SendMessage(&args);
            // Validate message success
            if (Status_IsOk(status)) {
                status = Messager_ResCodeToStatus(args.resCode);
            }
            // Validate config variable update success
            if (Status_IsOk(status)) {
                status = parseConfigResponse(args.resData, args.resLen, bleConfigVariables[i].id);
            }
        }
    }
    
    return status;
}

static status_t parseConfigResponse(uint8_t *response, size_t len, bleConfigIds_t id) {
    status_t status = StatusOk;
    uint8_t stringBuff[80];
    uint8_t configResponseCode = 0;
    if (sizeof(configResponseCode) == len) {
        memcpy(&configResponseCode, response, len);
        if (bleConfigResponsesSuccess != configResponseCode) {                        
            snprintf(stringBuff, sizeof(stringBuff), 
                    "Bluebits send config variable response code %u on config Id %u\r\n> ", 
                    configResponseCode, id);
            Console_WriteString(stringBuff);
            status = StatusSendConfig;
        }
    } else {
        snprintf(stringBuff, sizeof(stringBuff), 
                "Bluebits send config variable bad response length %u on config Id %u\r\n> ", 
                len, id);
        Console_WriteString(stringBuff);
        status = StatusSendConfig;
    }
    
    return status;
}

// Public functions bodies ---------------------------------------------------
status_t BlueBits_Init(void) {
	status_t status = StatusOk;

	if (initialized) {
		status = StatusAlreadyInitialized;
	}

	if (Status_IsOk(status)) {
		if (BlueBits_IsEnabled()) {
			status = tryWhoami(WHOAMI_RETRY_TIMEOUT);
			if (Status_IsOk(status)) {
			    status = sendConfig();
			}
			if (Status_IsOk(status)) {
				status = BlueBits_SendPowerState(publicStateAwake);
			}
			if (Status_IsOk(status)) {
				status = sendSetResbitInfo();
			}
			if (Status_IsOk(status)) {
				initialized = true;
			}
		}
	}

	return returnStatus(status, eSucInitStatus);
}

status_t BlueBits_SendPowerState(publicState_t powerState) {
	status_t status = StatusOk;

	uint16_t temp = (uint16_t) powerState;

	if (initialized) {
		sendMessageArgs_t args = {
				.messageId = SET_POWER_STATE_MESSAGE_ID,
				.messageData = (uint8_t *) &temp,
				.dataLen = sizeof(temp),
				.timeoutMs = SEND_BLOCKING_TIMEOUT,
		};
		status = Messager_SendMessage(&args);
		if (Status_IsOk(status)) {
			status = Messager_ResCodeToStatus(args.resCode);
		}
	}

	return returnStatus(status, eSucWriteStatus);
}

status_t BlueBits_SendPowerStateAsync(publicState_t powerState) {
	status_t status = StatusOk;

	if (initialized) {
		uint16_t temp = (uint16_t)powerState;
		sendMessageAsyncArgs_t args = {
				.messageId = SET_POWER_STATE_MESSAGE_ID,
				.messageData = (uint8_t *)&temp,
				.dataLen = sizeof(temp),
				.resHandler = sendPowerStateResHandler,
		};
		status = Messager_SendMessageAsync(&args);
	}

	return returnStatus(status, eSucWriteStatus);
}

status_t BlueBits_SendSummaryData(uint8_t * data, size_t len) {
	status_t status = StatusOk;

	if (initialized) {
		sendMessageArgs_t args = {
				.messageId = SUMMARY_DATA_MESSAGE_ID,
				.messageData = data,
				.dataLen = len,
				.timeoutMs = SEND_BLOCKING_TIMEOUT,
		};
		status = Messager_SendMessage(&args);
		if (Status_IsOk(status)) {
			status = Messager_ResCodeToStatus(args.resCode);
		}
	}

	return returnStatus(status, eSucWriteStatus);
}

bool BlueBits_IsEnabled(void) {
	configEnableState_t enabled = settingDisable;
	Config_Ioctl(configIoctlGetBluebitEnabled, (uint8_t *) &enabled);
	return (settingEnable == enabled);
}

/// SAEC Kinetic Vision, Inc. ----------- END OF FILE
