/**
  @file       rtc.c

  @copyright  (C) 2019 Kinetic Vision, Cincinnati Ohio.
               This software is property of SAEC Kinetic Vision, Inc
               and is considered confidential.

  @brief      RTC software unit "C" file.

  @author     Parker Kamer

  @ingroup    RtcSu

  Configuration History
  =====================

  Config Item    | Value
  -------------- | -----
  Config #       | NA
  Revision       | NA
  Revised, Date  | NA
  QA, Date       | NA
  Approved, Date | NA
  Released, Date | NA

  Significant Modification History (Most recent at top)
  =====================================================

  Date         | Initials | Details
  ------------ | -------- | -------
  24 Jul 2019  | PK       | Original

  Theory of Operation
  ===================
  The Real time clock will be used to gather timing data for each study. THe RTC's
  wakeup interrupt will also be used to turn on periodically so the unit can gather
  data.

*/

// Includes ------------------------------------------------------------------

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <time.h>

#include "stm32l4xx_hal.h"
#include "../StatusSu/Status.h"
#include "../ConsoleSu/Console.h"
#include "../SwUnitControlSu/SwUnitControl.h"
#include "rtc.h"
#include "../ConfigSu/Config.h"
#include "main.h"

// Private function prototypes -----------------------------------------------
static status_t cliRtcReadCommand(uint16_t argc, uint8_t **argv);
static status_t cliRtcWriteCommand(uint16_t argc, uint8_t **argv);

// Private macros ------------------------------------------------------------
/// This macro feeds status information for tracking purposes to software unit control.
#define returnStatus(__status__,__source__) SwUnitControl_WriteStatus(eSucRtcSu,__source__,__status__,__LINE__);

// Private constants ---------------------------------------------------------
#define MIN_ALARM_TIME_SECONDS		1

#define HI_RES_WAKEUP_CUTOFF		30 // sec
#define HI_RES_PERIOD_MULTIPLIER	2048UL
// Private types -------------------------------------------------------------

// Private constants ---------------------------------------------------------

// Private variables ---------------------------------------------------------
RTC_HandleTypeDef hrtc;

static const consoleCommand_t commandList[] = {
	{ "read-rtc", "usage: read current time from the rtc", cliRtcReadCommand },
	{ "write-rtc", "usage: write a start time to the rtc", cliRtcWriteCommand },
    { NULL, NULL, NULL },
};
static consoleRegistration_t exportedReg;
static bool initialized = false;

uint8_t DaysInMonths[12] = {31,28,31,30,31,30,31,31,30,31,30,31};

// Private function bodies ---------------------------------------------------
static status_t uint32_ConvertAtoi(uint8_t *a, uint32_t *pN)
{
	uint32_t n;

	if (NULL == a) {
		return StatusNullParameter;
	}

	// Number format 0x__?
	if ( (strlen(a) > 2) && ('0' == a[0]) && ('x' == a[1]) ) {
		sscanf(&a[2], "%lx", &n);
	} else {
		n = atoi(a);
	}

	*pN = n;

	return StatusOk;
} //uint32_ConvertAtoi

static status_t cliRtcReadCommand(uint16_t argc, uint8_t **argv)
{
	status_t status;
	rtcDataHandler_t rtcData;
	char buff[50];

	status = StatusOk;

	RTC_ReadTime(&rtcData);

	unsigned int dateTimeBuff[7];
	dateTimeBuff[0] = rtcData.rtcDateData.months;
	dateTimeBuff[1] = rtcData.rtcDateData.days;
	dateTimeBuff[2] = rtcData.rtcDateData.years;
	dateTimeBuff[3] = rtcData.rtcTimeData.hours;
	dateTimeBuff[4] = rtcData.rtcTimeData.minutes;
	dateTimeBuff[5] = rtcData.rtcTimeData.seconds;
	dateTimeBuff[6] = rtcData.rtcTimeData.milliseconds;

	sprintf(buff, "Time %02i/%02i/%02i %02i:%02i:%02i:%03u\r\n", dateTimeBuff[0],dateTimeBuff[1],dateTimeBuff[2],dateTimeBuff[3],
																	dateTimeBuff[4],dateTimeBuff[5],dateTimeBuff[6]);
	Console_WriteString(buff);

	return status;
} //rtcReadCommand

static status_t cliRtcWriteCommand(uint16_t argc, uint8_t **argv)
{
	status_t status;
	rtcDataHandler_t rtcData;

	status = StatusOk;

	uint32_t month;
	uint32_t day;
	uint32_t year;
	uint32_t hour;
	uint32_t minute;
	uint32_t second;

	if (StatusOk == status) {
		status = uint32_ConvertAtoi(argv[1], &month);
	}
	if (StatusOk == status) {
		status = uint32_ConvertAtoi(argv[2], &day);
	}
	if (StatusOk == status) {
		status = uint32_ConvertAtoi(argv[3], &year);
	}
	if (StatusOk == status) {
		status = uint32_ConvertAtoi(argv[4], &hour);
	}
	if (StatusOk == status) {
		status = uint32_ConvertAtoi(argv[5], &minute);
	}
	if (StatusOk == status) {
		status = uint32_ConvertAtoi(argv[6], &second);
	}

	rtcData.rtcDateData.months = month;
	rtcData.rtcDateData.days = day;
	rtcData.rtcDateData.years = year;
	rtcData.rtcTimeData.hours = hour;
	rtcData.rtcTimeData.minutes = minute;
	rtcData.rtcTimeData.seconds = second;

	RTC_WriteTime(&rtcData);

	return status;
} //rtcWriteCommand

// Public functions bodies ---------------------------------------------------
void HAL_RTC_MspInit(RTC_HandleTypeDef* hrtc)
{
  if(hrtc->Instance==RTC)
  {
    /* Peripheral clock enable */
    __HAL_RCC_RTC_ENABLE();
    /* RTC interrupt Init */
    HAL_NVIC_SetPriority(RTC_WKUP_IRQn, 5, 15);
    HAL_NVIC_EnableIRQ(RTC_WKUP_IRQn);

    HAL_NVIC_SetPriority(RTC_Alarm_IRQn, 5, 15);
    HAL_NVIC_EnableIRQ(RTC_Alarm_IRQn);
  }

} //HAL_RTC_MspInit

status_t RTC_Init(void)
{	
	status_t status = StatusOk;

	if(initialized){
		status = StatusAlreadyInitialized;
	}

	if (StatusOk == status) {
		hrtc.Instance = RTC;
		hrtc.Init.HourFormat = RTC_HOURFORMAT_24;
		hrtc.Init.AsynchPrediv = 127;
		hrtc.Init.SynchPrediv = 255;
		hrtc.Init.OutPut = RTC_OUTPUT_DISABLE;
		hrtc.Init.OutPutRemap = RTC_OUTPUT_REMAP_NONE;
		hrtc.Init.OutPutPolarity = RTC_OUTPUT_POLARITY_HIGH;
		hrtc.Init.OutPutType = RTC_OUTPUT_TYPE_OPENDRAIN;
		if (HAL_RTC_Init(&hrtc) != HAL_OK)
		{
		 status = StatusHal;
		}
	}

	if (StatusOk == status) {
		//Use the Rtc value from the config file on start up
		rtcDataHandler_t rtcData;
		status = Config_Ioctl(configIoctlGetRtc, (uint8_t *)&rtcData);

		if(StatusOk == status){
			//Check for valid time parameters
			if(12 < rtcData.rtcDateData.months || 1 > rtcData.rtcDateData.months){
				rtcData.rtcDateData.months = 1;
			}
			if(31 < rtcData.rtcDateData.days || 1 > rtcData.rtcDateData.days){
				rtcData.rtcDateData.days = 0;
			}
			if(99 < rtcData.rtcDateData.years || 0 > rtcData.rtcDateData.years){
				rtcData.rtcDateData.years = 0;
			}
			if(23 < rtcData.rtcTimeData.hours || 0 > rtcData.rtcTimeData.hours){
				rtcData.rtcTimeData.hours = 0;
			}
			if(59 < rtcData.rtcTimeData.minutes || 0 > rtcData.rtcTimeData.minutes){
				rtcData.rtcTimeData.minutes = 0;
			}
			if(59 < rtcData.rtcTimeData.seconds || 0 > rtcData.rtcTimeData.seconds){
				rtcData.rtcTimeData.seconds = 0;
			}
			status = RTC_WriteTime(&rtcData);
		}
		if(StatusOk == status){
			status = Console_ExportCommandsToCli (&exportedReg, commandList);
			initialized = true;
		}
	}

	return returnStatus(status, eSucInitStatus);

} //RTC_Init

status_t RTC_ReadTime(rtcDataHandler_t* rtcReturnData)
{
	RTC_DateTypeDef sDate = {0};
	RTC_TimeTypeDef sTime = {0};
	HAL_StatusTypeDef halStatus = HAL_OK;
	status_t status = StatusOk;

	halStatus = HAL_RTC_GetTime(&hrtc, &sTime, RTC_FORMAT_BIN);
	if(HAL_OK != halStatus){
		status = StatusHal;
	}

	if(StatusOk == status){
		halStatus = HAL_RTC_GetDate(&hrtc, &sDate, RTC_FORMAT_BIN);
		if(HAL_OK != halStatus){
			status = StatusHal;
		}
	}

	if(StatusOk == status){
		rtcReturnData->rtcDateData.years = sDate.Year;
		rtcReturnData->rtcDateData.months = sDate.Month;
		rtcReturnData->rtcDateData.days = sDate.Date;

		rtcReturnData->rtcTimeData.hours = sTime.Hours;
		rtcReturnData->rtcTimeData.minutes = sTime.Minutes;
		rtcReturnData->rtcTimeData.seconds = sTime.Seconds;

		//Second fraction ratio * time_unit= [(SecondFraction-SubSeconds)/(SecondFraction+1)] * time_unit
		float subSecondsVal = (float)sTime.SubSeconds;
		float fractionSecondsVal = (float)sTime.SecondFraction;
		float subSecondRatio = ((fractionSecondsVal-subSecondsVal)/(fractionSecondsVal+1));
		rtcReturnData->rtcTimeData.milliseconds = (uint32_t)(subSecondRatio * 1000);
	}

	return returnStatus(status, eSucReadStatus);

} //RTC_ReadTime

uint32_t RTC_GetUnixTime(rtcDataHandler_t * rtcTime)
{
	struct tm timeinfo = {
			.tm_year = rtcTime->rtcDateData.years + 100, // time.h is based off of 1900, our system is 2000
			.tm_mon = rtcTime->rtcDateData.months - 1, // from 1-indexed to 0-indexed
			.tm_mday = rtcTime->rtcDateData.days,
			.tm_hour = rtcTime->rtcTimeData.hours,
			.tm_min = rtcTime->rtcTimeData.minutes,
			.tm_sec = rtcTime->rtcTimeData.seconds,
			.tm_isdst = 0,
	};
	time_t unixTime = mktime(&timeinfo);
	return (uint32_t)unixTime;
}

status_t RTC_SetAlarm(rtcDataHandler_t * alarmTime)
{
	// Sanitize input
	if(31 < alarmTime->rtcDateData.days || 1 > alarmTime->rtcDateData.days){
		alarmTime->rtcDateData.days = 1;
	}
	if(23 < alarmTime->rtcTimeData.hours || 0 > alarmTime->rtcTimeData.hours){
		alarmTime->rtcTimeData.hours = 0;
	}
	if(59 < alarmTime->rtcTimeData.minutes || 0 > alarmTime->rtcTimeData.minutes){
		alarmTime->rtcTimeData.minutes = 0;
	}
	if(59 < alarmTime->rtcTimeData.seconds || 0 > alarmTime->rtcTimeData.seconds){
		alarmTime->rtcTimeData.seconds = 0;
	}
	
	// Make sure time hasn't elapsed
	rtcDataHandler_t currentTime;
	status_t status = RTC_ReadTime(&currentTime);
	if (StatusOk == status) {
		int32_t diff = RTC_GetUnixTime(alarmTime) - RTC_GetUnixTime(&currentTime);
		if (diff > MIN_ALARM_TIME_SECONDS) {
			RTC_AlarmTypeDef sAlarm = {0};
			sAlarm.AlarmTime.Hours = alarmTime->rtcTimeData.hours;
			sAlarm.AlarmTime.Minutes = alarmTime->rtcTimeData.minutes;
			sAlarm.AlarmTime.Seconds = alarmTime->rtcTimeData.seconds;
			sAlarm.AlarmTime.SubSeconds = 0x0;
			sAlarm.AlarmTime.DayLightSaving = RTC_DAYLIGHTSAVING_NONE;
			sAlarm.AlarmTime.StoreOperation = RTC_STOREOPERATION_RESET;
			sAlarm.AlarmMask = RTC_ALARMMASK_NONE;
			sAlarm.AlarmSubSecondMask = RTC_ALARMSUBSECONDMASK_None;
			sAlarm.AlarmDateWeekDaySel = RTC_ALARMDATEWEEKDAYSEL_DATE;
			sAlarm.AlarmDateWeekDay = alarmTime->rtcDateData.days;
			sAlarm.Alarm = RTC_ALARM_A;
			if (HAL_RTC_SetAlarm_IT(&hrtc, &sAlarm, RTC_FORMAT_BIN) != HAL_OK)
			{
				status = StatusHal;
			}
		} else {
			status = StatusAlarmAlreadyElapsed;
		}
	}
	
	return returnStatus(status, eSucIoctlStatus);
}

status_t RTC_ClearAlarm(void)
{
	// We don't care about this status
	HAL_RTC_DeactivateAlarm(&hrtc, RTC_ALARM_A);
	
	return StatusOk;
}

status_t RTC_SetWakeupTimer(uint16_t wakeupTimeSec)
{
	status_t status = StatusOk;
	
	if (wakeupTimeSec < HI_RES_WAKEUP_CUTOFF) {
		uint32_t period = wakeupTimeSec * HI_RES_PERIOD_MULTIPLIER;
		// TODO: if wakeupTime is over 1 second, do we need to subtract 1024?
		if (HAL_RTCEx_SetWakeUpTimer_IT(&hrtc, period, RTC_WAKEUPCLOCK_RTCCLK_DIV16) 
				!= HAL_OK) {
			status = StatusHal;
		}
	} else {
		if (HAL_RTCEx_SetWakeUpTimer_IT(&hrtc, wakeupTimeSec, RTC_WAKEUPCLOCK_CK_SPRE_16BITS) 
				!= HAL_OK) {
			status = StatusHal;
		}
	}
	
	return returnStatus(status, eSucIoctlStatus);
}

status_t RTC_ClearWakeupTimer(void)
{	
	// We don't care about this status
	HAL_RTCEx_DeactivateWakeUpTimer(&hrtc);
	
	return StatusOk;
}

status_t RTC_WriteTime(rtcDataHandler_t* rtcSetupData)
{
	RTC_DateTypeDef sDate = {0};
	RTC_TimeTypeDef sTime = {0};
	HAL_StatusTypeDef halStatus = HAL_OK;
	status_t status = StatusOk;

	sDate.WeekDay = RTC_WEEKDAY_MONDAY;
	sDate.Month = rtcSetupData->rtcDateData.months;
	sDate.Date = rtcSetupData->rtcDateData.days;
	sDate.Year = rtcSetupData->rtcDateData.years;

	sTime.Hours = rtcSetupData->rtcTimeData.hours;
	sTime.Minutes = rtcSetupData->rtcTimeData.minutes;
	sTime.Seconds = rtcSetupData->rtcTimeData.seconds;
	sTime.TimeFormat = RTC_HOURFORMAT12_AM;
	sTime.DayLightSaving = RTC_DAYLIGHTSAVING_NONE;
	sTime.StoreOperation = RTC_STOREOPERATION_SET;

	halStatus = HAL_RTC_SetTime(&hrtc, &sTime, RTC_FORMAT_BIN);
	if(HAL_OK != halStatus){
		status = StatusHal;
	}

	if(StatusOk == status){
		halStatus = HAL_RTC_SetDate(&hrtc, &sDate, RTC_FORMAT_BIN);
		if(HAL_OK != halStatus){
			status = StatusHal;
		}
	}

	return returnStatus(status, eSucWriteStatus);

} //RTC_WriteTime


void RTC_DiffTime(rtcDataHandler_t current, rtcDataHandler_t last, rtcDataHandler_t* diff){

	rtcDataHandler_t timeDiff;
	//Date ====================================================================================================
	//Handle Years
	if(last.rtcDateData.years > current.rtcDateData.years){
		timeDiff.rtcDateData.years = (99 - last.rtcDateData.years) + current.rtcDateData.years;
	}
	else{
		timeDiff.rtcDateData.years = current.rtcDateData.years - last.rtcDateData.years;
	}

	//Handle Months
	if(last.rtcDateData.months > current.rtcDateData.months){
		timeDiff.rtcDateData.months = (12 - last.rtcDateData.months) + current.rtcDateData.months;
	}
	else{
		timeDiff.rtcDateData.months = current.rtcDateData.months - last.rtcDateData.months;
	}

	//Handle Days TODO:Specific month handling
	if(last.rtcDateData.days > current.rtcDateData.days){
		timeDiff.rtcDateData.days = (DaysInMonths[last.rtcDateData.months-1] - last.rtcDateData.days) + current.rtcDateData.days;
	}
	else{
		timeDiff.rtcDateData.days = current.rtcDateData.days - last.rtcDateData.days;
	}

	//Time ====================================================================================================
	//Handle Hours
	if(last.rtcTimeData.hours > current.rtcTimeData.hours){
		timeDiff.rtcTimeData.hours = (24 - last.rtcTimeData.hours) + current.rtcTimeData.hours;
	}
	else{
		timeDiff.rtcTimeData.hours = current.rtcTimeData.hours - last.rtcTimeData.hours;
	}

	//Handle Minutes
	if(last.rtcTimeData.minutes > current.rtcTimeData.minutes){
		timeDiff.rtcTimeData.minutes = (60 - last.rtcTimeData.minutes) + current.rtcTimeData.minutes;
	}
	else{
		timeDiff.rtcTimeData.minutes = current.rtcTimeData.minutes - last.rtcTimeData.minutes;
	}

	//Handle Seconds
	if(last.rtcTimeData.seconds > current.rtcTimeData.seconds){
		timeDiff.rtcTimeData.seconds = (60 - last.rtcTimeData.seconds) + current.rtcTimeData.seconds;;
	}
	else{
		timeDiff.rtcTimeData.seconds = current.rtcTimeData.seconds - last.rtcTimeData.seconds;
	}

	memcpy(diff, &timeDiff, sizeof(rtcDataHandler_t));
}


/// SAEC Kinetic Vision, Inc. ----------- END OF FILE
