/**
  @file       rtc.h

  @copyright  (C) 2019 Kinetic Vision, Cincinnati Ohio.
               This software is property of SAEC Kinetic Vision, Inc
               and is considered confidential.

  @brief      RTC software unit "H" file.

  @author     Parker Kamer

  @defgroup   RtcSu Real time clock used for periodic wake up from low power mode and
  	  	  	  	  	time management

  Configuration History
  =====================

  Config Item    | Value
  -------------- | -----
  Config #       | NA
  Revision       | NA
  Revised, Date  | NA
  QA, Date       | NA
  Approved, Date | NA
  Released, Date | NA

  Significant Modification History (Most recent at top)
  =====================================================

  Date         | Initials | Details
  ------------ | -------- | -------
  24 Jul 2019  | PK       | Original

  Theory of Operation
  ===================
  The Real time clock will be used to gather timing data for each study. THe RTC's
  wakeup interrupt will also be used to turn on periodically so the unit can gather
  data.

  */

// Define to prevent recursive inclusion -------------------------------------
#ifndef __RTC_SU_H
#define __RTC_SU_H

#include "../StatusSu/Status.h"

// Exported macro ------------------------------------------------------------

// Exported types ------------------------------------------------------------
typedef struct {
	uint8_t hours;
	uint8_t minutes;
	uint8_t seconds;
	uint32_t milliseconds;
}rtcTimeData_t;

typedef struct {
	uint8_t years;
	uint8_t months;
	uint8_t days;
}rtcDateData_t;

typedef struct {
	rtcTimeData_t rtcTimeData;
	rtcDateData_t rtcDateData;
}rtcDataHandler_t;

typedef enum {
	rtcIoctlTimeCompare,

	NUM_RTC_IOCTL
} rtcIoctl_t;

// Exported constants --------------------------------------------------------

// Exported objects ----------------------------------------------------------

// Exported functions --------------------------------------------------------

/**
  * @brief  Initialize the real time clock peripheral.
  * @return StatusOk, StatusAlreadyInitialized
  */
status_t RTC_Init(void);

/**
  * @brief  Read the years, months, days, hours, minutes, seconds and sub seconds from the real time clock.
  * @param  args[out] rtcReturnData - Pointer to a data structure that will hold the time data.
  * @return StatusOk, StatusHal
  */
status_t RTC_ReadTime(rtcDataHandler_t* rtcReturnData);

/// @brief Convert RTC time to unix time
uint32_t RTC_GetUnixTime(rtcDataHandler_t * rtcTime);

/// @brief Set RTC alarm interrupt (for long use)
status_t RTC_SetAlarm(rtcDataHandler_t * alarmTime);

/// @brief Cancels RTC alarm interrupt
status_t RTC_ClearAlarm(void);

/// @brief Set RTC wakeup timer interrupt (for short use)
status_t RTC_SetWakeupTimer(uint16_t wakeupTimeSec); 

/// @brief Cancels RTC wakeup timer (if running)
status_t RTC_ClearWakeupTimer(void);

/**
  * @brief  Write (setup) the years, months, days, hours, minutes, seconds and sub seconds onto the real time clock.
  * @param  args[in] rtcSetupData - Time values to be used when setting up the real time clock
  * @return StatusOk, StatusHal
  */
status_t RTC_WriteTime(rtcDataHandler_t* rtcSetupData);

/**
  * @brief  Calculate the difference between two points in time
  * @param  args[in] current - current time value
  * @param  args[in] last - previously acquired time value
  * @param  args[out] diff - difference between current and last
  * @return StatusOk
  */
void RTC_DiffTime(rtcDataHandler_t current, rtcDataHandler_t last, rtcDataHandler_t* diff);

#endif // __RTC_SU_H

/// SAEC Kinetic Vision, Inc. ----------- END OF FILE
