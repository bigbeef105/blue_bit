/**
  @file       timer.c

  @copyright  (C) 2019 Kinetic Vision, Cincinnati Ohio.
               This software is property of SAEC Kinetic Vision, Inc
               and is considered confidential.

  @brief      Timer software unit "C" file.

  @author     Parker Kamer

  @ingroup    TimerSu

  Configuration History
  =====================

  Config Item    | Value
  -------------- | -----
  Config #       | NA
  Revision       | NA
  Revised, Date  | NA
  QA, Date       | NA
  Approved, Date | NA
  Released, Date | NA

  Significant Modification History (Most recent at top)
  =====================================================

  Date         | Initials | Details
  ------------ | -------- | -------
  24 Jul 2019  | PK       | Original

  Theory of Operation
  ===================
  The timer peripheral will be configured by the config file to trigger periodically.
  Once the interrupt triggers, the data aggregator software unit will be called in
  order to gather the peripheral data.

*/

// Includes ------------------------------------------------------------------

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <math.h>

#include "stm32l4xx_hal.h"

#include "../StatusSu/Status.h"
#include "../ConsoleSu/Console.h"
#include "../Bno055Su/bno055.h"
#include "../RtcSu/rtc.h"
#include "../Ms5837Su/Ms5837.h"
#include "../AdcSu/adc.h"
#include "../GpioSu/gpio.h"
#include "../DataAggregatorSu/DataAggregator.h"
#include "../UsbSerialSu/UsbSerial.h"
#include "../SwUnitControlSu/SwUnitControl.h"
#include "../Middlewares/Third_Party/FatFs/src/ff.h"
#include "../UserInterfaceSu/UserInterface.h"
#include "../ConfigSu/Config.h"
#include "../DataReceiverSu/DataReceiver.h"
#include "timer.h"
#include "main.h"
#include "fatfs.h"


// Private function prototypes -----------------------------------------------
static status_t convertFreqToPeriod(frequencySettings_t freq, uint32_t* period);
static status_t Timer_DataAggregatorCallback(void);

static status_t initMs5837Timer(void);
static status_t initHX711Timer(void);
// Private macros ------------------------------------------------------------
/// This macro feeds status information for tracking purposes to software unit control.
#define returnStatus(__status__,__source__) SwUnitControl_WriteStatus(eSucTimerSu,__source__,__status__,__LINE__);
// Private constants ---------------------------------------------------------
#define DEFAULT_MICROSEC_INTERRUPT      1000

#ifndef LSI_BUILD
#define LPTIM_PERIOD_MS_MULTIPLY		32.768f
#else
#define LPTIM_PERIOD_MS_MULTIPLY		32.0f
#endif // LSI_BUILD


// Private types -------------------------------------------------------------
typedef struct {
    bool inBlocking;
    uint32_t startTime;
    uint32_t totalTime;
    uint32_t totalTimeBlocking;
    uint32_t numCalls;
    uint32_t callDepth;
    uint32_t numCollisions;
    uint32_t maxCallDepth;
} readProfile_t;

// Private constants ---------------------------------------------------------

// Private variables ---------------------------------------------------------
TIM_HandleTypeDef htim2;
TIM_HandleTypeDef htim6;
TIM_HandleTypeDef htim7;
TIM_HandleTypeDef htim15;
LPTIM_HandleTypeDef hlptim1;

static void (*ms5837callback)(void) = NULL;
static void (*hx711callback)(void) = NULL;

static bool initialized = false;

#ifdef PROFILE_READS
static volatile readProfile_t readProfile = { false, 0, 0, 0, 0, 0, 0, 0 };
#endif // PROFILE_READS

// Private function bodies ---------------------------------------------------
void HAL_TIM_Base_MspInit(TIM_HandleTypeDef* htim_base)
{
  if(htim_base->Instance==TIM2)
  {
    /* Peripheral clock enable */
    __HAL_RCC_TIM2_CLK_ENABLE();
    /* TIM2 interrupt Init */
    HAL_NVIC_SetPriority(TIM2_IRQn, 4, 0); // needs to be lower than other timers for data agg
    HAL_NVIC_EnableIRQ(TIM2_IRQn);
  }
  else if(htim_base->Instance==TIM6)
  {
  /* USER CODE BEGIN TIM6_MspInit 0 */

  /* USER CODE END TIM6_MspInit 0 */
    /* Peripheral clock enable */
    __HAL_RCC_TIM6_CLK_ENABLE();
    /* TIM6 interrupt Init */
    HAL_NVIC_SetPriority(TIM6_DAC_IRQn, 3, 0);
    HAL_NVIC_EnableIRQ(TIM6_DAC_IRQn);
  /* USER CODE BEGIN TIM6_MspInit 1 */

  /* USER CODE END TIM6_MspInit 1 */
  }
  else if(htim_base->Instance==TIM7)
  {
  /* USER CODE BEGIN TIM7_MspInit 0 */

  /* USER CODE END TIM7_MspInit 0 */
    /* Peripheral clock enable */
    __HAL_RCC_TIM7_CLK_ENABLE();
    /* TIM7 interrupt Init */
    HAL_NVIC_SetPriority(TIM7_IRQn, 3, 0);
    HAL_NVIC_EnableIRQ(TIM7_IRQn);
  /* USER CODE BEGIN TIM7_MspInit 1 */

  /* USER CODE END TIM7_MspInit 1 */
  }
  else if(htim_base->Instance==TIM15)
  {
	 /* Peripheral clock enable */
	 __HAL_RCC_TIM15_CLK_ENABLE();

	 HAL_NVIC_SetPriority(TIM1_BRK_TIM15_IRQn, 3, 0);
	 HAL_NVIC_EnableIRQ(TIM1_BRK_TIM15_IRQn);
  }
} //HAL_TIM_Base_MspInit

void HAL_TIM_Base_MspDeInit(TIM_HandleTypeDef* htim_base)
{
  if(htim_base->Instance==TIM2)
  {
    /* Peripheral clock disable */
    __HAL_RCC_TIM2_CLK_DISABLE();

    /* TIM2 interrupt DeInit */
    HAL_NVIC_DisableIRQ(TIM2_IRQn);
  }
  else if(htim_base->Instance==TIM6)
  {
    /* Peripheral clock disable */
    __HAL_RCC_TIM6_CLK_DISABLE();

    HAL_NVIC_DisableIRQ(TIM6_DAC_IRQn);
  }
  else if(htim_base->Instance==TIM7)
  {
    /* Peripheral clock disable */
    __HAL_RCC_TIM7_CLK_DISABLE();

    HAL_NVIC_DisableIRQ(TIM7_IRQn);
  }
  else if(htim_base->Instance==TIM15)
  {
    /* Peripheral clock disable */
    __HAL_RCC_TIM15_CLK_DISABLE();

    HAL_NVIC_DisableIRQ(TIM1_BRK_TIM15_IRQn);
  }
} //HAL_TIM_Base_MspDeInit

void HAL_LPTIM_MspInit(LPTIM_HandleTypeDef* hlptim)
{
  if(hlptim->Instance==LPTIM1)
  {
  /* USER CODE BEGIN LPTIM1_MspInit 0 */

  /* USER CODE END LPTIM1_MspInit 0 */
    /* Peripheral clock enable */
    __HAL_RCC_LPTIM1_CLK_ENABLE();
    /* LPTIM1 interrupt Init */
    HAL_NVIC_SetPriority(LPTIM1_IRQn, 5, 0);
    HAL_NVIC_EnableIRQ(LPTIM1_IRQn);
  /* USER CODE BEGIN LPTIM1_MspInit 1 */

  /* USER CODE END LPTIM1_MspInit 1 */
  }

}

void HAL_LPTIM_MspDeInit(LPTIM_HandleTypeDef* hlptim)
{
  if(hlptim->Instance==LPTIM1)
  {
  /* USER CODE BEGIN LPTIM1_MspDeInit 0 */

  /* USER CODE END LPTIM1_MspDeInit 0 */
    /* Peripheral clock disable */
    __HAL_RCC_LPTIM1_CLK_DISABLE();

    /* LPTIM1 interrupt DeInit */
    HAL_NVIC_DisableIRQ(LPTIM1_IRQn);
  /* USER CODE BEGIN LPTIM1_MspDeInit 1 */

  /* USER CODE END LPTIM1_MspDeInit 1 */
  }

}

static status_t convertFreqToPeriod(frequencySettings_t setting, uint32_t* period)
{
	status_t status = StatusOk;
	uint32_t frequency;

	switch(setting){
		case freq1hz:
			frequency = 1;
			break;
		case freq10hz:
			frequency = 10;
			break;
		case freq50hz:
			frequency = 50;
			break;
		case freq100hz:
			frequency = 100;
			break;
		case freq200hz:
			frequency = 200;
			break;
		case freq300hz:
			frequency = 300;
			break;
		case freq400hz:
			frequency = 400;
			break;
		default:
			status = StatusParameter1;
			break;
	}

	if(StatusOk == status){
		float temp = 0.0;

		//Convert frequency into seconds
		temp = (1 / (float)frequency);

		//Timer period value: 1 == 100us
		temp *= (1 / 0.0001);

		*period = (uint32_t)temp;
	}

	return status;
} //convertFreqToPeriod

static status_t Timer_DataAggregatorCallback(void)
{
	status_t status = StatusOk;
	
#ifdef PROFILE_READS
	readProfile.numCalls++;
    if (readProfile.callDepth > 0) {
        readProfile.numCollisions++;
    } else {
        readProfile.startTime = HAL_GetTick();
    }
    readProfile.inBlocking = true;
    uint32_t startTimeBlocking = HAL_GetTick();
    
    readProfile.callDepth++;
#endif
    
#ifndef NO_SENSOR_READS
	status = DataAggregator_ReadData();
#endif
	
#ifdef PROFILE_READS
	uint32_t timeSpent = HAL_GetTick() - startTimeBlocking;
	readProfile.totalTimeBlocking += timeSpent;
	readProfile.inBlocking = false;
#ifdef PROFILE_WRITES
	DataReceive_ProfileInterruptTime(timeSpent);
#endif // PROFILE_WRITES
#endif // PROFILE_READS

	return status;
}

static status_t initMs5837Timer(void)
{
    TIM_MasterConfigTypeDef sMasterConfig = {0};
    uint32_t clkFrequency = HAL_RCC_GetSysClockFreq();
        
    htim7.Instance = TIM7;
    htim7.Init.Prescaler = clkFrequency / 1000000UL; // 1us period
    htim7.Init.CounterMode = TIM_COUNTERMODE_UP;
    htim7.Init.Period = DEFAULT_MICROSEC_INTERRUPT;
    htim7.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
    if (HAL_TIM_Base_Init(&htim7) != HAL_OK)
    {
        return StatusHal;
    }
    sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
    sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
    if (HAL_TIMEx_MasterConfigSynchronization(&htim7, &sMasterConfig) != HAL_OK)
    {
        return StatusHal;
    }
    
    return StatusOk;
}

static status_t initHX711Timer(void)
{
    TIM_MasterConfigTypeDef sMasterConfig = {0};
    uint32_t clkFrequency = HAL_RCC_GetSysClockFreq();
        
    htim6.Instance = TIM6;
    htim6.Init.Prescaler = clkFrequency / 1000000UL; // 1us period
    htim6.Init.CounterMode = TIM_COUNTERMODE_UP;
    htim6.Init.Period = DEFAULT_MICROSEC_INTERRUPT;
    htim6.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
    if (HAL_TIM_Base_Init(&htim6) != HAL_OK)
    {
        return StatusHal;
    }
    sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
    sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
    if (HAL_TIMEx_MasterConfigSynchronization(&htim6, &sMasterConfig) != HAL_OK)
    {
        return StatusHal;
    }
    
    return StatusOk;
}

static void TIM15_InitDelayUS(uint16_t period, bool interruptEnabled)
{

  /* USER CODE BEGIN TIM15_Init 0 */

  /* USER CODE END TIM15_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM15_Init 1 */

  /* USER CODE END TIM15_Init 1 */
  htim15.Instance = TIM15;
  htim15.Init.Prescaler = HAL_RCC_GetSysClockFreq()/1000000;
  htim15.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim15.Init.Period = period;
  htim15.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim15.Init.RepetitionCounter = 0;
  htim15.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim15) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim15, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim15, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }

  if(interruptEnabled){
	  HAL_TIM_Base_Start_IT(&htim15);
  }
  else{
	  HAL_TIM_Base_Start(&htim15);
  }
}

// Public functions bodies ---------------------------------------------------
status_t Timer_HandleInterrupt(TIM_HandleTypeDef *htim)
{
	status_t status = StatusOk;

	if(htim->Instance == TIM2){
		status = Timer_DataAggregatorCallback();
		
	} else if (htim->Instance == TIM6) {
        HAL_TIM_Base_Stop_IT(htim);
        if (hx711callback) hx711callback();
        
	} else if (htim->Instance == TIM7) {
        HAL_TIM_Base_Stop_IT(htim);
        if (ms5837callback) ms5837callback();
	}

	return status;
} //Timer_HandleInterrupt

status_t Timer_HandleLptimInterrupt(LPTIM_HandleTypeDef *hlptim)
{
	HAL_LPTIM_TimeOut_Stop_IT(hlptim);
	HAL_LPTIM_DeInit(hlptim);
	
	return StatusOk;
}

status_t Timer_Init(void)
{
	float secondsPerPeriod;
	uint32_t clkFrequency;
	uint32_t timerPrescaler;
	uint32_t periodValue;
	frequencySettings_t freqSetting;

	HAL_StatusTypeDef halStatus = HAL_OK;
	status_t status = StatusOk;

	if(initialized){
		status = StatusAlreadyInitialized;
	}
	else
	{
		TIM_ClockConfigTypeDef sClockSourceConfig = {0};
		TIM_MasterConfigTypeDef sMasterConfig = {0};

		secondsPerPeriod = 0.0001; 						       //100us == 1 period
		clkFrequency = HAL_RCC_GetSysClockFreq(); 			   //80MHz
		timerPrescaler = clkFrequency * secondsPerPeriod - 1;  //Seconds based period calculation

		//Get the frequency from the config struct
		Config_Ioctl(configIoctlGetFreq, &freqSetting);

		status = convertFreqToPeriod(freqSetting, &periodValue);

		if(StatusOk == status){
			//Data Aggregator Specific Timer (100us period)
			htim2.Instance = TIM2;
			htim2.Init.Prescaler =  timerPrescaler;
			htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
			htim2.Init.Period = periodValue;
			htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
			htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_ENABLE;
			halStatus = HAL_TIM_Base_Init(&htim2);
			if(HAL_OK != halStatus){
				status = StatusHal;
			}
		}

		if(StatusOk == status){
			sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
			halStatus = HAL_TIM_ConfigClockSource(&htim2, &sClockSourceConfig);
			if(HAL_OK != halStatus){
				status = StatusHal;
			}
		}

		if(StatusOk == status){
			sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
			sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
			halStatus = HAL_TIMEx_MasterConfigSynchronization(&htim2, &sMasterConfig);
			if(HAL_OK != halStatus){
				status = StatusHal;
			}
		}

		if(StatusOk == status){
            status = initMs5837Timer();
        }
		if(StatusOk == status){
            status = initHX711Timer();
        }
		if(StatusOk == status){
			TIM15_InitDelayUS(0xFFFF, 0);
		}

		if(StatusOk == status){
			 initialized = true;
		}
	}

	return returnStatus(status, eSucInitStatus);
} //Timer_Init

status_t Timer_DeInit(void)
{
	status_t status = StatusOk;

	if(initialized){
		HAL_StatusTypeDef halStatus = HAL_TIM_Base_DeInit(&htim2);
		if(HAL_OK != halStatus){
			status = StatusHal;
		}
		
		if(StatusOk == status){
            halStatus = HAL_TIM_Base_DeInit(&htim6);
            if(HAL_OK != halStatus){
                status = StatusHal;
            }
        }
		
		if(StatusOk == status){
            halStatus = HAL_TIM_Base_DeInit(&htim7);
            if(HAL_OK != halStatus){
                status = StatusHal;
            }
        }

		if(StatusOk == status){
			halStatus = HAL_TIM_Base_DeInit(&htim15);
			if(HAL_OK != halStatus){
				status = StatusHal;
			}
		}

		if(StatusOk == status){
			initialized = false;
		}
	}

	return status;
}

status_t Timer_Ioctl(timerIoctl_t ioctlCode, uint32_t value)
{
	status_t status = StatusOk;
	HAL_StatusTypeDef halStat;
	uint32_t periodMs;

	switch(ioctlCode){
		case timerIoctlStart:
			halStat = HAL_TIM_Base_Start_IT(&htim2);
			if(HAL_OK != halStat){
				status = StatusHal;
			}
			break;

		case timerIoctlStop:
			halStat = HAL_TIM_Base_Stop_IT(&htim2);
			if(HAL_OK != halStat){
				status = StatusHal;
			}
			break;

		case timerIoctlSetPeriod:
			status = convertFreqToPeriod(value, &periodMs);
			if(StatusOk != status){
				status = StatusParameter2;
			} else {
			    __HAL_TIM_SET_AUTORELOAD(&htim2, periodMs);
			}
			break;
		default:
			status = StatusParameter1;
			break;
	}

	return returnStatus(status, eSucIoctlStatus);

} // Timer_Ioctl

void Timer_MicroSecDelay(uint32_t delay){
	uint16_t tickStart;
	uint16_t tickCurrent;
	uint16_t tickDiff;

	tickStart = TIM15->CNT;

	while(1){
		tickCurrent = TIM15->CNT;

		if(tickCurrent < tickStart){
			tickDiff = (0xFFFF - tickStart) + tickCurrent;
		}
		else{
			tickDiff = tickCurrent - tickStart;
		}

		if(tickDiff >= delay){
			break;
		}
	}
}

status_t Timer_Ms5837AsyncDelay(uint16_t usTime, void (*callback)(void))
{
    status_t status = StatusOk;
    
    if (!callback) {
        status = StatusNullParameter;
    }
    // Correct period if needed
    if (StatusOk == status) {
        htim7.Init.Period = usTime;
        if (HAL_TIM_Base_Init(&htim7) != HAL_OK)
        {
            status = StatusHal;
        }
    }
    // Start timer
    if (StatusOk == status) {
        ms5837callback = callback;
        __HAL_TIM_CLEAR_IT(&htim7, TIM_IT_UPDATE);
        if (HAL_TIM_Base_Start_IT(&htim7) != HAL_OK) {
            status = StatusHal;
        }
    }
    
    return returnStatus(status, eSucIoctlStatus);
}

status_t Timer_HX711AsyncDelay(uint16_t usTime, void (*callback)(void))
{
    status_t status = StatusOk;
    
    if (!callback) {
        status = StatusNullParameter;
    }
    // Correct period if needed
    if (StatusOk == status) {
        htim6.Init.Period = usTime;
        if (HAL_TIM_Base_Init(&htim6) != HAL_OK)
        {
            status = StatusHal;
        }
    }
    // Start timer
    if (StatusOk == status) {
        hx711callback = callback;
        __HAL_TIM_CLEAR_IT(&htim6, TIM_IT_UPDATE);
        if (HAL_TIM_Base_Start_IT(&htim6) != HAL_OK) {
            status = StatusHal;
        }
    }
    
    return returnStatus(status, eSucIoctlStatus);
}

status_t Timer_LowPowerInterrupt(uint32_t msTime)
{
	status_t status = StatusOk;
	
	hlptim1.Instance = LPTIM1;
	hlptim1.Init.Clock.Source = LPTIM_CLOCKSOURCE_APBCLOCK_LPOSC;
	hlptim1.Init.Clock.Prescaler = LPTIM_PRESCALER_DIV1;
	hlptim1.Init.Trigger.Source = LPTIM_TRIGSOURCE_SOFTWARE;
	hlptim1.Init.OutputPolarity = LPTIM_OUTPUTPOLARITY_HIGH;
	hlptim1.Init.UpdateMode = LPTIM_UPDATE_IMMEDIATE;
	hlptim1.Init.CounterSource = LPTIM_COUNTERSOURCE_INTERNAL;
	hlptim1.Init.Input1Source = LPTIM_INPUT1SOURCE_GPIO;
	hlptim1.Init.Input2Source = LPTIM_INPUT2SOURCE_GPIO;
	if (HAL_LPTIM_Init(&hlptim1) != HAL_OK)
	{
		status = StatusHal;
	}

	// Start timeout
	float periodFloat = msTime * LPTIM_PERIOD_MS_MULTIPLY;
	uint32_t period = (periodFloat > (float)0xFFFF) ? 0xFFFF : (uint32_t)periodFloat;
	HAL_LPTIM_TimeOut_Start_IT(&hlptim1, 0xFFFF, period);
	
	return returnStatus(status, eSucIoctlStatus);
}


#ifdef PROFILE_READS
void Timer_ProfileDataAggDone(void)
{
    if (readProfile.callDepth > readProfile.maxCallDepth)
        readProfile.maxCallDepth = readProfile.callDepth;
    
    readProfile.callDepth--;
    if (readProfile.callDepth == 0) {
        readProfile.totalTime += HAL_GetTick() - readProfile.startTime;
    }
}

void Timer_ProfileEnterSleep(void)
{
    if (readProfile.callDepth > 0) {
        readProfile.totalTime += HAL_GetTick() - readProfile.startTime;
    }
}

void Timer_ProfileAddBlockingTime(uint32_t timeMs)
{
    if (!readProfile.inBlocking)
        readProfile.totalTimeBlocking += timeMs;
}

#endif // PROFILE_READS
/// SAEC Kinetic Vision, Inc. ----------- END OF FILE
