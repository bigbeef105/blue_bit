/**
  @file       timer.h

  @copyright  (C) 2019 Kinetic Vision, Cincinnati Ohio.
               This software is property of SAEC Kinetic Vision, Inc
               and is considered confidential.

  @brief      Timer software unit "H" file.

  @author     Parker Kamer

  @defgroup   TimerSu Timer peripheral used for data gathering

  Configuration History
  =====================

  Config Item    | Value
  -------------- | -----
  Config #       | NA
  Revision       | NA
  Revised, Date  | NA
  QA, Date       | NA
  Approved, Date | NA
  Released, Date | NA

  Significant Modification History (Most recent at top)
  =====================================================

  Date         | Initials | Details
  ------------ | -------- | -------
  24 Jul 2019  | PK       | Original

  Theory of Operation
  ===================
  The timer peripheral will be configured by the config file to trigger periodically.
  Once the interrupt triggers, the data aggregator software unit will be called in
  order to gather the peripheral data.

  */

// Define to prevent recursive inclusion -------------------------------------
#ifndef __TIMER_SU_H
#define __TIMER_SU_H

#include "../ConfigSu/Config.h" // PROFILE_READS

// Exported macro ------------------------------------------------------------

// Exported types ------------------------------------------------------------

typedef enum {
	timerIoctlStart,
	timerIoctlStop,
	timerIoctlSetPeriod,
	NUM_TIMER_IOCTL
} timerIoctl_t;
// Exported constants --------------------------------------------------------

// Exported objects ----------------------------------------------------------
extern TIM_HandleTypeDef htim2;

// Exported functions --------------------------------------------------------
///  @brief Handle the timer interrupt
///  @param args[in] htim - timer hardware structure
///  @return StatusOk.
status_t Timer_HandleInterrupt(TIM_HandleTypeDef *htim);

///  @brief Handle the low power timer interrupt
status_t Timer_HandleLptimInterrupt(LPTIM_HandleTypeDef *hlptim);

///  @brief Initializes the timer software unit
///  @return StatusOk, StatusAlreadyInitialized.
status_t Timer_Init(void);

///  @brief DeInitializes the timer software unit
///  @return StatusOk, StatusHal.
status_t Timer_DeInit(void);

///  @brief Set the timer's period value
///  @param agrs[in] frequency - Desired frequency of the timer
///  @return StatusOk, StatusHal, StatusParameter1, StatusParameter2
status_t Timer_Ioctl(timerIoctl_t ioctlCode, uint32_t value);

///  @brief Generate a delay in micro seconds(us)
///  @param args[in] delay - delay value
void Timer_MicroSecDelay(uint32_t delay);

///  @brief Generate an interrupt in micro seconds(us)
///  @param args[in] usTime - time value in microseconds
///  @param args[in] callback - callback function to be called at the end of timeout
status_t Timer_Ms5837AsyncDelay(uint16_t usTime, void (*callback)(void));

///  @brief Generate an interrupt in micro seconds(us)
///  @param args[in] usTime - time value in microseconds
///  @param args[in] callback - callback function to be called at the end of timeout
status_t Timer_HX711AsyncDelay(uint16_t usTime, void (*callback)(void));

///  @brief Initiates low power timer interrupt for specified interval
status_t Timer_LowPowerInterrupt(uint32_t msTime);

#ifdef PROFILE_READS
void Timer_ProfileDataAggDone(void);
void Timer_ProfileEnterSleep(void);
void Timer_ProfileAddBlockingTime(uint32_t timeMs);
#endif // PROFILE_READS

#endif // __TIMER_SU_H

/// SAEC Kinetic Vision, Inc. ----------- END OF FILE


