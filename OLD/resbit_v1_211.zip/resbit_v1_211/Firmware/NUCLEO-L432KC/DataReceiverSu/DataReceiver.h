/**
  @file       DataReceiver.h

  @copyright  (C) 2019 Kinetic Vision, Cincinnati Ohio.
               This software is property of SAEC Kinetic Vision, Inc
               and is considered confidential.

  @brief      DataReceiver software unit "H" file.

  @author     Parker Kamer

  @defgroup   DataReceiverSU Handling data out of the fifo buffer and into
    						 the fatfs

  Configuration History
  =====================

  Config Item    | Value
  -------------- | -----
  Config #       | NA
  Revision       | NA
  Revised, Date  | NA
  QA, Date       | NA
  Approved, Date | NA
  Released, Date | NA

  Significant Modification History (Most recent at top)
  =====================================================

  Date         | Initials | Details
  ------------ | -------- | -------
  23 Jul 2019  | PK       | Original

  Theory of Operation
  ===================
  The Data Receiver software unit will be responsible for handling all
  gathered data from the fifo software unit and placing it into a .csv file.

  */

// Define to prevent recursive inclusion -------------------------------------
#ifndef __DATA_REC_SU_H
#define __DATA_REC_SU_H

#include "../ConfigSu/Config.h" // PROFILE_WRITES

// Exported macro ------------------------------------------------------------

// Exported types ------------------------------------------------------------

// Exported constants --------------------------------------------------------

// Exported objects ----------------------------------------------------------

// Exported functions --------------------------------------------------------

/// @brief Initializes the data receiver software unit
/// @return StatusOk, StatusAlreadyInitialized, StatusMakeFileSystem, StatusFileSystemMount
status_t DataReceive_Init(void);

/// @brief Foreground tick method
/// @return StatusOk, StatusQueueEmpty, StatusQueueSetup, StatusFatFsWrite, StatusFatFsFull, StatusFatFsSync
status_t DataReceive_Tick(void);

/// @brief Mounts file system and creates CSV file
status_t DataReceive_OpenCsvFile(uint32_t fileSizeKb);

/// @brief Attempts to write the remaining contents of the FIFO to the file system
status_t DataReceive_Flush(uint32_t timeoutMs);

/// @brief Closes CSV file and dismounts file system
status_t DataReceive_CloseCsvFile(void);

/// @brief Checks the CSV file and expands if within a threshold of the file size
status_t DataReceive_CheckCsvExpand(void);

#ifdef PROFILE_WRITES
void DataReceive_ProfileInterruptTime(uint32_t timeMs);
#endif

#endif // __DATA_REC_SU_H

/// SAEC Kinetic Vision, Inc. ----------- END OF FILE


