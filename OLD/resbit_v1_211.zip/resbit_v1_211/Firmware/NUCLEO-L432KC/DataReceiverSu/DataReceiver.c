/**
  @file       DataReceiver.c

  @copyright  (C) 2019 Kinetic Vision, Cincinnati Ohio.
               This software is property of SAEC Kinetic Vision, Inc
               and is considered confidential.

  @brief      DataReceiver software unit "C" file.

  @author     Parker Kamer

  @ingroup    DataReceiverSu

  Configuration History
  =====================

  Config Item    | Value
  -------------- | -----
  Config #       | NA
  Revision       | NA
  Revised, Date  | NA
  QA, Date       | NA
  Approved, Date | NA
  Released, Date | NA

  Significant Modification History (Most recent at top)
  =====================================================

  Date         | Initials | Details
  ------------ | -------- | -------
  23 Jul 2019  | PK       | Original

  Theory of Operation
  ===================
  The Data Receiver software unit will be responsible for handling all
  gathered data from the fifo software unit and placing it into a .csv file.

*/

// Includes ------------------------------------------------------------------

#include "DataReceiver.h"

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <math.h>

#include "stm32l4xx_hal.h"
#include "../Middlewares/Third_Party/FatFs/src/ff.h"
#include "../StatusSu/Status.h"
#include "../ConsoleSu/Console.h"
#include "../TimerSu/timer.h"
#include "../SwUnitControlSu/SwUnitControl.h"
#include "../GpioSu/gpio.h"
#include "../RtcSu/rtc.h"
#include "../PowerSu/power.h"
#include "../UserInterfaceSu/UserInterface.h"
#include "../Tc58FlashUtilitiesSu/Tc58FlashUtilities.h"
#include "../Tc58FlashPhysicalSu/Tc58FlashPhysical.h"
#include "../Tc58FlashPhysicalSu/Tc58FlashIoControl.h"
#include "../Tc58FlashBufferSu/Tc58FlashBuffer.h"
#include "../Tc58BlockSu/Tc58Block.h"
#include "../SysTimeSu/SysTime.h"
#include "usb_device.h"
#include "fatfs.h"

#include "../FifoSu/Fifo.h"
#include "../DeviceInfoSu/DeviceInfo.h"
#include "../DataAggregatorSu/DataAggregator.h"
#include "../SysStateSu/SysState.h"

// Private macros ------------------------------------------------------------

// Private constants ---------------------------------------------------------
/// These switch between file allocation modes -- these are mutually exclusive, only one should be defined
#define FILE_PRE_ALLOC_MODE
//#define FILE_CHUNK_ALLOC_MODE
#if defined(FILE_PRE_ALLOC_MODE) && defined(FILE_CHUNK_ALLOC_MODE)
#error File pre alloc and chunk alloc are mutually exclusive operating modes 
#endif

#define CSV_FILE_PREFIX				"DEVICE"

#ifdef FILE_PRE_ALLOC_MODE
#define FILE_ALLOC_RETRY_COUNT		8
#define FILE_ALLOC_RETRY_SHRINK		1048576UL // bytes

#elif defined(FILE_CHUNK_ALLOC_MODE)
#define FILE_EXPAND_SIZE			2097152UL // bytes
#define FILE_EXPAND_THRESHOLD		FILE_EXPAND_SIZE / 2UL

#endif

// This macro feeds status information for tracking purposes to software unit control.
#define returnStatus(__status__,__source__) SwUnitControl_WriteStatus(eSucDataReceiverSu,__source__,__status__,__LINE__);
#define CSV_LINE_BUFF_LEN       2048

// Private function prototypes -----------------------------------------------
static status_t linkCommand(uint16_t argc, uint8_t **argv);
static status_t cliQbfCommand(uint16_t argc, uint8_t **argv);
static void printFresultOnConsole(FRESULT r);
static status_t cliMkfsCommand(uint16_t argc, uint8_t **argv);
static status_t cliFormatCommand(uint16_t argc, uint8_t **argv);
static status_t cliReFormatCommand(uint16_t argc, uint8_t **argv);

static const char * getFilenameExt(const char *filename);
static status_t findLastCsvFileIndex(int16_t * output); // -1 for no files
static status_t truncateFile(const char * filename); // truncates an existing file

#ifdef FILE_CHUNK_ALLOC_MODE
static status_t expandFile(FIL * file, FSIZE_t newSize);
#endif

static status_t readFifoData(uint8_t* pBuffer, uint16_t bufferSize, uint16_t* bytesRead);
static status_t writeToFile(uint8_t* pBuffer, uint16_t bytesToWrite);

// Private types -------------------------------------------------------------
typedef enum {
    APPLICATION_IDLE = 0,
    APPLICATION_RUNNING,
} FS_FileOperationsTypeDef;

typedef struct {
    uint32_t totalTime;
    uint32_t numCalls;
    bool inProgress;
} writeProfile_t;

// Private constants ---------------------------------------------------------

// Private variables ---------------------------------------------------------
static uint8_t csvLineBuff[CSV_LINE_BUFF_LEN];
static const consoleCommand_t commandList[] = {
    { "usb-link", "usage: usb-link", linkCommand },
    { "qbf", "usage: qbf [# of Files=10] [# lines in file=10000]", cliQbfCommand },
	{ "mkfs", "make file system, usage: mkfs", cliMkfsCommand},
	{ "reformat", "format file system blocks (keep remap), usage: reformat", cliReFormatCommand},
	{ "format", "format file system blocks (zap remap), usage: format", cliFormatCommand},
    { NULL, NULL, NULL },
};

static consoleRegistration_t exportedReg;
static volatile bool initialized = false;
static volatile writeProfile_t writeProfile = { 0, 0, false, };
static bool fileOpen = false;
static bool diskFull = false; // this flag is set to prevent writing multiple "end of file"s

// Private function bodies ---------------------------------------------------
static status_t uint32_ConvertAtoi(uint8_t *a, uint32_t *pN)
{
	uint32_t n;

	if (NULL == a) {
		return StatusNullParameter;
	}

	// Number format 0x__?
	if ( (strlen(a) > 2) && ('0' == a[0]) && ('x' == a[1]) ) {
		sscanf(&a[2], "%lx", &n);
	} else {
		n = atoi(a);
	}

	*pN = n;

	return StatusOk;
} //uint32_ConvertAtoi

static void printFresultOnConsole(FRESULT r)
{
	switch (r)
	{
	case FR_OK:
		Console_WriteString("(0) Succeeded\r\n");
		break;
	case FR_DISK_ERR:
		Console_WriteString("(1) A hard error occurred in the low level disk I/O layer\r\n");
		break;
	case FR_INT_ERR:
		Console_WriteString("(2) Assertion failed\r\n");
		break;
	case FR_NOT_READY:
		Console_WriteString("(3) The physical drive cannot work\r\n");
		break;
	case FR_NO_FILE:
		Console_WriteString("(4) Could not find the file\r\n");
		break;
	case FR_NO_PATH:
		Console_WriteString("(5) Could not find the path\r\n");
		break;
	case FR_INVALID_NAME:
		Console_WriteString("(6) The path name format is invalid\r\n");
		break;
	case FR_DENIED:
		Console_WriteString("(7) Access denied due to prohibited access or directory full \r\n");
		break;
	case FR_EXIST:
		Console_WriteString("(8) Access denied due to prohibited access \r\n");
		break;
	case FR_INVALID_OBJECT:
		Console_WriteString("(9) The file/directory object is invalid \r\n");
		break;
	case FR_WRITE_PROTECTED:
		Console_WriteString("(10) The physical drive is write protected \r\n");
		break;
	case FR_INVALID_DRIVE:
		Console_WriteString("(11) The logical drive number is invalid \r\n");
		break;
	case FR_NOT_ENABLED:
		Console_WriteString("(12) The volume has no work area \r\n");
		break;
	case FR_NO_FILESYSTEM:
		Console_WriteString("(13) There is no valid FAT volume \r\n");
		break;
	case FR_MKFS_ABORTED:
		Console_WriteString("(14) The f_mkfs() aborted due to any problem \r\n");
		break;
	case FR_TIMEOUT:
		Console_WriteString("(15) Could not get a grant to access the volume within defined period \r\n");
		break;
	case FR_LOCKED:
		Console_WriteString("(16) The operation is rejected according to the file sharing policy \r\n");
		break;
	case FR_NOT_ENOUGH_CORE:
		Console_WriteString("(17) LFN working buffer could not be allocated \r\n");
		break;
	case FR_TOO_MANY_OPEN_FILES:
		Console_WriteString("(18) Number of open files > _FS_LOCK \r\n");
		break;
	case FR_INVALID_PARAMETER:
		Console_WriteString("(19) Given parameter is invalid \r\n");
		break;
	}
	return;
}

static status_t linkCommand(uint16_t argc, uint8_t **argv)
{

    status_t status;

    status = StatusOk;
#if 0
    /*##-1- Link the USB Host disk I/O driver ##################################*/
    if(FATFS_LinkDriver(&USBH_Driver, USBDISKPath) == 0)
    {
      /*##-2- Init Host Library ################################################*/
      USBH_Init(&hUSB_Host, USBH_UserProcess, 0);

      /*##-3- Add Supported Class ##############################################*/
      USBH_RegisterClass(&hUSB_Host, USBH_MSC_CLASS);

      /*##-4- Start Host Process ###############################################*/
      USBH_Start(&hUSB_Host);

      /* Enable VDDUSB supply */
      HAL_PWREx_EnableVddUSB();

      /*##-5- Run Application (Blocking mode) ##################################*/
      while (1)
      {
        /* USB Host Background task */
        USBH_Process(&hUSB_Host);

        /* Mass Storage Application State Machine */
        switch(Appli_state)
        {
          case APPLICATION_RUNNING:
          FS_FileOperations();
          Appli_state = APPLICATION_IDLE;
          break;

          case APPLICATION_IDLE:
          default:
          break;
        }
      }
    }
#endif
    return status;

} // linkCommand ...


static status_t cliReFormatCommand(uint16_t argc, uint8_t **argv)
{
	status_t status;

	status = StatusOk;

	// be certain that the volume is not mounted
 	f_mount(0, "", 0);

	status = Tc58Flash_DoIoControl(Tc58IoctlReFormat, NULL);

	return status;

} // cliReFormatCommand


static status_t cliFormatCommand(uint16_t argc, uint8_t **argv)
{
	status_t status;

	status = StatusOk;

	// be certain that the volume is not mounted
 	f_mount(0, "", 0);

	status = Tc58Flash_DoIoControl(Tc58IoctlFormat, NULL);

	return status;

} // cliFormatCommand

static status_t cliMkfsCommand(uint16_t argc, uint8_t **argv)
{
	uint8_t workBuffer[_MAX_SS];
	FRESULT res;
	status_t status;

	status = StatusOk;

 	f_mount(0, "", 0);

	res = f_mkfs("", FM_FAT32, 0, workBuffer, sizeof(workBuffer));

	if (res != FR_OK) {
		printFresultOnConsole(res);
		status = StatusMakeFileSystem;
	}

	return status;

} // cliMkfsCommand

static status_t cliQbfCommand(uint16_t argc, uint8_t **argv)
{
    const char qbfText[] = "<f=%lu, l=%lu A Quick Brown Fox Jumps Over the Lazy Dog>\r\n";
	FIL MyFile;

    FRESULT res;
    uint32_t bytesWritten;
    status_t status;
	uint8_t fileName[20];

    // Options
    uint32_t numberOfFiles;
    uint32_t numberLinesPerFile;
    uint32_t option;

    /* File system object for USB disk logical drive */
    FATFS USBDISKFatFs;

    status = StatusOk;

    // Setup default values for parameters

    numberOfFiles = 10; // Parameter 1
    numberLinesPerFile = 10000; // Parameter 2
    option = 0; // parameter 3

    // Get Parameter 1
    if (StatusOk == status) {
		if (argc > 1) {
			status = uint32_ConvertAtoi(argv[1], &numberOfFiles);
		}
    }

    // Get Parameter 2
    if (StatusOk == status) {
		if (argc > 2) {
			status = uint32_ConvertAtoi(argv[2], &numberLinesPerFile);
		}
    }

    // Get Parameter 3, File option - {0=mount:single, files:multiple}, {1=mount:single, file:single:,open:single}, {2=mount:multiple, file:single, open:multiple}
    if (StatusOk == status) {
		if (argc > 3) {
			status = uint32_ConvertAtoi(argv[3], &option);
		}
    }

    if (StatusOk == status) {

    	// Option 0=mount now
    	// Option 1=mount now
		if ((0 == option) || (1 == option)) {
			res = f_mount(&USBDISKFatFs, "", 1);
			if (res != FR_OK) {
				status = StatusFatFsMount;
			}
		}
    }

    if (StatusOk == status) {

    	// Option 1=file:single
		if (1 == option) {
			sprintf(fileName, "\\foxOpt1.txt");
			res = f_open(&MyFile, fileName, FA_OPEN_APPEND | FA_WRITE);
			if (res != FR_OK) {
				status = StatusFatFsOpen;
			}
		}
	}

    if (StatusOk == status) {

		for (uint32_t f = 0; ((f < numberOfFiles) && (StatusOk == status)); f++) {

			// 2=mount:multiple, file:single, open:multiple
			if (2 == option) {
				res = f_mount(&USBDISKFatFs, "", 1);
				if (res != FR_OK) {
					status = StatusFatFsMount;
					break;
				}

				sprintf(fileName, "\\foxOpt2.txt");
				res = f_open(&MyFile, fileName, FA_OPEN_APPEND | FA_WRITE);
				if (res != FR_OK) {
					f_mount(0, "", 1);
					status = StatusFatFsOpen;
					break;
				}
			}

			// Option 0, ... files:multiple
			if (0 == option) {

				sprintf(fileName, "\\fox%04ld.txt", f);
				res = f_open(&MyFile, fileName, FA_OPEN_APPEND | FA_WRITE);
				if (res != FR_OK) {
					f_mount(0, "", 1); // Un-do mount from earlier
					status = StatusFatFsOpen;
					break;
				}
			}

			uint8_t buff[100];
			sprintf(buff, "Cycle: %lu, f_open: %s\r\n", f, fileName);
			Console_WriteString(buff);

			// Write each line into the file.
			for (uint32_t i = 0; i < numberLinesPerFile; i++) {

				// Write a line...
				sprintf(buff, qbfText, f, i);
				res = f_write(&MyFile, buff, strlen(buff), (void *)&bytesWritten);

				// Check results
				if (res != FR_OK) {
					f_close(&MyFile);
					f_mount(0, "", 1);
			    	status = StatusFatFsWrite;
					break;
				}

				if (bytesWritten != strlen(buff)) {
					f_close(&MyFile);
					f_mount(0, "", 1);
			    	status = StatusFatFsBytesWritten;
					break;
				}

			} // for (uint32_t i = 0; i < numberLinesPerFile; i++) {

			// Every 1000 file iterations, sync the file system
			if (0 == (f%1000)) {
				res = f_sync(&MyFile);
				if (res != FR_OK) {
					f_close(&MyFile);
					f_mount(0, "", 1); // Un-do mount from earlier
					status = StatusFatFsSync;
					break;
				}
			}

			// 0=mount:single, files:multiple
			if (StatusOk == status) {
				if (0 == option) {
					res = f_close(&MyFile);
					if (res != FR_OK) {
						f_mount(0, "", 1);
						status = StatusFatFsClose;
						break;
					}
				}
			}

			// Note: 1=mount:single, file:single:,open:single

			// 2=mount:multiple, file:single, open:multiple
			if (StatusOk == status) {
				if (2 == option) {
					res = f_close(&MyFile);
					if (res != FR_OK) {
						f_mount(0, "", 1);
						status = StatusFatFsClose;
						break;
					}
					res = f_mount(&USBDISKFatFs, "", 1);
					if (res != FR_OK) {
						status = StatusFatFsDismount;
						break;
					}
				}
			}

			// Bust out?
			if (StatusOk != status) {
				break;
			}

		}  // for (uint16_t f = 0; (f < numberOfFiles) ...

	} // if (StatusOk == ...

    // Clean-up before return
    // File option - {0=mount:single, files:multiple}, {1=mount:single, file:single:,open:single}, {2=mount:multiple, file:single, open:multiple}
	if (StatusOk == status) {

		if (1 == option) {
			res = f_close(&MyFile);
			if (res != FR_OK) {
				f_mount(0, "", 1);
				status = StatusFatFsClose;
			}
		}
	}

	if (StatusOk == status) {

		if ((0 == option) || (1 == option)) {
			res = f_mount(&USBDISKFatFs, "", 1);
			if (res != FR_OK) {
				status = StatusFatFsDismount;
			}
		}
	}

    return status;

} // cliQbfCommand

static const char * getFilenameExt(const char *filename) 
{
    const char *dot = strrchr(filename, '.');
    if(!dot || dot == filename) {
    	return filename;
    } else {
    	return dot + 1;
    }
}

static status_t findLastCsvFileIndex(int16_t * output)
{
	status_t status = StatusOk;
	int16_t maxIndex = -1;
    
	// Open root
    DIR dir;
    FILINFO filinfo;
    FRESULT res = f_opendir(&dir, "");
    if (res == FR_OK) {
    	// Loop through files
        for (;;) {
        	// Get next file
            res = f_readdir(&dir, &filinfo);
            // Break on error or end of directory
            if (res != FR_OK || filinfo.fname[0] == 0) break;
            
            // Check if CSV file
            if ((strncmp(filinfo.fname, CSV_FILE_PREFIX, strlen(CSV_FILE_PREFIX)) == 0) &&
            		(strncmp(getFilenameExt(filinfo.fname), "CSV", strlen("CSV")) == 0))
            {
            	// Check if index is greater than current
            	int16_t newIndex = -1;
            	sscanf(&filinfo.fname[strlen(CSV_FILE_PREFIX)], "%hd", &newIndex);
            	
            	if (newIndex > maxIndex) maxIndex = newIndex;
            }
        }
        // Write output & close directory
        *output = maxIndex;
        f_closedir(&dir);
    } else {
    	status = StatusFatFsRead;
    }

    return status;
}

static status_t truncateFile(const char * filename)
{
	status_t status = StatusOk;
	FIL file;
	
	// We may get an FR_DENIED here, but that just means the file was already truncated & write protected
	FRESULT res = f_open(&file, filename, FA_OPEN_EXISTING | FA_READ | FA_WRITE);
	if (FR_OK == res) {
		// Let user know what's happening
		UserInterface_BlinkLed(ledPatternTruncateCsv);
		// Get file size
		FSIZE_t fileSize = f_size(&file);
		if (0 == fileSize) {
			// Handle file size 0
			res = f_close(&file);
			if (FR_OK == res) {
				f_unlink(filename);
			}
			if (FR_OK != res) status = StatusFatFsWrite;
		} else {
			// Do a binary search for the last non-0xFF
			FSIZE_t left = 0;
			FSIZE_t right = fileSize - 1;
			for (;;) {
				FSIZE_t middle = left + ((right - left) / 2);
				
				// Check boundaries -- if we're at left edge, close & unlink
				// if we're at right edge, exit and don't truncate
				if (0 == middle) {
					res = f_close(&file);
					if (FR_OK == res) {
						f_unlink(filename);
					}
					if (FR_OK != res) status = StatusFatFsWrite;
					return status; // exit function to avoid recalling close()
				} else if ((fileSize - 2) == middle) {
					break;
				}
				
				// Move read/write pointer
				res = f_lseek(&file, middle);
				if (FR_OK == res) {
					// Read 2 characters
					uint8_t buff[2];
					unsigned int bytesRead = 0;
					res = f_read(&file, buff, sizeof(buff), &bytesRead);
					if ((FR_OK == res) && (sizeof(buff) == bytesRead)) {
						// Check for last character condition
						if ((0xFF != buff[0]) && (0xFF == buff[1])) {
							// We've found the end, bring r/w pointer back to first 0xFF and truncate
							res = f_lseek(&file, middle + 1);
							if (FR_OK == res) {
								res = f_truncate(&file);
							}
							if (FR_OK != res) status = StatusFatFsWrite;
							break;
						} else if (0xFF == buff[0]) {
							// We're too high -- go down
							right = middle - 1;
						} else {
							// We're too low -- go up
							left = middle + 1;
						}
					} else {
						status = StatusFatFsRead;
						break;
					}
				} else {
					status = StatusFatFsWrite;
					break;
				}
			}
			
			res = f_close(&file);
			if (FR_OK != res) status = StatusFatFsClose;
			res = f_chmod(filename, AM_RDO, AM_RDO);
			if (FR_OK != res) status = StatusFatFsWrite;
		}
	}
	
	return status;
}

#ifdef FILE_CHUNK_ALLOC_MODE
static status_t expandFile(FIL * file, FSIZE_t newSize)
{
	FSIZE_t rwPointer = f_tell(file);
	FRESULT res = f_lseek(file, newSize); // seek to grow the file
	if (FR_OK == res) {
		res = f_lseek(file, rwPointer); // restore R/W pointer
	}
	
	return (FR_OK == res) ? StatusOk : StatusFatFsWrite;
}
#endif

static status_t readFifoData(uint8_t* pBuffer, uint16_t bufferSize, uint16_t* bytesRead)
{
    status_t status = StatusOk;
    *bytesRead = 0;
    
    uint16_t count = 0;
    status = Fifo_GetCount(&count);
    
    if (StatusOk == status) {
        if (count > 0) {
            uint16_t readLen = (count > bufferSize) ? bufferSize : count;
            status = Fifo_Read(pBuffer, readLen);
            
            if (StatusOk == status) {
                *bytesRead = readLen;
            }
        } else {
            status = StatusQueueEmpty;
        }
    }

    return returnStatus(status, eSucReadStatus);
}

static status_t writeToFile(uint8_t* pBuffer, uint16_t bytesToWrite)
{
    int bytesWritten;
    FRESULT res = FR_OK;
    status_t status = StatusOk;
    FIL* deviceDataFile;

    deviceDataFile = FATFS_GetCsvFile();
#ifndef SWO_PROFILE_BUILD
    // Prevent writes after file full (and multiple "end of file"'s
    if (diskFull) {
    	SysState_NotifyFlashFull();
    	status = StatusFatFsFull;
    }
    
    if (StatusOk == status) {
		res = f_write(deviceDataFile, pBuffer, bytesToWrite, &bytesWritten);
	
		// Check for bad result
		if (FR_OK != res) {
			status = StatusFatFsWrite;
		}
		// Check for end of disk
		else if (bytesWritten < bytesToWrite) {
			diskFull = true;
			status = StatusFatFsFull;
		}
		// Check for file full/expand
		else if (FATFS_GetCsvFileSize() < f_tell(deviceDataFile)) {
#ifdef FILE_PRE_ALLOC_MODE
			diskFull = true;
			status = StatusFatFsFull;
#elif defined(FILE_CHUNK_ALLOC_MODE)
			status = expandFile(deviceDataFile, FATFS_GetCsvFileSize() + FILE_EXPAND_SIZE);
			FATFS_SetCsvFileSize(f_size(deviceDataFile));
#endif
		}
    }
    
    // I
#endif // SWO_PROFILE_BUILD

#if 0
    if(StatusOk == status){
        FRESULT res;
        res = f_sync(deviceDataFile);
        if(FR_OK != res){
            status = StatusFatFsSync;
        }
    }
#endif

    return returnStatus(status, eSucWriteStatus);
}


// Public functions bodies ---------------------------------------------------
status_t DataReceive_Init(void)
{
	status_t status;
	status = StatusOk;

	if (initialized) {
	    status = StatusAlreadyInitialized;
	}

	if (StatusOk == status) {
		status = Console_ExportCommandsToCli (&exportedReg, commandList);
	}
	
	if (StatusOk == status) {
		initialized = true;
		fileOpen = false;
	}

	return returnStatus(status, eSucInitStatus);

}  // DataReceive_Init

status_t DataReceive_Tick(void)
{
	uint16_t returnBytes = 0;
	status_t status = StatusOk;

	if (StatusOk == status) {
		status = readFifoData(csvLineBuff, sizeof(csvLineBuff), &returnBytes);
	}
	if ((StatusOk == status) && fileOpen)
	{
#ifndef NO_FLASH_WRITES
	    
#ifdef PROFILE_WRITES
	    writeProfile.inProgress = true;
	    writeProfile.numCalls++;
	    uint32_t startTime = HAL_GetTick();
#endif // PROFILE_WRITES

        status = writeToFile(csvLineBuff, returnBytes);

		
#ifdef PROFILE_WRITES
        writeProfile.totalTime += HAL_GetTick() - startTime;
        writeProfile.inProgress = false;
#endif // PROFILE_WRITES
        
#endif // NO_FLASH_WRITES
		if(StatusFatFsFull == status){
			//Flash Chip is full, Stop the Study
			SysState_NotifyFlashFull();
		}
	}

	return returnStatus(status, eSucWriteStatus);
} //DataReceive_Tick

status_t DataReceive_OpenCsvFile(uint32_t fileSizeKb)
{
	status_t status = StatusOk;
#ifndef SWO_PROFILE_BUILD
	FRESULT res;
	FATFS* USBDISKFatFs;
	FIL* deviceDataFile;

	USBDISKFatFs = FATFS_GetFileSystem();
	deviceDataFile = FATFS_GetCsvFile();

	res = f_mount(USBDISKFatFs, "", 1);

	if (FR_OK != res) {
		status = StatusFatFsVolume;
	}
	
	// Truncate last file
	int16_t lastCsvIndex = -1;
	if (StatusOk == status) {
		status = findLastCsvFileIndex(&lastCsvIndex);
		// If -1, there was no CSV file
		if ((lastCsvIndex >= 0) && (StatusOk == status)) {
			// Build file name
			uint8_t filename[20];
			sprintf(filename, "device%02d.csv", lastCsvIndex);
			status = truncateFile(filename);
		}
	}
	
	// Make new file
	if (StatusOk == status) {
		// Build file name
		uint8_t filename[20];
		sprintf(filename, "device%02d.csv", lastCsvIndex + 1);

		// Open file
		res = f_open(deviceDataFile, filename, FA_CREATE_NEW | FA_READ | FA_WRITE);
		if (res == FR_OK) {
			UserInterface_BlinkLed(ledPatternCreateCsv); // don't update status with this
			// Allocate file space
#ifdef FILE_PRE_ALLOC_MODE
			DWORD freeClust = 0;
			res = f_getfree("", &freeClust, &USBDISKFatFs);
			if (res == FR_OK) {
				int64_t fileSize = freeClust * USBDISKFatFs->csize * 512; // TODO: Get sector size from disk driver
				int64_t shrinkSize = FILE_ALLOC_RETRY_SHRINK;
				for (int i = 0; (i < FILE_ALLOC_RETRY_COUNT) && (fileSize > 0); i++) {
					res = f_expand(deviceDataFile, (DWORD)fileSize, 1);
					if (FR_DENIED == res) {
						// Retry with smaller file
						fileSize -= shrinkSize;
						shrinkSize *= 2; // exponential shrink
					} else {
						break;
					}
				}
			}
#elif defined(FILE_CHUNK_ALLOC_MODE)
			status = expandFile(deviceDataFile, FILE_EXPAND_SIZE);
#endif
		}
		// Store file size & setup file header
		if ((res == FR_OK) && (StatusOk == status)) {
			FATFS_SetCsvFileSize(f_size(deviceDataFile));
			
			serialNum_t serialNum;
			DeviceInfo_GetSerialNum(&serialNum);
			//Set UUID
			snprintf(csvLineBuff, sizeof(csvLineBuff), "UUID: %08lX-%08lX-%08lX\r\n", 
					serialNum.words[0], serialNum.words[1], serialNum.words[2]);
			f_puts(csvLineBuff, deviceDataFile);

			//Set Firmware Version
			char * firmwareVersion;
			DeviceInfo_GetFirmwareVersionStr(&firmwareVersion);
			snprintf(csvLineBuff, sizeof(csvLineBuff), "Firmware Version: %s %s %s\r\n", 
					firmwareVersion, __DATE__, __TIME__);
			f_puts(csvLineBuff, deviceDataFile);
			
			// Get header data from data aggregator
			status = DataAggregator_PrintHeader(csvLineBuff, sizeof(csvLineBuff));

			if (StatusOk == status) {
				f_puts(csvLineBuff, deviceDataFile);
				f_sync(deviceDataFile);
			}
			
			diskFull = false;
			fileOpen = true;
		} else if (res ==  FR_NO_FILESYSTEM) {
			status = StatusFatFsVolume;
		} else if (res ==  FR_DENIED) {
			status = StatusFatFsOpen;
		}
	}
#endif // SWO_PROFILE_BUILD
	return returnStatus(status, eSucWriteStatus);
}

status_t DataReceive_Flush(uint32_t timeoutMs)
{
	status_t status = StatusFlushTimeout; // this will be cleared if we flush buffer in time
	uint32_t startTime = SysTime_GetMs();
	
	status_t tickStatus = StatusOk;
	while (!SysTime_IsElapsed(startTime, timeoutMs)) {
		tickStatus = DataReceive_Tick();
		if (StatusQueueEmpty == tickStatus) {
			// This is what we wanted -- report good status
			status = StatusOk;
			break;
		} else if (StatusFatFsFull == tickStatus) {
			status = tickStatus;
		}
	}
	
	// TODO: If we depart from pre-allocated files, sync here
	
	return returnStatus(status, eSucIoctlStatus);
}

status_t DataReceive_CloseCsvFile(void)
{
	status_t status = StatusOk;
	FIL* deviceDataFile = FATFS_GetCsvFile();;
	
	// Let user know what's happening
	UserInterface_BlinkLed(ledPatternTruncateCsv);
	// Truncate and close
	FRESULT res = f_truncate(deviceDataFile);
	if (FR_OK != res) status = StatusFatFsWrite;
	res = f_close(deviceDataFile);
	if (FR_OK != res) status = StatusFatFsClose;
	
	// Write protect, unfortunately we have to chmod with file closed, so we rebuild the name..
	int16_t lastCsvIndex = -1;
	status = Status_Preserve(status, findLastCsvFileIndex(&lastCsvIndex));
	if (StatusOk == status) {
		uint8_t filename[20];
		sprintf(filename, "device%02d.csv", lastCsvIndex);
		res = f_chmod(filename, AM_RDO, AM_RDO);
		if (FR_OK != res) status = StatusFatFsWrite;
	}
	
	// Dismount drive
	res = f_mount(0, "", 1);
	if (FR_OK != res) status = StatusFatFsDismount;
	
	fileOpen = false;
	
	return StatusOk;
}

status_t DataReceive_CheckCsvExpand(void)
{
	status_t status = StatusOk;
#ifndef SWO_PROFILE_BUILD
#ifdef FILE_CHUNK_ALLOC_MODE
	FIL * deviceDataFile = FATFS_GetCsvFile();
	// Check for file expand
	if (FATFS_GetCsvFileSize() <= (f_tell(deviceDataFile) + FILE_EXPAND_THRESHOLD)) {
		status = expandFile(deviceDataFile, FATFS_GetCsvFileSize() + FILE_EXPAND_SIZE);
		FATFS_SetCsvFileSize(f_size(deviceDataFile));
	}
#endif // FILE_CHUNK_ALLOC_MODE
#endif // SWO_PROFILE_BUILD
	return status;
}

#ifdef PROFILE_WRITES
void DataReceive_ProfileInterruptTime(uint32_t timeMs)
{
    if (writeProfile.inProgress) {
        writeProfile.totalTime -= timeMs;
    }
}
#endif


/// SAEC Kinetic Vision, Inc. ----------- END OF FILE


