/**
  @file       I2C.c

  @copyright  (C) 2019 Kinetic Vision, Cincinnati Ohio.
               This software is property of SAEC Kinetic Vision, Inc
               and is considered confidential.

  @brief      I2C software unit "C" file.

  @author     Parker Kamer

  @ingroup    I2cSu

  Configuration History
  =====================

  Config Item    | Value
  -------------- | -----
  Config #       | NA
  Revision       | NA
  Revised, Date  | NA
  QA, Date       | NA
  Approved, Date | NA
  Released, Date | NA

  Significant Modification History (Most recent at top)
  =====================================================

  Date         | Initials | Details
  ------------ | -------- | -------
  22 Jul 2019  | PK       | Original

  Theory of Operation
  ===================
  Communication to the IMU (BNO055) will be handled over an I2C interface.

*/

// Includes ------------------------------------------------------------------

#include "i2c.h"

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include "stm32l4xx_hal.h"

#include "../StatusSu/Status.h"
#include "../ConsoleSu/Console.h"
#include "../SwUnitControlSu/SwUnitControl.h"
#include "../ConfigSu/Config.h" // SYS_CLOCK_##MHZ
#include "../SysTimeSu/SysTime.h"
#include "../PowerSu/power.h"
#include "i2c.h"

// Private macros ------------------------------------------------------------
/// This macro feeds status information for tracking purposes to software unit control.
#define returnStatus(__status__,__source__) SwUnitControl_WriteStatus(eSucI2cSu,__source__,__status__,__LINE__);
#define I2C_INSTANCE_POOL_SIZE			6

// Private constants ---------------------------------------------------------

// Private types -------------------------------------------------------------
typedef enum {
	I2cOpRead,
	I2cOpWrite,
	I2cOpMemRead,
} i2cOp_t;

typedef struct {
	bool created;
	bool opPending;
	i2cOp_t op;
	uint8_t slaveAddress;
	volatile overlapped_t * overlapped;
} instanceData_t;

// Private variables ---------------------------------------------------------
I2C_HandleTypeDef hi2c1; // this needs to be accessible to st files
static bool initialized = false;
static instanceData_t instances[I2C_INSTANCE_POOL_SIZE];
static bool opInProgress = false;
static instanceData_t * opInstance;
static uint32_t opStartTime = 0;
static uint32_t opTimeout = 0;

// Private function prototypes -----------------------------------------------
static void write(instanceData_t * instance);
static void read(instanceData_t * instance);
static void memRead(instanceData_t * instance);

static status_t waitForOpOrTimeout(uint32_t * timeout);
static void setupAsyncTimeout(uint32_t timeoutMs);

static inline void handleHalCallback(uint32_t errorCode);
static inline void sendCallback(overlappedCallback_t callback, uint32_t errorCode);
static inline void startNextOp(void);

static void resetInstanceData(void);
static void clearAllOperations(void);

// Private function bodies ---------------------------------------------------
static void write(instanceData_t * instance)
{
    instance->opPending = false;
	HAL_StatusTypeDef halStatus = HAL_I2C_Master_Transmit_IT(&hi2c1,
			instance->slaveAddress, (uint8_t *)instance->overlapped->outBuffer,
			instance->overlapped->outBufferSize);

	if(HAL_OK == halStatus) {
		opInstance = instance;
		opInProgress = true;

		setupAsyncTimeout(instance->overlapped->timeout);
	} else {
		instance->overlapped->callback(StatusHal);
	}
}

static void read(instanceData_t * instance)
{
    instance->opPending = false;
	HAL_StatusTypeDef halStatus = HAL_I2C_Master_Receive_IT(&hi2c1,
			instance->slaveAddress | 1, (uint8_t *)instance->overlapped->inBuffer,
			instance->overlapped->inBufferSize);

	if(HAL_OK == halStatus) {
		opInstance = instance;
		opInProgress = true;

		setupAsyncTimeout(instance->overlapped->timeout);
	} else {
		instance->overlapped->callback(StatusHal);
	}
}

static void memRead(instanceData_t * instance)
{
    instance->opPending = false;
	HAL_StatusTypeDef halStatus = HAL_OK;
	// Determine reg address size
	if (instance->overlapped->outBufferSize == 1) {
		halStatus = HAL_I2C_Mem_Read_IT(&hi2c1, instance->slaveAddress | 1 ,
				*((uint8_t *)instance->overlapped->outBuffer),
				I2C_MEMADD_SIZE_8BIT, (uint8_t *)instance->overlapped->inBuffer,
				instance->overlapped->inBufferSize);

	} else if (instance->overlapped->outBufferSize == 2) {
		halStatus = HAL_I2C_Mem_Read_IT(&hi2c1, instance->slaveAddress | 1 ,
				*((uint16_t*)instance->overlapped->outBuffer),
				I2C_MEMADD_SIZE_16BIT, (uint8_t *)instance->overlapped->inBuffer,
				instance->overlapped->inBufferSize);
	} else {
		// error
		halStatus = HAL_ERROR;
	}

	if(HAL_OK == halStatus) {
		opInstance = instance;
		opInProgress = true;

		setupAsyncTimeout(instance->overlapped->timeout);
	} else {
		instance->overlapped->callback(StatusHal);
	}
}

static status_t waitForOpOrTimeout(uint32_t * timeout)
{
	status_t status = StatusOk;

	if (opInProgress) {
		// Wait for op or timeout to end
		uint32_t start = SysTime_GetMs();
		while (opInProgress && !SysTime_IsElapsed(start, *timeout));

		uint32_t newTime = SysTime_GetMs();
		if (SysTime_IsElapsed(start, *timeout))
			status = StatusHalTimeout;
		else
			*timeout -= (newTime - start); // update time
	}

	return status;
}

static void setupAsyncTimeout(uint32_t timeoutMs)
{
	opStartTime = SysTime_GetMs();
	opTimeout = timeoutMs;
}

static inline void handleHalCallback(uint32_t errorCode)
{
	if (opInstance) {
		overlappedCallback_t callback = opInstance->overlapped->callback;
		// Update state
		opInstance = NULL;
		opInProgress = false;

		sendCallback(callback, errorCode);
	}
	startNextOp();
}

static inline void sendCallback(overlappedCallback_t callback, uint32_t errorCode)
{
	if (errorCode == HAL_I2C_ERROR_NONE)
		callback(StatusOk);
	else if (errorCode == HAL_I2C_ERROR_TIMEOUT)
		callback(StatusHalTimeout);
	else
		callback(StatusHal);
}

static inline void startNextOp(void)
{
	for (int i = 0; i < I2C_INSTANCE_POOL_SIZE; i++) {
		if (instances[i].created && instances[i].opPending) {
			if (instances[i].op == I2cOpWrite)
				write(&instances[i]);
			if (instances[i].op == I2cOpRead)
				read(&instances[i]);
			if (instances[i].op == I2cOpMemRead)
				memRead(&instances[i]);

			break;
		}
	}
}

static void resetInstanceData(void)
{
	for (int i = 0; i < I2C_INSTANCE_POOL_SIZE; i++) {
		instances[i].created = false;
	}
	opInProgress = false;
	opInstance = NULL;
}

static void clearAllOperations(void)
{
	for (int i = 0; i < I2C_INSTANCE_POOL_SIZE; i++) {
		instances[i].opPending = false;
	}
	opInProgress = false;
	opInstance = NULL;
}

// Public functions bodies ---------------------------------------------------

status_t I2C_Init(bool resetInstances)
{
	status_t status = StatusOk;

	if(initialized) {
		status = StatusAlreadyInitialized;
	} else {
		hi2c1.Instance = I2C1;
		
		// Setup timing reg for 100KHz. 300 ns Rise, 300 ns Fall
		switch (Power_GetClockSpeed()) {
			case clockSpeed80Mhz:
				//hi2c1.Init.Timing = 0x20A60D20; // Old -- 400 KHz
				hi2c1.Init.Timing = 0x30A54E69; // 100 KHz
				break;
			case clockSpeed60Mhz:
				//hi2c1.Init.Timing = 0x10B60F24; // Old -- 400 KHz
				hi2c1.Init.Timing = 0x20A44E69; // 100 KHz
				break;
			case clockSpeed40Mhz:
				//hi2c1.Init.Timing = 0x00F71330; // Old -- 400 KHz
				hi2c1.Init.Timing = 0x10A44D69; // 100 KHz
				break;
			case clockSpeed26Mhz:
				//hi2c1.Init.Timing = 0x00A40C1E; // Old -- 400 KHz
				hi2c1.Init.Timing = 0x00E46488; // 100 KHz
				break;
			case clockSpeed16Mhz:
				//hi2c1.Init.Timing = 0x00610611; // Old -- 400 KHz
				hi2c1.Init.Timing = 0x00813F50; // 100 KHz
				break;
			case clockSpeed8Mhz:
				//hi2c1.Init.Timing = 0x00300208; // Old -- 400 KHz
				hi2c1.Init.Timing = 0x00401E26; // 100 KHz
				break;
			case clockSpeed4Mhz:
				//hi2c1.Init.Timing = 0x00100002; // Old -- 400 KHz
				hi2c1.Init.Timing = 0x00200D12; // 100 KHz
				break;
			default:
				hi2c1.Init.Timing = 0x10A44D69;
				break;
		}

        hi2c1.Init.OwnAddress1 = 0;
		hi2c1.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
		hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
		hi2c1.Init.OwnAddress2 = 0;
		hi2c1.Init.OwnAddress2Masks = I2C_OA2_NOMASK;
		hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
		hi2c1.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
		if (HAL_OK != HAL_I2C_Init(&hi2c1)) {
			status = StatusHal;
		}

		// Configure Analogue filter
		if (HAL_OK != HAL_I2CEx_ConfigAnalogFilter(&hi2c1, I2C_ANALOGFILTER_ENABLE)) {
			status = StatusHal;
		}

		// Configure Digital filter
		if (HAL_OK != HAL_I2CEx_ConfigDigitalFilter(&hi2c1, 0)) {
			status = StatusHal;
		}

		if (StatusOk == status) {
			if (resetInstances)
				resetInstanceData();
			initialized = true;
		}
	}

	return returnStatus(status, eSucInitStatus);
}

status_t I2C_DeInit(void)
{
	status_t status = StatusOk;
	if(initialized) {

		HAL_StatusTypeDef halStatus = HAL_I2C_DeInit(&hi2c1);
		if(HAL_OK != halStatus){
			status = StatusHal;
		}
		else {
			clearAllOperations();
			initialized = false;
		}
	}

	return status;
}

status_t I2C_Tick(void)
{
	status_t status = StatusOk;
	// Check for async timeout
	// This won't be very accurate, but it should pull the software out of
	// a held I2C operation..
	if (opInProgress) {
		if (SysTime_IsElapsed(opStartTime, opTimeout)) {
			if (opInstance) {
				HAL_I2C_Master_Abort_IT(&hi2c1, opInstance->slaveAddress);
				status = StatusHalTimeout; // track timeouts
			}
		}
	}

	return returnStatus(status, eSucIoctlStatus);
}

status_t I2C_CreateHandle(i2cHandle_t * handleOut, uint8_t slaveAddress)
{
	status_t status = StatusInstancePoolFull;

	// seek free instance
	for (int i = 0; i < I2C_INSTANCE_POOL_SIZE; i++) {
		if (!instances[i].created) {
			instances[i].created = true;
			instances[i].opPending = false;
			instances[i].slaveAddress = slaveAddress;
			*handleOut = i;

			status = StatusOk;
			break;
		}
	}

	return returnStatus(status, eSucIoctlStatus);
}

status_t I2C_CloseHandle(i2cHandle_t handle)
{
	status_t status = StatusOk;

	if ((handle >= I2C_INSTANCE_POOL_SIZE) || !instances[handle].created)
		status = StatusInstanceNotFound;

	if (StatusOk == status) {
		instances[handle].created = false;
		instances[handle].opPending = false;
	}

	return returnStatus(status, eSucIoctlStatus);
}

status_t I2C_WriteAsync(i2cHandle_t handle, volatile overlapped_t * overlapped)
{
	status_t status = StatusOk;

	// Input validation
	if ((handle >= I2C_INSTANCE_POOL_SIZE) || !instances[handle].created)
		status = StatusInstanceNotFound;
	else if (instances[handle].opPending || (opInstance == &instances[handle]))
		status = StatusAlreadyInProgress;
	else if (overlapped == NULL)
		status = StatusNullParameter;
	else if ((overlapped->callback == NULL) || (overlapped->outBuffer == NULL))
		status = StatusNullParameter;
	else if (overlapped->outBufferSize < 1)
		status = StatusBufferLength;

	if (StatusOk == status) {
		instances[handle].op = I2cOpWrite;
		instances[handle].overlapped = overlapped;
		if (!opInProgress) {
			write(&instances[handle]);
		} else {
			instances[handle].opPending = true;
		}
	}

	return returnStatus(status, eSucWriteStatus);
}

status_t I2C_ReadAsync(i2cHandle_t handle, volatile overlapped_t * overlapped)
{
	status_t status = StatusOk;

	// Input validation
	if ((handle >= I2C_INSTANCE_POOL_SIZE) || !instances[handle].created)
		status = StatusInstanceNotFound;
	else if (instances[handle].opPending || (opInstance == &instances[handle]))
		status = StatusAlreadyInProgress;
	else if (overlapped == NULL)
		status = StatusNullParameter;
	else if ((overlapped->callback == NULL) || (overlapped->inBuffer == NULL))
		status = StatusNullParameter;
	else if (overlapped->inBufferSize < 1)
		status = StatusBufferLength;

	if (StatusOk == status) {
		instances[handle].op = I2cOpRead;
		instances[handle].overlapped = overlapped;
		if (!opInProgress) {
			read(&instances[handle]);
		} else {
			instances[handle].opPending = true;
		}
	}

	return returnStatus(status, eSucWriteStatus);
}

status_t I2C_MemReadAsync(i2cHandle_t handle, volatile overlapped_t * overlapped)
{
	status_t status = StatusOk;

	// Input validation
	if ((handle >= I2C_INSTANCE_POOL_SIZE) || !instances[handle].created)
		status = StatusInstanceNotFound;
	else if (instances[handle].opPending || (opInstance == &instances[handle]))
		status = StatusAlreadyInProgress;
	else if (overlapped == NULL)
		status = StatusNullParameter;
	else if ((overlapped->callback == NULL) || (overlapped->inBuffer == NULL)
			|| (overlapped->outBuffer == NULL))
		status = StatusNullParameter;
	else if ((overlapped->inBufferSize < 1) || (overlapped->outBufferSize < 1))
		status = StatusBufferLength;

	if (StatusOk == status) {
		instances[handle].op = I2cOpMemRead;
		instances[handle].overlapped = overlapped;
		if (!opInProgress) {
			memRead(&instances[handle]);
		} else {
			instances[handle].opPending = true;
		}
	}

	return returnStatus(status, eSucWriteStatus);
}

status_t I2C_Write(i2cHandle_t handle, uint8_t * writeBuffer, size_t len,
		uint16_t timeout)
{
	status_t status = StatusOk;

	// Input validation
	if ((handle >= I2C_INSTANCE_POOL_SIZE) || !instances[handle].created)
		status = StatusInstanceNotFound;
	else if (writeBuffer == NULL)
		status = StatusNullParameter;
	else if (len < 1)
		status = StatusBufferLength;

	uint32_t newTimeout = timeout;
	if (StatusOk == status) {
		waitForOpOrTimeout(&newTimeout);
	}

	if (StatusOk == status) {
		HAL_StatusTypeDef halStatus = HAL_I2C_Master_Transmit(&hi2c1,
					instances[handle].slaveAddress, writeBuffer, len, newTimeout);
		if (halStatus == HAL_TIMEOUT) {
			status = StatusHalTimeout;
		} else if (halStatus != HAL_OK) {
			status = StatusHal;
		}
	}

	startNextOp();
	return returnStatus(status, eSucWriteStatus);
}

status_t I2C_Read(i2cHandle_t handle, uint8_t * readBuffer, size_t len,
		uint16_t timeout)
{
	status_t status = StatusOk;

	// Input validation
	if ((handle >= I2C_INSTANCE_POOL_SIZE) || !instances[handle].created)
		status = StatusInstanceNotFound;
	else if (readBuffer == NULL)
		status = StatusNullParameter;
	else if (len < 1)
		status = StatusBufferLength;

	uint32_t newTimeout = timeout;
	if (StatusOk == status) {
		waitForOpOrTimeout(&newTimeout);
	}

	if (StatusOk == status) {
		HAL_StatusTypeDef halStatus = HAL_I2C_Master_Receive(&hi2c1,
					instances[handle].slaveAddress, readBuffer, len, newTimeout);
		if (halStatus == HAL_TIMEOUT) {
			status = StatusHalTimeout;
		} else if (halStatus != HAL_OK) {
			status = StatusHal;
		}
	}

	startNextOp();
	return returnStatus(status, eSucWriteStatus);
}

status_t I2C_MemRead(i2cHandle_t handle, uint16_t regAddress,
		size_t addressSize, uint8_t * readBuffer, size_t len, uint16_t timeout)
{
	status_t status = StatusOk;

	// Input validation
	if ((handle >= I2C_INSTANCE_POOL_SIZE) || !instances[handle].created)
		status = StatusInstanceNotFound;
	else if (readBuffer == NULL)
		status = StatusNullParameter;
	else if ((len < 1) || ((addressSize != 1) && (addressSize != 2)))
		status = StatusBufferLength;

	uint32_t newTimeout = timeout;
	if (StatusOk == status) {
		waitForOpOrTimeout(&newTimeout);
	}

	if (StatusOk == status) {
		HAL_StatusTypeDef halStatus;
		if (addressSize == 1) {
			halStatus = HAL_I2C_Mem_Read(&hi2c1, instances[handle].slaveAddress,
					regAddress, I2C_MEMADD_SIZE_8BIT, readBuffer, len, newTimeout);
		} else {
			halStatus = HAL_I2C_Mem_Read(&hi2c1, instances[handle].slaveAddress,
					regAddress, I2C_MEMADD_SIZE_16BIT, readBuffer, len, newTimeout);
		}

		if (halStatus == HAL_TIMEOUT) {
			status = StatusHalTimeout;
		} else if (halStatus != HAL_OK) {
			status = StatusHal;
		}
	}

	startNextOp();
	return returnStatus(status, eSucWriteStatus);
}


// HAL Function ptr customizations ---------------------------------------------
void HAL_I2C_MspInit(I2C_HandleTypeDef* hi2c)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  if(hi2c->Instance==I2C1)
  {
    __HAL_RCC_GPIOA_CLK_ENABLE();

    /**I2C1 GPIO Configuration
    PA9     ------> I2C1_SCL
    PA10     ------> I2C1_SDA
    */
    GPIO_InitStruct.Pin = GPIO_PIN_9;
    GPIO_InitStruct.Mode = GPIO_MODE_AF_OD;
    GPIO_InitStruct.Pull = GPIO_PULLUP;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
    GPIO_InitStruct.Alternate = GPIO_AF4_I2C1;
    HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

    GPIO_InitStruct.Pin = GPIO_PIN_10;
    GPIO_InitStruct.Mode = GPIO_MODE_AF_OD;
    GPIO_InitStruct.Pull = GPIO_PULLUP;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
    GPIO_InitStruct.Alternate = GPIO_AF4_I2C1;
    HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

    /* Peripheral clock enable */
    __HAL_RCC_I2C1_CLK_ENABLE();

    /* I2C1 interrupt DeInit */
    HAL_NVIC_SetPriority(I2C1_EV_IRQn, 2, 0);
    HAL_NVIC_EnableIRQ(I2C1_EV_IRQn);

    HAL_NVIC_SetPriority(I2C1_ER_IRQn, 2, 0);
    HAL_NVIC_EnableIRQ(I2C1_ER_IRQn);

  }

}

void HAL_I2C_MspDeInit(I2C_HandleTypeDef* hi2c)
{
  if(hi2c->Instance==I2C1)
  {
	/* Peripheral clock disable */
    __HAL_RCC_I2C1_CLK_DISABLE();
    __HAL_I2C_DISABLE(hi2c);
    /* I2C1 interrupt DeInit */
    HAL_NVIC_DisableIRQ(I2C1_EV_IRQn);

    HAL_NVIC_DisableIRQ(I2C1_ER_IRQn);
  }

}

void HAL_I2C_MasterTxCpltCallback(I2C_HandleTypeDef * hi2c)
{
	handleHalCallback(hi2c->ErrorCode);
}

void HAL_I2C_MasterRxCpltCallback(I2C_HandleTypeDef * hi2c)
{
	handleHalCallback(hi2c->ErrorCode);
}

void HAL_I2C_MemRxCpltCallback(I2C_HandleTypeDef * hi2c)
{
	handleHalCallback(hi2c->ErrorCode);
}

void HAL_I2C_AbortCpltCallback(I2C_HandleTypeDef * hi2c)
{
	handleHalCallback(hi2c->ErrorCode);
}

void HAL_I2C_ErrorCallback(I2C_HandleTypeDef * hi2c)
{
	handleHalCallback(hi2c->ErrorCode);
}

//void HAL_I2C_EV_IRQHandler(I2C_HandleTypeDef * hi2c)
//{
//	if (opInstance) {
//		sendCallback(opInstance->overlapped->callback, hi2c->ErrorCode);
//	}
//	startNextOp();
//}
//
//void HAL_I2C_ER_IRQHandler(I2C_HandleTypeDef * hi2c)
//{
//	if (opInstance) {
//		sendCallback(opInstance->overlapped->callback, hi2c->ErrorCode);
//	}
//	startNextOp();
//}

/// SAEC Kinetic Vision, Inc. ----------- END OF FILE
