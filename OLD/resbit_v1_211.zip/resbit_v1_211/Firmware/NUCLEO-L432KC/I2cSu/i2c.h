/**
  @file       I2C.h

  @copyright  (C) 2019 Kinetic Vision, Cincinnati Ohio.
               This software is property of SAEC Kinetic Vision, Inc
               and is considered confidential.

  @brief      I2C software unit "H" file.

  @author     Parker Kamer

  @defgroup   I2cSu I2C communication handling

  Configuration History
  =====================

  Config Item    | Value
  -------------- | -----
  Config #       | NA
  Revision       | NA
  Revised, Date  | NA
  QA, Date       | NA
  Approved, Date | NA
  Released, Date | NA

  Significant Modification History (Most recent at top)
  =====================================================

  Date         | Initials | Details
  ------------ | -------- | -------
  22 Jul 2019  | PK       | Original

  Theory of Operation
  ===================
  Communication to several device, on board or externally connected, will be
  handled over an I2C interface. This software unit will support blocking and
  non blocking forms of communication.

  */

// Define to prevent recursive inclusion -------------------------------------
#ifndef __I2C_SU_H
#define __I2C_SU_H

#include <stdint.h> // int types
#include <stdbool.h> // bool

#include "../StatusSu/Status.h"

// Exported macro ------------------------------------------------------------

// Exported types ------------------------------------------------------------
typedef uint8_t i2cHandle_t;

typedef void (* overlappedCallback_t)(status_t status);

typedef struct {
    overlappedCallback_t callback;
    uint32_t timeout;
    void * inBuffer;
    size_t inBufferSize;
    void * outBuffer;
    size_t outBufferSize;
} overlapped_t;

// Exported constants --------------------------------------------------------

// Exported objects ----------------------------------------------------------

// Exported functions --------------------------------------------------------

///  @brief Initializes the template software unit
///  @param args[in] resetInstances - when true, init will clear all i2c handles
///   and instance data
///  @return StatusOk, StatusAlreadyInitialized, StatusHal
status_t I2C_Init(bool resetInstances);

///  @brief Initializes the template software unit
///  @return StatusOk, StatusHal
status_t I2C_DeInit(void);

///  @brief Gives foreground execution time to this software unit
///  @return StatusOk, StatusHalTimeout
status_t I2C_Tick(void);

///  @brief Creates an I2C instance and returns a handle for that instance
///  @args[out] handleOut - pointer to variable storing new handle
///  @args[in] slaveAddress - address of the I2C slave device associated with this handle
///  @return StatusOk, StatusInstancePoolFull
status_t I2C_CreateHandle(i2cHandle_t * handleOut, uint8_t slaveAddress);

///  @brief Closes an I2C instance
///  @args[in] handle - handle associated with the instance to be closed
///  @return StatusOk, StatusInstanceNotFound
status_t I2C_CloseHandle(i2cHandle_t handle);

///  @brief Qeues a write operation
///  @args[in] handle - handle associated with the instance to be written
///  @args[in] overlapped - pointer to overlapped structure
///   callback - function to be executed upon completion/cancellation/timeout of the operation
///   timeoutMs - max time allowed for operation
///   inBuffer - ignored (can be NULL)
///   inBufferLen - ignored
///   outBuffer - pointer to data to be written to the slave
///   outBufferLen - length of data to be written to the slave
///  @return StatusOk, StatusInstanceNotFound, StatusNullParameter, StatusBufferLength,
///   StatusAlreadyInProgress
status_t I2C_WriteAsync(i2cHandle_t handle, volatile overlapped_t * overlapped);

///  @brief Qeues a read operation
///  @args[in] handle - handle associated with the instance to be read
///  @args[in] overlapped - pointer to overlapped structure
///   callback - function to be executed upon completion/cancellation/timeout of the operation
///   timeoutMs - max time allowed for operation
///   inBuffer - pointer to buffer to store bytes read from I2C device
///   inBufferLen - number of bytes to read from I2C device
///   outBuffer - ignored (can be NULL)
///   outBufferLen - ignored
///  @return StatusOk, StatusInstanceNotFound, StatusNullParameter, StatusBufferLength,
///   StatusAlreadyInProgress
status_t I2C_ReadAsync(i2cHandle_t handle, volatile overlapped_t * overlapped);

///  @brief Qeues a mem read operation (writes slave reg address then reads)
///  @args[in] handle - handle associated with the instance to be transacted
///  @args[in] overlapped - pointer to overlapped structure
///   callback - function to be executed upon completion/cancellation/timeout of the operation
///   timeoutMs - max time allowed for operation
///   inBuffer - pointer to buffer to store bytes read from I2C device
///   inBufferLen - number of bytes to read from I2C device
///   outBuffer - pointer to I2C slave register address
///   outBufferLen - 1 for 8bit slave register address, 2 for 16bit slave register address
///  @return StatusOk, StatusInstanceNotFound, StatusNullParameter, StatusBufferLength,
///   StatusAlreadyInProgress
status_t I2C_MemReadAsync(i2cHandle_t handle, volatile overlapped_t * overlapped);

///  @brief Issues a blocking write operation, bus must be verified idle
///   first with I2C_IsIdle()
///  @args[in] handle - handle associated with the instance to be written
///  @args[in] writeBuffer - pointer to data to be written to the slave
///  @args[in] len - length of data to be written to the slave
///  @args[in] timeout - max time allowed for operation
///  @return StatusOk, StatusInstanceNotFound, StatusNullParameter, StatusBufferLength,
///   StatusHal, StatusHalTimeout
status_t I2C_Write(i2cHandle_t handle, uint8_t * writeBuffer, size_t len,
		uint16_t timeout);

///  @brief Issues a blocking read operation, bus must be verified idle
///   first with I2C_IsIdle()
///  @args[in] handle - handle associated with the instance to be read
///  @args[out] readBuffer - pointer to buffer to store bytes read from I2C device
///  @args[in] len - number of bytes to read from I2C device
///  @args[in] timeout - max time allowed for operation
///  @return StatusOk, StatusInstanceNotFound, StatusNullParameter, StatusBufferLength,
///   StatusHal, StatusHalTimeout
status_t I2C_Read(i2cHandle_t handle, uint8_t * readBuffer, size_t len,
		uint16_t timeout);

///  @brief Issues a blocking mem read operation, bus must be verified idle
///   first with I2C_IsIdle()
///  @args[in] handle - handle associated with the instance to be transacted
///  @args[in] regAddress - I2C slave register address
///  @args[in] addressSize - 1 for 8bit slave register address, 2 for 16bit slave register address
///  @args[out] readBuffer - pointer to buffer to store bytes read from I2C device
///  @args[in] len - number of bytes to read from I2C device
///  @args[in] timeout - max time allowed for operation
///  @return StatusOk, StatusInstanceNotFound, StatusNullParameter, StatusBufferLength,
///   StatusHal, StatusHalTimeout
status_t I2C_MemRead(i2cHandle_t handle, uint16_t regAddress,
		size_t addressSize, uint8_t * readBuffer, size_t len, uint16_t timeout);


#endif // __I2C_SU_H

/// SAEC Kinetic Vision, Inc. ----------- END OF FILE
