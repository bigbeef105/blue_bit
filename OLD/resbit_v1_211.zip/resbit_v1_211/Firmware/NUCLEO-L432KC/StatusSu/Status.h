 /**
  *****************************************************************************
  *
  * @file     Status.h
  * @brief    Status software unit "H" file.
  * @author   Sherman Couch
  * @defgroup StatusSoftwareUnit Status software unit.
  *
  ******************************************************************************
  *
  * @copyright COPYRIGHT (c) 201 SAEC Kinetic Vision, Inc.
  *            All Rights Reserved
  *
  * This software is property of SAEC Kinetic Vision, Inc and is considered
  * confidential.
  *
  ******************************************************************************
  * 
  * Significant Modification History (Most Recent at top)
  * -----------------------------------------------------
  *
  * Date        | Initials | Description
  * ----------- | -------- | ----------- 
  * 05 Jun 2019 | SRC      | Import
  */

// Define to prevent recursive inclusion -------------------------------------
#ifndef __STATUS_H
#define __STATUS_H

#include <stdint.h>
#include <stdio.h>

// Exported macro ------------------------------------------------------------

#define hbound1(_a_) (sizeof(_a_)/sizeof(_a_[0]))
///
/// Returns if the status is ok
///
#define Status_IsOk(status) (status == StatusOk)

///
/// Returns if the status is an error status
///
#define Status_IsError(status) (status != StatusOk)

///
/// Does not overwrite status if already bad (pretty hacky, but it always preserves status & always calls expr)
/// 
#define Status_Preserve(status, expr) ((StatusOk == (status)) ? (expr) : ((expr) == (status)) ? (status) : (status))

// Exported types ------------------------------------------------------------
typedef enum {
	StatusOk = 0,                  //!< StatusOk
	StatusParameter1,              //!< StatusParameter1
	StatusParameter2,              //!< StatusParameter2
	StatusParameter3,              //!< StatusParameter3
	StatusParameter4,              //!< StatusParameter4
	StatusParameter5,              //!< StatusParameter5
	StatusParameter6,              //!< StatusParameter6
	StatusParameter7,              //!< StatusParameter7
	StatusParameter8,              //!< StatusParameter8
	StatusParameterValue,          //!< StatusParameterValue

	StatusNotInitialized = 10,     //!< StatusNotInitialized
	StatusAlreadyInitialized,      //!< StatusAlreadyInitialized
	StatusCarriageReturn,          //!< StatusCarriageReturn
	StatusAlreadyLinked,           //!< StatusAlreadyLinked
	StatusClosed,                  //!< StatusClosed
	StatusHal,                     //!< StatusHal
	StatusHalTimeout,              //!< StatusHalTimeout
	StatusCommandNotFound,         //!< StatusCommandNotFound
	StatusDeviceId,                //!< StatusDeviceId
	StatusSpi,                     //!< StatusSpi

	StatusTc58FlashTimeout = 20,   //!< StatusTc58FlashTimeout
	StatusParameterCount,          //!< StatusParameterCount
	StatusPageNumber,              //!< StatusPageNumber
	StatusNullParameter,           //!< StatusNullParameter
	StatusNotImplemented,          //!< StatusNotImplemented
	StatusPageOffset,              //!< StatusPageOffset
	StatusByteValue,               //!< StatusByteValue
	StatusWriteEnable,             //!< StatusWriteEnable
	StatusProgramFailed,           //!< StatusProgramFailed
	StatusBlockNumber,             //!< StatusBlockNumber

	StatusErase = 30,              //!< StatusErase
	StatusCodePath,                //!< StatusCodePath
	StatusImuChipId,               //!< StatusImuChipId
    StatusDiskNoInit, // Maps to : #define STA_NOINIT		0x01 (Drive not initialized)
	StatusDiskNoDisk, // Maps to : #define STA_NODISK		0x02 (No medium in the drive)
    StatusDiskProtect, // Maps to : #define STA_PROTECT		0x04 (Write protected)
	StatusResultDiskError, // Maps to: DRESULT (type), value: RES_ERROR = 1
	StatusResultWriteProtect, // Maps to: DRESULT (type), value: RES_WRPRT = 2
	StatusResultNotReady, // Maps to: DRESULT (type), value: RES_NOTRDY = 3
	StatusResultInvalidParameter, // Maps to: DRESULT (type), value: RES_PARERR = 4

	StatusTooFewFlashSectors = 40, //!< StatusTooFewFlashSectors
    StatusErased,               //!< StatusErased
	StatusNotErased,               //!< StatusNotErased
	StatusSwUnitEnabled,           //!< StatusSwUnitEnabled
	StatusSwUnitDisabled,          //!< StatusSwUnitDisabled
	StatusSwUnitControlId,         //!< StatusSwUnitControlId
	StautsAdcActiveChannel,        //!< StautsAdcActiveChannel
	StautsAdcNotActiveChannel,     //!< StautsAdcNotActiveChannel
	StautsAdcMaxActiveChannels,    //!< StautsAdcMaxActiveChannels
	StatusAdcNoActiveChannels,     //!< StatusAdcNoActiveChannels

	StatusDataFormat = 50,         //!< StatusDataFormat
	StatusQueueSetup,              //!< StatusQueueSetup
	StatusQueueEmpty,              //!< StatusQueueEmpty
	StatusQueueFull,               //!< StatusQueueFull
	StatusQueueActive,             //!< StatusQueueActive
	StatusCsvEndsInCrLf,           //!< StatusCsvEndsInCrLf
	StatusCsvLineLength,           //!< StatusCsvLineLength
	StatusSpaceAvailable,          //!< StatusSpaceAvailable
	StatusBufferLength,            //!< StatusBufferLength
	StatusNoFileFound,             //!< StatusNoFileFound

	StatusFatFsWrite = 60,         //!< StatusFatFsWrite
	StatusFatFsRead,               //!< StatusFatFsRead
	StatusFatFsOpen,               //!< StatusFatFsOpen
	StatusFatFsClose,              //!< StatusFatFsClose
	StatusFatFsSync,               //!< StatusFatFsSync
	StatusFatFsMount,              //!< StatusFatFsMount
	StatusFatFsVolume,             //!< StatusFatFsVolume
	StatusFatFsFull,               //!< StatusFatFsFull
	StatusFloatingPtError,         //!< StatusFloatingPtError
	StatusSpanningBlock,           //!< StatusSpanningBlock

	StatusUsbConnected = 70,       //!< StatusUsbConnected
	StatusUsbNotConnected,         //!< StatusUsbNotConnected
	StatusNotFormatted,            //!< StatusNotFormatted
	StatusConfigId,                //!< StatusConfigId
	StatusBufferSize,              //!< StatusBufferSize
	StatusFlashType,               //!< StatusFlashType
	StatusFlashBeginAddress,       //!< StatusFlashBeginAddress
	StatusFlashEndAddress,         //!< StatusFlashEndAddress
	StatusFirmwareLogic,           //!< StatusFirmwareLogic
	StatusRemapTable,              //!< StatusRemapTable

	StatusRemapTableSize = 80,     //!< StatusRemapTableSize
	StatusBlockRemapTable,         //!< StatusBlockRemapTable
	StatusFlashPageSize,           //!< StatusFlashPageSize
	StatusFlashBelowMinValidBlocks,//!< StatusFlashBelowMinValidBlocks
	StatusFlashScratchPadBlock,    //!< StatusFlashScratchPadBlock
	StatusFlashRamapTableBlock,    //!< StatusFlashRamapTableBlock
	StatusMakeFileSystem,          //!< StatusMakeFileSystem
	StatusFileSystemDriver,        //!< StatusFileSystemDriver
	StatusFileSystemMount,         //!< StatusFileSystemMount
	StatusConfigStringSize,        //!< StatusConfigStringSize

	StatusConfigStringValue = 90,  //!< StatusConfigStringValue
	StatusConfigSettings,          //!< StatusConfigSettings
	StatusHx711Timeout,            //!< StatusHx711Timeout
	StatusTooManyFiles,            //!< StatusTooManyFiles
	StatusImuAxisRemap,            //!< StatusImuAxisRemap
	StatusBlockPoolLimit,          //!< StatusBlockPoolLimit
	StatusTooManyBadBlocks,        //!< StatusTooManyBadBlocks
	StatusBlockOk,                 //!< StatusBlockOk
	StatusRemap,                   //!< StatusRemap
	StatusTc58ProgramLoad,         //!< StatusTc58ProgramLoad

	StatusBlockPoolFull = 100,     //!< StatusBlockPoolFull
	StatusFatFsBytesWritten,       //!< StatusFatFsBytesWritten
	StatusFatFsDismount,           //!< StatusFatFsDismount
	StatusSource,                  //!< StatusSource
	StatusDestination,             //!< StatusDestination
	StatusRemapBlock,              //!< StatusRemapBlock
	StatusFlashEcc,                //!< StatusFlashEcc
	StatusFlashMemComp,            //!< StatusFlashMemComp
	StatusImuDataNotRdy,           //!< StatusImuDataNotRdy
	StatusI2cChipId,               //!< StatusI2cChipId

	StatusI2cataNotRdy = 110,      //!< StatusI2cataNotRdy
	StatusInstancePoolFull,        //!< StatusInstancePoolFull
	StatusInstanceNotFound,        //!< StatusInstanceNotFound
	StatusAlreadyInProgress,       //!< StatusAlreadyInProgress

	StatusComsCRC = 120,           //!< StatusComsCRC
    StatusComsInvalidNumPackets,//!< StatusComsInvalidNumPackets
    StatusComsInvalidPacketNum, //!< StatusComsInvalidPacketNum
    StatusComsInvalidDataLen,   //!< StatusComsInvalidDataLen
    StatusComsPacketOrder,      //!< StatusComsPacketOrder
    StatusComsDataLenMismatch,  //!< StatusComsDataLenMismatch
    StatusComsReceiveTimeout,   //!< StatusComsReceiveTimeout
    StatusComsSendTimeout,      //!< StatusComsSendTimeout
    StatusComsUnknown,          //!< StatusComsUnknown
    StatusComsResponseError,    //!< StatusComsResponseError

    StatusMessageId = 130,      //!< StatusMessageId
	StatusMessageData,             //!< StatusMessageData
	StatusMessageNotReceived,      //!< StatusMessageNotReceived
	StatusBufferEmpty,             //!< StatusBufferEmpty
	StatusBufferFull,              //!< StatusBufferFull
	StatusSendConfig,              //!< StatusSendConfig
	 
	StatusAlarmAlreadyElapsed = 140,
	StatusFlushTimeout,
	StatusInvalidState,

} status_t;

// Exported constants --------------------------------------------------------

// Exported objects ----------------------------------------------------------

// Exported functions --------------------------------------------------------

#endif // __STATUS_H

/// SAEC Kinetic Vision, Inc. ----------- END OF FILE

