/**
  @file     Tc58FlashUtilities.h

  @copyright  (C) 2019 Kinetic Vision, Cincinnati Ohio.
               This software is property of SAEC Kinetic Vision, Inc
               and is considered confidential.

  @brief      TC58 Flash software unit "H" file.

  @author     Sherman Couch

  @defgroup   Tc58FlashPhysicalSoftwareUnit Tc58FlashPhysical Software Unit (SU),
              encapsulates the details of physical access to the TC58 flash.

  Configuration Information
  =========================

  Config Item    | Value
  -------------- | -----
  Config #       | NA
  Revision       | NA
  Revised, Date  | NA
  QA, Date       | TBD
  Approved, Date | NA
  Released, Date | NA

  Significant Modification History (Most recent at top)
  =====================================================

  Date         | Initials | Details
  ------------ | -------- | -------
  06 Sep 2019  | SC       | Retooled, physical operations are on page only basis, remap ops know 512 byte sectors.
  21 Aug 2019  | SC       | Original

  Theory of Operation
  ===================

  */

// Define to prevent recursive inclusion -------------------------------------
#ifndef __TC58_UTILS_H
#define __TC58_UTILS_H

// Exported macro ------------------------------------------------------------

// Device geometry
#define SIZEOF_LARGEST_PAGE 4096
#define TC58_BLOCKS_PER_UNIT 2048

// From the datasheet
#define MIN_NUMBER_OF_VALID_BLOCKS 2008

#define TC58_BYTES_PER_SECTOR_512 512
#define TC58_MAX_SECTORS_PER_PAGE 8
#define TC58_MAX_BYTES_PER_PAGE (TC58_MAX_SECTORS_PER_PAGE*TC58_BYTES_PER_SECTOR_512) // 4096

#define TC58_INVALID_PAGE_NUMBER 0xFFFF




// Exported types ------------------------------------------------------------

typedef struct {
	uint16_t block;
	uint16_t page;
} Tc58PageAddress_t;

typedef struct {
	uint16_t block;		// 0 .. 2047
	uint16_t page; 		// 0 .. 63
	uint16_t sector;	// 0 .. 7
} Tc58RemapAddress_t;

typedef enum {
	BI_FIRST_REMAPPABLE_BLOCK = 0,

	BI_FILE_SYSTEM_FIRST_BLOCK = BI_FIRST_REMAPPABLE_BLOCK,
	BI_FILE_SYSTEM_LAST_BLOCK = 1499,
	BI_SCRATCHPAD_BLOCK = 1500,

	// The scratchpad was the last block which can be remapped
	BI_LAST_REMAPPABLE_BLOCK = BI_SCRATCHPAD_BLOCK,

	// Every index below here cannot be remapped
	BI_POOL_FIRST_BLOCK = 1501,
	BI_POOL_LAST_BLOCK = (TC58_BLOCKS_PER_UNIT-2),

	// Important: Keep this block last in the part, the format and reformat logic elsewhere depend upon this
	BI_REMAP_BLOCK_FIXED_BLOCK = (TC58_BLOCKS_PER_UNIT-1),

	BI_POOL_MID_POINT = ((BI_POOL_LAST_BLOCK - BI_POOL_FIRST_BLOCK)/2) + BI_POOL_FIRST_BLOCK,


} Tc58BlockIndex_t;



// Exported constants --------------------------------------------------------

// Exported objects ----------------------------------------------------------

// Exported functions --------------------------------------------------------

///  @brief Initializes the software unit
///  @details This function will only return the values shown.
///  @return StatusOK, all is well
///  @return StatusDiskNoInit, maps at a higher level to: #define STA_NOINIT 0x01 (Drive not initialized)
///  @return StatusDiskNoDisk, maps at a higher level to: #define STA_NODISK 0x02 (No medium in the drive)
///  @return StatusDiskProtect, maps at a higher level to: #define STA_PROTECT 0x04 (Write protected)
status_t Tc58Util_Init (void);

///  @brief      Converts from an address of type "Tc58PhysicalAddress_t" to a sector number.
///  @param[in]  a, the TC58 address
///  @param[out] *pS, sectorNumber
///  @return StatusOk
status_t Tc58Util_ConvertAddrRemapToSectors (Tc58RemapAddress_t a, int32_t *pS);

///  @brief      Converts from a sector number to a "Tc58PhysicalAddress_t"
///  @param[in]  s, sectorNumber
///  @param[out] *pA, the TC58 address
///  @return StatusOk
status_t Tc58Util_ConvertAddrSectorsToRemap(int32_t s, Tc58RemapAddress_t *pA);

///  @brief      Adds remap sectors (512 bytes) to remap address passed, returns new remap address in "*pAddress"
///  @param[in]  addSectors
///  @param[in]  *pAddress
///  @param[out] *pAddress
///  @return StatusOk
status_t Tc58Util_AddSectorsToRemapAddress (Tc58RemapAddress_t *pAddress, uint16_t addSectors);

///  @brief      Adds pages (e.g. aprox 4224 bytes, 2048 bytes, etc) to physical address passed, returns new physical address in "*pAddress"
///  @param[in]  addPages
///  @param[in]  *pAddress
///  @param[out] *pAddress
///  @return StatusOk
status_t Tc58Util_AddPagesToPageAddress (Tc58PageAddress_t *pAddress, uint16_t pagesToAdd);

#endif // __TC58_UTILS_H

/// SAEC Kinetic Vision, Inc. ----------- END OF FILE

