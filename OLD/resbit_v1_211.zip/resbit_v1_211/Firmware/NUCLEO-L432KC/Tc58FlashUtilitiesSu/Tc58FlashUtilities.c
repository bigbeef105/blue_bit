/**
  @file    Tc58FlashUtilities.c

  @author  Sherman Couch

  @file       Template.c

  @copyright  (C) 2019 Kinetic Vision, Cincinnati Ohio.
               This software is property of SAEC Kinetic Vision, Inc
               and is considered confidential.

  @brief      Tc58FlashUtility software unit "C" file.

  @ingroup Tc58FlashUtilitiesSoftwareUnit


  Configuration History
  =====================

  Config Item    | Value
  -------------- | -----
  Config #       | NA
  Revision       | NA
  Revised, Date  | NA
  QA, Date       | NA
  Approved, Date | NA
  Released, Date | NA

 Significant Modification History (Most Recent at top)
 -----------------------------------------------------

 Date        | Initials | Description
 ----------- | -------- | -----------
 21 Aug 2019 | SC       | Split several utility functions into this separate software unit.

 Theory of Operation
 -------------------

  */

// Includes ------------------------------------------------------------------

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <stdint.h>

#include "stm32l4xx_hal.h"

// Project software unit includes
#include "../StatusSu/Status.h"
#include "../Tc58FlashUtilitiesSu/Tc58FlashUtilities.h"
#include "../Tc58FlashPhysicalSu/Tc58FlashPhysical.h"
#include "../SwUnitControlSu/SwUnitControl.h"
#include "../Tc58FlashBufferSu/Tc58FlashBuffer.h"


// Private function prototypes -----------------------------------------------

// Private macros ------------------------------------------------------------

// This macro feeds status information for tracking purposes to software unit control.
#define returnStatus(__status__,__source__) SwUnitControl_WriteStatus(eSucTc58FlashUtilitySu,__source__,__status__,__LINE__);

#define TOSHIBA_MANUFACTURE_ID 0x98
#define DEVICE_ID_TC58CVG2S0H 0xCD
#define DEVICE_ID_TC58CVG1S3H 0xCB

#define PAGES_PER_BLOCK 64
#define DEVICE_MODEL "TC58CVG2S0HRAIG"
#define PARAMETER_PAGE_DEVICE_MODEL_OFFSET 44

// Private types -------------------------------------------------------------

// Private constants ---------------------------------------------------------

// Private function prototypes -----------------------------------------------

// Private constants ---------------------------------------------------------

// Private variables ---------------------------------------------------------

static bool initialized = false;
static Tc58PhysicalGeometry_t lGeometry;

// Private function bodies ---------------------------------------------------


// Public functions bodies ---------------------------------------------------


// This function adjusts (adds) a sector to the address
status_t Tc58Util_AddSectorsToRemapAddress (Tc58RemapAddress_t *pAddress, uint16_t addSectors)
{
	status_t status;
	uint16_t carry;

	status = StatusOk;

	if (NULL == pAddress) {
		status = StatusNullParameter;
	} else if (!initialized) {
        status = StatusNotInitialized;
    }

    if (StatusOk == status) {

		pAddress->sector += addSectors;

		if (pAddress->sector >= lGeometry.sectorsPerPage) {

			carry = (pAddress->sector/lGeometry.sectorsPerPage);

			pAddress->sector -= (carry * lGeometry.sectorsPerPage);
			pAddress->page += carry;
		}

		if (pAddress->page >= lGeometry.pagesPerBlock) {

			carry = (pAddress->page/lGeometry.pagesPerBlock);

			pAddress->page -= (carry * lGeometry.pagesPerBlock);
			pAddress->block += carry;
		}
    }

    return status;

} // Tc58Util_AddSectorsToRemapAddress


status_t Tc58Util_ConvertAddrSectorsToRemap(int32_t sector, Tc58RemapAddress_t *pA)
{
	status_t status;

	status = StatusOk;

	if (NULL == pA) {
		status = StatusNullParameter;
	} else if (!initialized) {
        status = StatusNotInitialized;
    }

    if (StatusOk == status) {

		// Even though the physical limits for block, page and page offset are smaller than 32 bits;
		// for calculation purposes, use 32 bit variables for block, page and page offset.
		uint32_t block32;
		uint32_t page32;
		uint32_t sector32;

		block32 = sector;
		block32 /= lGeometry.pagesPerBlock; // 64
		block32 /= lGeometry.sectorsPerPage; // 8 or 4
		sector -= (block32 * (lGeometry.pagesPerBlock * lGeometry.sectorsPerPage));

		page32 = sector / lGeometry.sectorsPerPage; // 64
		sector -= (page32 * lGeometry.sectorsPerPage);

		sector32 = sector;

		pA -> block = block32;
		pA -> page = page32;
		pA -> sector = sector32;
	}

	return status;

} // Tc58Util_ConvertAddrSectorsToRemap

status_t Tc58Util_ConvertAddrRemapToSectors(Tc58RemapAddress_t a, int32_t *pS)
{
	status_t status;

	status = StatusOk;

	if (NULL == pS) {
		status = StatusNullParameter;
	} if (!initialized) {
		status = StatusNotInitialized;
	}

	if (StatusOk == status) {
		(*pS) = ((int32_t) a.block) * ((int32_t) lGeometry.pagesPerBlock) * ((int32_t) lGeometry.sectorsPerPage);
		(*pS) += (int32_t) a.page * ((int32_t) lGeometry.sectorsPerPage);
		(*pS) += (int32_t) a.sector;
	}

	return status;

} // Tc58Util_ConvertAddrRemapToSectors


status_t Tc58Util_Init(void)
{
    status_t status;
    status = StatusOk;

    if (initialized) {
        status = StatusAlreadyInitialized;
    }

    if (StatusOk == status) {
        status = Tc58FlashPhysical_GetGeometry (&lGeometry);
    }

    if (StatusOk == status) {
    	initialized = true;
    }

    // We care about tracking this status, use macro to feed status to SW Unit control.
    return returnStatus(status, eSucInitStatus);

} // Tc58FlashPhysical_Init



/// SAEC Kinetic Vision, Inc  ----------- END OF FILE
