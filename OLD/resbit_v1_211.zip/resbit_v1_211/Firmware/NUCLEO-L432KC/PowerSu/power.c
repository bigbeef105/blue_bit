/**
  @file       Template.c

  @copyright  (C) 2019 Kinetic Vision, Cincinnati Ohio.
               This software is property of SAEC Kinetic Vision, Inc
               and is considered confidential.

  @brief      Template software unit "C" file.

  @author     Parker Kamer

  @ingroup    PowerSu

  Configuration History
  =====================

  Config Item    | Value
  -------------- | -----
  Config #       | NA
  Revision       | NA
  Revised, Date  | NA
  QA, Date       | NA
  Approved, Date | NA
  Released, Date | NA

  Significant Modification History (Most recent at top)
  =====================================================

  Date         | Initials | Details
  ------------ | -------- | -------
  05 Aug 2019  | PK       | Original

  Theory of Operation
  ===================
  TBD

*/

// Includes ------------------------------------------------------------------

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

#include "stm32l4xx_hal.h"

#include "../StatusSu/status.h"
#include "../ConsoleSu/console.h"
#include "../GpioSu/gpio.h"
#include "../SwUnitControlSu/SwUnitControl.h"
#include "../TimerSu/timer.h"
#include "../Middlewares/Third_Party/FatFs/src/ff.h"
#include "../UserInterfaceSu/UserInterface.h"
#include "../Tc58FlashUtilitiesSu/Tc58FlashUtilities.h"
#include "../Tc58FlashBufferSu/Tc58FlashBuffer.h"
#include "../Tc58FlashPhysicalSu/Tc58FlashPhysical.h"
#include "../SpiSu/spi.h"
#include "../UsartSu/usart.h"
#include "../I2cSu/i2c.h"
#include "../Bno055Su/bno055.h"
#include "../Lis2de12Su/lis2de12.h"
#include "../AdcSu/adc.h"
#include "../RtcSu/rtc.h"
#include "../ConfigSu/Config.h"
#include "../DataReceiverSu/DataReceiver.h"
#include "../DataAggregatorSu/DataAggregator.h"
#include "../SummaryDataSu/SummaryData.h"
#include "../BlueBitsSu/BlueBits.h"
#include "../ProtocolHalSu/ProtocolHal.h"
#include "usb_device.h"
#include "usbd_core.h"

#include "power.h"


// Private macros ------------------------------------------------------------
/// This macro feeds status information for tracking purposes to software unit control.
#define returnStatus(__status__,__source__) SwUnitControl_WriteStatus(eSucPowerSu,__source__,__status__,__LINE__);

// Private constants ---------------------------------------------------------
#define CLOCK_SWITCH_STOP2_DWELL_TIME		100 // ms
#define NORMAL_POWER_CLOCK_SPEED			clockSpeed80Mhz

// Private types -------------------------------------------------------------

// Private function prototypes -----------------------------------------------
static status_t clockConfigNormal(void);
static status_t clockConfigLowPower(void);

// Exported variables ---------------------------------------------------------

// Private variables ---------------------------------------------------------
static bool initialized = false;
static clockMode_t clockMode = clockModeNormal;
static clockSpeed_t lowPowerClockSpeed = NORMAL_POWER_CLOCK_SPEED; // default to normal
static configEnableState_t configUartDebug;


// Private function bodies ---------------------------------------------------
static status_t clockConfigNormal(void)
{
	status_t status = StatusOk;
	
	RCC_OscInitTypeDef RCC_OscInitStruct = { 0 };
	RCC_ClkInitTypeDef RCC_ClkInitStruct = { 0 };
	RCC_PeriphCLKInitTypeDef PeriphClkInit = { 0 };
	uint32_t flatency = FLASH_LATENCY_4;
	
	/** Configure the main internal regulator output voltage
	 * 
	 *  This must precede switching the clock to a higher speed
	 */
	if (HAL_PWREx_ControlVoltageScaling(PWR_REGULATOR_VOLTAGE_SCALE1) != HAL_OK)
	{
	  status = StatusHal;
	}
	/** Configure LSE Drive Capability 
	 */
	HAL_PWR_EnableBkUpAccess();
	__HAL_RCC_LSEDRIVE_CONFIG(RCC_LSEDRIVE_LOW);
	/** Initializes the CPU, AHB and APB busses clocks 
	 */
#ifndef LSI_BUILD
	RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_LSE
			| RCC_OSCILLATORTYPE_MSI;
	RCC_OscInitStruct.LSIState = RCC_LSI_OFF;
	RCC_OscInitStruct.LSEState = RCC_LSE_ON;
#else
	RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_LSI
			| RCC_OSCILLATORTYPE_MSI;
	RCC_OscInitStruct.LSIState = RCC_LSI_ON;
	RCC_OscInitStruct.LSEState = RCC_LSE_OFF;
#endif // LSI_BUILD
	RCC_OscInitStruct.MSIState = RCC_MSI_ON;
	RCC_OscInitStruct.HSIState = RCC_HSI_OFF;
	RCC_OscInitStruct.HSI48State = RCC_HSI48_OFF;
	RCC_OscInitStruct.MSICalibrationValue = 0;
	RCC_OscInitStruct.MSIClockRange = RCC_MSIRANGE_6;
	RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
	RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_MSI;
	RCC_OscInitStruct.PLL.PLLM = 1;
	RCC_OscInitStruct.PLL.PLLN = 40;
	RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV7;
	RCC_OscInitStruct.PLL.PLLQ = RCC_PLLQ_DIV2;
	RCC_OscInitStruct.PLL.PLLR = RCC_PLLR_DIV2;
	
	flatency = FLASH_LATENCY_4;

	if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK) {
		status = StatusHal;
	}

	/** Initializes the CPU, AHB and APB busses clocks 
	 */
	RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK | RCC_CLOCKTYPE_SYSCLK
			| RCC_CLOCKTYPE_PCLK1 | RCC_CLOCKTYPE_PCLK2;
	RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
	RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
	RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
	RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

	if (StatusOk == status) {
		if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, flatency) != HAL_OK) {
			status = StatusHal;
		}
	}

	PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_RTC
			| RCC_PERIPHCLK_USART1 | RCC_PERIPHCLK_I2C1 | RCC_PERIPHCLK_USB
			| RCC_PERIPHCLK_ADC | RCC_PERIPHCLK_LPTIM1;
	PeriphClkInit.Usart1ClockSelection = RCC_USART1CLKSOURCE_PCLK2;
	PeriphClkInit.I2c1ClockSelection = RCC_I2C1CLKSOURCE_PCLK1;
	PeriphClkInit.AdcClockSelection = RCC_ADCCLKSOURCE_PLLSAI1;
#ifndef LSI_BUILD
	PeriphClkInit.RTCClockSelection = RCC_RTCCLKSOURCE_LSE;
	PeriphClkInit.Lptim1ClockSelection = RCC_LPTIM1CLKSOURCE_LSE;
#else
	PeriphClkInit.RTCClockSelection = RCC_RTCCLKSOURCE_LSI;
	PeriphClkInit.Lptim1ClockSelection = RCC_LPTIM1CLKSOURCE_LSI;
#endif // LSI_BUILD
	PeriphClkInit.UsbClockSelection = RCC_USBCLKSOURCE_PLLSAI1;
	PeriphClkInit.PLLSAI1.PLLSAI1Source = RCC_PLLSOURCE_MSI;
	PeriphClkInit.PLLSAI1.PLLSAI1M = 1;
	PeriphClkInit.PLLSAI1.PLLSAI1N = 24;
	PeriphClkInit.PLLSAI1.PLLSAI1P = RCC_PLLP_DIV7;
	PeriphClkInit.PLLSAI1.PLLSAI1Q = RCC_PLLQ_DIV2;
	PeriphClkInit.PLLSAI1.PLLSAI1R = RCC_PLLR_DIV2;
	PeriphClkInit.PLLSAI1.PLLSAI1ClockOut = RCC_PLLSAI1_48M2CLK
			| RCC_PLLSAI1_ADC1CLK;
	
	if (StatusOk == status) {
		if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK) {
			status = StatusHal;
		}
	}
	
	/** Enable MSI Auto calibration
	 */
	HAL_RCCEx_EnableMSIPLLMode();

	HAL_RCCEx_WakeUpStopCLKConfig(RCC_STOP_WAKEUPCLOCK_MSI);
	
	return returnStatus(status, eSucIoctlStatus);
}

static status_t clockConfigLowPower(void)
{
	status_t status = StatusOk;
	
	RCC_OscInitTypeDef RCC_OscInitStruct = { 0 };
	RCC_ClkInitTypeDef RCC_ClkInitStruct = { 0 };
	RCC_PeriphCLKInitTypeDef PeriphClkInit = { 0 };
	
	// Get values based on configured LP clock speed -- default to 80 Mhz values
	uint32_t flatency = FLASH_LATENCY_4;
	uint32_t plln = 40;
	uint32_t pllr = RCC_PLLR_DIV2;
	uint32_t sysClockSource = RCC_SYSCLKSOURCE_PLLCLK;
	uint32_t voltageScale = PWR_REGULATOR_VOLTAGE_SCALE1;
	switch (lowPowerClockSpeed) {
		case clockSpeed80Mhz:
			flatency = FLASH_LATENCY_4;
			plln = 40;
			pllr = RCC_PLLR_DIV2;
			sysClockSource = RCC_SYSCLKSOURCE_PLLCLK;
			voltageScale = PWR_REGULATOR_VOLTAGE_SCALE1;
			break;
		case clockSpeed60Mhz:
			flatency = FLASH_LATENCY_3;
			plln = 30;
			pllr = RCC_PLLR_DIV2;
			sysClockSource = RCC_SYSCLKSOURCE_PLLCLK;
			voltageScale = PWR_REGULATOR_VOLTAGE_SCALE1;
			break;
		case clockSpeed40Mhz:
			flatency = FLASH_LATENCY_2;
			plln = 20;
			pllr = RCC_PLLR_DIV2;
			sysClockSource = RCC_SYSCLKSOURCE_PLLCLK;
			voltageScale = PWR_REGULATOR_VOLTAGE_SCALE1;
			break;
		case clockSpeed26Mhz:
			flatency = FLASH_LATENCY_2;
			plln = 26;
			pllr = RCC_PLLR_DIV4;
			sysClockSource = RCC_SYSCLKSOURCE_PLLCLK;
			voltageScale = PWR_REGULATOR_VOLTAGE_SCALE2;
			break;
		case clockSpeed16Mhz:
			flatency = FLASH_LATENCY_2;
			plln = 16;
			pllr = RCC_PLLR_DIV4;
			sysClockSource = RCC_SYSCLKSOURCE_PLLCLK;
			voltageScale = PWR_REGULATOR_VOLTAGE_SCALE2;
			break;
		case clockSpeed8Mhz:
			flatency = FLASH_LATENCY_1;
			plln = 16;
			pllr = RCC_PLLR_DIV8;
			sysClockSource = RCC_SYSCLKSOURCE_PLLCLK;
			voltageScale = PWR_REGULATOR_VOLTAGE_SCALE2;
			break;
		case clockSpeed4Mhz:
			flatency = FLASH_LATENCY_0;
			plln = 16;
			pllr = RCC_PLLR_DIV8;
			sysClockSource = RCC_SYSCLKSOURCE_MSI;
			voltageScale = PWR_REGULATOR_VOLTAGE_SCALE2;
			break;
		default:
			// keep defaults
			break;
	}

	/** Configure LSE Drive Capability 
	 */
	HAL_PWR_EnableBkUpAccess();
	__HAL_RCC_LSEDRIVE_CONFIG(RCC_LSEDRIVE_LOW);
	/** Initializes the CPU, AHB and APB busses clocks 
	 */
#ifndef LSI_BUILD
	RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_LSE
			| RCC_OSCILLATORTYPE_MSI;
	RCC_OscInitStruct.LSIState = RCC_LSI_OFF;
	RCC_OscInitStruct.LSEState = RCC_LSE_ON;
#else
	RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_LSI
			| RCC_OSCILLATORTYPE_MSI;
	RCC_OscInitStruct.LSIState = RCC_LSI_ON;
	RCC_OscInitStruct.LSEState = RCC_LSE_OFF;
#endif // LSI_BUILD
	RCC_OscInitStruct.MSIState = RCC_MSI_ON;
	RCC_OscInitStruct.HSIState = RCC_HSI_OFF;
	RCC_OscInitStruct.HSI48State = RCC_HSI48_OFF;
	
	RCC_OscInitStruct.MSICalibrationValue = 0;
	RCC_OscInitStruct.MSIClockRange = RCC_MSIRANGE_6;
	
	RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
	RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_MSI;
	RCC_OscInitStruct.PLL.PLLM = 1;
	RCC_OscInitStruct.PLL.PLLN = plln;
	RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV7;
	RCC_OscInitStruct.PLL.PLLQ = RCC_PLLQ_DIV2;
	RCC_OscInitStruct.PLL.PLLR = pllr;

	if (StatusOk == status) {
		if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK) {
			status = StatusHal;
		}
	}

	/** Initializes the CPU, AHB and APB busses clocks 
	 */
	RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK | RCC_CLOCKTYPE_SYSCLK
			| RCC_CLOCKTYPE_PCLK1 | RCC_CLOCKTYPE_PCLK2;
	RCC_ClkInitStruct.SYSCLKSource = sysClockSource;
	RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
	RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
	RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

	if (StatusOk == status) {
		if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, flatency) != HAL_OK) {
			status = StatusHal;
		}
	}

	PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_RTC
			| RCC_PERIPHCLK_USART1 | RCC_PERIPHCLK_I2C1
			| RCC_PERIPHCLK_ADC | RCC_PERIPHCLK_LPTIM1;
	PeriphClkInit.Usart1ClockSelection = RCC_USART1CLKSOURCE_PCLK2;
	PeriphClkInit.I2c1ClockSelection = RCC_I2C1CLKSOURCE_PCLK1;
	PeriphClkInit.AdcClockSelection = RCC_ADCCLKSOURCE_PLLSAI1;
#ifndef LSI_BUILD
	PeriphClkInit.RTCClockSelection = RCC_RTCCLKSOURCE_LSE;
	PeriphClkInit.Lptim1ClockSelection = RCC_LPTIM1CLKSOURCE_LSE;
#else
	PeriphClkInit.RTCClockSelection = RCC_RTCCLKSOURCE_LSI;
	PeriphClkInit.Lptim1ClockSelection = RCC_LPTIM1CLKSOURCE_LSI;
#endif // LSI_BUILD
	PeriphClkInit.PLLSAI1.PLLSAI1Source = RCC_PLLSOURCE_MSI;
	PeriphClkInit.PLLSAI1.PLLSAI1M = 1;
	PeriphClkInit.PLLSAI1.PLLSAI1N = 24;
	PeriphClkInit.PLLSAI1.PLLSAI1P = RCC_PLLP_DIV7;
	PeriphClkInit.PLLSAI1.PLLSAI1Q = RCC_PLLQ_DIV2;
	PeriphClkInit.PLLSAI1.PLLSAI1R = RCC_PLLR_DIV2;
	PeriphClkInit.PLLSAI1.PLLSAI1ClockOut = RCC_PLLSAI1_48M2CLK
			| RCC_PLLSAI1_ADC1CLK;
	
	if (StatusOk == status) {
		if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK) {
			status = StatusHal;
		}
	}
	/** Configure the main internal regulator output voltage
	 *  
	 *  In the case where we're switching to range 2, this must come after switching the clock
	 *  If this is set to range 1, it actually doesn't update (normal clock uses range 1 already)
	 */
	if (StatusOk == status) {
		if (HAL_PWREx_ControlVoltageScaling(voltageScale)
				!= HAL_OK) {
			status = StatusHal;
		}
	}
	/** Enable MSI Auto calibration
	 */
	HAL_RCCEx_EnableMSIPLLMode();

	HAL_RCCEx_WakeUpStopCLKConfig(RCC_STOP_WAKEUPCLOCK_MSI);
	
	return returnStatus(status, eSucIoctlStatus);
}


// Public functions bodies ---------------------------------------------------
status_t Power_Init(void)
{
	status_t status = StatusOk;

	if(initialized){
		status = StatusAlreadyInitialized;
	}
	else
	{
		status = clockConfigNormal();
		status = Status_Preserve(status, Config_Ioctl(configIoctlGetUart, &configUartDebug));
		// Initialize state regardless of return
		initialized = true;
		clockMode = clockModeNormal;
	}

	return returnStatus(status, eSucInitStatus);
} //Power_Init

status_t Power_EnterLowPower(void)
{
	status_t status = StatusOk;

#ifdef PROFILE_READS
	Timer_ProfileEnterSleep();
#endif
	// Turn off TC58
	HAL_GPIO_WritePin(TC58_SPI_CS_GPIO_Port, TC58_SPI_CS_Pin, GPIO_PIN_RESET);
	HAL_GPIO_WritePin(LOAD_SWITCH_Port, LOAD_SWITCH_Pin, GPIO_PIN_RESET);
	
	// Turn off peripherals
	status = Tc58FlashPhysical_DeInit();
	status = Status_Preserve(status, ProtocolHal_DeInit());
	status = Status_Preserve(status, I2C_DeInit());
	status = Status_Preserve(status, Spi_DeInit());
	if(settingEnable == configUartDebug){
		status = Status_Preserve(status, Usart_DeInit());
	}

	// Handle flash and ticks
	HAL_SuspendTick();
	FLASH->ACR |= FLASH_ACR_SLEEP_PD;
	// Sleep MCU
	HAL_PWREx_EnterSTOP2Mode(PWR_STOPENTRY_WFI);

	return returnStatus(status, eSucIoctlStatus);
}

status_t Power_ExitLowPower(clockMode_t exitClockMode)
{
	status_t status = StatusOk;
	
	// Handle flash, call clock config, restore systick
	FLASH->ACR &= ~FLASH_ACR_SLEEP_PD;
	HAL_ResumeTick();
	if (exitClockMode == clockModeNormal) {
		status = clockConfigNormal();
	} else {
		status = clockConfigLowPower();
	}
	
	// Turn on peripherals
	status = Status_Preserve(status, I2C_Init(false));
	status = Status_Preserve(status, ProtocolHal_Init(false)); // re-enables I2C pull-ups
	status = Status_Preserve(status, Spi_Init());
	
	HAL_GPIO_WritePin(LOAD_SWITCH_Port, LOAD_SWITCH_Pin, GPIO_PIN_SET);
	HAL_GPIO_WritePin(TC58_SPI_CS_GPIO_Port, TC58_SPI_CS_Pin, GPIO_PIN_SET);
	HAL_Delay(2);
	
	status = Status_Preserve(status, Tc58FlashPhysical_Init());
	if(settingEnable == configUartDebug){
		status = Status_Preserve(status, Usart_Init());
	}
	// TODO: Restore this, but in sys state module
	//status = RTC_ReadUnixTime(&wakeTime);

	return returnStatus(status, eSucReadStatus);
}

void _Power_NormalClockResume(void)
{
	clockMode = clockModeNormal;
	clockConfigNormal();
}

status_t Power_SwitchClockMode(clockMode_t newClockMode)
{
	status_t status = StatusOk;
	if (newClockMode != clockMode) {
		status = Timer_LowPowerInterrupt(CLOCK_SWITCH_STOP2_DWELL_TIME);
		if (StatusOk == status) {
			// Enter stop 2 mode to stop pll so we can reconfigure
			// this is a hacky way of doing this, but it works..
			HAL_SuspendTick();
			FLASH->ACR |= FLASH_ACR_SLEEP_PD;
			HAL_PWREx_EnterSTOP2Mode(PWR_STOPENTRY_WFI);
			
			
			// Once we wake up from lptim..
			FLASH->ACR &= ~FLASH_ACR_SLEEP_PD;
			HAL_ResumeTick();
			if (newClockMode == clockModeNormal) {
				status = clockConfigNormal();
			} else {
				status = clockConfigLowPower();
			}
			clockMode = newClockMode;
			
			// Need to reinitialize I2C so that it updates clock speed
			status = Status_Preserve(status, I2C_DeInit());
			status = Status_Preserve(status, I2C_Init(false));
		}
	}
	
	return returnStatus(status, eSucIoctlStatus);
}

clockSpeed_t Power_GetClockSpeed(void)
{
	if (clockModeNormal == clockMode) {
		return NORMAL_POWER_CLOCK_SPEED;
	} else {
		return lowPowerClockSpeed;
	}
}

status_t Power_SetLowPowerClockSpeed(clockSpeed_t clockSpeed)
{
	lowPowerClockSpeed = clockSpeed;
	return StatusOk;
}

status_t Power_Sleep(uint32_t durationMs, clockMode_t exitClockMode)
{
	status_t status = Timer_LowPowerInterrupt(durationMs);
	if (StatusOk == status) {
		HAL_SuspendTick();
		HAL_PWREx_EnterSTOP2Mode(PWR_STOPENTRY_WFI);
		
		// Once we wake up from lptim..
		if (exitClockMode == clockModeNormal) {
			status = clockConfigNormal();
		} else {
			status = clockConfigLowPower();
		}
		HAL_ResumeTick();
	}
	
	return returnStatus(status, eSucIoctlStatus);
}


/// SAEC Kinetic Vision, Inc. ----------- END OF FILE
