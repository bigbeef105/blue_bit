/**
  @file       power.h

  @copyright  (C) 2019 Kinetic Vision, Cincinnati Ohio.
               This software is property of SAEC Kinetic Vision, Inc
               and is considered confidential.

  @brief      Power software unit "H" file.

  @author     Parker Kamer

  @defgroup   PowerSu Handles entering low power mode.

  Configuration History
  =====================

  Config Item    | Value
  -------------- | -----
  Config #       | NA
  Revision       | NA
  Revised, Date  | NA
  QA, Date       | NA
  Approved, Date | NA
  Released, Date | NA

  Significant Modification History (Most recent at top)
  =====================================================

  Date         | Initials | Details
  ------------ | -------- | -------
  05 Aug 2019  | PK       | Original

  Theory of Operation
  ===================
  This software unit will handle the power states of the device. This includes entering
  and exiting sleep and protect modes. Thi SU will also handle the usb power state.

  */

// Define to prevent recursive inclusion -------------------------------------
#ifndef __POWER_SU_H
#define __POWER_SU_H

#include "../StatusSu/Status.h"
#include "../ConfigSu/Config.h"

// Exported macro ------------------------------------------------------------

// Exported types ------------------------------------------------------------
typedef enum {
	clockModeNormal = 0,
	clockModeLowPower,
} clockMode_t;

// Exported constants --------------------------------------------------------

// Exported objects ----------------------------------------------------------

// Exported functions --------------------------------------------------------
///  @brief Initialize the Power software unit, sets system clock to normal mode
///  @return StatusOk, StatusAlreadyInitialized
status_t Power_Init(void);

///  @brief Disables hardware and enters stop 2 mode
status_t Power_EnterLowPower(void);

///  @brief Enables hardware and reconfigures clock in the supplied mode
status_t Power_ExitLowPower(clockMode_t exitClockMode);

///  @brief Switches clock mode to the desired setting (or nothing if already in that mode)
status_t Power_SwitchClockMode(clockMode_t newClockMode);

///  @brief Returns the current clock speed
clockSpeed_t Power_GetClockSpeed(void);

///  @brief Sets the low power clock speed
status_t Power_SetLowPowerClockSpeed(clockSpeed_t clockSpeed);

///  @brief Enters low power for a specified amount of time
status_t Power_Sleep(uint32_t durationMs, clockMode_t exitClockMode);

///  @brief XXNOTOUCHXX this is used by the USB PCD HAL
void _Power_NormalClockResume(void);


#endif // __POWER_SU_H

/// SAEC Kinetic Vision, Inc. ----------- END OF FILE


