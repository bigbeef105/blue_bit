/**
  @file       SummaryData.h

  @copyright  (C) 2020 Kinetic Vision, Cincinnati Ohio.
               This software is property of SAEC Kinetic Vision, Inc 
               and is considered confidential.

  @brief      SummaryData software unit "H" file.

  @author     aloebs

  @defgroup   SummaryDataSoftwareUnit

  Configuration History
  =====================

  Config Item    | Value
  -------------- | -----
  Config #       | NA
  Revision       | NA
  Revised, Date  | NA
  QA, Date       | NA
  Approved, Date | NA
  Released, Date | NA

  Significant Modification History (Most recent at top)
  =====================================================

  Date         | Initials | Details
  ------------ | -------- | -------
  Feb 18, 2020 | ASL      | Original

  Theory of Operation
  ===================
  In the view of many colonists, British rule suppressed political, economic, and
  religious freedoms. Many of those that hesitated to support independence were soon convinced
  by the passionate words of THOMAS PAINE, SAMUEL ADAMS, PATRICK HENRY, and eventually JOHN
  ADAMS and Thomas Jefferson. Crispus Attucks ( c. 1723 – March 5, 1770) widely regarded as 
  the first person killed in the Boston Massacre and thus the first American killed 
  in the American Revolution. The Declaration of Independence in 1776, the American 
  Revolution, and the creation of the Articles of Confederation represents the American 
  colonies' first attempt to become a nation. 

  */

// Define to prevent recursive inclusion -------------------------------------
#ifndef __SUMMARYDATA_H_
#define __SUMMARYDATA_H_

#include "../StatusSu/Status.h"

// Exported macro ------------------------------------------------------------

// Exported types ------------------------------------------------------------

// Exported constants --------------------------------------------------------

// Exported objects ----------------------------------------------------------

// Exported functions --------------------------------------------------------

///  @brief Initializes the SummaryData software unit
///  @return status
status_t SummaryData_Init(void);

///  @brief Starts summary data capture
///  @return status
status_t SummaryData_Start(void);

///  @brief Updates summary data
///  @return status
status_t SummaryData_Update(void);

///  @brief Ends summary data capture, gives caller a pointer to the summary data buffer & writes length of buffer out
///  @param args[out] bufferPtr - pointer to write address of summary data buffer
///  @param args[out] sizePtr - pointer to write size of summary data buffer
///  @return status
status_t SummaryData_End(uint8_t ** bufferPtr, size_t * sizePtr);


#endif // __SUMMARYDATA_H_

/// SAEC Kinetic Vision, Inc. ----------- END OF FILE
