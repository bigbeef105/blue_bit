/**
  @file       SummaryData.c

  @copyright  (C) 2020 Kinetic Vision, Cincinnati Ohio.
               This software is property of SAEC Kinetic Vision, Inc 
               and is considered confidential.

  @brief      SummaryData software unit "C" file.

  @author     aloebs

  @ingroup    SummaryDataSoftwareUnit 

  Configuration History
  =====================

  Config Item    | Value
  -------------- | -----
  Config #       | NA
  Revision       | NA
  Revised, Date  | NA
  QA, Date       | NA
  Approved, Date | NA
  Released, Date | NA

  Significant Modification History (Most recent at top)
  =====================================================

  Date         | Initials | Details
  ------------ | -------- | -------
  Feb 18, 2020 | ASL      | Original

  Theory of Operation
  ===================
  In the view of many colonists, British rule suppressed political, economic, and
  religious freedoms. Many of those that hesitated to support independence were soon convinced
  by the passionate words of THOMAS PAINE, SAMUEL ADAMS, PATRICK HENRY, and eventually JOHN
  ADAMS and Thomas Jefferson. Crispus Attucks ( c. 1723 – March 5, 1770) widely regarded as the
  first person killed in the Boston Massacre and thus the first American killed in the 
  American Revolution. The Declaration of Independence in 1776, the American Revolution,
  and the creation of the Articles of Confederation represent the American colonies' first
  attempt to become a nation. 

*/

// Includes ------------------------------------------------------------------

#include "SummaryData.h"

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

#include "../SwUnitControlSu/SwUnitControl.h"
#include "../ConfigSu/Config.h"
#include "../TriggerCountSummarySu/TriggerCountSummary.h"
#include "../WakeSummarySu/WakeSummary.h"

// Private macros ------------------------------------------------------------
#define returnStatus(__status__,__source__) SwUnitControl_WriteStatus(eSucSummaryDataSu,__source__,__status__,__LINE__)
#define ARR_LEN(_array_) (sizeof(_array_)/sizeof(*_array_))

// Private constants ---------------------------------------------------------
#define SUMMARY_BUFFER_LEN				80
#define SUMMARY_COUNT_LEN				2
#define SUMMARY_DATA_LEN				SUMMARY_BUFFER_LEN - SUMMARY_COUNT_LEN

#define SUMMARY_DATA_HEADER_LEN			7

// Private types -------------------------------------------------------------
typedef struct {
	const configSettings_t configSetting;
	bool enabled;
	const uint16_t eventId;
	const uint8_t dataLen;
	status_t (*init)(void);
	status_t (*start)(uint32_t * timeStampField, uint8_t * dataField, size_t dataLen);
	status_t (*update)(void);
	status_t (*end)(void);
} summaryEventData_t;

typedef struct {
	union {
		uint8_t bytes[SUMMARY_BUFFER_LEN];
		struct {
			uint16_t count;
			uint8_t data[SUMMARY_DATA_LEN];
		};
	};
	size_t index;
} summaryDataBuffer_t;

// Private constants ---------------------------------------------------------

// Private variables ---------------------------------------------------------
static bool initialized = false;
static bool inProgress = false;
static summaryEventData_t summaryEvents[] = {
	{
		configIoctlGetWakeSummaryEnabled,
		false,
		0x00,
		4,
		WakeSummary_Init,
		WakeSummary_Start,
		WakeSummary_Update,
		WakeSummary_End
	},
	{
		configIoctlGetTrigCountEnabled,
		false,
		0x01,
		4,
		TriggerCountSummary_Init,
		TriggerCountSummary_Start,
		TriggerCountSummary_Update,
		TriggerCountSummary_End
	},
};
static summaryDataBuffer_t summaryBuffer;

// Private function prototypes -----------------------------------------------
static bool checkEnabled(configIoctl_t ioctlCommand);
static void summaryBufferReset(void);
static status_t summaryBufferAdd(summaryEventData_t * event,
		uint32_t ** timeStampPtrOut, uint8_t ** dataPtrOut);

// Private function bodies ---------------------------------------------------
static bool checkEnabled(configIoctl_t ioctlCommand)
{
	configEnableState_t enabled;
	status_t status = Config_Ioctl(ioctlCommand, &enabled);
	if (Status_IsOk(status)) {
		return (settingEnable == enabled);
	} else {
		return false;
	}
}

static void summaryBufferReset(void)
{
	summaryBuffer.count = 0;
	summaryBuffer.index = 0;
}

static status_t summaryBufferAdd(summaryEventData_t * event,
		uint32_t ** timeStampPtrOut, uint8_t ** dataPtrOut)
{
	status_t status = StatusOk;

	// Make sure theres room..
	if ((event->dataLen + SUMMARY_DATA_HEADER_LEN) >
			(SUMMARY_DATA_LEN - summaryBuffer.index)) {
		status = StatusBufferFull;
	}

	if (Status_IsOk(status)) {
		// Event ID
		memcpy(&summaryBuffer.data[summaryBuffer.index],
				&event->eventId, sizeof(event->eventId));
		summaryBuffer.index += sizeof(event->eventId);
		// Timestamp
		*timeStampPtrOut = (uint32_t *)&summaryBuffer.data[summaryBuffer.index];
		summaryBuffer.index += sizeof(**timeStampPtrOut);
		// Size
		memcpy(&summaryBuffer.data[summaryBuffer.index],
				&event->dataLen, sizeof(event->dataLen));
		summaryBuffer.index += sizeof(event->dataLen);
		// Data
		*dataPtrOut = (uint8_t *)&summaryBuffer.data[summaryBuffer.index];
		summaryBuffer.index += event->dataLen;

		summaryBuffer.count++;
	}

	return status;
}

// Public functions bodies ---------------------------------------------------

status_t SummaryData_Init(void)
{
	status_t status = StatusOk;

	if (initialized) {
		status = StatusAlreadyInitialized;
	}

	if (Status_IsOk(status)) {
		// Find enabled summary events
		for (int i = 0; i < ARR_LEN(summaryEvents); i++) {
			if (checkEnabled(summaryEvents[i].configSetting)) {
				summaryEvents[i].enabled = true;
				status = summaryEvents[i].init(); // call event's init
			}
		}
	}

	if (Status_IsOk(status)) {
		initialized = true;
		inProgress = false;
	}

	return returnStatus(status, eSucInitStatus);
}

status_t SummaryData_Start(void)
{
	status_t status = StatusOk;

	// Build buffer & call event start() functions
	summaryBufferReset();
	for (int i = 0; i < ARR_LEN(summaryEvents); i++) {
		if (summaryEvents[i].enabled) {
			uint32_t * timeStampPtr;
			uint8_t * dataPtr;
			status = summaryBufferAdd(&summaryEvents[i], &timeStampPtr, &dataPtr);
			if (Status_IsOk(status)) {
				status = summaryEvents[i].start(timeStampPtr, dataPtr,
						summaryEvents[i].dataLen);
			}
		}
	}

	if (Status_IsOk(status)) {
		inProgress = true;
	}

	return returnStatus(status, eSucIoctlStatus);
}

status_t SummaryData_Update(void)
{
	status_t status = StatusOk;

	if (!inProgress) {
		status = StatusCodePath; // this should be unreachable
	}

	if (Status_IsOk(status)) {
		for (int i = 0; i < ARR_LEN(summaryEvents); i++) {
			if (summaryEvents[i].enabled) {
				status = summaryEvents[i].update();
			}
		}
	}

	return returnStatus(status, eSucIoctlStatus);
}

status_t SummaryData_End(uint8_t ** bufferPtr, size_t * sizePtr)
{
	status_t status = StatusOk;

	for (int i = 0; i < ARR_LEN(summaryEvents); i++) {
		if (summaryEvents[i].enabled) {
			status = summaryEvents[i].end();
		}
	}

	inProgress = false;
	*bufferPtr = summaryBuffer.bytes;
	*sizePtr = summaryBuffer.index + SUMMARY_COUNT_LEN;

	return returnStatus(status, eSucIoctlStatus);
}

/// SAEC Kinetic Vision, Inc. ----------- END OF FILE
