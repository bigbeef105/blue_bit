/**
  @file       Ms5837.c

  @copyright  (C) 2019 Kinetic Vision, Cincinnati Ohio.
               This software is property of SAEC Kinetic Vision, Inc
               and is considered confidential.

  @brief      Pressure sensor software unit "C" file.

  @author     Parker Kamer

  @ingroup    Ms5837Su

  Configuration History
  =====================

  Config Item    | Value
  -------------- | -----
  Config #       | NA
  Revision       | NA
  Revised, Date  | NA
  QA, Date       | NA
  Approved, Date | NA
  Released, Date | NA

  Significant Modification History (Most recent at top)
  =====================================================

  Date         | Initials | Details
  ------------ | -------- | -------
  03 Oct 2019  | PK       | Original

  Theory of Operation
  ===================
  TBD

*/

// Includes ------------------------------------------------------------------

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <math.h>

#include "stm32l4xx_hal.h"
#include "../StatusSu/Status.h"
#include "../SwUnitControlSu/SwUnitControl.h"
#include "../I2cSu/i2c.h"
#include "../TimerSu/timer.h"
#include "../DataAggregatorSu/DataAggregator.h"
#include "Ms5837.h"


// Private macros ------------------------------------------------------------
/// This macro feeds status information for tracking purposes to software unit control.
#define returnStatus(__status__,__source__) SwUnitControl_WriteStatus(eSucMs5837,__source__,__status__,__LINE__);

// Private constants ---------------------------------------------------------
#define MS5837_I2C_ADDRESS 											0xEC
#define MS5837_I2C_TIMEOUT_VAL										20 // ms
#define MS5837_COEFFICIENT_NUMBERS									7

#define MS5837_CONVERSION_OSR_MASK									0x0F

#define MS5837_CONVERSION_TIME_OSR_256								1000
#define MS5837_CONVERSION_TIME_OSR_512								2000
#define MS5837_CONVERSION_TIME_OSR_1024								3000
#define MS5837_CONVERSION_TIME_OSR_2048								5000
#define MS5837_CONVERSION_TIME_OSR_4096								9000
#define MS5837_CONVERSION_TIME_OSR_8192								17000

#define MS5837_RESET_COMMAND                                        0x1E
#define MS5837_PRESSURE_CONVERSION_OSR_256                          0x40
#define MS5837_PRESSURE_CONVERSION_OSR_1024                         0x42
#define MS5837_PRESSURE_CONVERSION_OSR_2048                         0x46
#define MS5837_PRESSURE_CONVERSION_OSR_4096                         0x47
#define MS5837_PRESSURE_CONVERSION_OSR_8192                         0x4A
#define MS5837_TEMPERATURE_CONVERSION_OSR_256                       0x50
#define MS5837_TEMPERATURE_CONVERSION_OSR_512                       0x52
#define MS5837_TEMPERATURE_CONVERSION_OSR_1024                      0x54
#define MS5837_TEMPERATURE_CONVERSION_OSR_2048                      0x56
#define MS5837_TEMPERATURE_CONVERSION_OSR_4096                      0x58
#define MS5837_TEMPERATURE_CONVERSION_OSR_8192                      0x5A
#define MS5837_READ_ADC                                             0x00

#define MS5837_CONVERSION_TIMEOUT                                   560 // us

// Private types -------------------------------------------------------------
typedef enum{
	crcIndex,
	pressureSensIndex,
	pressureOffsetIndex,
	coeffofPressureSensIndex,
	coeffofPressureOffsetIndex,
	referenceTemperatrueIndex,
	coeffofTemperatureIndex

}calibIndex_t;

typedef enum{
	cmdReset = 0x1E,
	cmdConvertD1 = 0x40,
	cmdConvertD2 = 0x50,
	cmdAdc = 0x00,
	cmdProm = 0xA0
}ms5837Cmd_t;

typedef enum {
    pressureMSB = 0,
    pressureB1,
    pressureB2,
    
    tempMSB,
    tempB1,
    tempB2,
    
    RAW_DATA_BUFFER_LEN,
} rawDataIndex_t;

typedef enum {
    readDataStateStart = 0,
    readDataStatePressRequest,
    readDataStatePressTimeout,
    readDataStatePressRead,
    readDataStateTempRequest,
    readDataStateTempTimeout,
    readDataStateTempRead,
} readDataState_t;

// Private constants ---------------------------------------------------------

// Private variables ---------------------------------------------------------
static uint16_t calibrationArray[NUM_MS5837IDS][MS5837_COEFFICIENT_NUMBERS];
static uint8_t i2cWriteBuffer;
static uint8_t rawDataBuffer[RAW_DATA_BUFFER_LEN];
static uint8_t rawDataIndex = 0;

static i2cHandle_t i2cHandle;
static volatile overlapped_t i2cOverlapped;

static connectorDataHandler_t * dataHandlerOut = NULL;
static void (*readCallback)(void) = NULL;

static bool initialized = false;

static ms5837Ids_t currentReadId;
static readDataState_t readDataState;
static bool storePressure = false;
static bool storeTemp = false;

// Private function prototypes -----------------------------------------------
static void i2cCallback(status_t status);
static void timerCallback(void);

static status_t processReadDataState(bool start);

static status_t startDataConversion(uint8_t cmd);
static status_t requestData(void);
static void processData(float * pressureOut, float * tempOut);

// Private function bodies ---------------------------------------------------
static void i2cCallback(status_t status)
{
	processReadDataState(false);
}

static void timerCallback(void)
{
    processReadDataState(false);
}

static status_t processReadDataState(bool start)
{
    status_t status = StatusOk;
    
    if (start) readDataState = readDataStateStart;
    
    switch (readDataState) {
        case readDataStateStart:
            readDataState = readDataStatePressRequest;            
            status = startDataConversion(MS5837_PRESSURE_CONVERSION_OSR_256);
            break;
        case readDataStatePressRequest:
            readDataState = readDataStatePressTimeout;
            status = Timer_Ms5837AsyncDelay(MS5837_CONVERSION_TIMEOUT, timerCallback);
            break;
        case readDataStatePressTimeout:
            readDataState = readDataStatePressRead;
            rawDataIndex = pressureMSB;
            status = requestData();
            break;
            
            
        case readDataStatePressRead:
            readDataState = readDataStateTempRequest;
            status = startDataConversion(MS5837_TEMPERATURE_CONVERSION_OSR_256);
            break;
        case readDataStateTempRequest:
            readDataState = readDataStateTempTimeout;
            status = Timer_Ms5837AsyncDelay(MS5837_CONVERSION_TIMEOUT, timerCallback);
            break;
        case readDataStateTempTimeout:
            readDataState = readDataStateTempRead;
            rawDataIndex = tempMSB;
            status = requestData();
            break;
            
            
        case readDataStateTempRead:
            ;float press, temp;
            processData(&press, &temp);
            if (dataHandlerOut && readCallback) {
                if (storePressure) {
                    if (storeTemp) {
                        // Pressure and temp
                        dataHandlerOut->data[0].float32 = press;
                        dataHandlerOut->data[1].float32 = temp;
                    } else {
                        // Pressure
                        dataHandlerOut->data[0].float32 = press;
                    }
                } else if (storeTemp) {
                    // Temp
                    dataHandlerOut->data[0].float32 = temp;
                }
                readCallback();
            } else {
                status = StatusCodePath; // these pointers shouldn't be null
            }
            break;
            
            
        default:
            status = StatusCodePath;
            break;
    }
    
    return status;
}

static status_t startDataConversion(uint8_t cmd)
{
    i2cWriteBuffer = cmd;

    i2cOverlapped.callback = i2cCallback;
    i2cOverlapped.timeout = MS5837_I2C_TIMEOUT_VAL;
    i2cOverlapped.outBuffer = &i2cWriteBuffer;
    i2cOverlapped.outBufferSize = 1;
    
    return I2C_WriteAsync(i2cHandle, &i2cOverlapped);
}

static status_t requestData(void)
{
    i2cWriteBuffer = cmdAdc;

    i2cOverlapped.callback = i2cCallback;
    i2cOverlapped.timeout = MS5837_I2C_TIMEOUT_VAL;
    i2cOverlapped.outBuffer = &i2cWriteBuffer;
    i2cOverlapped.outBufferSize = 1;
    i2cOverlapped.inBuffer = &rawDataBuffer[rawDataIndex];
    i2cOverlapped.inBufferSize = RAW_DATA_BUFFER_LEN / 2;
    
    return I2C_MemReadAsync(i2cHandle, &i2cOverlapped);
}

static void processData(float * pressureOut, float * tempOut)
{
    uint32_t pressure, temp;
    int32_t dT, TEMP;
    int64_t OFF, SENS, P, T2, OFF2, SENS2;
    
    pressure = ((uint32_t)rawDataBuffer[pressureMSB] << 16) |
            ((uint32_t)rawDataBuffer[pressureB1] << 8) | rawDataBuffer[pressureB2];
    temp = ((uint32_t)rawDataBuffer[tempMSB] << 16) |
            ((uint32_t)rawDataBuffer[tempB1] << 8) | rawDataBuffer[tempB2];
    
    

    //Calculate Temperature and Pressure ==========================
    // Difference between actual and reference temperature = D2 - Tref
    dT = temp - ((int32_t)calibrationArray[currentReadId][referenceTemperatrueIndex] << 8);

    // Actual temperature = 2000 + dT * TEMPSENS
    TEMP = 2000 + ((int64_t)dT * (int64_t)calibrationArray[currentReadId][coeffofTemperatureIndex] >> 23) ;

    // Second order temperature compensation
    if( TEMP < 2000 )
    {
        T2 = ( 11 * ( (int64_t)dT  * (int64_t)dT  ) ) >> 35;
        OFF2 = 31 * ((int64_t)TEMP - 2000) * ((int64_t)TEMP - 2000) / 8 ;
        SENS2 = 63 * ((int64_t)TEMP - 2000) * ((int64_t)TEMP - 2000) / 32 ;
    }
    else
    {
        T2 = 0;
        OFF2 = 0;
        SENS2 = 0;
    }

    // OFF = OFF_T1 + TCO * dT
    OFF = ( (int64_t)(calibrationArray[currentReadId][pressureOffsetIndex]) << 17 ) + 
            ( ( (int64_t)(calibrationArray[currentReadId][coeffofPressureOffsetIndex]) * dT ) >> 6 ) ;
    OFF -= OFF2 ;

    // Sensitivity at actual temperature = SENS_T1 + TCS * dT
    SENS = ( (int64_t)calibrationArray[currentReadId][pressureSensIndex] << 16 ) + 
            ( ((int64_t)calibrationArray[currentReadId][coeffofPressureSensIndex] * dT) >> 7 ) ;
    SENS -= SENS2 ;

    // Temperature compensated pressure = D1 * SENS - OFF
    P = ( ( (pressure * SENS) >> 21 ) - OFF ) >> 15 ;

    *pressureOut = (float)P / 100;
    *tempOut = ( (float)TEMP - T2 ) / 100;
}

// Public functions bodies ---------------------------------------------------
status_t Ms5837_Init(void)
{
	status_t status = StatusOk;

	// Create i2c instance on first initialization
	if (!initialized) {
	    status = I2C_CreateHandle(&i2cHandle, MS5837_I2C_ADDRESS);
	    if (StatusOk == status) {
	        initialized = true;
	    }
	} else {
	    status = StatusAlreadyInitialized;
	}

	

    return returnStatus(status, eSucInitStatus);
}

status_t Ms5837_SetupSensor(ms5837Ids_t sensorId)
{
    status_t status = StatusOk;
    
    uint8_t promData[2];
    for(int i = 0; i < MS5837_COEFFICIENT_NUMBERS; i++)
    {
        status = I2C_MemRead(i2cHandle, cmdProm + i*2, 1, promData,
                2, MS5837_I2C_TIMEOUT_VAL);

        if(StatusOk == status) {
            calibrationArray[sensorId][i] = (promData[0] << 8) | promData[1];
        } else {
            break;
        }
    }
    
    return returnStatus(status, eSucIoctlStatus);
}

status_t Ms5837_ReadPressure(ms5837Ids_t sensorId, connectorDataHandler_t * dataOut, void (*callback)(void))
{
    status_t status = StatusOk;
    
    if (!dataOut || !callback) {
        status = StatusNullParameter;
    } else {
        dataHandlerOut = dataOut;
        readCallback = callback;
    }
    
    if (StatusOk == status) {
        // Update state information
        currentReadId = sensorId;
        storePressure = true;
        storeTemp = false;
        
        status = processReadDataState(true);
    }
    
    return returnStatus(status, eSucReadStatus);
}

status_t Ms5837_ReadTemp(ms5837Ids_t sensorId, connectorDataHandler_t * dataOut, void (*callback)(void))
{
    status_t status = StatusOk;
    
    if (!dataOut || !callback) {
        status = StatusNullParameter;
    } else {
        dataHandlerOut = dataOut;
        readCallback = callback;
    }
    
    if (StatusOk == status) {
        // Update state information
        currentReadId = sensorId;
        storePressure = false;
        storeTemp = true;
        
        status = processReadDataState(true);
    }
    
    return returnStatus(status, eSucReadStatus);
}

status_t Ms5837_ReadPressureTemp(ms5837Ids_t sensorId, connectorDataHandler_t * dataOut, void (*callback)(void))
{
    status_t status = StatusOk;
    
    if (!dataOut || !callback) {
        status = StatusNullParameter;
    } else {
        dataHandlerOut = dataOut;
        readCallback = callback;
    }
    
    if (StatusOk == status) {
        // Update state information
        currentReadId = sensorId;
        storePressure = true;
        storeTemp = true;
        
        status = processReadDataState(true);
    }
    
    return returnStatus(status, eSucReadStatus);
}


/// SAEC Kinetic Vision, Inc. ----------- END OF FILE
