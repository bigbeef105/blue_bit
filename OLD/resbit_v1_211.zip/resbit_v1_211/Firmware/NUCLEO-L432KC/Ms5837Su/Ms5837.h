/**
  @file       Ms5837.h

  @copyright  (C) 2019 Kinetic Vision, Cincinnati Ohio.
               This software is property of SAEC Kinetic Vision, Inc
               and is considered confidential.

  @brief      Pressure sensor software unit "H" file.

  @author     Parker Kamer

  @defgroup   Ms5837Su Pressure and Temperature Reading

  Configuration History
  =====================

  Config Item    | Value
  -------------- | -----
  Config #       | NA
  Revision       | NA
  Revised, Date  | NA
  QA, Date       | NA
  Approved, Date | NA
  Released, Date | NA

  Significant Modification History (Most recent at top)
  =====================================================

  Date         | Initials | Details
  ------------ | -------- | -------
  03 Oct 2019  | PK       | Original

  Theory of Operation
  ===================
  The device will be used to read pressure and temperature data.
  This software unit will handle 2 (subject to change) devices.

  */

// Define to prevent recursive inclusion -------------------------------------
#ifndef __MS5837_H
#define __MS5837_H

#include "../DataAggregatorSu/DataAggregator.h"

// Exported macro ------------------------------------------------------------

// Exported types ------------------------------------------------------------
typedef enum {
    ms5837Id_0 = 0,
    ms5837Id_1,
    
    NUM_MS5837IDS
} ms5837Ids_t;
// Exported constants --------------------------------------------------------

// Exported objects ----------------------------------------------------------

// Exported functions --------------------------------------------------------

///  @brief Initializes the MS5837 software unit
///  @return StatusOk, StatusHal
status_t Ms5837_Init(void);

///  @brief Reads calibration parameters for the desired sensor
///  @param args[in] sensorId - sensor logic Id
///  @return StatusOk, StatusHal
status_t Ms5837_SetupSensor(ms5837Ids_t sensorId);

// ** ---------------------------------------------------------------------------
// ** NOTE ** Only supports asynchronous reads of one pressure sensor at a time
// ** ---------------------------------------------------------------------------
///  @brief Reads pressure data into dataOut, calls callback when complete
status_t Ms5837_ReadPressure(ms5837Ids_t sensorId, connectorDataHandler_t * dataOut, void (*callback)(void));

///  @brief Reads temperature data into dataOut, calls callback when complete
status_t Ms5837_ReadTemp(ms5837Ids_t sensorId, connectorDataHandler_t * dataOut, void (*callback)(void));

///  @brief Reads pressure and temperature data into dataOut, calls callback when complete
status_t Ms5837_ReadPressureTemp(ms5837Ids_t sensorId, connectorDataHandler_t * dataOut, void (*callback)(void));


#endif // __MS5837_H

/// SAEC Kinetic Vision, Inc. ----------- END OF FILE


