/**
  @file       DataAggregator.c

  @copyright  (C) 2019 Kinetic Vision, Cincinnati Ohio.
               This software is property of SAEC Kinetic Vision, Inc
               and is considered confidential.

  @brief      DataAggregator software unit "C" file.

  @author     Parker Kamer

  @ingroup    DataAggregatorSu

  Configuration History
  =====================

  Config Item    | Value
  -------------- | -----
  Config #       | NA
  Revision       | NA
  Revised, Date  | NA
  QA, Date       | NA
  Approved, Date | NA
  Released, Date | NA

  Significant Modification History (Most recent at top)
  =====================================================

  Date         | Initials | Details
  ------------ | -------- | -------
  23 Jul 2019  | PK       | Original

  Theory of Operation
  ===================
  The Data Aggregator will pull data from all configured peripherals periodically
  and place the gathered data into the fifo software unit.

*/

// Includes ------------------------------------------------------------------

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <math.h>

#include "stm32l4xx_hal.h"
#include "../StatusSu/Status.h"
#include "../ConsoleSu/Console.h"
#include "../RtcSu/rtc.h"
#include "../AdcSu/adc.h"
#include "../Ms5837Su/Ms5837.h"
#include "../FDC2214Su/FDC2214.h"
#include "../HX711Su/HX711.h"
#include "../HallSu/Hall.h"
#include "../GpioSu/gpio.h"
#include "../SwUnitControlSu/SwUnitControl.h"
#include "../ConfigSu/Config.h"
#include "../Bno055Su/bno055.h"
#include "../MultiplexerSu/Multiplexer.h"
#include "../TimerSu/timer.h"
#include "../DataReceiverSu/DataReceiver.h"
#include "../SummaryDataSu/SummaryData.h"
#include "../DualPressTempSu/DualPressTemp.h"
#include "../BlueBitsSu/BlueBits.h"
#include "../FifoSu/Fifo.h"
#include "../UsbSerialSu/UsbSerial.h"
#include "../Lis2de12Su/lis2de12.h"
#include "../Base64Su/Base64.h"

#include "DataAggregator.h"
#include "../UtilitySu/Utility.h"

// Private macros ------------------------------------------------------------
/// This macro feeds status information for tracking purposes to software unit control.
#define returnStatus(__status__,__source__) SwUnitControl_WriteStatus(eSucDataAggregSu,__source__,__status__,__LINE__);
#define READLOCK()								\
		do {									\
			if (readLock) {						\
				return StatusOk;				\
			} else {							\
				readLock = true;				\
			}									\
		} while (0)

#define READUNLOCK()							\
		do {									\
			readLock = false;					\
		} while (0)

// Private constants ---------------------------------------------------------
#define DATA_AGG_BIT_SET        1
#define DATA_AGG_BIT_CLEAR      0

#define CSV_MAX_LINE_LENGTH     200

// Private types -------------------------------------------------------------
typedef union {
    uint8_t whole;
    struct {
    	uint8_t inProgress : 1;
    	uint8_t lpAcc : 1;
        uint8_t imu : 1;
        uint8_t adc : 1;
        uint8_t j1 : 1;
        uint8_t j2 : 1;
        uint8_t j4 : 1;
    };
} dataAggBitField_t;

typedef struct {
    rtcDataHandler_t rtcData;
    accDataHandler_t lpAccData;
    imuDataHandler_t imuData;
    adcDataHandler_t adcData;
    connectorDataHandler_t connectorData[NUM_CONNECTORS];
} dataAggBuffer_t;

// Private function prototypes -----------------------------------------------
static status_t getLpAccSettings(lpAccSettings_t * settingsOut);
static status_t getImuSettings(imuSettings_t * settingsOut);
static status_t getConnectorSettings(connectorSettings_t * settingsOut);
static status_t getAdcSettings(connectorSettings_t * connectorSettingsIn, adcSettings_t * settingsOut);

static bool sensorTypeIsAnalog(extSensorTypes_t sensorType);
static dataAggBitField_t setupDataAggMask(void);

static void updateConnectorBit(dataAggBitField_t * field, connectors_t connector, bool bitState);
static void (*getConnectorCallback(connectors_t connector))(void);

static void lpAccReadCallback(void);
static void imuReadCallback(void);
static void adcReadCallback(void);
static void j1ReadCallback(void);
static void j2ReadCallback(void);
static void j4ReadCallback(void);
static void invalidCallback(void);

static status_t readAsyncData(dataAggBitField_t mask, dataAggBitField_t * complete, dataAggBuffer_t * buffer);
static status_t formatAndWrite(dataAggBuffer_t * buffer);

static status_t encodeData(dataAggBuffer_t * inBuffer, uint8_t * outBuffer, uint16_t bufferLen, 
		uint16_t * bytesWritten);
static status_t encodeConnectorData(connectorSettings_t * settings, dataAggBuffer_t * dataIn,
        base64Encoder_t * encoder);
static status_t encodeLpAccData(lpAccSettings_t * settings, accDataHandler_t * dataIn, base64Encoder_t * encoder);
static status_t encodeImuData(imuSettings_t * settings, imuDataHandler_t * dataIn, base64Encoder_t * encoder);
static status_t encodeAdcData(adcSettings_t * settings, adcDataHandler_t * dataIn, base64Encoder_t * encoder);

static status_t validateSnprintfReturn(uint16_t retVal, uint16_t targetBufferLen);

static status_t formatData(dataAggBuffer_t * inBuffer, uint8_t * outBuffer, uint16_t bufferLen, 
		uint16_t * bytesWritten);
static status_t formatRtcData(rtcDataHandler_t * dataIn, uint8_t * bufferOut, uint16_t bufferLen,
        uint16_t * bytesWritten);
static status_t formatConnectorData(connectorSettings_t * settings, dataAggBuffer_t * dataIn,
        uint8_t * bufferOut, uint16_t bufferLen, uint16_t * bytesWritten);
static status_t formatLpAccData(lpAccSettings_t * settings, accDataHandler_t * dataIn, uint8_t * bufferOut,
        uint16_t bufferLen, uint16_t * bytesWritten);
static status_t formatImuData(imuSettings_t * settings, imuDataHandler_t * dataIn, uint8_t * bufferOut,
        uint16_t bufferLen, uint16_t * bytesWritten);
static status_t formatAdcData(adcSettings_t * settings, adcDataHandler_t * dataIn, uint8_t * bufferOut,
        uint16_t bufferLen, uint16_t * bytesWritten);


// Private constants ---------------------------------------------------------

// Private variables ---------------------------------------------------------
static bool usbSerialMode = false;
static bool binaryFileMode = false;
static lpAccSettings_t lpAccSettings;
static imuSettings_t imuSettings;
static adcSettings_t adcSettings;
static connectorSettings_t connectorSettings;

// used for ping-pong buffer
static dataAggBuffer_t dataAggBuffer1;
static dataAggBuffer_t dataAggBuffer2;
static dataAggBuffer_t * readBuffer = NULL;
static dataAggBuffer_t * writeBuffer = NULL;

// this is to avoid putting this buffer on the stack
static uint8_t csvBuffer[CSV_MAX_LINE_LENGTH];

// state information
static dataAggBitField_t dataAggCompleteBitfield;
static dataAggBitField_t dataAggCompleteMask;
static bool readPending = false;
static bool writePending = false;
static bool initialized = false;

static bool readLock = false;


// TODO: Delete -- for testing
uint32_t readRequests = 0;
uint32_t readCompletes = 0;
uint32_t readPendings = 0;

// Private function bodies ---------------------------------------------------
static status_t getLpAccSettings(lpAccSettings_t * settingsOut)
{
	configEnableState_t enabled = settingDisable;
    status_t status = Config_Ioctl(configIoctlGetLpAcc, &enabled);
    if (StatusOk == status) {
    	settingsOut->enabled = (settingEnable == enabled) ? true : false;
    }
    
    return status;
}

static status_t getImuSettings(imuSettings_t * settingsOut)
{
    configEnableState_t enabled = settingDisable;
    status_t status = Config_Ioctl(configIoctlGetImu, &enabled);
    if ((StatusOk == status) && (settingEnable == enabled)) {
        // IMU is enabled, so check other settings
        settingsOut->enabled = true;
        // Accel
        if (StatusOk == status) {
            status = Config_Ioctl(configIoctlGetAcc, &enabled);
        }
        if (StatusOk == status) {
            settingsOut->accelEnabled = (settingEnable == enabled) ? true : false;
        }
        // Gyro
        if (StatusOk == status) {
            status = Config_Ioctl(configIoctlGetGyr, &enabled);
        }
        if (StatusOk == status) {
            settingsOut->gyroEnabled = (settingEnable == enabled) ? true : false;
        }
        // Mag
        if (StatusOk == status) {
            status = Config_Ioctl(configIoctlGetMag, &enabled);
        }
        if (StatusOk == status) {
            settingsOut->magEnabled = (settingEnable == enabled) ? true : false;
        }
        // Euler
        if (StatusOk == status) {
            status = Config_Ioctl(configIoctlGetEuler, &enabled);
        }
        if (StatusOk == status) {
            settingsOut->eulerEnabled = (settingEnable == enabled) ? true : false;
        }
        // Quat
        if (StatusOk == status) {
            status = Config_Ioctl(configIoctlGetQuat, &enabled);
        }
        if (StatusOk == status) {
            settingsOut->quatEnabled = (settingEnable == enabled) ? true : false;
        }
    }
    
    return status;
}

static status_t getConnectorSettings(connectorSettings_t * settingsOut)
{
    extSensorTypes_t sensorType = sensorNull;
    
    // J1
    status_t status = Config_Ioctl(configIoctlGetJ1, &sensorType);
    if (StatusOk == status) {
        sensorType = (sensorBluebit == sensorType) ? sensorNull : sensorType; // clear if bluebit
        settingsOut->sensorTypes[connectorJ1] = sensorType;
    }
    // J2
    if (StatusOk == status) {
        status = Config_Ioctl(configIoctlGetJ2, &sensorType);
    }
    if (StatusOk == status) {
        sensorType = (sensorBluebit == sensorType) ? sensorNull : sensorType; // clear if bluebit
        settingsOut->sensorTypes[connectorJ2] = sensorType;
    }
    // J4
    if (StatusOk == status) {
        status = Config_Ioctl(configIoctlGetJ4, &sensorType);
    }
    if (StatusOk == status) {
        sensorType = (sensorBluebit == sensorType) ? sensorNull : sensorType; // clear if bluebit
        settingsOut->sensorTypes[connectorJ4] = sensorType;
    }
    
    return status;
}

static status_t getAdcSettings(connectorSettings_t * connectorSettingsIn, adcSettings_t * settingsOut)
{
    configEnableState_t enabled = settingDisable;
	settingsOut->enabled = false; // this will get flipped to true if any channels are found below
    
    // V batt
    status_t status = Config_Ioctl(configIoctlGetBatteryOutput, &enabled);
    if (StatusOk == status) {
    	if (settingEnable == enabled) {
    		settingsOut->vBattEnabled = true;
    		settingsOut->enabled = true;
    	}
    	else {
    		settingsOut->vBattEnabled = false;
    	}
    }
    // Temp
    if (StatusOk == status) {
        status = Config_Ioctl(configIoctlGetTemperatureOutput, &enabled);
    }
    if (StatusOk == status) {
    	if (settingEnable == enabled) {
    		settingsOut->tempEnabled = true;
    		settingsOut->enabled = true;
    	}
    	else {
    		settingsOut->tempEnabled = false;
    	}
    }
    
    // Map connectors: non analog -> null
    if (StatusOk == status) {
        // J1
        if (sensorTypeIsAnalog(connectorSettingsIn->sensorTypes[connectorJ1])) {
            settingsOut->connectorSettings.sensorTypes[connectorJ1] = 
                    connectorSettingsIn->sensorTypes[connectorJ1];
            settingsOut->enabled = true;
        } else {
            settingsOut->connectorSettings.sensorTypes[connectorJ1] = sensorNull;
        }
        // J2
        if (sensorTypeIsAnalog(connectorSettingsIn->sensorTypes[connectorJ2])) {
            settingsOut->connectorSettings.sensorTypes[connectorJ2] = 
                    connectorSettingsIn->sensorTypes[connectorJ2];
            settingsOut->enabled = true;
        } else {
            settingsOut->connectorSettings.sensorTypes[connectorJ2] = sensorNull;
        }
        // J4
        if (sensorTypeIsAnalog(connectorSettingsIn->sensorTypes[connectorJ4])) {
            settingsOut->connectorSettings.sensorTypes[connectorJ4] = 
                    connectorSettingsIn->sensorTypes[connectorJ4];
            settingsOut->enabled = true;
        } else {
            settingsOut->connectorSettings.sensorTypes[connectorJ4] = sensorNull;
        }
    }
    
    return status;
}

static bool sensorTypeIsAnalog(extSensorTypes_t sensorType)
{
    bool retVal = false;
    switch (sensorType) {
        case sensorAnalog:
        case sensorHall:
        case sensorLongRangeHall:
            retVal = true;
            break;
        default:
            // Keep false
            break;
    }
    
    return retVal;
}

static dataAggBitField_t setupDataAggMask(void)
{
    dataAggBitField_t mask;
    mask.whole = 0;
    mask.inProgress = DATA_AGG_BIT_SET; // This will be set when we're trying to compare bitfields
    
    // Low power accel field
    if (lpAccSettings.enabled) {
        mask.lpAcc = DATA_AGG_BIT_SET;
    }
    // Imu field
    if (imuSettings.enabled) {
        mask.imu = DATA_AGG_BIT_SET;
    }
    // Adc field
    if (adcSettings.enabled)
    {
        mask.adc = DATA_AGG_BIT_SET;
    }
    // Connector fields -- ignore if this data is coming from the adc
    if ((connectorSettings.sensorTypes[connectorJ1] != sensorNull) &&
            !sensorTypeIsAnalog(connectorSettings.sensorTypes[connectorJ1])) {
        mask.j1 = DATA_AGG_BIT_SET;
    }
    if ((connectorSettings.sensorTypes[connectorJ2] != sensorNull) &&
            !sensorTypeIsAnalog(connectorSettings.sensorTypes[connectorJ2])) {
        mask.j2 = DATA_AGG_BIT_SET;
    }
    if ((connectorSettings.sensorTypes[connectorJ4] != sensorNull) &&
            !sensorTypeIsAnalog(connectorSettings.sensorTypes[connectorJ4])) {
        mask.j4 = DATA_AGG_BIT_SET;
    }
    
    return mask;
}

static void updateConnectorBit(dataAggBitField_t * field, connectors_t connector, bool bitState)
{
    switch (connector) {
        case connectorJ1:
            field->j1 = bitState;
            break;
        case connectorJ2:
            field->j2 = bitState;
            break;
        case connectorJ4:
            field->j4 = bitState;
            break;
    }
}

static void (*getConnectorCallback(connectors_t connector))(void)
{
    void (*callback)(void) = &invalidCallback; // to avoid dereferencing a junk pointer
    switch (connector) {
        case connectorJ1:
            callback = &j1ReadCallback;
            break;
        case connectorJ2:
            callback = &j2ReadCallback;
            break;
        case connectorJ4:
            callback = &j4ReadCallback;
            break;
    }
    
    return callback;
}

static void lpAccReadCallback(void)
{
	dataAggCompleteBitfield.lpAcc = DATA_AGG_BIT_SET;
}

static void imuReadCallback(void)
{
    dataAggCompleteBitfield.imu = DATA_AGG_BIT_SET;
}

static void adcReadCallback(void)
{
    dataAggCompleteBitfield.adc = DATA_AGG_BIT_SET;
}

static void j1ReadCallback(void)
{
    dataAggCompleteBitfield.j1 = DATA_AGG_BIT_SET;
}

static void j2ReadCallback(void)
{
    dataAggCompleteBitfield.j2 = DATA_AGG_BIT_SET;
}

static void j4ReadCallback(void)
{
    dataAggCompleteBitfield.j4 = DATA_AGG_BIT_SET;
}

static void invalidCallback(void)
{
    // TODO: Report this error
}

static status_t readAsyncData(dataAggBitField_t mask, dataAggBitField_t * complete, dataAggBuffer_t * buffer)
{
    status_t temp = StatusOk;
    status_t retVal = StatusOk;
    // LP Accel
    if (mask.lpAcc == DATA_AGG_BIT_SET) {
    	temp = Lis2de12_ReadData(&buffer->lpAccData, &lpAccReadCallback);
        // Handle bad status
        if (StatusOk != temp) {
            complete->lpAcc = DATA_AGG_BIT_SET; // don't expect the callback to return
            retVal = temp;
        }
    }
    // IMU
    if (mask.imu == DATA_AGG_BIT_SET) {
        temp = Bno055_ReadData(&imuSettings, &buffer->imuData, &imuReadCallback);
        // Handle bad status
        if (StatusOk != temp) {
            complete->imu = DATA_AGG_BIT_SET; // don't expect the callback to return
            retVal = temp;
        }
    }
    // ADC
    if (mask.adc == DATA_AGG_BIT_SET) {
        temp = ADC_ReadData(&buffer->adcData, &adcReadCallback);
        // Handle bad status
        if (StatusOk != temp) {
            complete->adc = DATA_AGG_BIT_SET; // don't expect the callback to return
            retVal = temp;
        }
    }
    // Peripheral sensors
    for (int i = 0; i < NUM_CONNECTORS; i++) {
        void (*callback)(void) = getConnectorCallback((connectors_t)i);
        switch (connectorSettings.sensorTypes[i]) {
            case sensorPressure:
                temp = Ms5837_ReadPressure(ms5837Id_0, &buffer->connectorData[i], callback);
                break;
            case sensorTemperature:
                temp = Ms5837_ReadTemp(ms5837Id_0, &buffer->connectorData[i], callback);
                break;
            case sensorPressureTemp:
                temp = Ms5837_ReadPressureTemp(ms5837Id_0, &buffer->connectorData[i], callback);
                break;
            case sensorDualPressure:
                temp = DualPressTemp_ReadPressure(&buffer->connectorData[i], callback);
                break;
            case sensorDualTemp:
                temp = DualPressTemp_ReadTemp(&buffer->connectorData[i], callback);
                break;
            case sensorDualPressureTemp:
                temp = DualPressTemp_ReadPressureTemp(&buffer->connectorData[i], callback);
                break;
            case sensorLoadCell:
                // HX711 is currently synchronous
                temp = HX711_ReadData((connectors_t)i, &buffer->connectorData[i]);
                updateConnectorBit(&dataAggCompleteBitfield, (connectors_t)i, DATA_AGG_BIT_SET);
                break;
            case sensorLiquidLvl:
                temp = FDC2214_ReadData(&buffer->connectorData[i], callback);
                break;
            case sensorDigital:
                if (GPIO_GetConnectorGPIOInputState((connectors_t)i)) {
                    buffer->connectorData[i].data[0].uint32 = 1;
                } else {
                    buffer->connectorData[i].data[0].uint32 = 0;
                }
                updateConnectorBit(&dataAggCompleteBitfield, (connectors_t)i, DATA_AGG_BIT_SET);
                break;
            default:
                break;
        }
        // Handle bad statuses
        if (StatusOk != temp) {
            updateConnectorBit(complete, (connectors_t)i, DATA_AGG_BIT_SET);
            retVal = temp;
        }
    }
    
    return retVal;
}

static status_t formatAndWrite(dataAggBuffer_t * buffer)
{
	status_t status = StatusOk;
	uint16_t writeLen = 0;
	if (binaryFileMode) {
		status = encodeData(buffer, csvBuffer, sizeof(csvBuffer), &writeLen);
	} else {
		status = formatData(buffer, csvBuffer, sizeof(csvBuffer), &writeLen);
	}
	
	if (StatusOk == status) {
		status = Fifo_Write(csvBuffer, writeLen);
	}
	
	return status;
}

static status_t encodeData(dataAggBuffer_t * inBuffer, uint8_t * outBuffer, uint16_t bufferLen, 
		uint16_t * bytesWritten)
{
    status_t status = StatusOk;
    
    // Start base64 encoder
    base64Encoder_t encoder;
    status = Base64_EncoderStart(&encoder, outBuffer, bufferLen);
    
    // Add data --
    // Follow current ordering which is datetime -> connectors -> imu -> adc (internal)
    
    // RTC data
    if (StatusOk == status) {
    	uint32_t unixTime = RTC_GetUnixTime(&inBuffer->rtcData);
    	status = Base64_EncoderAddChunk(&encoder, (uint8_t *)&unixTime, sizeof(unixTime));
    }
    // Connector data
    if (StatusOk == status) {
        status = encodeConnectorData(&connectorSettings, inBuffer, &encoder);
    }
    // LP accel data
    if (StatusOk == status) {
        status = encodeLpAccData(&lpAccSettings, &inBuffer->lpAccData, &encoder);
    }
    // IMU data
    if (StatusOk == status) {
        status = encodeImuData(&imuSettings, &inBuffer->imuData, &encoder);
    }
    // non-connector ADC data
    if (StatusOk == status) {
        status = encodeAdcData(&adcSettings, &inBuffer->adcData, &encoder);
    }
    
    // End base64 encoder (pads, gives total bytes written)
    if (StatusOk == status) {
    	status = Base64_EncoderEnd(&encoder, bytesWritten);
    }
    
    return status;
}

static status_t encodeConnectorData(connectorSettings_t * settings, dataAggBuffer_t * dataIn,
        base64Encoder_t * encoder)
{
    status_t status = StatusOk;
    
    for (int i = 0; i < NUM_CONNECTORS; i++) {
        if (StatusOk == status) {
            switch (settings->sensorTypes[i]) {
                case sensorPressure:
                case sensorTemperature:
                case sensorLoadCell:
                case sensorLiquidLvl:
                case sensorDigital:
                case sensorHall:
                case sensorLongRangeHall:
                case sensorAnalog:
                	// 4 byte data type
					status = Base64_EncoderAddChunk(encoder, dataIn->connectorData[i].data[0].uint8, 4);
                    break;
                case sensorPressureTemp:
                case sensorDualPressure:
                case sensorDualTemp:
                	// 8 byte data type
					status = Base64_EncoderAddChunk(encoder, dataIn->connectorData[i].data[0].uint8, 8);
                    break;
                case sensorDualPressureTemp:
                	// 16 byte data type
					status = Base64_EncoderAddChunk(encoder, dataIn->connectorData[i].data[0].uint8, 16);
                    break;
                default:
                    break;
            }
        }
    }
    return status;
}

static status_t encodeLpAccData(lpAccSettings_t * settings, accDataHandler_t * dataIn, base64Encoder_t * encoder)
{
    status_t status = StatusOk;
    
    if (settings->enabled) {
    	status = Base64_EncoderAddChunk(encoder, (uint8_t *)&dataIn->accData, sizeof(dataIn->accData));
    }
    
    return status;
}

static status_t encodeImuData(imuSettings_t * settings, imuDataHandler_t * dataIn, base64Encoder_t * encoder)
{
    status_t status = StatusOk;
    
    if (settings->enabled) {
        // acc
        if (settings->accelEnabled && (StatusOk == status)) {
        	status = Base64_EncoderAddChunk(encoder, (uint8_t *)&dataIn->accData, sizeof(dataIn->accData));
        }
        // gyro
        if (settings->gyroEnabled && (StatusOk == status)) {
        	status = Base64_EncoderAddChunk(encoder, (uint8_t *)&dataIn->gyrData, sizeof(dataIn->gyrData));
        }
        // mag
        if (settings->magEnabled && (StatusOk == status)) {
        	status = Base64_EncoderAddChunk(encoder, (uint8_t *)&dataIn->magData, sizeof(dataIn->magData));
        }
        // euler
        if (settings->eulerEnabled && (StatusOk == status)) {
        	status = Base64_EncoderAddChunk(encoder, (uint8_t *)&dataIn->eulerData, sizeof(dataIn->eulerData));
        }
        // quat
        if (settings->quatEnabled && (StatusOk == status)) {
        	status = Base64_EncoderAddChunk(encoder, (uint8_t *)&dataIn->quatData, sizeof(dataIn->quatData));
        }
    }
    
    return status;
}

static status_t encodeAdcData(adcSettings_t * settings, adcDataHandler_t * dataIn, base64Encoder_t * encoder)
{
    status_t status = StatusOk;

    // Batt
    if (settings->vBattEnabled && (StatusOk == status)) {
    	status = Base64_EncoderAddChunk(encoder, (uint8_t *)&dataIn->vBattery, sizeof(dataIn->vBattery));
    }
    
    // Temp
    if (settings->tempEnabled && (StatusOk == status)) {
    	status = Base64_EncoderAddChunk(encoder, (uint8_t *)&dataIn->temperature, 
    			sizeof(dataIn->temperature));
    }
    
    return status;
}

static status_t validateSnprintfReturn(uint16_t retVal, uint16_t targetBufferLen)
{
    status_t status = StatusOk;
    
    if (retVal < 0) {
        status = StatusCodePath; // something is wrong with the format string
    } else if (retVal == targetBufferLen) {
        status = StatusBufferFull;
    }
    
    return status;
}

static status_t formatData(dataAggBuffer_t * inBuffer, uint8_t * outBuffer, uint16_t bufferLen, 
		uint16_t * bytesWritten)
{
    status_t status = StatusOk;
    uint16_t bufferIndex = 0;
    uint16_t bytesWrittenTemp = 0;
    // Follow current ordering which is datetime -> connectors -> imu -> adc (internal)
    
    // Rtc data
    if (StatusOk == status) {
        status = formatRtcData(&inBuffer->rtcData, &outBuffer[bufferIndex],
                bufferLen - bufferIndex, &bytesWrittenTemp);
        bufferIndex += bytesWrittenTemp;
    }
    
    // Connector data
    if (StatusOk == status) {
        status = formatConnectorData(&connectorSettings, inBuffer, &outBuffer[bufferIndex],
                bufferLen - bufferIndex, &bytesWrittenTemp);
        bufferIndex += bytesWrittenTemp;
    }
    
    // LP accel data
    if (StatusOk == status) {
        status = formatLpAccData(&lpAccSettings, &inBuffer->lpAccData, &outBuffer[bufferIndex],
                bufferLen - bufferIndex, &bytesWrittenTemp);
        bufferIndex += bytesWrittenTemp;
    }
    
    // IMU data
    if (StatusOk == status) {
        status = formatImuData(&imuSettings, &inBuffer->imuData, &outBuffer[bufferIndex],
                bufferLen - bufferIndex, &bytesWrittenTemp);
        bufferIndex += bytesWrittenTemp;
    }
    
    // non-connector ADC data
    if (StatusOk == status) {
        status = formatAdcData(&adcSettings, &inBuffer->adcData, &outBuffer[bufferIndex],
                bufferLen - bufferIndex, &bytesWrittenTemp);
        bufferIndex += bytesWrittenTemp;
    }
    
    // Take off trailing comma, append CR+LF
    if (StatusOk == status) {
        if ((bufferLen - bufferIndex) > 0) {
            outBuffer[bufferIndex - 1] = '\r'; // overwrite comma
            outBuffer[bufferIndex] = '\n';
            bufferIndex++;
        } else {
            status = StatusBufferFull;
        }
    }
    
    if (StatusOk == status) {
        *bytesWritten = bufferIndex;
    }
    
    return status;
}

static status_t formatRtcData(rtcDataHandler_t * dataIn, uint8_t * bufferOut, uint16_t bufferLen,
        uint16_t * bytesWritten)
{
	// Date
	uint16_t writeLen = Utility_ItoaBase10(dataIn->rtcDateData.months, bufferOut, 2);
	bufferOut[writeLen++] = '/';
	writeLen += Utility_ItoaBase10(dataIn->rtcDateData.days, bufferOut + writeLen, 2);
	bufferOut[writeLen++] = '/';
	writeLen += Utility_ItoaBase10(dataIn->rtcDateData.years, bufferOut + writeLen, 2);
	bufferOut[writeLen++] = ' ';
	
	// Time
	writeLen += Utility_ItoaBase10(dataIn->rtcTimeData.hours, bufferOut + writeLen, 2);
	bufferOut[writeLen++] = ':';
	writeLen += Utility_ItoaBase10(dataIn->rtcTimeData.minutes, bufferOut + writeLen, 2);
	bufferOut[writeLen++] = ':';
	writeLen += Utility_ItoaBase10(dataIn->rtcTimeData.seconds, bufferOut + writeLen, 2);
	bufferOut[writeLen++] = '.';
	writeLen += Utility_ItoaBase10(dataIn->rtcTimeData.milliseconds, bufferOut + writeLen, 3);
	
	// Trailing comma
	bufferOut[writeLen++] = ',';
	
	*bytesWritten = writeLen;
	// For performance reasons, we're going to avoid checking buffer length after every character.
	// However, if we've exceeded it, we will throw a bad status here to make it easy to catch
	// when debugging.
	return (writeLen <= bufferLen) ? StatusOk : StatusBufferLength;
}

static status_t formatConnectorData(connectorSettings_t * settings, dataAggBuffer_t * dataIn,
        uint8_t * bufferOut, uint16_t bufferLen, uint16_t * bytesWritten)
{
    uint16_t writeLen = 0;
    
    for (int i = 0; i < NUM_CONNECTORS; i++) {
		switch (settings->sensorTypes[i]) {
			case sensorPressure:
			case sensorTemperature:
			case sensorLoadCell:
				writeLen += Utility_FtoaBase10(dataIn->connectorData[i].data[0].float32, 
						bufferOut + writeLen, fPrecision_3);
				bufferOut[writeLen++] = ',';
				break;
			case sensorLiquidLvl:
			case sensorDigital:
				writeLen += Utility_ItoaBase10(dataIn->connectorData[i].data[0].uint32, 
						bufferOut + writeLen, 1);
				bufferOut[writeLen++] = ',';
				break;
			case sensorPressureTemp:
			case sensorDualPressure:
			case sensorDualTemp:
				// This fills two floats
				writeLen += Utility_FtoaBase10(dataIn->connectorData[i].data[0].float32, 
						bufferOut + writeLen, fPrecision_3);
				bufferOut[writeLen++] = ',';
				writeLen += Utility_FtoaBase10(dataIn->connectorData[i].data[1].float32, 
						bufferOut + writeLen, fPrecision_3);
				bufferOut[writeLen++] = ',';
				break;
			case sensorDualPressureTemp:
				// This fills four floats
				writeLen += Utility_FtoaBase10(dataIn->connectorData[i].data[0].float32, 
						bufferOut + writeLen, fPrecision_3);
				bufferOut[writeLen++] = ',';
				writeLen += Utility_FtoaBase10(dataIn->connectorData[i].data[1].float32, 
						bufferOut + writeLen, fPrecision_3);
				bufferOut[writeLen++] = ',';
				writeLen += Utility_FtoaBase10(dataIn->connectorData[i].data[2].float32, 
						bufferOut + writeLen, fPrecision_3);
				bufferOut[writeLen++] = ',';
				writeLen += Utility_FtoaBase10(dataIn->connectorData[i].data[3].float32, 
						bufferOut + writeLen, fPrecision_3);
				bufferOut[writeLen++] = ',';
			
			// Analog sensors
			case sensorHall:
			case sensorLongRangeHall:
			case sensorAnalog:
				writeLen += Utility_ItoaBase10(dataIn->adcData.connectorData[i].float32, 
						bufferOut + writeLen, 1);
				bufferOut[writeLen++] = ',';
				break;
				
			default:
				break;
		}
    }
    
    *bytesWritten = writeLen;
    // For performance reasons, we're going to avoid checking buffer length after every character.
	// However, if we've exceeded it, we will throw a bad status here to make it easy to catch
	// when debugging.
	return (writeLen <= bufferLen) ? StatusOk : StatusBufferLength;
}

static status_t formatLpAccData(lpAccSettings_t * settings, accDataHandler_t * dataIn, uint8_t * bufferOut,
        uint16_t bufferLen, uint16_t * bytesWritten)
{
    uint16_t writeLen = 0;
    
    if (settings->enabled) {
    	writeLen += Utility_FtoaBase10(dataIn->accData[0], bufferOut + writeLen, fPrecision_0);
		bufferOut[writeLen++] = ',';
    	writeLen += Utility_FtoaBase10(dataIn->accData[1], bufferOut + writeLen, fPrecision_0);
		bufferOut[writeLen++] = ',';
    	writeLen += Utility_FtoaBase10(dataIn->accData[2], bufferOut + writeLen, fPrecision_0);
		bufferOut[writeLen++] = ',';
    }
    
    *bytesWritten = writeLen;
    // For performance reasons, we're going to avoid checking buffer length after every character.
	// However, if we've exceeded it, we will throw a bad status here to make it easy to catch
	// when debugging.
	return (writeLen <= bufferLen) ? StatusOk : StatusBufferLength;
}

static status_t formatImuData(imuSettings_t * settings, imuDataHandler_t * dataIn, uint8_t * bufferOut,
        uint16_t bufferLen, uint16_t * bytesWritten)
{
    uint16_t writeLen = 0;
    
    if (settings->enabled) {
        // acc
        if (settings->accelEnabled) {
        	writeLen += Utility_FtoaBase10(dataIn->accData[0], bufferOut + writeLen, fPrecision_0);
			bufferOut[writeLen++] = ',';
			writeLen += Utility_FtoaBase10(dataIn->accData[1], bufferOut + writeLen, fPrecision_0);
			bufferOut[writeLen++] = ',';
			writeLen += Utility_FtoaBase10(dataIn->accData[2], bufferOut + writeLen, fPrecision_0);
			bufferOut[writeLen++] = ',';
        }
        // gyro
        if (settings->gyroEnabled) {
        	writeLen += Utility_FtoaBase10(dataIn->gyrData[0], bufferOut + writeLen, fPrecision_3);
			bufferOut[writeLen++] = ',';
			writeLen += Utility_FtoaBase10(dataIn->gyrData[1], bufferOut + writeLen, fPrecision_3);
			bufferOut[writeLen++] = ',';
			writeLen += Utility_FtoaBase10(dataIn->gyrData[2], bufferOut + writeLen, fPrecision_3);
			bufferOut[writeLen++] = ',';
        }
        // mag
        if (settings->magEnabled) {
        	writeLen += Utility_FtoaBase10(dataIn->magData[0], bufferOut + writeLen, fPrecision_3);
			bufferOut[writeLen++] = ',';
			writeLen += Utility_FtoaBase10(dataIn->magData[1], bufferOut + writeLen, fPrecision_3);
			bufferOut[writeLen++] = ',';
			writeLen += Utility_FtoaBase10(dataIn->magData[2], bufferOut + writeLen, fPrecision_3);
			bufferOut[writeLen++] = ',';
        }
        // euler
        if (settings->eulerEnabled) {
        	writeLen += Utility_FtoaBase10(dataIn->eulerData[0], bufferOut + writeLen, fPrecision_3);
			bufferOut[writeLen++] = ',';
			writeLen += Utility_FtoaBase10(dataIn->eulerData[1], bufferOut + writeLen, fPrecision_3);
			bufferOut[writeLen++] = ',';
			writeLen += Utility_FtoaBase10(dataIn->eulerData[2], bufferOut + writeLen, fPrecision_3);
			bufferOut[writeLen++] = ',';
        }
        // quat
        if (settings->quatEnabled) {
        	writeLen += Utility_FtoaBase10(dataIn->quatData[0], bufferOut + writeLen, fPrecision_3);
			bufferOut[writeLen++] = ',';
			writeLen += Utility_FtoaBase10(dataIn->quatData[1], bufferOut + writeLen, fPrecision_3);
			bufferOut[writeLen++] = ',';
			writeLen += Utility_FtoaBase10(dataIn->quatData[2], bufferOut + writeLen, fPrecision_3);
			bufferOut[writeLen++] = ',';
			writeLen += Utility_FtoaBase10(dataIn->quatData[3], bufferOut + writeLen, fPrecision_3);
			bufferOut[writeLen++] = ',';
        }
    }
    
    *bytesWritten = writeLen;
    // For performance reasons, we're going to avoid checking buffer length after every character.
	// However, if we've exceeded it, we will throw a bad status here to make it easy to catch
	// when debugging.
	return (writeLen <= bufferLen) ? StatusOk : StatusBufferLength;
}

static status_t formatAdcData(adcSettings_t * settings, adcDataHandler_t * dataIn, uint8_t * bufferOut,
        uint16_t bufferLen, uint16_t * bytesWritten)
{
    uint16_t writeLen = 0;
    
    // batt
    if (settings->vBattEnabled) {
    	writeLen += Utility_FtoaBase10(dataIn->vBattery, bufferOut + writeLen, fPrecision_3);
		bufferOut[writeLen++] = ',';
    }
    // internal temp
    if (settings->tempEnabled) {
    	writeLen += Utility_FtoaBase10(dataIn->temperature, bufferOut + writeLen, fPrecision_3);
		bufferOut[writeLen++] = ',';
    }
    
    *bytesWritten = writeLen;
    // For performance reasons, we're going to avoid checking buffer length after every character.
	// However, if we've exceeded it, we will throw a bad status here to make it easy to catch
	// when debugging.
	return (writeLen <= bufferLen) ? StatusOk : StatusBufferLength;
}

// Public functions bodies ---------------------------------------------------
status_t DataAggregator_Init(void)
{
	status_t status = StatusOk;

	if(initialized){
		status = StatusAlreadyInitialized;
	}
	
	// Get settings
	if (StatusOk == status) {
	    status = getLpAccSettings(&lpAccSettings);
	}
	if (StatusOk == status) {
	    status = getImuSettings(&imuSettings);
	}
	if (StatusOk == status) {
	    status = getConnectorSettings(&connectorSettings);
	}
	if (StatusOk == status) {
	    status = getAdcSettings(&connectorSettings, &adcSettings);
	}
	if (StatusOk == status) {
		configEnableState_t enabled = settingDisable;
		status = Config_Ioctl(configIoctlGetBinaryFileMode, (uint8_t *)&enabled);
		if (StatusOk == status) {
			binaryFileMode = (settingEnable == enabled) ? true : false;
		}
	}
	
	// Initialize ADC, enabled peripheral sensors
	if (StatusOk == status) {
	    status = ADC_Init(&adcSettings); // ADC will initialize analog peripherals
	}
    for (int i = 0; i < NUM_CONNECTORS; i++) {
        if (StatusOk == status) {
            switch (connectorSettings.sensorTypes[i]) {
                case sensorPressure:
                case sensorTemperature:
                case sensorPressureTemp:
                    status = Ms5837_Init();
                    if (StatusOk == status) {
                        status = Ms5837_SetupSensor(ms5837Id_0);
                    }
                    break;
                case sensorDualPressure:
                case sensorDualTemp:
                case sensorDualPressureTemp:
                    status = DualPressTemp_Init();
                    break;
                case sensorLoadCell:
                    status = HX711_Init((connectors_t)i);
                    break;
                case sensorLiquidLvl:
                    status = FDC2214_Init((connectors_t)i);
                    break;
                case sensorDigital:
                    GPIO_SetupConnectorGPIOInput((connectors_t)i, true);
                    break;
                default:
                    break;
            }
        }
    }
    
    // Initialize complete mask
    dataAggCompleteMask = setupDataAggMask();
    
    if(StatusOk == status){
        initialized = true;
        readPending = false;
        writePending = false;
    }
    
    return returnStatus(status, eSucInitStatus);
}

status_t DataAggregator_On(bool usbSerial)
{
	status_t status = StatusOk;
	
	usbSerialMode = usbSerial;
	if (usbSerialMode) {
		// Turn on all IMU settings
		imuSettings.enabled = true;
		imuSettings.accelEnabled = true;
		imuSettings.gyroEnabled = true;
		imuSettings.magEnabled = true;
		imuSettings.eulerEnabled = true;
		imuSettings.quatEnabled = true;
	}
	
	// --------
	// We want to turn everything on regardless of status, but preserve bad statuses (for logging)
	
	// Turn on lp accel
	if (lpAccSettings.enabled) {
		status = Lis2de12_EnableRead();
	}
	// Turn on BNO
	if (imuSettings.enabled) {
		status = Status_Preserve(status, Bno055_Ioctl(imuIoctlNormalPow, NULL));
	}
	// Turn on ADC
	if (adcSettings.enabled) {
		status = Status_Preserve(status, ADC_StudyDataOn());
	}
	// Turn on peripherals
	for (int i = 0; i < NUM_CONNECTORS; i++) {
		switch (connectorSettings.sensorTypes[i]) {
			case sensorLoadCell:
				status = Status_Preserve(status, HX711_PowerOn((connectors_t)i));
				break;
			case sensorLiquidLvl:
				status = Status_Preserve(status, FDC2214_PowerOn());
				break;
			// Other sensors don't need on/off
			default:
				break;
		}
    }
	
	// Start summary data
	status = Status_Preserve(status, SummaryData_Start());
	
	// Reset state
	readPending = false;
	writePending = false;
	readBuffer = &dataAggBuffer1;
	writeBuffer = NULL;
	dataAggCompleteBitfield.whole = 0;
	
	// Start timer
	status = Status_Preserve(status, Timer_Init());
	status = Status_Preserve(status, Timer_Ioctl(timerIoctlStart, 0));
	
	return returnStatus(status, eSucIoctlStatus);
}

status_t DataAggregator_Off(void)
{
	status_t status = StatusOk;
	
	// --------
	// We want to turn everything off regardless of status, but preserve bad statuses (for logging)
	
	// Stop timer
	status = Timer_Ioctl(timerIoctlStop, 0);
	status = Status_Preserve(status, Timer_DeInit());
	
	// Turn off lp accel
	if (lpAccSettings.enabled) {
		status = Status_Preserve(status, Lis2de12_DisableRead());
	}
	// Turn off BNO
	if (imuSettings.enabled) {
		status = Status_Preserve(status, Bno055_Ioctl(imuIoctlSuspendPow, NULL));
	}
	// Turn off ADC
	if (adcSettings.enabled) {
		status = Status_Preserve(status, ADC_StudyDataOff());
	}
	// Turn off peripherals
	for (int i = 0; i < NUM_CONNECTORS; i++) {
		switch (connectorSettings.sensorTypes[i]) {
			case sensorLoadCell:
				status = Status_Preserve(status, HX711_PowerOff((connectors_t)i));
				break;
			case sensorLiquidLvl:
				status = Status_Preserve(status, FDC2214_PowerOff());
				break;
			// Other sensors don't need on/off
			default:
				break;
		}
    }
	
	// Write if pending
	if (writePending && writeBuffer) {
		status = Status_Preserve(status, formatAndWrite(writeBuffer));
		if (StatusOk == status) {
			// TODO: Delete -- for testing
			readCompletes++;
		}
	}
	
	// Reset state
	readPending = false;
	writePending = false;
	
	// End summary data capture, send to bluebits
	uint8_t * summaryData;
	size_t summaryDataLen;
	status = Status_Preserve(status, SummaryData_End(&summaryData, &summaryDataLen));
	status = Status_Preserve(status, BlueBits_SendSummaryData(summaryData, summaryDataLen));
	
	return returnStatus(status, eSucIoctlStatus);
}

status_t DataAggregator_ReadData(void)
{
	// TODO: Delete, for testing
	readRequests++;
	// We don't want to call this from timer interrupt if its already being executed
	READLOCK();
	status_t status = StatusOk;
	
	// If we have a previous read thats done..
	if ((dataAggCompleteBitfield.whole & dataAggCompleteMask.whole) == dataAggCompleteMask.whole) {
		// Ping pong buffers -- if a previous write is pending, thats fine, we will
		// overwrite with the most recent data
		writeBuffer = readBuffer;
		readBuffer = (readBuffer == &dataAggBuffer1) ? &dataAggBuffer2 : &dataAggBuffer1;
		// Clear complete mask
		dataAggCompleteBitfield.whole = 0;
		// Set write pending
		writePending = true;
	}
	
	// Make sure read is ready
	if (0 == dataAggCompleteBitfield.whole && readBuffer) {
		// Start read
		status = RTC_ReadTime(&readBuffer->rtcData);
		if (StatusOk == status) {
			// Update state
			dataAggCompleteBitfield.inProgress = DATA_AGG_BIT_SET;
			status = readAsyncData(dataAggCompleteMask, &dataAggCompleteBitfield, readBuffer);
			readPending = false;
		}
	} else {
		readPending = true;
		// TODO: delete -- for testing
		readPendings++;
	}
	
	// Write if pending
	if (writePending && writeBuffer) {
		// Update summary data
		status = SummaryData_Update();
		// If we're in USB serial mode, send to USB, else, save to fifo which goes to filesystem downstream
		status_t writeStatus = StatusOk;
		if (usbSerialMode) {
			writeStatus = Serial_HandleOutput(&writeBuffer->rtcData, &writeBuffer->imuData);
		} else {
			// Format & write to FIFO
			writeStatus = formatAndWrite(writeBuffer);
		}
		
		if (StatusOk == writeStatus) {
			writePending = false;
			// TODO: Delete -- for testing
			readCompletes++;
		} else {
			// Overwrite any bad statuses from summary data with bad format & write status
			// which is more critical to operation..
			status = writeStatus;
		}
		// If status if bad, write pending remains
	}

    READUNLOCK();
	return returnStatus(status, eSucReadStatus);
}

status_t DataAggregator_PrintHeader(uint8_t * bufferOut, uint16_t bufferLen)
{
	status_t status = StatusOk;
	uint16_t bufferIndex = 0;
	uint16_t writeLen = 0;
	
	// RTC
	if (StatusOk == status) {
		writeLen = snprintf(&bufferOut[bufferIndex], bufferLen - bufferIndex, "Time,");
		status = validateSnprintfReturn(writeLen, bufferLen);
		if (StatusOk == status) {
			bufferIndex += writeLen;
		}
	}
	// J Connectors
	uint8_t connectorName[2];
	for (int i = 0; i < NUM_CONNECTORS; i++) {
		status = Status_Preserve(status, 
				GPIO_GetNameFromConnector((connectors_t)i, connectorName, sizeof(connectorName)));
        if (StatusOk == status) {
            switch (connectorSettings.sensorTypes[i]) {
            	// Single header column
                case sensorPressure:
                case sensorTemperature:
                case sensorLoadCell:
                case sensorLiquidLvl:
                case sensorDigital:
				case sensorHall:
                case sensorLongRangeHall:
                case sensorAnalog:
                    writeLen = snprintf(&bufferOut[bufferIndex],
                            bufferLen - bufferIndex, "J%s,", connectorName);
                    status = validateSnprintfReturn(writeLen, bufferLen - bufferIndex);
                    if (StatusOk == status) {
                        bufferIndex += writeLen;
                    }
                    break;
				// Two header column
                case sensorPressureTemp:
                case sensorDualPressure:
                case sensorDualTemp:
                    // This fills two floats
                    writeLen = snprintf(&bufferOut[bufferIndex],
                            bufferLen - bufferIndex, "J%s A,J%s B,", 
							connectorName,
							connectorName);
                    status = validateSnprintfReturn(writeLen, bufferLen - bufferIndex);
                    if (StatusOk == status) {
                        bufferIndex += writeLen;
                    }
                    break;
				// Four header column
                case sensorDualPressureTemp:
                    // This fills four floats
                    writeLen = snprintf(&bufferOut[bufferIndex],
                            bufferLen - bufferIndex, "J%s A,J%s B,J%s C,J%s D,", 
							connectorName,
							connectorName,
							connectorName,
							connectorName);
                    status = validateSnprintfReturn(writeLen, bufferLen - bufferIndex);
                    if (StatusOk == status) {
                        bufferIndex += writeLen;
                    }
                    break;
                default:
                    break;
            }
        }
    }
	// LP accel
	if (lpAccSettings.enabled && (StatusOk == status)) {
		uint16_t writeLen = snprintf(&bufferOut[bufferIndex], bufferLen - bufferIndex, 
				"LP Acc X,LP Acc Y,LP Acc Z,");
		status = validateSnprintfReturn(writeLen, bufferLen);
		if (StatusOk == status) {
			bufferIndex += writeLen;
		}
	}
	// IMU
	if (imuSettings.accelEnabled && (StatusOk == status)) {
		uint16_t writeLen = snprintf(&bufferOut[bufferIndex], bufferLen - bufferIndex, 
				"Acc X,Acc Y,Acc Z,");
		status = validateSnprintfReturn(writeLen, bufferLen);
		if (StatusOk == status) {
			bufferIndex += writeLen;
		}
	}
	if (imuSettings.gyroEnabled && (StatusOk == status)) {
		uint16_t writeLen = snprintf(&bufferOut[bufferIndex], bufferLen - bufferIndex, 
				"Gyr X,Gyr Y,Gyr Z,");
		status = validateSnprintfReturn(writeLen, bufferLen);
		if (StatusOk == status) {
			bufferIndex += writeLen;
		}
	}
	if (imuSettings.magEnabled && (StatusOk == status)) {
		uint16_t writeLen = snprintf(&bufferOut[bufferIndex], bufferLen - bufferIndex, 
				"Mag X,Mag Y,Mag Z,");
		status = validateSnprintfReturn(writeLen, bufferLen);
		if (StatusOk == status) {
			bufferIndex += writeLen;
		}
	}
	if (imuSettings.eulerEnabled && (StatusOk == status)) {
		uint16_t writeLen = snprintf(&bufferOut[bufferIndex], bufferLen - bufferIndex, 
				"Yaw,Roll,Pitch,");
		status = validateSnprintfReturn(writeLen, bufferLen);
		if (StatusOk == status) {
			bufferIndex += writeLen;
		}
	}
	if (imuSettings.quatEnabled && (StatusOk == status)) {
		uint16_t writeLen = snprintf(&bufferOut[bufferIndex], bufferLen - bufferIndex, 
				"QW,QX,QY,QZ,");
		status = validateSnprintfReturn(writeLen, bufferLen);
		if (StatusOk == status) {
			bufferIndex += writeLen;
		}
	}
	
	// ADC
	if (adcSettings.vBattEnabled && (StatusOk == status)) {
		uint16_t writeLen = snprintf(&bufferOut[bufferIndex], bufferLen - bufferIndex, 
				"Bat,");
		status = validateSnprintfReturn(writeLen, bufferLen);
		if (StatusOk == status) {
			bufferIndex += writeLen;
		}
	}
	if (adcSettings.tempEnabled && (StatusOk == status)) {
		uint16_t writeLen = snprintf(&bufferOut[bufferIndex], bufferLen - bufferIndex, 
				"Temperature,");
		status = validateSnprintfReturn(writeLen, bufferLen);
		if (StatusOk == status) {
			bufferIndex += writeLen;
		}
	}
	
	// Take off trailing comma, append CR+LF+\0
    if (StatusOk == status) {
        if ((bufferLen - bufferIndex) > 0) {
            bufferOut[bufferIndex - 1] = '\r'; // overwrite comma
            bufferOut[bufferIndex] = '\n';
            bufferOut[bufferIndex + 1] = '\0';
        } else {
            status = StatusBufferFull;
        }
    }
    
    return returnStatus(status, eSucIoctlStatus);
}

status_t DataAggregator_Tick(void)
{
    status_t status = StatusOk;
    
    if (readPending) {
        status = DataAggregator_ReadData();
        // TODO: Delete -- for testing
        readRequests--; // prevent tick() method messing up our figure
        if (readPending) readPendings--; // prevent tick() method messing up our figure
    }
    
    // handle data agg state will report the status
    return status;
}

/// SAEC Kinetic Vision, Inc. ----------- END OF FILE
