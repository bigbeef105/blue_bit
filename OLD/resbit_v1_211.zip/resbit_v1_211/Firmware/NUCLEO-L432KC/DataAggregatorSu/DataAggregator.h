/**
  @file       DataAggregator.h

  @copyright  (C) 2019 Kinetic Vision, Cincinnati Ohio.
               This software is property of SAEC Kinetic Vision, Inc
               and is considered confidential.

  @brief      DataAggregator software unit "H" file.

  @author     Parker Kamer

  @defgroup   DataAggregatorSu Acquires data from all configured data peripherals

  Configuration History
  =====================

  Config Item    | Value
  -------------- | -----
  Config #       | NA
  Revision       | NA
  Revised, Date  | NA
  QA, Date       | NA
  Approved, Date | NA
  Released, Date | NA

  Significant Modification History (Most recent at top)
  =====================================================

  Date         | Initials | Details
  ------------ | -------- | -------
  23 Jul 2019  | PK       | Original

  Theory of Operation
  ===================
  The Data Aggregator will pull data from all configured peripherals periodically
  and place the gathered data into the fifo software unit.

  */

// Define to prevent recursive inclusion -------------------------------------
#ifndef __DATA_AGG_SU_H
#define __DATA_AGG_SU_H

#include <stdbool.h>
#include <stdint.h>

#include "../ConfigSu/Config.h"
#include "../GpioSu/gpio.h"
#include "../StatusSu/Status.h"

// Exported macro ------------------------------------------------------------
#define CONNECTOR_MAX_DATA_LEN          4 // bytes (dual pressure + temperature -> 4 floats)

// Exported types ------------------------------------------------------------
typedef struct {
    extSensorTypes_t sensorTypes[NUM_CONNECTORS];
} connectorSettings_t;

typedef struct {
	bool enabled;
} lpAccSettings_t;

typedef struct {
    bool enabled;
    bool accelEnabled;
    bool gyroEnabled;
    bool magEnabled;
    bool quatEnabled;
    bool eulerEnabled;
} imuSettings_t;

typedef struct {
	bool enabled;
    bool vBattEnabled;
    bool tempEnabled;
    connectorSettings_t connectorSettings;
} adcSettings_t;

typedef union {
    uint8_t uint8[4];
    uint16_t uint16[2];
    uint32_t uint32;
    
    int8_t int8[4];
    int16_t int16[2];
    int32_t int32;
    
    float float32;
} memBlock32_t;

typedef struct {
    memBlock32_t data[CONNECTOR_MAX_DATA_LEN];
} connectorDataHandler_t;

typedef enum {
	aggIoctlResetAggDataRdy,

	NUM_AGG_IOCTL
} aggIoctl_t;
// Exported constants --------------------------------------------------------

// Exported objects ----------------------------------------------------------

// Exported functions --------------------------------------------------------

/// @brief Initialize all digital peripherals
/// @return StatusOk, StatusAlreadyInitialized
status_t DataAggregator_Init(void);

/// @brief Turn on everything needed for study data aggregation
status_t DataAggregator_On(bool usbSerial);

/// @brief Turn off everything needed for study data aggregation
status_t DataAggregator_Off(void);

/// @brief Read all data required by the config file and place into fifo buffer
status_t DataAggregator_ReadData(void);

/// @brief Prints header information for enabled sensors to bufferOut
status_t DataAggregator_PrintHeader(uint8_t * bufferOut, uint16_t bufferLen);

/// @brief Initiates data aggregation if pending (i.e. still busy at last timer interrupt)
status_t DataAggregator_Tick(void);

// TODO: Add on/off functions for data aggregator and all children (ADC, IMU, peripheral sensors)


#endif // __DATA_AGG_SU_H

/// SAEC Kinetic Vision, Inc. ----------- END OF FILE






