/**
  @file       ProtocolHal.h

  @copyright  (C) 2020 Kinetic Vision, Cincinnati Ohio.
               This software is property of SAEC Kinetic Vision, Inc
               and is considered confidential.

  @brief      ProtocolHal software unit "H" file.

  @author     Andrew Loebs

  @defgroup   ProtocolHalSoftwareUnit Abstracts interaction with I2C/GPIO pin in Resbit/Bluebits coms

  Configuration History
  =====================

  Config Item    | Value
  -------------- | -----
  Config #       | NA
  Revision       | NA
  Revised, Date  | NA
  QA, Date       | NA
  Approved, Date | NA
  Released, Date | NA

  Significant Modification History (Most recent at top)
  =====================================================

  Date         | Initials | Details
  ------------ | -------- | -------
  10 Feb 2020  | ASL      | Original

  Theory of Operation
  ===================
  Abstracts interaction with I2C/GPIO pin in Resbit/Bluebits coms

  */

// Define to prevent recursive inclusion -------------------------------------
#ifndef __PROTOCOL_HAL_H
#define __PROTOCOL_HAL_H

#include <stdbool.h> // bool
#include <stdint.h> // int types
#include <stdio.h> // size_t

#include "../StatusSu/Status.h" // status_t
#include "../PacketSu/Packet.h" // packet_t, response_t


// Exported macro ------------------------------------------------------------

// Exported types ------------------------------------------------------------

// Exported constants --------------------------------------------------------

// Exported objects ----------------------------------------------------------

// Exported functions --------------------------------------------------------

///  @brief Initializes the ProtocolHal software unit
///  @param args[in] onStartup - should only be true on first init call
///  @return StatusOk, StatusAlreadyInitialized.
status_t ProtocolHal_Init(bool onStartup);

///  @brief Uninitializes the ProtocolHal software unit
///  @return StatusOk
status_t ProtocolHal_DeInit(void);

///  @brief Foreground tick method
///  @return StatusOk
status_t ProtocolHal_Tick(void);

///  @brief Returns true if packet has been received
bool ProtocolHal_HasPacket(void);

///  @brief Copies packet to specified memory location
///  @param args[out] out - memory address to copy packet to
///  @param args[out] outLen - number of bytes copied
///  @return StatusOk, StatusNullParameter
status_t ProtocolHal_GetPacket(packet_t * out, size_t * outLen);

///  @brief Returns true if response has been received
bool ProtocolHal_HasResponse(void);

///  @brief Copies response to specified memory location
///  @param args[out] out - memory address to copy response to
///  @return StatusOk, StatusNullParameter
status_t ProtocolHal_GetResponse(response_t * out);

///  @brief Returns true if previous write has finished and/or no write is pending
bool ProtocolHal_IsWriteDone(void);

///  @brief Qeues packet write
///  @param args[in] packet - pointer to packet to write data from
///  @return StatusOk, StatusNullParameter
status_t ProtocolHal_WritePacket(packet_t * packet);

///  @brief Qeues response write
///  @param args[in] packet - pointer to packet to write data from
///  @return StatusOk, StatusNullParameter
status_t ProtocolHal_WriteResponse(response_t * response);

///  @brief Resets state, clears buffers, gpios
void ProtocolHal_Reset(void);

#endif // __PROTOCOL_HAL_H

/// SAEC Kinetic Vision, Inc. ----------- END OF FILE
