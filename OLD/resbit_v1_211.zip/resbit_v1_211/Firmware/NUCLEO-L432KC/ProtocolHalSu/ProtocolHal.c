/**
  @file       ProtocolHal.c

  @copyright  (C) 2020 Kinetic Vision, Cincinnati Ohio.
               This software is property of SAEC Kinetic Vision, Inc
               and is considered confidential.

  @brief      ProtocolHal software unit "C" file.

  @author     Andrew Loebs

  @ingroup    ProtocolHalSoftwareUnit

  Configuration History
  =====================

  Config Item    | Value
  -------------- | -----
  Config #       | NA
  Revision       | NA
  Revised, Date  | NA
  QA, Date       | NA
  Approved, Date | NA
  Released, Date | NA

  Significant Modification History (Most recent at top)
  =====================================================

  Date         | Initials | Details
  ------------ | -------- | -------
  10 Feb 2020  | ASL      | Original

  Theory of Operation
  ===================
  Abstracts interaction with I2C/GPIO pin in Resbit/Bluebits coms

*/

// Includes ------------------------------------------------------------------

#include "ProtocolHal.h"

#include <string.h> // memcpy

#include "stm32l4xx_hal.h" // HAL_* functions

#include "../SwUnitControlSu/SwUnitControl.h" // SwUnitControl_WriteStatus()
#include "../I2cSu/i2c.h" // I2C_* functions
#include "../ConfigSu/Config.h" // Config_Ioctl()
#include "../BlueBitsSu/BlueBits.h" // BlueBits_IsEnabled()
#include "../SysTimeSu/SysTime.h"

// Private function prototypes -----------------------------------------------
static status_t gpioPinInit(void);
static void gpioPinSet(void);
static void gpioPinClear(void);
static status_t indicationPinInit(void);
static bool indicationPinStatus(void);
static status_t i2cWrite(uint8_t * buffer, size_t len);
static status_t i2cRead(uint8_t * buffer, size_t len);
static void writeCallback(status_t status);
static void readCallback(status_t status);

// Private macros ------------------------------------------------------------
#define returnStatus(__status__,__source__) SwUnitControl_WriteStatus(eSucProtocolHalSu,__source__,__status__,__LINE__);

// Private constants ---------------------------------------------------------
#define COMS_I2C_ADDRESS        0x08 << 1
#define NUM_CONNECTORS			3

#define GPIO_PIN_SET_DELAY		5 // ms

// Private types -------------------------------------------------------------
typedef enum {
	transferStateIdle = 0,
	transferStateInProgress,
	transferStateDone,
} transferState_t;

typedef struct {
	configIoctl_t getConnectorSetting;
	GPIO_TypeDef *gpioPort;
	uint16_t gpioPin;
	GPIO_TypeDef *indicationPort;
	uint16_t indicationPin;
} connectorPinSettings_t;

// Private constants ---------------------------------------------------------

// Private variables ---------------------------------------------------------
static bool initialized = false;
static transferState_t writeState = transferStateIdle;
static transferState_t readState = transferStateIdle;
static bool packetPending = false;
static bool responsePending = false;
static bool gpioState = false;

static i2cHandle_t i2cHandle;
static volatile overlapped_t i2cOverlapped;

static packet_t rxPacket;
static response_t rxResponse;

static bool hasPacket = false;
static bool hasResponse = false;

static int connectorIndex;
static const connectorPinSettings_t connectorPinSettings[NUM_CONNECTORS] = {
		{ configIoctlGetJ1, GPIOB, GPIO_PIN_1, GPIOA, GPIO_PIN_0 },
		{ configIoctlGetJ2, GPIOB, GPIO_PIN_1, GPIOA, GPIO_PIN_1 },
		{ configIoctlGetJ4, GPIOB, GPIO_PIN_0, GPIOA, GPIO_PIN_5 },
};

// Private function bodies ---------------------------------------------------
static status_t findConnectorIndex() 
{
	status_t status = StatusOk;

	connectorIndex = 0;
	bool found = false;
	while ((connectorIndex < NUM_CONNECTORS) && !found) {
		extSensorTypes_t jConnectorSetting;
		Config_Ioctl(connectorPinSettings[connectorIndex].getConnectorSetting,
				&jConnectorSetting);
		if (sensorBluebit == jConnectorSetting) {
			found = true;
		} else {
			connectorIndex++;
		}
	}

	if (!found) {
		status = StatusCodePath; // bluebit should have been present before this was called
	}

	return status;
}

static status_t gpioPinInit(void)
{
	status_t status = StatusOk;

	GPIO_InitTypeDef gpioInitStruct = {
		.Pin = connectorPinSettings[connectorIndex].gpioPin,
		.Mode = GPIO_MODE_OUTPUT_PP,
		.Pull = GPIO_NOPULL,
	};
	HAL_GPIO_Init(connectorPinSettings[connectorIndex].gpioPort, 
			&gpioInitStruct);

	return status;
}

static void gpioPinSet(void)
{
	HAL_GPIO_WritePin(connectorPinSettings[connectorIndex].gpioPort, 
			connectorPinSettings[connectorIndex].gpioPin, 
			GPIO_PIN_SET);
	
	// delay
	uint32_t start = SysTime_GetMs();
	while (!SysTime_IsElapsed(start, GPIO_PIN_SET_DELAY));
}

static void gpioPinClear(void)
{
	HAL_GPIO_WritePin(connectorPinSettings[connectorIndex].gpioPort, 
			connectorPinSettings[connectorIndex].gpioPin, 
			GPIO_PIN_RESET);
}

static status_t indicationPinInit(void)
{
	status_t status = StatusOk;

	GPIO_InitTypeDef gpioInitStruct = {
		.Pin = connectorPinSettings[connectorIndex].indicationPin,
		.Mode = GPIO_MODE_INPUT,
		.Pull = GPIO_NOPULL,
		.Speed = GPIO_SPEED_FREQ_LOW,
	};
	HAL_GPIO_Init(connectorPinSettings[connectorIndex].indicationPort, 
			&gpioInitStruct);

	return status;
}

static bool indicationPinStatus(void)
{
	return (bool)HAL_GPIO_ReadPin(
			connectorPinSettings[connectorIndex].indicationPort, 
			connectorPinSettings[connectorIndex].indicationPin);
}

static status_t i2cWrite(uint8_t * buffer, size_t len)
{
	status_t status = StatusOk;

	i2cOverlapped.callback = writeCallback;
	i2cOverlapped.timeout = COMS_TIMEOUT_MS;
	i2cOverlapped.outBuffer = buffer;
	i2cOverlapped.outBufferSize = len;

	status = (I2C_WriteAsync(i2cHandle, &i2cOverlapped));
	if (Status_IsOk(status))
		writeState = transferStateInProgress;

	return status;
}

static status_t i2cRead(uint8_t * buffer, size_t len)
{
	status_t status = StatusOk;

	i2cOverlapped.callback = readCallback;
	i2cOverlapped.timeout = COMS_TIMEOUT_MS;
	i2cOverlapped.inBuffer = buffer;
	i2cOverlapped.inBufferSize = len;

	status = (I2C_ReadAsync(i2cHandle, &i2cOverlapped));
	if (Status_IsOk(status))
		readState = transferStateInProgress;

	return status;
}

static void writeCallback(status_t status)
{
	// TODO: Handle errors
	writeState = transferStateDone;
}

static void readCallback(status_t status)
{
	// TODO: Handle errors
	readState = transferStateDone;
}

// Public functions bodies ---------------------------------------------------
status_t ProtocolHal_Init(bool onStartup)
{
    status_t status = StatusOk;

    if (initialized)
        status = StatusAlreadyInitialized;

    if (BlueBits_IsEnabled()) {
    	if (onStartup) {
			status = findConnectorIndex();
			if (Status_IsOk(status)) {
				status = gpioPinInit();
			}
			if (Status_IsOk(status)) {
				status = indicationPinInit();
			}
    	}
		if (Status_IsOk(status)) {
			gpioPinSet(); // enable BlueBits i2c pull ups
			if (onStartup) {
				status = I2C_CreateHandle(&i2cHandle, COMS_I2C_ADDRESS);
			}
		}

		if (Status_IsOk(status)) {
			initialized = true;
			writeState = transferStateIdle;
			readState = transferStateIdle;
			packetPending = false;
			responsePending = false;
			gpioState = indicationPinStatus();
			hasPacket = false;
			hasResponse = false;
		}
    }

    return returnStatus(status, eSucInitStatus);
}

status_t ProtocolHal_DeInit(void)
{
	status_t status = StatusOk;
	
	if (BlueBits_IsEnabled() && initialized) {
		gpioPinClear();
		initialized = false;
	}
	
	return status;
}

status_t ProtocolHal_Tick(void)
{
    status_t status = StatusOk;

    if (initialized) {
		if (transferStateDone == readState) {
			if (packetPending) {
				// Read body
				uint8_t * readAddress = rxPacket.bytes + PACKET_HEADER_LEN;
				status = i2cRead(readAddress, rxPacket.dataLen);
				packetPending = false; // read still in progress, when done we'll bump down to last else clause
			} else if (responsePending) {
				responsePending = false;
				hasResponse = true;
				readState = transferStateIdle;
			} else {
				hasPacket = true;
				readState = transferStateIdle;
			}
        } else if (gpioState != indicationPinStatus()) {
            gpioState = !gpioState; // toggle state
            // Detect rising edge
            if (false != gpioState) {
                if (responsePending) {
                    // Read response
                	status = i2cRead(rxResponse.bytes, RESPONSE_LEN);
                } else {
                    // Read packet header
                	status = i2cRead(rxPacket.bytes, PACKET_HEADER_LEN);
                    packetPending = true;
                }
            }
        }
    }

    return returnStatus(status, eSucIoctlStatus);
}

bool ProtocolHal_HasPacket(void)
{
    return hasPacket;
}

status_t ProtocolHal_GetPacket(packet_t * out, size_t * outLen)
{
    status_t status = StatusOk;

    // Input validation
    if (out == NULL)
        status = StatusNullParameter;

    if (Status_IsOk(status)) {
        *outLen = PACKET_HEADER_LEN + rxPacket.dataLen;
        memcpy(out->bytes, rxPacket.bytes, *outLen);
        hasPacket = false;
    }

    return returnStatus(status, eSucReadStatus);
}

bool ProtocolHal_HasResponse(void)
{
    return hasResponse;
}

status_t ProtocolHal_GetResponse(response_t * out)
{
    status_t status = StatusOk;

    // Input validation
    if (out == NULL)
        status = StatusNullParameter;

    if (Status_IsOk(status)) {
        memcpy(out->bytes, rxResponse.bytes, RESPONSE_LEN);
        hasResponse = false;
    }

    return returnStatus(status, eSucReadStatus);
}

bool ProtocolHal_IsWriteDone(void)
{
    return writeState == transferStateDone;
}

status_t ProtocolHal_WritePacket(packet_t * packet)
{
    status_t status = StatusOk;

    size_t len = PACKET_HEADER_LEN + packet->dataLen;
    status = i2cWrite(packet->bytes, len);

    if (Status_IsOk(status)) {
        responsePending = true;
    }

    return returnStatus(status, eSucWriteStatus);
}

status_t ProtocolHal_WriteResponse(response_t * response)
{
    status_t status = i2cWrite(response->bytes, RESPONSE_LEN);

    return returnStatus(status, eSucWriteStatus);
}

void ProtocolHal_Reset(void)
{
    // Reset internal state
    writeState = transferStateIdle;
    readState = transferStateIdle;
    packetPending = false;
    responsePending = false;
    gpioState = indicationPinStatus();
    hasPacket = false;
    hasResponse = false;
}

/// SAEC Kinetic Vision, Inc. ----------- END OF FILE
