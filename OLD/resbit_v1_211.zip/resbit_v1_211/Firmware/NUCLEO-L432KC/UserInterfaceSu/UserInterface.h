/**
  @file       UserInterface.h

  @copyright  (C) 2019 Kinetic Vision, Cincinnati Ohio.
               This software is property of SAEC Kinetic Vision, Inc
               and is considered confidential.

  @brief      User Interface software unit "H" file.

  @author     Parker Kamer

  @defgroup   UserInterfaceSu User interface handling

  Configuration History
  =====================

  Config Item    | Value
  -------------- | -----
  Config #       | NA
  Revision       | NA
  Revised, Date  | NA
  QA, Date       | NA
  Approved, Date | NA
  Released, Date | NA

  Significant Modification History (Most recent at top)
  =====================================================

  Date         | Initials | Details
  ------------ | -------- | -------
  14 Aug 2019  | PK       | Original

  Theory of Operation
  ===================
  This software unit will handle all user interface events, including
  button event handling and the led status display.

  */

// Define to prevent recursive inclusion -------------------------------------
#ifndef __TEMPLATE_H
#define __TEMPLATE_H

#include "../StatusSu/Status.h"

// Exported macro ------------------------------------------------------------

// Exported types ------------------------------------------------------------
typedef enum{
	ledPatternStudyReady = 0,		//Green - 2 blink
	ledPatternStudyActive,			//Green - 1 blink
	ledPatternStudyEnd,				//Green - 5 blink
	ledPatternMissingFile,			//Red - 1 blink
	ledPatternConfigFile,			//Red - 2 blink
	ledPatternDeviceStatus,			//Red - 3 blink
	
	ledPatternDeepSleep,			//Red/Green/Red/Green/Red
	ledPatternWakeup,				//Green - 1 flicker
	ledPatternSleep,				//Red - 1 flicker
	ledPatternProtect,				//Red & Green - 1 flicker
	
	ledPatternCreateCsv,			//Red & Green - 1 blink
	ledPatternTruncateCsv,			//Red & Green/Green/Red & Green
	ledPatternCalibrateStep,		//Green - 1 long blink
	
	NUM_LED_PATTERNS
} ledPattern_t;

// Exported constants --------------------------------------------------------

// Exported objects ----------------------------------------------------------

// Exported functions --------------------------------------------------------

/// @brief Initialize the user interface software unit
/// @note  This should be the final software unit that is initialized. If there
/// 	   are no errors to report, this software unit will begin a study.
/// @return StatusOk, StatusAlreadyInitialized
status_t UserInterface_Init(void);

/// @brief Handles LED and Button states
/// @return StatusOk
status_t UserInterface_Tick(void);

/// @brief Blocking function for blinking an LED pattern
status_t UserInterface_BlinkLed(ledPattern_t pattern);

/// @brief Async function for blinking an LED pattern -- blinks are updated in tick() loop
status_t UserInterface_BlinkLedAsync(ledPattern_t pattern);

/// @brief Waits for button press -- used in calibration procedure
void UserInterface_WaitForButton(void);

/// @brief Turns off LED
void UserInterface_ForceLedOff(void);

#endif // __TEMPLATE_H

/// SAEC Kinetic Vision, Inc. ----------- END OF FILE


