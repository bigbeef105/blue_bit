/**
  @file       UserInterface.c

  @copyright  (C) 2019 Kinetic Vision, Cincinnati Ohio.
               This software is property of SAEC Kinetic Vision, Inc
               and is considered confidential.

  @brief      User Interface software unit "C" file.

  @author     Parker Kamer

  @ingroup    UserInterfaceSu

  Configuration History
  =====================

  Config Item    | Value
  -------------- | -----
  Config #       | NA
  Revision       | NA
  Revised, Date  | NA
  QA, Date       | NA
  Approved, Date | NA
  Released, Date | NA

  Significant Modification History (Most recent at top)
  =====================================================

  Date         | Initials | Details
  ------------ | -------- | -------
  14 Aug 2019  | PK       | Original

  Theory of Operation
  ===================
  This software unit will handle all user interface events, including
  button event handling and the led status display.

*/

// Includes ------------------------------------------------------------------

#include "UserInterface.h"

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

#include "../GpioSu/gpio.h"
#include "../ConfigSu/Config.h"
#include "../UsartSu/usart.h"
#include "../ConsoleSu/Console.h"
#include "../SysTimeSu/SysTime.h"
#include "../SwUnitControlSu/SwUnitControl.h"
#include "../SysStateSu/SysState.h"


// Private macros ------------------------------------------------------------
/// This macro feeds status information for tracking purposes to software unit control.
#define returnStatus(__status__,__source__) SwUnitControl_WriteStatus(eSucUserInterfaceSu,__source__,__status__,__LINE__);

#define BUTTON_SHORT_PRESS_MIN_DUR			50 // ms
#define BUTTON_LONG_PRESS_MIN_DUR			1200 // ms

// Private types -------------------------------------------------------------
typedef struct {
	GPIO_PinState red;
	GPIO_PinState green;
	uint16_t holdTime; // ms
} ledBlinkStep_t;

// Private constants ---------------------------------------------------------
static const ledBlinkStep_t ledStudyReady[] = {
		{ GPIO_PIN_RESET, GPIO_PIN_SET, 500 },
		{ GPIO_PIN_RESET, GPIO_PIN_RESET, 500 },
		{ GPIO_PIN_RESET, GPIO_PIN_SET, 500 },
		{ 0 }, // must be zero-terminated
};
static const ledBlinkStep_t ledStudyActive[] = {
		{ GPIO_PIN_RESET, GPIO_PIN_SET, 500 },
		{ 0 }, // must be zero-terminated
};
static const ledBlinkStep_t ledStudyEnd[] = {
		{ GPIO_PIN_RESET, GPIO_PIN_SET, 500 },
		{ GPIO_PIN_RESET, GPIO_PIN_RESET, 500 },
		{ GPIO_PIN_RESET, GPIO_PIN_SET, 500 },
		{ GPIO_PIN_RESET, GPIO_PIN_RESET, 500 },
		{ GPIO_PIN_RESET, GPIO_PIN_SET, 500 },
		{ GPIO_PIN_RESET, GPIO_PIN_RESET, 500 },
		{ GPIO_PIN_RESET, GPIO_PIN_SET, 500 },
		{ GPIO_PIN_RESET, GPIO_PIN_RESET, 500 },
		{ GPIO_PIN_RESET, GPIO_PIN_SET, 500 },
		{ 0 }, // must be zero-terminated
};
static const ledBlinkStep_t ledMissingFile[] = {
		{ GPIO_PIN_SET, GPIO_PIN_RESET, 500 },
		{ 0 }, // must be zero-terminated
};
static const ledBlinkStep_t ledConfigFile[] = {
		{ GPIO_PIN_SET, GPIO_PIN_RESET, 500 },
		{ GPIO_PIN_RESET, GPIO_PIN_RESET, 500 },
		{ GPIO_PIN_SET, GPIO_PIN_RESET, 500 },
		{ 0 }, // must be zero-terminated
};
static const ledBlinkStep_t ledDeviceStatus[] = {
		{ GPIO_PIN_SET, GPIO_PIN_RESET, 500 },
		{ GPIO_PIN_RESET, GPIO_PIN_RESET, 500 },
		{ GPIO_PIN_SET, GPIO_PIN_RESET, 500 },
		{ GPIO_PIN_RESET, GPIO_PIN_RESET, 500 },
		{ GPIO_PIN_SET, GPIO_PIN_RESET, 500 },
		{ 0 }, // must be zero-terminated
};
static const ledBlinkStep_t ledDeepSleep[] = {
		{ GPIO_PIN_SET, GPIO_PIN_RESET, 250 },
		{ GPIO_PIN_RESET, GPIO_PIN_SET, 250 },
		{ GPIO_PIN_SET, GPIO_PIN_RESET, 250 },
		{ GPIO_PIN_RESET, GPIO_PIN_SET, 250 },
		{ GPIO_PIN_SET, GPIO_PIN_RESET, 250 },
		{ 0 }, // must be zero-terminated
};
static const ledBlinkStep_t ledWakeup[] = {
		{ GPIO_PIN_RESET, GPIO_PIN_SET, 10 },
		{ 0 }, // must be zero-terminated
};
static const ledBlinkStep_t ledSleep[] = {
		{ GPIO_PIN_SET, GPIO_PIN_RESET, 10 },
		{ 0 }, // must be zero-terminated
};
static const ledBlinkStep_t ledProtect[] = {
		{ GPIO_PIN_SET, GPIO_PIN_SET, 10 },
		{ 0 }, // must be zero-terminated
};
static const ledBlinkStep_t ledCreateCsv[] = {
		{ GPIO_PIN_SET, GPIO_PIN_SET, 500 },
		{ 0 }, // must be zero-terminated
};
static const ledBlinkStep_t ledTruncateCsv[] = {
		{ GPIO_PIN_SET, GPIO_PIN_SET, 200 },
		{ GPIO_PIN_RESET, GPIO_PIN_SET, 100 },
		{ GPIO_PIN_SET, GPIO_PIN_SET, 200 },
		{ 0 }, // must be zero-terminated
};
static const ledBlinkStep_t ledCalibrateStep[] = {
		{ GPIO_PIN_RESET, GPIO_PIN_SET, 2500 },
		{ 0 }, // must be zero-terminated
};

static const ledBlinkStep_t * const ledBlinkSteps[NUM_LED_PATTERNS] = {
		[ledPatternStudyReady] = ledStudyReady,
		[ledPatternStudyActive] = ledStudyActive,
		[ledPatternStudyEnd] = ledStudyEnd,
		[ledPatternMissingFile] = ledMissingFile,
		[ledPatternConfigFile] = ledConfigFile,
		[ledPatternDeviceStatus] = ledDeviceStatus,
		[ledPatternDeepSleep] = ledDeepSleep,
		[ledPatternWakeup] = ledWakeup,
		[ledPatternSleep] = ledSleep,
		[ledPatternProtect] = ledProtect,
		[ledPatternCreateCsv] = ledCreateCsv,
		[ledPatternTruncateCsv] = ledTruncateCsv,
		[ledPatternCalibrateStep] = ledCalibrateStep,
};

// Private function prototypes -----------------------------------------------
static void ledOutput(GPIO_PinState red, GPIO_PinState green);
static bool getButtonState(void);

static void updateLed(void);
static void handleButton(void);

// Private variables ---------------------------------------------------------
static bool initialized = false;
static bool ledEnabled = false;

static bool buttonState = true; // button is active low
static uint32_t buttonDownStart = 0;
static bool buttonPressReported = false;

static const ledBlinkStep_t * currentSteps = NULL;
static uint16_t stepIndex = 0;
static uint32_t stepStartTime = 0;

// Private function bodies ---------------------------------------------------
static void ledOutput(GPIO_PinState red, GPIO_PinState green)
{
	HAL_GPIO_WritePin(LED_RED_GPIO_Port, LED_RED_Pin, red);
	HAL_GPIO_WritePin(LED_GREEN_GPIO_Port, LED_GREEN_Pin, green);
}

static bool getButtonState(void)
{
	if (HAL_GPIO_ReadPin(BUTTON_INT_GPIO_Port, BUTTON_INT_Pin) == GPIO_PIN_SET) {
		return true;
	} else {
		return false;
	}
}

static void updateLed(void)
{
	if (ledEnabled && currentSteps) {
		// check timeout
		if (SysTime_IsElapsed(stepStartTime, currentSteps[stepIndex].holdTime)) {
			stepIndex++;
			
			// Check for done
			if (currentSteps[stepIndex].holdTime == 0) {
				currentSteps = NULL;
				ledOutput(GPIO_PIN_RESET, GPIO_PIN_RESET);
			} else {
				// Go to next step
				stepStartTime = SysTime_GetMs();
				ledOutput(currentSteps[stepIndex].red, currentSteps[stepIndex].green);
			}
		}
	}
}

static void handleButton(void)
{
	bool newButtonState = getButtonState();
	
	// Detect edges
	if (newButtonState != buttonState) {
		// Button was pressed
		if (!newButtonState) {
			buttonDownStart = SysTime_GetMs();
			buttonPressReported = false;
		} else {
			// Button was released
			if (!buttonPressReported) {
				if (SysTime_IsElapsed(buttonDownStart, BUTTON_LONG_PRESS_MIN_DUR)) {
					// Report long press
					SysState_NotifyLongButtonPress();
					buttonPressReported = true;
				} else if (SysTime_IsElapsed(buttonDownStart, BUTTON_SHORT_PRESS_MIN_DUR)) {
					// Report current status
					UserInterface_BlinkLedAsync(SysState_GetCurrentStateBlinkPattern());
					buttonPressReported = true;
				}
			}
		}
	} else {
		// If button has been down longer than long press -- report
		if (!newButtonState && SysTime_IsElapsed(buttonDownStart, BUTTON_LONG_PRESS_MIN_DUR)) {
			// Report long press
			if (!buttonPressReported) {
				SysState_NotifyLongButtonPress();
				buttonPressReported = true;
			}
		}
	}
	
	buttonState = newButtonState;
}

// Public functions bodies ---------------------------------------------------
status_t UserInterface_Init(void)
{
	status_t status = StatusOk;

	if (initialized) {
		status = StatusAlreadyInitialized;
	}
	
	if (StatusOk == status) {
		// Get initial button state
		buttonState = getButtonState();
		if (!buttonState) {
			buttonDownStart = SysTime_GetMs();
		}
		// Get uart/led enabled/disabled
		configEnableState_t configDebugLed = settingDisable;
		configEnableState_t configDebugUart = settingDisable;
		
		status = Config_Ioctl(configIoctlGetLed, &configDebugLed);
		if (StatusOk == status) {
			status = Config_Ioctl(configIoctlGetUart, &configDebugUart);
		}
		
		if (StatusOk == status) {
			if (settingDisable == configDebugUart) {
				// Turn off UART & console -- We don't care about storing these statuses
				Usart_DeInit();
				Console_Enable(false);
				
				// Setup LED pins only if UART is disabled and LED is enabled..
				if (settingEnable == configDebugLed) {
					  GPIO_InitTypeDef GPIO_InitStruct = {0};
					  GPIO_InitStruct.Pin = LED_RED_Pin;
					  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
					  GPIO_InitStruct.Pull = GPIO_NOPULL;
					  HAL_GPIO_Init(LED_RED_GPIO_Port, &GPIO_InitStruct);
					  HAL_GPIO_WritePin(LED_RED_GPIO_Port, LED_RED_Pin, GPIO_PIN_RESET);
					
					  GPIO_InitStruct.Pin = LED_GREEN_Pin;
					  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
					  GPIO_InitStruct.Pull = GPIO_NOPULL;
					  HAL_GPIO_Init(LED_GREEN_GPIO_Port, &GPIO_InitStruct);
					  HAL_GPIO_WritePin(LED_GREEN_GPIO_Port, LED_GREEN_Pin, GPIO_PIN_RESET);
					  
					  ledEnabled = true;
				}
			}
		}
	}
	
	if (StatusOk == status) {
		initialized = true;
	}

	return returnStatus(status, eSucInitStatus);
}

status_t UserInterface_Tick(void){
	status_t status = StatusOk;

	updateLed();
	handleButton();

	return returnStatus(status, eSucIoctlStatus);
}

status_t UserInterface_BlinkLed(ledPattern_t pattern)
{
	status_t status = StatusOk;
	
	if (ledEnabled && !currentSteps) {
		// Blink the specified pattern
		const ledBlinkStep_t * steps = ledBlinkSteps[pattern];
		for (int i = 0; steps[i].holdTime != 0; i++) {
			uint32_t startTime = SysTime_GetMs();
			ledOutput(steps[i].red, steps[i].green);
			
			// Wait for delay
			while (!SysTime_IsElapsed(startTime, steps[i].holdTime));
		}
		
		// Turn LED off
		ledOutput(GPIO_PIN_RESET, GPIO_PIN_RESET);
	}
	
	return returnStatus(status, eSucIoctlStatus);
}

status_t UserInterface_BlinkLedAsync(ledPattern_t pattern)
{
	status_t status = StatusOk;
	
	if (ledEnabled && !currentSteps) {
		currentSteps = ledBlinkSteps[pattern];
		stepIndex = 0;
		stepStartTime = SysTime_GetMs();
		
		ledOutput(currentSteps[stepIndex].red, currentSteps[stepIndex].green);
	}
	
	return returnStatus(status, eSucIoctlStatus);
}

void UserInterface_WaitForButton(void)
{
	// Active low -- wait for press down
	while (getButtonState());
	// Wait for release
	while (!getButtonState());
}

void UserInterface_ForceLedOff(void)
{
	currentSteps = NULL; // cancel any async blink operations
	ledOutput(GPIO_PIN_RESET, GPIO_PIN_RESET);
}

/// SAEC Kinetic Vision, Inc. ----------- END OF FILE
