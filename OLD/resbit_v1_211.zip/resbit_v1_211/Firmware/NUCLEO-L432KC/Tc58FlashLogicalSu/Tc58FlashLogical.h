/**
  @file       Tc58FlashLogical.h

  @copyright  (C) 2019 Kinetic Vision, Cincinnati Ohio.
               This software is property of SAEC Kinetic Vision, Inc
               and is considered confidential.

  @brief      Tc58FlashLogical software unit "H" file.

  @author     Sherman Couch

  @defgroup   Tc58FlashLogicalName This SU lays between the "CHAN N" file system, and mapped sectors.

  Configuration History
  =====================

  Config Item    | Value
  -------------- | -----
  Config #       | NA
  Revision       | NA
  Revised, Date  | NA
  QA, Date       | NA
  Approved, Date | NA
  Released, Date | NA

  Significant Modification History (Most recent at top)
  =====================================================

  Date         | Initials | Details
  ------------ | -------- | -------
  23 Jul 2019  | SC       | Harmonized with higher level "diskio.[ch]" interfaces.
  23 Jun 2019  | SC       | Original

  Theory of Operation
  ===================
  - File System (FS) operations specify starting with logical sector zero.  Because of
    issues such as bad blocks, or blocks allocated outside the file system, the physical
    sector addressing details are hidden from the FS.
  - Presents the FS caller with a "simple" read/write 512 byte sectors interface.
  - Encapsulates the ugly details of TC58 block operations from the FS.

  */

// Define to prevent recursive inclusion -------------------------------------
#ifndef __TC58_FLASH_LOGICAL_H
#define __TC58_FLASH_LOGICAL_H

// Exported macro ------------------------------------------------------------

// Exported types ------------------------------------------------------------

// Exported constants --------------------------------------------------------

// Exported objects ----------------------------------------------------------

// Exported functions --------------------------------------------------------


///  @brief   Initializes the Tc58FlashLogical software unit
///  @details This function will only return the values shown.
///  @pre     The underlying "TC58" physical flash driver should have already been initialized.
///  @return  StatusOK, all is well, TC58 software and device is initialized
///  @return  StatusDiskNoInit, maps at a higher level to: #define STA_NOINIT 0x01 (Drive not initialized)
///  @return  StatusDiskNoDisk, maps at a higher level to: #define STA_NODISK 0x02 (No medium in the drive)
///  @return  StatusDiskProtect, maps at a higher level to: #define STA_PROTECT 0x04 (Write protected)
status_t Tc58FlashLogical_Init(void);

///  @brief Returns the status of the TC58 flash
///  @details This function will only return the values shown.
///  @return StatusOK, all is well
///  @return StatusDiskNoInit, maps at a higher level to: #define STA_NOINIT 0x01 (Drive not initialized)
///  @return StatusDiskNoDisk, maps at a higher level to: #define STA_NODISK 0x02 (No medium in the drive)
///  @return StatusDiskProtect, maps at a higher level to: #define STA_PROTECT 0x04 (Write protected)
status_t Tc58FlashLogical_ReturnStatus(void);

///  @brief Returns "sectors" read from the TC58 flash part
///  @details This function will only return the values shown.
///  @return StatusOK, all is well, data was read OK
///  @return StatusResultDiskError, maps at a higher level to: DRESULT (type), value: RES_ERROR = 1
///  @return StatusResultWriteProtect, maps at a higher level to: DRESULT (type), value: RES_WRPRT = 2
///  @return StatusResultNotReady, maps at a higher level to: DRESULT (type), value: RES_NOTRDY = 3
///  @return StatusResultInvalidParameter,  maps at a higher level to: DRESULT (type), value: RES_PARERR = 4
status_t Tc58FlashLogical_Read(uint8_t pBuffer[], uint32_t sector, uint32_t sectorCount);

///  @brief Writes "sectors" to the TC58 flash part
///  @details This function will only return the values shown.
///  @return StatusOK, all is well, data was written OK.
///  @return StatusResultDiskError, maps at a higher level to: DRESULT (type), value: RES_ERROR = 1
///  @return StatusResultWriteProtect, maps at a higher level to: DRESULT (type), value: RES_WRPRT = 2
///  @return StatusResultNotReady, maps at a higher level to: DRESULT (type), value: RES_NOTRDY = 3
///  @return StatusResultInvalidParameter,  maps at a higher level to: DRESULT (type), value: RES_PARERR = 4
status_t Tc58FlashLogical_Write(uint8_t pBuffer[], uint32_t sector, uint32_t sectorCount);

#endif // __TC58_FLASH_LOGICAL_H

/// SAEC Kinetic Vision, Inc. ----------- END OF FILE

