/**
  @file       Tc58FlashLogical.c

  @copyright  (C) 2019 Kinetic Vision, Cincinnati Ohio.
               This software is property of SAEC Kinetic Vision, Inc
               and is considered confidential.

  @brief      Tc58FlashLogical software unit "C" file.

  @author     Sherman Couch

  @ingroup    Tc58FlashLogicalName

  Configuration History
  =====================

  Config Item    | Value
  -------------- | -----
  Config #       | NA
  Revision       | NA
  Revised, Date  | NA
  QA, Date       | NA
  Approved, Date | NA
  Released, Date | NA

  Significant Modification History (Most recent at top)
  =====================================================

  Date         | Initials | Details
  ------------ | -------- | -------
  10 Sep 2019  | SC       | Refactor "Remap_" into "Buffer_".
  06 Sep 2019  | SC       | Retooled (again) for 512 byte sectors, bottom layer (remap) now uses recast "remap" addresses.
  20 Aug 2019  | SC       | Bottom of driver no longer interfaces with physical layer, it now interfaces with top of "Tc58Remap_" driver.
  01 Jul 2019  | SC       | This is a new SU which lays on top of the TC58 physical driver.

  Theory of Operation
  ===================
  The logical driver provides interfaces harmonized with the lower remap driver, and
  the excellent high "diskIo" driver written by Chan N (Japan).

  */

// Includes ------------------------------------------------------------------

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

#include "../StatusSu/Status.h"
#include "../Tc58FlashUtilitiesSu/Tc58FlashUtilities.h"
#include "../Tc58FlashPhysicalSu/Tc58FlashPhysical.h"
#include "../SwUnitControlSu/SwUnitControl.h"
#include "../ConsoleSu/Console.h"
#include "Tc58FlashLogical.h"

#include "../Tc58FlashBufferSu/Tc58FlashBuffer.h"

// Private macros ------------------------------------------------------------

// This macro feeds status information for tracking purposes to software unit control.
#define returnStatus(__status__,__source__) SwUnitControl_WriteStatus(eSucTc58FlashLogicalSu,__source__,__status__,__LINE__);


// Private constants ---------------------------------------------------------

// Private types -------------------------------------------------------------

// Private function prototypes -----------------------------------------------

// The logical CLI commands use "sector number" to locate the first sector of their
// operation.  Max sector number for this TC58 driver is 1,027,583 (2007*512 -1).
static status_t cliLogReadCommand(uint16_t argc, uint8_t **argv);
static status_t cliLogWriteCommand(uint16_t argc, uint8_t **argv);
static status_t cliLogTraceCommand(uint16_t argc, uint8_t **argv);

static status_t cliFlashTestCommand(uint16_t argc, uint8_t **argv);

// Private constants ---------------------------------------------------------

static const consoleCommand_t commandList[] = {
    { "lr", "logical read\r\n\t"
    		"usage: lr sectorNum sectorCount", cliLogReadCommand
    },

    { "lw", "logical write\r\n\t"
    		"usage: lw sectorNum sectorCount byteValue", cliLogWriteCommand
    },

    { "lt", "logical trace\r\n\t"
    		"usage: ftrace [0|1]", cliLogTraceCommand
    },

    { "ft", "flash test\r\n\t"
    		"usage: ", cliFlashTestCommand
    },


    { NULL, NULL, NULL
    },
};

// Private variables ---------------------------------------------------------

static bool initialized = false;
static bool lDebugTrace = false;

static consoleRegistration_t exportedReg = {
    (consoleCommand_t *) commandList, // .pList =
    NULL, // .pNext =
};

// Private function bodies ---------------------------------------------------

static uint32_t convertAToUint32(uint8_t *a)
{
	uint32_t n;

	if (NULL == a) {
		return 0l;
	}

	// Number format 0x__?
	if ( (strlen(a) > 2) && ('0' == a[0]) && ('x' == a[1]) ) {
		sscanf(&a[2], "%lx", &n);
	} else {
		n = atoi(a);
	}

	return n;

} // convertAToUint32

static status_t cliLogTraceCommand(uint16_t argc, uint8_t **argv)
{
	status_t status;

	status = StatusOk;

	if (argc > 1) {
		if (*argv[1] == '0') {
			lDebugTrace = false;
		} else if (*argv[1] == '1') {
			lDebugTrace = true;
		} else {
			status = StatusParameter1;
		}
	}
	return status;

} // cliLogTraceCommand

static status_t cliLogReadCommand(uint16_t argc, uint8_t **argv)
{
	// "usage: lr sectorNum sectorCount", cliLogReadCommand
    status_t status;
	uint8_t buff[50];

    status = StatusOk;

    if (!initialized) {
        status = StatusNotInitialized;
    }

    if (StatusOk == status) {
    	if (argc < 3) {
    		status = StatusParameterCount;
    	}
    }

    if (StatusOk == status) {
		uint32_t sectorNum;
		uint32_t sectorCount;
		uint8_t sectorBuffer[TC58_BYTES_PER_SECTOR_512];

		sectorNum = convertAToUint32(argv[1]);
    	sectorCount = convertAToUint32(argv[2]);

    	for ( ;sectorCount; sectorCount--, sectorNum++) {

    		// Attempt to read "sectorNum"
    		status = Tc58FlashLogical_Read (sectorBuffer, sectorNum, 1);
    		sprintf(buff, "\r\n\r\nSector: %lu", sectorNum);
    		Console_WriteString(buff);

    	    // print out sector
    		if (StatusOk == status) {

				for (uint16_t i = 0; i < TC58_BYTES_PER_SECTOR_512; i++) {

					if (0 == (i % 16)) {
						sprintf(buff, "\r\n%03X : ", i);
						Console_WriteString(buff);
					}

					sprintf(buff, "%02x ", sectorBuffer[i]);
					Console_WriteString(buff);
				}
    		} else {
    			sprintf(buff, "Tc58FlashLogical_Read Status: %u", status);
        		Console_WriteString(buff);
    		}
    	}
    }

    return status;

} // cliLogReadCommand

static status_t cliLogWriteCommand(uint16_t argc, uint8_t **argv)
{
	// "usage: lw sectorNum sectorCount startByteValue", cliLogWriteCommand

    status_t status;

    status = StatusOk;

    if (!initialized) {
        status = StatusNotInitialized;
    }

    if (StatusOk == status) {
    	if (argc < 4) {
    		status = StatusParameterCount;
    	}
    }

	uint32_t sectorNum;
	uint16_t sectorCount;
	uint8_t sectorBuffer[TC58_BYTES_PER_SECTOR_512];
	uint8_t byteValue;
    if (StatusOk == status) {

    	sectorNum = convertAToUint32(argv[1]);
    	sectorCount = convertAToUint32(argv[2]);
    	byteValue = convertAToUint32(argv[3]);
    }

    if (StatusOk == status) {
		for (uint16_t i = 0; i < sizeof(sectorBuffer); i++) {
			sectorBuffer[i] = byteValue;
		}

		for (uint16_t i = 0; i < sectorCount; i++) {

			status = Tc58FlashLogical_Write (sectorBuffer, sectorNum+i, 1);
			if (StatusOk != status) {
				break;
			}

			status = Tc58Buffer_SynchronizeStorage ( );
			if (StatusOk != status) {
				break;
			}
		}
    }

    return status;

} // cliLogWriteCommand


static status_t cliFlashTestCommand(uint16_t argc, uint8_t **argv)
{
	// "usage: ft [startSector(0)] [endSector(1027585)] [c(Continue)]"

	status_t status;
	uint32_t startSector;
	uint32_t endSector;
	bool continueOption;

	char sectorBuffOut[TC58_BYTES_PER_SECTOR_512];
	char sectorBuffIn[TC58_BYTES_PER_SECTOR_512];
	char consoleBuff[80];

    status = StatusOk;
    continueOption = false;

    if (!initialized) {
        status = StatusNotInitialized;
    }

    if (StatusOk == status) {
    	if (argc >= 4) {
    		if (*argv[4] != 'c') {
    	    	sprintf(consoleBuff, "Error, expected 'c'\r\n");
    	    	Console_WriteString(consoleBuff);
        		status = StatusParameterValue;
    		} else {
    			continueOption = true;
    		}
    	}
    }

    if (StatusOk == status) {
    	if (argc < 2) {
    		startSector = 0;
    	} else {
        	startSector = convertAToUint32(argv[1]);
    	}

    	if (argc < 3) {
    		endSector = 100;
    	} else {
        	endSector = convertAToUint32(argv[2]);
    	}

    	sprintf(consoleBuff, "Sector range: %lu .. %lu\r\n", startSector, endSector);
    	Console_WriteString(consoleBuff);

    	if (startSector > endSector) {
    		status = StatusParameterValue;
    	}
    }

    // Fill the range of memory with 0xAA
    if (StatusOk == status) {
    	for (uint16_t i = 0; i < sizeof(sectorBuffOut); i++) {
    		sectorBuffOut[i] = 0xAA;
    	}

    	for (uint32_t sector = startSector; sector <= endSector; sector++) {
    		// Print progress
    		sprintf(consoleBuff, "(%lu)", sector);
  			Console_WriteString (consoleBuff);

    		status = Tc58FlashLogical_Write(sectorBuffOut, sector, 1);
    	}
    }

    // Read, verify and re-write with 0x55 (flips all bits)
    if (StatusOk == status) {

    	// Prepare output sector buffer to replace the 55's with AA's
    	for (uint16_t i = 0; i < sizeof(sectorBuffOut); i++) {
    		sectorBuffOut[i] = 0x55;
    	}

    	// For each sector under test, read, check for 0xAA, then if OK, re-write with 0x55
    	for (uint32_t sector = startSector; sector <= endSector; sector++) {

    		// Print progress
    		sprintf(consoleBuff, "<%lu>", sector);
  			Console_WriteString (consoleBuff);

  			status = Tc58FlashLogical_Read(sectorBuffIn, sector, 1);
    	    if (StatusOk != status) {
    	    	break;
    	    }

    		// Check for 0xAA
        	for (uint16_t i = 0; i < sizeof(sectorBuffIn); i++) {
        		if (sectorBuffIn[i] != 0xAA) {

        			sprintf(consoleBuff, "Error, Sector: %lu, Offset: %u, Read: %02X, Expected: 0xAA\r\n", sector, i, sectorBuffIn[i]);
        	    	Console_WriteString(consoleBuff);

        	    	if (!continueOption) {
						status = StatusByteValue;
						break;
        	    	}
        		}
        	}

        	// Stop the test upon first failure?
	    	if (StatusOk != status) {
	    		break;
	    	}

        	// If no error(s)Flip all bits
	    	if (StatusOk == status) {
	    		status = Tc58FlashLogical_Write(sectorBuffOut, sector, 1);
	    	}
    	}
    }

    return status;

} // cliFlashTestCommand

// Public functions bodies ---------------------------------------------------

status_t Tc58FlashLogical_Init(void)
{
    status_t status;
    status = StatusOk;

    if (initialized) {
        status = StatusAlreadyInitialized;
    }

    if (status == StatusOk) {
    	status = Console_ExportCommandsToCli (&exportedReg, commandList);
    }

    if (status == StatusOk) {

     	// Record a successful initialization
    	initialized = true;
    }

    // We care about tracking this status, use macro to feed status to SW Unit control.
    return returnStatus(status, eSucInitStatus);

} // Tc58FlashLogical_Init



status_t Tc58FlashLogical_Read(uint8_t pBuffer[], uint32_t sector, uint32_t sectorCount)
{
	if (lDebugTrace) {
		uint8_t buff[50];
		sprintf(buff, "<r %lu,%lu>", sector, sectorCount);
		Console_WriteString(buff);
	}

	status_t status;

	status = StatusOk;

	if (!initialized) {
	    status = StatusDiskNoInit;
	}

	// validate parameters

	if (StatusOk == status) {
		if (NULL == pBuffer) {
			status = StatusResultInvalidParameter;
		}
	}

	// Convert from sector to a chip address
	Tc58RemapAddress_t a;
	if (StatusOk == status) {
		status = Tc58Util_ConvertAddrSectorsToRemap(sector, &a);
	}

	// Read the data
	if (StatusOk == status) {

		while (sectorCount--) {
			status = Tc58Buffer_ReadOneSector(a, pBuffer);

			if (StatusOk != status) {
				break;
			}

			if (sectorCount) {
				status = Tc58Util_AddSectorsToRemapAddress (&a, 1);
				pBuffer += TC58_BYTES_PER_SECTOR_512;
			}

			if (StatusOk != status) {
				break;
			}
		}
	}


    // We care about tracking this status, use macro to feed status to SW Unit control.
    return returnStatus(status, eSucReadStatus);

} // Tc58FlashLogical_Read

status_t Tc58FlashLogical_ReturnStatus(void)
{
    status_t status;
    status = StatusOk;

    if (!initialized) {
        status = StatusDiskNoInit;
    }

	if (status == StatusOk) {
    	status = Tc58Buffer_ReturnStatus( );
    }

    // We care about tracking this status, use macro to feed status to SW Unit control.
    return returnStatus(status, eSucIoctlStatus);

} // Tc58Logical_ReturnStatus

status_t Tc58FlashLogical_Write(uint8_t pBuffer[], uint32_t sector, uint32_t sectorCount)
{
	if (lDebugTrace) {
		uint8_t buff[50];
		sprintf(buff, "<w %lu,%lu>", sector, sectorCount);
		Console_WriteString(buff);
	}

	status_t status;

	status = StatusOk;

	if (!initialized) {
	    status = StatusDiskNoInit;
	}

	// validate parameters
	if (StatusOk == status) {
		if (NULL == pBuffer) {
			status = StatusResultInvalidParameter;
		}
	}

	// Convert from sector to a remap address
	Tc58RemapAddress_t a;
	if (StatusOk == status) {
		status = Tc58Util_ConvertAddrSectorsToRemap(sector, &a);
	}

	if (StatusOk == status) {

		while (sectorCount--) {
			status = Tc58Buffer_WriteOneSector(a, pBuffer);
			if (StatusOk != status) {
				break;
			}

			if (sectorCount) {
				status = Tc58Util_AddSectorsToRemapAddress (&a, 1);
				pBuffer += TC58_BYTES_PER_SECTOR_512;
			}

			if (StatusOk != status) {
				break;
			}
		}
	}

    // We care about tracking this status, use macro to feed status to SW Unit control.
    return returnStatus(status, eSucWriteStatus);

} // Tc58FlashLogical_Write


/// SAEC Kinetic Vision, Inc  ----------- END OF FILE

