/**
 @file       main.c

 @copyright  (C) 2019 Kinetic Vision, Cincinnati Ohio.
 This software is property of SAEC Kinetic Vision, Inc
 and is considered confidential.

 @brief      main software unit "C" file.
 @author     Sherman Couch
 @ingroup    mainName

 Configuration History
 =====================

 Config Item    | Value
 -------------- | -----
 Config #       | NA
 Revision       | NA
 Revised, Date  | NA
 QA, Date       | NA
 Approved, Date | NA
 Released, Date | NA

 Significant Modification History (Most recent at top)
 =====================================================

 Date         | Initials | Details
 ------------ | -------- | -------
 22 Jul 2019  | SC/PK    | Update using standardized templates/function naming.
 01 Jun 2019  | SC       | Original

 Theory of Operation
 ===================


 */

// Includes ------------------------------------------------------------------
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <math.h>

#include "Status.h"
#include "main.h"
#include "fatfs.h"
#include "usb_device.h"
#include "ff_gen_drv.h"
#include "../SysTimeSu/SysTime.h"
#include "../I2cSu/i2c.h"
#include "../ConsoleSu/console.h"
#include "../SpiSu/spi.h"
#include "../UsartSu/usart.h"
#include "../GpioSu/gpio.h"
#include "../Tc58FlashUtilitiesSu/Tc58FlashUtilities.h"
#include "../Tc58FlashPhysicalSu/Tc58FlashPhysical.h"
#include "../Tc58FlashPhysicalSu/Tc58FlashIoControl.h"
#include "../Tc58BlockSu/Tc58Block.h"
#include "../Tc58FlashLogicalSu/Tc58FlashLogical.h"
#include "../RtcSu/rtc.h"
#include "../ConfigSu/Config.h"
#include "../UsartSu/Usart.h"
#include "../SpiSu/Spi.h"
#include "../GpioSu/Gpio.h"
#include "../DataReceiverSu/DataReceiver.h"
#include "../AdcSu/adc.h"
#include "../Bno055Su/bno055.h"
#include "../TimerSu/timer.h"
#include "../DataAggregatorSu/DataAggregator.h"
#include "../SwUnitControlSu/SwUnitControl.h"
#include "../PowerSu/power.h"
#include "../Tc58FlashBufferSu/Tc58FlashBuffer.h"
#include "../UserInterfaceSu/UserInterface.h"
#include "../Lis2de12Su/lis2de12.h"
#include "../Hx711Su/Hx711.h"
#include "../HallSu/Hall.h"
#include "../MultiplexerSu/Multiplexer.h"
#include "../ProtocolHalSu/ProtocolHal.h"
#include "../ProtocolHandlerSu/ProtocolHandler.h"
#include "../MessagerSu/Messager.h"
#include "../SummaryDataSu/SummaryData.h"
#include "../BlueBitsSu/BlueBits.h"
#include "../DeviceInfoSu/DeviceInfo.h"
#include "../FifoSu/Fifo.h"
#include "../SysStateSu/SysState.h"

// Private macros ------------------------------------------------------------

// Private constants ---------------------------------------------------------
#define INIT_STATUS_SPRINTF_BUFF_LEN        50
#define HARDWARE_QA_LED_BLINK_DURATION		500 // ms
#define HARDWARE_QA_LED_BLINK_COUNT			2
#define HARDWARE_QA_LED_HOLD_DURATION		2000 // ms

// Private types -------------------------------------------------------------

// Private constants ---------------------------------------------------------

// Exported variables ---------------------------------------------------------

// Private variables ---------------------------------------------------------

// Private function prototypes -----------------------------------------------
static status_t utilitiesInit(void);
static status_t flashFsInit(void);
static status_t bluebitsInit(void);
static status_t dataCollectionInit(void);

// Private function bodies ---------------------------------------------------
int main(void)
{
	// Initialize HAL drivers
	HAL_Init();

	// Configure the system clock
	status_t status = Power_Init();
	
#ifdef HARDWARE_QA_BUILD
	// Configure LED's
	__HAL_RCC_GPIOB_CLK_ENABLE();
	GPIO_InitTypeDef GPIO_InitStruct = {0};
	GPIO_InitStruct.Pin = LED_RED_Pin;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	HAL_GPIO_Init(LED_RED_GPIO_Port, &GPIO_InitStruct);
	
	GPIO_InitStruct.Pin = LED_GREEN_Pin;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	HAL_GPIO_Init(LED_GREEN_GPIO_Port, &GPIO_InitStruct);
	
	// Flash LED's based on status
	if (StatusOk == status) {
		// Green blinky
		HAL_GPIO_WritePin(LED_RED_GPIO_Port, LED_RED_Pin, GPIO_PIN_RESET);
		for (int i = 0; i < HARDWARE_QA_LED_BLINK_COUNT; i++) {
			HAL_GPIO_WritePin(LED_GREEN_GPIO_Port, LED_GREEN_Pin, GPIO_PIN_SET);
			HAL_Delay(HARDWARE_QA_LED_BLINK_DURATION);
			HAL_GPIO_WritePin(LED_GREEN_GPIO_Port, LED_GREEN_Pin, GPIO_PIN_RESET);
			HAL_Delay(HARDWARE_QA_LED_BLINK_DURATION);
		}
	} else {
	  // Red blinky
		HAL_GPIO_WritePin(LED_GREEN_GPIO_Port, LED_GREEN_Pin, GPIO_PIN_RESET);
		for (int i = 0; i < HARDWARE_QA_LED_BLINK_COUNT; i++) {
			HAL_GPIO_WritePin(LED_RED_GPIO_Port, LED_RED_Pin, GPIO_PIN_SET);
			HAL_Delay(HARDWARE_QA_LED_BLINK_DURATION);
			HAL_GPIO_WritePin(LED_RED_GPIO_Port, LED_RED_Pin, GPIO_PIN_RESET);
			HAL_Delay(HARDWARE_QA_LED_BLINK_DURATION);
		}
	}
	
	// Erase firmware so that we can use USB-DFU
	HAL_FLASH_Unlock();
    FLASH_EraseInitTypeDef EraseInitStruct = {
            .TypeErase = TYPEERASE_MASSERASE,
            .Banks = FLASH_BANK_BOTH,
    };
    uint32_t SectorError = 0;
    if (HAL_FLASHEx_Erase(&EraseInitStruct, &SectorError) != HAL_OK) {
        while(1);
    }
    HAL_FLASH_Lock();
    
    // If we're here, flash erase didn't work, so just blink red indefinitely
    HAL_GPIO_WritePin(LED_GREEN_GPIO_Port, LED_GREEN_Pin, GPIO_PIN_RESET);
	while (1) {
		HAL_GPIO_WritePin(LED_RED_GPIO_Port, LED_RED_Pin, GPIO_PIN_SET);
		HAL_Delay(HARDWARE_QA_LED_BLINK_DURATION);
		HAL_GPIO_WritePin(LED_RED_GPIO_Port, LED_RED_Pin, GPIO_PIN_RESET);
		HAL_Delay(HARDWARE_QA_LED_BLINK_DURATION);
	}
#endif // HARDWARE_QA_BUILD

	// Configure GPIO, console, stats reporting, device info, sys time
	if (StatusOk == status) {
		status = utilitiesInit();
	}

	// Configure file system and grab config values from config file
	if (StatusOk == status) {
		status = flashFsInit();
	}
	
	// Configure user interface, de-initialize USART if disabled
	if (StatusOk == status) {
		status = UserInterface_Init();
		if (StatusOk != status) {
			char buff[INIT_STATUS_SPRINTF_BUFF_LEN];
			sprintf(buff, "UserInterface_Init() - Status: %d\r\n", status);
			Console_WriteString(buff);
		}
	}

	// Configure bluebits -- this is where we setup I2C, as when bluebits is enabled
	// we need to tell bluebits to enable I2C pullups for I2C to function..
	if (StatusOk == status) {
		status = bluebitsInit();
	}
	
	// Configure the sensors -> CSV file pipeline
	if (StatusOk == status) {
		status = dataCollectionInit();
	}

	// Initialize system state with the start up status
	SysState_Init(status);

	while (1) {	
#ifndef SWO_PROFILE_BUILD // this is a nice way of putting all non-interrupt processes into one bucket
		
		Console_Tick(); // checks for characters in receive buffer
		I2C_Tick(); // checks timeout values for async operations
		DataAggregator_Tick(); // starts read/write if pending
		DataReceive_Tick(); // checks FIFO and writes to CSV if pending
		UserInterface_Tick(); // updates button & led states

		// Handle bluebits messaging
		ProtocolHal_Tick();
		ProtocolHandler_Tick();
		Messager_Tick();

		// Maintain system state
		SysState_HandleState();
		
#endif // SWO_PROFILE_BUILD
	}

	// The execution path should never reach this point.
	return StatusCodePath;
}

// ==============================================================
//  Helper functions
// ==============================================================
static status_t utilitiesInit(void)
{
	// Get pins managed by GPIO Su set up first
	status_t status = GPIO_Init();

	// Get the console (on the UART) going early.
	if (StatusOk == status) {
		status = Usart_Init();
	}
	if (StatusOk == status) {
		status = Console_Init();
	}

	// ******************************************************
	// * Console is now operational (if status == StatusOK) *
	// ******************************************************
	char buff[INIT_STATUS_SPRINTF_BUFF_LEN];
	if (StatusOk == status) {
		status = SwUnitControl_Init();
		if (StatusOk != status) {
			sprintf(buff, "SwUnitControl_Init() - Status: %d\r\n", status);
			Console_WriteString(buff);
		}
	}

	if (StatusOk == status) {
		status = DeviceInfo_Init();
		if (StatusOk != status) {
			sprintf(buff, "DeviceInfo_Init() - Status: %d\r\n", status);
			Console_WriteString(buff);
		}
	}

	if (StatusOk == status) {
		status = SysTime_Init();
		if (StatusOk != status) {
			sprintf(buff, "SysTime_Init() - Status: %d\r\n", status);
			Console_WriteString(buff);
		}
	}
	
	return status;
}

static status_t flashFsInit(void)
{
	status_t status = StatusOk;
	char buff[INIT_STATUS_SPRINTF_BUFF_LEN];

	// Get TC58 up and running
#ifndef SWO_PROFILE_BUILD
	if (StatusOk == status) {
		status = Spi_Init();
		if (StatusOk != status) {
			sprintf(buff, "Spi_Init() - Status: %d\r\n", status);
			Console_WriteString(buff);
		}
	}

	// Note: TC58 Flash Physical init should be the first "TC58" SU init
	if (StatusOk == status) {
		status = Tc58FlashPhysical_Init();
		if (StatusOk != status) {
			sprintf(buff, "Tc58FlashPhysical_Init() - Status: %d\r\n", status);
			Console_WriteString(buff);
		}
	}

	// Note: TC58 block init should precede the flash "buffer" unit SU init
	if (StatusOk == status) {
		status = Tc58Block_Init();
		if (StatusOk != status) {
			sprintf(buff, "Tc58Block_Init() - Status: %d\r\n", status);
			Console_WriteString(buff);
		}
	}

	if (StatusOk == status) {
		status = Tc58Buffer_Init(); // Depends upon physical
		if (StatusOk != status) {
			sprintf(buff, "Tc58Buffer_Init() - Status: %d\r\n", status);
			Console_WriteString(buff);
		}
	}

	// Note: TC58 Flash utility init should precede the "logic " SU init.
	if (StatusOk == status) {
		status = Tc58Util_Init(); // Depends upon remap
		if (StatusOk != status) {
			sprintf(buff, "Tc58Util_Init() - Status: %d\r\n", status);
			Console_WriteString(buff);
		}
	}

	if (StatusOk == status) {
		status = Tc58FlashLogical_Init(); // Depends upon remap
		if (StatusOk != status) {
			sprintf(buff, "Tc58FlashLogical_Init() - Status: %d\r\n", status);
			Console_WriteString(buff);
		}
	}
#endif // SWO_PROFILE_BUILD

	// Initialize FAT file system
	if (StatusOk == status) {
		extern uint8_t retUSER; /* Return value for USER */
		MX_FATFS_Init();

		if (0 != retUSER) {
			status = StatusFileSystemDriver;
			sprintf(buff, "MX_FATFS_Init() - Status: %d, %d\r\n", status,
					retUSER);
			Console_WriteString(buff);
		}
	}
	
	// Is there a need to build the file system?
	if (StatusOk == status) {
		uint32_t mkfsIndication;
		FATFS* USBDISKFatFs = FATFS_GetFileSystem();
		status = Tc58Flash_DoIoControl(Tc58IoctlGetMkfsIndication, &mkfsIndication);

		if (StatusOk == status) {
			// If there is no make file system indication, then mount should succeed.  Test that mount succeeds.
			if (!mkfsIndication) {
				FRESULT res = f_mount(USBDISKFatFs, "", 1);
				// Mount failed?
				if (res != FR_OK) {
					// Set flag to cause a file system make.
			  		mkfsIndication = true;
			  	} else {
				 	//unmount
				 	f_mount(0, "", 0);
			  	}
			}

			// Do we need to build the file system?
			if (mkfsIndication) {
				uint8_t workBuffer[_MAX_SS];
				FRESULT res;
				// Note: #warning FM_FAT32 is a requirement.
				res = f_mkfs("", FM_FAT32, 0, workBuffer, sizeof(workBuffer));

				if (res != FR_OK) {
					status = StatusMakeFileSystem;
				}
			}
		}
	}

	// Read config file values -- format file system if specified in config
	if (StatusOk == status) {
		status = Config_Init();
		if (StatusOk != status) {
			sprintf(buff, "Config_Init() - Status: %d\r\n", status);
			Console_WriteString(buff);
		} else {
#ifndef SWO_PROFILE_BUILD
			configEnableState_t formatFileSystem;
			Config_Ioctl(configIoctlGetFormatFileSys, &formatFileSystem);
			if (settingEnable == formatFileSystem) {

				status = Tc58Block_EraseAndRemapDevice();

				if (StatusOk == status) {
					uint8_t workBuffer[_MAX_SS];
					FRESULT res = f_mkfs("", FM_FAT32, 0, workBuffer,
							sizeof(workBuffer));
					if (FR_OK != res) {
						status = StatusMakeFileSystem;
					}
				}
			}
#endif // SWO_PROFILE_BUILD
		}
	}
	
	return status;
}

static status_t bluebitsInit(void)
{
	status_t status = StatusOk;
	char buff[INIT_STATUS_SPRINTF_BUFF_LEN];
	
	if (StatusOk == status) {
		status = I2C_Init(true);
		if (StatusOk != status) {
			sprintf(buff, "I2C_Init() - Status: %d\r\n", status);
			Console_WriteString(buff);
		}
	}

	if (StatusOk == status) {
		status = ProtocolHal_Init(true); // THIS MUST PRECEDE ALL I2C DEVICE INIT's
		if (StatusOk != status) {
			sprintf(buff, "ProtocolHal_Init() - Status: %d\r\n", status);
			Console_WriteString(buff);
		}
	}

	if (StatusOk == status) {
		status = ProtocolHandler_Init();
		if (StatusOk != status) {
			sprintf(buff, "ProtocolHandler_Init() - Status: %d\r\n", status);
			Console_WriteString(buff);
		}
	}

	if (StatusOk == status) {
		status = Messager_Init();
		if (StatusOk != status) {
			sprintf(buff, "Messager_Init() - Status: %d\r\n", status);
			Console_WriteString(buff);
		}
	}

	if (StatusOk == status) {
		status = BlueBits_Init();
		if (StatusOk != status) {
			sprintf(buff, "BlueBits_Init() - Status: %d\r\n", status);
			Console_WriteString(buff);
		}
	}
	
	return status;
}

static status_t dataCollectionInit(void)
{
	status_t status = StatusOk;
	char buff[INIT_STATUS_SPRINTF_BUFF_LEN];
	
	if (StatusOk == status) {
		status = Lis2de12_Init();
		if (StatusOk != status) {
			sprintf(buff, "IMU_InitLsi() - Status: %d\r\n", status);
			Console_WriteString(buff);
		}
	}

	if (StatusOk == status) {
		status = Bno055_Init();
		if (StatusOk != status) {
			sprintf(buff, "IMU_InitBno055() - Status: %d\r\n", status);
			Console_WriteString(buff);
		}
	}
    
    if (StatusOk == status) {
        status = Timer_Init();
        if (StatusOk != status) {
            sprintf(buff, "Timer_Init() - Status: %d\r\n", status);
            Console_WriteString(buff);
        }
    }
    
	if (StatusOk == status) {
		status = RTC_Init();
		if (StatusOk != status) {
			sprintf(buff, "RTC_Init() - Status: %d\r\n", status);
			Console_WriteString(buff);
		}
	}

	if (StatusOk == status) {
		status = Fifo_Init();
		if (StatusOk != status) {
			sprintf(buff, "csvFifo_Init() - Status: %d\r\n", status);
			Console_WriteString(buff);
		}
	}

	// Initialize data receiver (handles CSV file interaction, makes file system if needed)
	if (StatusOk == status) {
		status = DataReceive_Init();
		if (StatusOk != status) {
			sprintf(buff, "DataReceive_Init() - Status: %d\r\n", status);
			Console_WriteString(buff);
		}
	}

	if (StatusOk == status) {
		// This calls inits for enabled peripherals
		status = DataAggregator_Init();
		if (StatusOk != status) {
			sprintf(buff, "DataAggregator_Init() - Status: %d\r\n", status);
			Console_WriteString(buff);
		}
	}

	if (StatusOk == status) {
		status = SummaryData_Init();
		if (StatusOk != status) {
			sprintf(buff, "SummaryData_Init() - Status: %d\r\n", status);
			Console_WriteString(buff);
		}
	}
	
	return status;
}

// ==============================================================
//  ISR's
// ==============================================================
void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
	if (GPIO_Pin == LIS2DE12_INT_Pin) {
		SysState_NotifyImuInterrupt(
				HAL_GPIO_ReadPin(LIS2DE12_INT_Port, LIS2DE12_INT_Pin));
	} else if (GPIO_Pin == BUTTON_INT_Pin) {
		SysState_NotifyButtonInterrupt(
				HAL_GPIO_ReadPin(BUTTON_INT_GPIO_Port, BUTTON_INT_Pin));
	}
}

void HAL_RTCEx_WakeUpTimerEventCallback(RTC_HandleTypeDef *hrtc)
{
	SysState_NotifyWakeupTimerInterrupt();
}

void HAL_RTC_AlarmAEventCallback(RTC_HandleTypeDef *hrtc)
{
	HAL_RTC_DeactivateAlarm(hrtc, RTC_ALARM_A);
}


void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
	Timer_HandleInterrupt(htim);
}

void HAL_LPTIM_CompareMatchCallback(LPTIM_HandleTypeDef *hlptim)
{
	Timer_HandleLptimInterrupt(hlptim);
}


void HAL_ADC_LevelOutOfWindowCallback(ADC_HandleTypeDef *hadc)
{
	// TODO: Delete this?
}


// Public function bodies ---------------------------------------------------
void Error_Handler(void)
{
	// This function loops forever.
	while (1) {

	}
}

void Main_Halt(void)
{
	// This function loops forever.
	while (1) {

	}
}

#ifdef  USE_FULL_ASSERT
/**
 * @brief  Reports the name of the source file and the source line number
 *         where the assert_param error has occurred.
 * @param  file: pointer to the source file name
 * @param  line: assert_param error line source number
 * @retval None
 */
void assert_failed(char *file, uint32_t line)
{
	/* User can add his own implementation to report the file name and line number,
	 tex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */

	char buff[80];
	sprintf(buff, "Wrong parameters value: file %s on line %d\r\n", file,
			(int) line);
	Console_WriteString(buff);
}
#endif /* USE_FULL_ASSERT */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
