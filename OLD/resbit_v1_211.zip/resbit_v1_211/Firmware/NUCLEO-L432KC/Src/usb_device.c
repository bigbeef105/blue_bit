/* USER CODE BEGIN Header */
/**
 ******************************************************************************
 * @file           : usb_device.c
 * @version        : v2.0_Cube
 * @brief          : This file implements the USB Device
 ******************************************************************************
 * @attention
 *
 * <h2><center>&copy; Copyright (c) 2019 STMicroelectronics.
 * All rights reserved.</center></h2>
 *
 * This software component is licensed by ST under Ultimate Liberty license
 * SLA0044, the "License"; You may not use this file except in compliance with
 * the License. You may obtain a copy of the License at:
 *                             www.st.com/SLA0044
 *
 ******************************************************************************
 */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/

#include <stdbool.h>

#include "usb_device.h"
#include "usbd_core.h"
#include "usbd_desc.h"
#include "usbd_msc.h"
#include "usbd_storage_if.h"
#include "usbd_cdc_if.h"
#include "main.h"

#include "../StatusSu/status.h"

#include "../Bno055Su/bno055.h"
#include "../TimerSu/timer.h"

/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* USER CODE BEGIN PRIVATE_DEFINES */
/* Define size for the receive and transmit buffer over CDC */
/* It's up to user to redefine and/or remove those define */
#define APP_RX_DATA_SIZE  1000
#define APP_TX_DATA_SIZE  1000
/* USER CODE END PRIVATE_DEFINES */

/* USER CODE BEGIN PV */
/* Private variables ---------------------------------------------------------*/

/* Create buffer for reception and transmission           */
/* It's up to user to redefine and/or remove those define */
/** Received data over USB are stored in this buffer      */
uint8_t UserRxBufferFS[APP_RX_DATA_SIZE];

/** Data to send over USB CDC are stored in this buffer   */
uint8_t UserTxBufferFS[APP_TX_DATA_SIZE];

/* USER CODE END PV */

/* USER CODE BEGIN PFP */
/* Private function prototypes -----------------------------------------------*/

/* USER CODE END PFP */

/* USB Device Core handle declaration. */
USBD_HandleTypeDef hUsbDeviceFS;
extern USBD_DescriptorsTypeDef FS_Desc;

/*
 * -- Insert your variables declaration here --
 */
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/*
 * -- Insert your external function declaration here --
 */
/* USER CODE BEGIN 1 */

/* USER CODE END 1 */

/**
 * Init USB device Library, add supported class and start the library
 * @retval None
 */
status_t MX_USB_DEVICE_Init(bool cdcEnable)
{
	/* USER CODE BEGIN USB_DEVICE_Init_PreTreatment */
	status_t status = StatusOk;
	/* USER CODE END USB_DEVICE_Init_PreTreatment */
	uint16_t length;
	uint8_t* usbDescriptor = FS_Desc.GetDeviceDescriptor(1, &length);

	if (cdcEnable) {
		usbDescriptor[4] = 0x2;
	} else {
		usbDescriptor[4] = 0x0;
	}
	/* Init Device Library, add supported class and start the library. */
	if (USBD_Init(&hUsbDeviceFS, &FS_Desc, DEVICE_FS) != USBD_OK) {
		status = StatusHal;
	}

	if (cdcEnable) {
		if (StatusOk == status) {
			if (USBD_RegisterClass(&hUsbDeviceFS, &USBD_CDC) != USBD_OK) {
				status = StatusHal;
			}
		}
		if (StatusOk == status) {
			if (USBD_CDC_RegisterInterface(&hUsbDeviceFS, &USBD_Interface_fops_FS)
					!= USBD_OK) {
				status = StatusHal;
			}
		}
	} else {
		if (StatusOk == status) {
			if (USBD_RegisterClass(&hUsbDeviceFS, &USBD_MSC) != USBD_OK) {
				status = StatusHal;
			}
		}
		if (StatusOk == status) {
			if (USBD_MSC_RegisterStorage(&hUsbDeviceFS,
					&USBD_Storage_Interface_fops_FS) != USBD_OK) {
				status = StatusHal;
			}
		}
	}

	if (StatusOk == status) {
		if (USBD_Start(&hUsbDeviceFS) != USBD_OK) {
			status = StatusHal;
		}
	}

	return status;
}

status_t MX_USB_DEVICE_DeInit(void)
{
	if (USBD_OK == USBD_DeInit(&hUsbDeviceFS))
		return StatusOk;
	else
		return StatusHal;
}

/**
 * @}
 */

/**
 * @}
 */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
