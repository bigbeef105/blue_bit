/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : usbd_storage_if.c
  * @version        : v2.0_Cube
  * @brief          : Memory management layer.
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2019 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under Ultimate Liberty license
  * SLA0044, the "License"; You may not use this file except in compliance with
  * the License. You may obtain a copy of the License at:
  *                             www.st.com/SLA0044
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "usbd_storage_if.h"

/* USER CODE BEGIN INCLUDE */
#include "../StatusSu/status.h"
#include "../ConsoleSu/Console.h"
#include "../Tc58FlashUtilitiesSu/Tc58FlashUtilities.h"
#include "../Tc58FlashPhysicalSu/Tc58FlashIoControl.h"
#include "../Tc58FlashPhysicalSu/Tc58FlashPhysical.h"
// #include "../Tc58FlashPhysicalSu/Tc58FlashIoControl.h"
#include "diskio.h"
#include "ff_gen_drv.h"

#include "../Tc58FlashBufferSu/Tc58FlashBuffer.h"
/* USER CODE END INCLUDE */

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/

/* USER CODE BEGIN PV */
/* Private variables ---------------------------------------------------------*/
extern Disk_drvTypeDef  disk;
static Tc58PhysicalGeometry_t lGeometry;
/* USER CODE END PV */

/** @addtogroup STM32_USB_OTG_DEVICE_LIBRARY
  * @brief Usb device.
  * @{
  */

/** @defgroup USBD_STORAGE
  * @brief Usb mass storage device module
  * @{
  */

/** @defgroup USBD_STORAGE_Private_TypesDefinitions
  * @brief Private types.
  * @{
  */

/* USER CODE BEGIN PRIVATE_TYPES */

/* USER CODE END PRIVATE_TYPES */

/**
  * @}
  */

/** @defgroup USBD_STORAGE_Private_Defines
  * @brief Private defines.
  * @{
  */

#define STORAGE_LUN_NBR                  1
#define STORAGE_BLK_NBR                  0x10000
#define STORAGE_BLK_SIZ                  0x200

/* USER CODE BEGIN PRIVATE_DEFINES */
//#define STORAGE_DEBUG
/* USER CODE END PRIVATE_DEFINES */

/**
  * @}
  */

/** @defgroup USBD_STORAGE_Private_Macros
  * @brief Private macros.
  * @{
  */

/* USER CODE BEGIN PRIVATE_MACRO */

/* USER CODE END PRIVATE_MACRO */

/**
  * @}
  */

/** @defgroup USBD_STORAGE_Private_Variables
  * @brief Private variables.
  * @{
  */

/* USER CODE BEGIN INQUIRY_DATA_FS */
/** USB Mass storage Standard Inquiry Data. */
const int8_t STORAGE_Inquirydata_FS[] = {/* 36 */
  
  /* LUN 0 */
  0x00,
  0x80,
  0x02,
  0x02,
  (STANDARD_INQUIRY_DATA_LEN - 5),
  0x00,
  0x00,	
  0x00,
  'P', 'r', 'o', 'c', 't', 'e', 'r', ' ', /* Manufacturer : 8 bytes */
  'S', 'p', 'r', 'a', 'y', 'b', 'i', 't', /* Product      : 16 Bytes */
  // 'S', 'T', 'M', ' ', ' ', ' ', ' ', ' ', /* Manufacturer : 8 bytes */
  // 'P', 'r', 'o', 'd', 'u', 'c', 't', ' ', /* Product      : 16 Bytes */
  ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ',
  '0', '.', '0' ,'1'                      /* Version      : 4 Bytes */
}; 
/* USER CODE END INQUIRY_DATA_FS */

/* USER CODE BEGIN PRIVATE_VARIABLES */

/* USER CODE END PRIVATE_VARIABLES */

/**
  * @}
  */

/** @defgroup USBD_STORAGE_Exported_Variables
  * @brief Public variables.
  * @{
  */


/* USER CODE BEGIN EXPORTED_VARIABLES */

/* USER CODE END EXPORTED_VARIABLES */

/**
  * @}
  */

/** @defgroup USBD_STORAGE_Private_FunctionPrototypes
  * @brief Private functions declaration.
  * @{
  */

static int8_t STORAGE_Init_FS(uint8_t lun);
static int8_t STORAGE_GetCapacity_FS(uint8_t lun, uint32_t *block_num, uint16_t *block_size);
static int8_t STORAGE_IsReady_FS(uint8_t lun);
static int8_t STORAGE_IsWriteProtected_FS(uint8_t lun);
static int8_t STORAGE_Read_FS(uint8_t lun, uint8_t *buf, uint32_t blk_addr, uint16_t blk_len);
static int8_t STORAGE_Write_FS(uint8_t lun, uint8_t *buf, uint32_t blk_addr, uint16_t blk_len);
static int8_t STORAGE_GetMaxLun_FS(void);

/* USER CODE BEGIN PRIVATE_FUNCTIONS_DECLARATION */

/* USER CODE END PRIVATE_FUNCTIONS_DECLARATION */

/**
  * @}
  */

USBD_StorageTypeDef USBD_Storage_Interface_fops_FS =
{
  STORAGE_Init_FS,
  STORAGE_GetCapacity_FS,
  STORAGE_IsReady_FS,
  STORAGE_IsWriteProtected_FS,
  STORAGE_Read_FS,
  STORAGE_Write_FS,
  STORAGE_GetMaxLun_FS,
  (int8_t *)STORAGE_Inquirydata_FS
};

/* Private functions ---------------------------------------------------------*/
/**
  * @brief  Initializes over USB FS IP
  * @param  lun:
  * @retval USBD_OK if all operations are OK else USBD_FAIL
  */
int8_t STORAGE_Init_FS(uint8_t lun)
{
  /* USER CODE BEGIN 2 */
#ifdef STORAGE_DEBUG
  char buff[50];
  sprintf(buff, "STORAGE_Init_FS() lun:%i USBD_OK\r\n", lun);
  Console_WriteString(buff);
#endif

  status_t status;
  status = Tc58FlashPhysical_GetGeometry (&lGeometry);
  if (StatusOk != status)
  {
	  return (USBD_FAIL);
  }

  if(disk_initialize(lun) == RES_OK)
  {
  	  return (USBD_OK);
  }
  else
  {
	  return (USBD_FAIL);
  }
  /* USER CODE END 2 */
}

/**
  * @brief  .
  * @param  lun: .
  * @param  block_num: .
  * @param  block_size: .
  * @retval USBD_OK if all operations are OK else USBD_FAIL
  */
int8_t STORAGE_GetCapacity_FS(uint8_t lun, uint32_t *block_num, uint16_t *block_size)
{
  /* USER CODE BEGIN 3 */
	status_t status;

	status = StatusOk;

    // Setup the sector count
    // Formerly: *block_num  = TC58_NUMBER_OF_FS_BLOCKS  * TC58_SECTORS_PER_BLOCK;
    if (status == StatusOk) {
    	status = Tc58Flash_DoIoControl(Tc58IoctlGetSectorCount, block_num);
    }

    if (StatusOk == status) {
    	uint32_t blockSize32;
    	status = Tc58Flash_DoIoControl(Tc58IoctlGetBlockSize, &blockSize32);
        if (StatusOk == status) {
        	*block_size = (uint16_t) blockSize32; // lGeometry.bytesPerSector; // TC58_BYTES_PER_SECTOR;
        }
    }


    if (StatusOk == status) {

#if STORAGE_DEBUG
	Console_WriteString("STORAGE_GetCapacity_FS()\r\n");
    char buff[50];
    sprintf(buff, "Sector Count: %ld\r\n", *block_num);
    Console_WriteString(buff);
#endif

        return (USBD_OK);
    } else {
    	return (USBD_FAIL);
    }

  /* USER CODE END 3 */
}

/**
  * @brief  .
  * @param  lun: .
  * @retval USBD_OK if all operations are OK else USBD_FAIL
  */
int8_t STORAGE_IsReady_FS(uint8_t lun)
{
  /* USER CODE BEGIN 4 */
#ifdef STORAGE_DEBUG
  char buff[50];
  sprintf(buff, "STORAGE_IsReady_FS() lun:%i\r\n", lun);
  Console_WriteString(buff);
#endif

  if(disk.is_initialized[lun] == 1)
  {
	  return (USBD_OK);
  }
  else
  {
	  return (USBD_FAIL);
  }
  /* USER CODE END 4 */
}

/**
  * @brief  .
  * @param  lun: .
  * @retval USBD_OK if all operations are OK else USBD_FAIL
  */
int8_t STORAGE_IsWriteProtected_FS(uint8_t lun)
{
  /* USER CODE BEGIN 5 */
#ifdef STORAGE_DEBUG
  Console_WriteString("STORAGE_IsWriteProtected_FS()\r\n");
#endif

  return (USBD_OK);
  /* USER CODE END 5 */
}

/**
  * @brief  .
  * @param  lun: .
  * @retval USBD_OK if all operations are OK else USBD_FAIL
  */
int8_t STORAGE_Read_FS(uint8_t lun, uint8_t *buf, uint32_t blk_addr, uint16_t blk_len)
{
  /* USER CODE BEGIN 6 */
#ifdef STORAGE_DEBUG
  char buff[100];
  sprintf(buff, "STORAGE_Read_FS() lun:%i blk_addr:%u blk_len:%i\r\n", lun, (unsigned int)blk_addr, blk_len);
  Console_WriteString(buff);
#endif

  if(disk_read(lun, buf, blk_addr, blk_len) == RES_OK)
  {
#ifdef STORAGE_DEBUG
  char buff[100];
  sprintf(buff, "STORAGE_Read_FS() USBD_OK\r\n", lun, (unsigned int)blk_addr, blk_len);
  Console_WriteString(buff);
#endif
  	  return (USBD_OK);
  }
  else
  {
#ifdef STORAGE_DEBUG
  char buff[100];
  sprintf(buff, "STORAGE_Read_FS() USBD_FAIL\r\n", lun, (unsigned int)blk_addr, blk_len);
  Console_WriteString(buff);
#endif
	  return (USBD_FAIL);
  }
  /* USER CODE END 6 */
}

/**
  * @brief  .
  * @param  lun: .
  * @retval USBD_OK if all operations are OK else USBD_FAIL
  */
int8_t STORAGE_Write_FS(uint8_t lun, uint8_t *buf, uint32_t blk_addr, uint16_t blk_len)
{
  /* USER CODE BEGIN 7 */
#ifdef STORAGE_DEBUG
  char buff[100];
  sprintf(buff, "STORAGE_Write_FS() lun:%i blk_addr:%u blk_len:%i\r\n", lun, (unsigned int)blk_addr, blk_len);
  Console_WriteString(buff);
#endif

  if(disk_write(lun, buf, blk_addr, blk_len) == RES_OK)
  {
#ifdef STORAGE_DEBUG
  char buff[100];
  sprintf(buff, "STORAGE_Write_FS() USBD_OK\r\n", lun, (unsigned int)blk_addr, blk_len);
  Console_WriteString(buff);
#endif
	  return (USBD_OK);
  }
  else
  {
#ifdef STORAGE_DEBUG
  char buff[100];
  sprintf(buff, "STORAGE_Write_FS() USBD_FAIL\r\n", lun, (unsigned int)blk_addr, blk_len);
  Console_WriteString(buff);
#endif
	  return (USBD_FAIL);
  }
  /* USER CODE END 7 */
}

/**
  * @brief  .
  * @param  None
  * @retval .
  */
int8_t STORAGE_GetMaxLun_FS(void)
{
  /* USER CODE BEGIN 8 */
#ifdef STORAGE_DEBUG
  Console_WriteString("STORAGE_GetMaxLun_FS()\r\n");
#endif

  return (STORAGE_LUN_NBR - 1);
  /* USER CODE END 8 */
}

/* USER CODE BEGIN PRIVATE_FUNCTIONS_IMPLEMENTATION */

/* USER CODE END PRIVATE_FUNCTIONS_IMPLEMENTATION */

/**
  * @}
  */

/**
  * @}
  */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
