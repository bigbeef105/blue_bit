/**
  @file       gpio.h

  @copyright  (C) 2019 Kinetic Vision, Cincinnati Ohio.
               This software is property of SAEC Kinetic Vision, Inc
               and is considered confidential.

  @brief      GPIO software unit "H" file.
  @author     Parker Kamer
  @defgroup   GpioSu General Purpose Input Output pin configuration and interrupt handling

  Configuration History
  =====================

  Config Item    | Value
  -------------- | -----
  Config #       | NA
  Revision       | NA
  Revised, Date  | NA
  QA, Date       | SC,22 Jul 2019
  Approved, Date | NA
  Released, Date | NA

  Significant Modification History (Most recent at top)
  =====================================================

  Date         | Initials | Details
  ------------ | -------- | -------
  22 Jul 2019  | PK       | Original

  Theory of Operation
  ===================
  Spray Bit 2.0 requires several gpio pins to access peripherals that are
  both on the board and connected externally. This software unit must setup
  the pins for their intended purpose and handle any interrupt case caused
  by the triggering of an EXTI line.

  */

// Define to prevent recursive inclusion -------------------------------------
#ifndef __GPIO_SU_H
#define __GPIO_SU_H

#include <stdbool.h>

#include "stm32l4xx_hal.h"
#include "../StatusSu/Status.h"

// Exported macro ------------------------------------------------------------

// Exported constants --------------------------------------------------------
#define TC58_SPI_CS_Pin GPIO_PIN_8
#define TC58_SPI_CS_GPIO_Port GPIOA

#define BUTTON_INT_Pin GPIO_PIN_15
#define BUTTON_INT_GPIO_Port GPIOA

#define LIS2DE12_INT_Pin GPIO_PIN_5
#define LIS2DE12_INT_Port GPIOB
#define LIS2DE12_INT_EXTI_IRQn EXTI9_5_IRQn

#define SWDIO_Pin GPIO_PIN_13
#define SWDIO_GPIO_Port GPIOA
#define SWCLK_Pin GPIO_PIN_14
#define SWCLK_GPIO_Port GPIOA

#define LOAD_SWITCH_Pin 	GPIO_PIN_2
#define LOAD_SWITCH_Port    GPIOA

#define LED_RED_Pin 	    GPIO_PIN_6
#define LED_RED_GPIO_Port   GPIOB
#define LED_GREEN_Pin 	    GPIO_PIN_7
#define LED_GREEN_GPIO_Port GPIOB

#define VSUP_SAMPLE_CNTRL_Pin       GPIO_PIN_4
#define VSUP_SAMPLE_CNTRL_Port      GPIOB

#define VSUP_SAMPLE_Pin             GPIO_PIN_3
#define VSUP_SAMPLE_Port            GPIOA
#define VSUP_SAMPLE_AnalogChannel   ADC_CHANNEL_8

#define NUM_CONNECTORS      3

// Exported types ------------------------------------------------------------
typedef enum {
    connectorJ1 = 0,
    connectorJ2,
    connectorJ4,
} connectors_t;
// Exported objects ----------------------------------------------------------

// Exported functions --------------------------------------------------------

///  @brief Initializes the gpio software unit
///  @return StatusOk
status_t GPIO_Init(void);

///  @brief Returns the analog port associated with the J connector
GPIO_TypeDef * GPIO_GetConnectorAnalogPort(connectors_t connector);

///  @brief Returns the analog pin associated with the J connector
uint32_t GPIO_GetConnectorAnalogPin(connectors_t connector);

///  @brief Returns the analog channel associated with the J connector
uint32_t GPIO_GetConnectorAnalogChannel(connectors_t connector);

///  @brief Returns the GPIO port associated with the J connector
GPIO_TypeDef * GPIO_GetConnectorGPIOPort(connectors_t connector);

///  @brief Returns the GPIO pin associated with the J connector
uint32_t GPIO_GetConnectorGPIOPin(connectors_t connector);

///  @brief Gives the text-based specifier associated the the connector
status_t GPIO_GetNameFromConnector(connectors_t connector, char * out, size_t len);

///  @brief Gives the connector associated with the text-based specifier (i.e. '1','2','4')
status_t GPIO_GetConnectorFromName(char * string, size_t len, connectors_t * out);

///  @brief Sets up the GPIO pin associated with the given connector as a digital input with pullup enabled/disabled
void GPIO_SetupConnectorGPIOInput(connectors_t connector, bool pullUp);

///  @brief Gets the GPIO pin associated the the given connector's input signal
bool GPIO_GetConnectorGPIOInputState(connectors_t connector);

#endif // __GPIO_SU_H

/// SAEC Kinetic Vision, Inc. ----------- END OF FILE

