/**
  @file       gpio.c

  @copyright  (C) 2019 Kinetic Vision, Cincinnati Ohio.
               This software is property of SAEC Kinetic Vision, Inc
               and is considered confidential.

  @brief      GPIO software unit "C" file.
  @author     Parker Kamer
  @ingroup    GpioSu

  Configuration History
  =====================

  Config Item    | Value
  -------------- | -----
  Config #       | NA
  Revision       | NA
  Revised, Date  | NA
  QA, Date       | SC,22 Jul 2019
  Approved, Date | NA
  Released, Date | NA

  Significant Modification History (Most recent at top)
  =====================================================

  Date         | Initials | Details
  ------------ | -------- | -------
  22 Jul 2019  | PK       | Original

  Theory of Operation
  ===================
  Spray Bit 2.0 requires several gpio pins to access peripherals that are
  both on the board and connected externally. This software unit must setup
  the pins for their intended purpose and handle any interrupt case caused
  by the triggering of an EXTI line.

*/

// Includes ------------------------------------------------------------------

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

#include "../StatusSu/Status.h"
#include "../GpioSu/gpio.h"
#include "../SwUnitControlSu/SwUnitControl.h"



// Private macros ------------------------------------------------------------
/// This macro feeds status information for tracking purposes to software unit control.
#define returnStatus(__status__,__source__) SwUnitControl_WriteStatus(eSucGpioSu,__source__,__status__,__LINE__);

// Private types -------------------------------------------------------------
typedef struct {
    GPIO_TypeDef * analogPort;
    uint32_t analogPin;
    uint32_t analogChannel;
    
    GPIO_TypeDef * gpioPort;
    uint32_t gpioPin;
} connectorPins_t;

typedef struct {
    char* pValue;
    connectors_t connector;
} connectorNames_t;

// Private constants ---------------------------------------------------------
static const connectorPins_t connectorPins[] = {
    {//J1
        .analogPort = GPIOA,
        .analogPin = GPIO_PIN_0,
        .analogChannel = ADC_CHANNEL_5,
        
        .gpioPort = GPIOB,
        .gpioPin = GPIO_PIN_1,
    },
    {//J2
        .analogPort = GPIOA,
        .analogPin = GPIO_PIN_1,
        .analogChannel = ADC_CHANNEL_6,
        
        .gpioPort = GPIOB,
        .gpioPin = GPIO_PIN_1,
    },
    {//J4
        .analogPort = GPIOA,
        .analogPin = GPIO_PIN_5,
        .analogChannel = ADC_CHANNEL_10,
        
        .gpioPort = GPIOB,
        .gpioPin = GPIO_PIN_0,
    }
};

static const connectorNames_t connectorNames[NUM_CONNECTORS] = {
    {
        .pValue = "1",
        .connector = connectorJ1,
    },
    {
        .pValue = "2",
        .connector = connectorJ2,
    },
    {
        .pValue = "4",
        .connector = connectorJ4,
    },
};

// Private variables ---------------------------------------------------------
static bool initialized = false;

// Private function prototypes -----------------------------------------------


// Private function bodies ---------------------------------------------------

// Public functions bodies ---------------------------------------------------
status_t GPIO_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStruct = {0};

	status_t status = StatusOk;

	if(initialized){
		status = StatusAlreadyInitialized;
	}
	else{

		/* GPIO Ports Clock Enable */
		__HAL_RCC_GPIOC_CLK_ENABLE();
		__HAL_RCC_GPIOA_CLK_ENABLE();
		__HAL_RCC_GPIOB_CLK_ENABLE();

		/*Configure GPIO pin Output Level */
		HAL_GPIO_WritePin(TC58_SPI_CS_GPIO_Port, TC58_SPI_CS_Pin, GPIO_PIN_RESET);

		/*Configure GPIO pin : PA8 */
		GPIO_InitStruct.Pin = TC58_SPI_CS_Pin;
		GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
		GPIO_InitStruct.Pull = GPIO_NOPULL;
		GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
		HAL_GPIO_Init(TC58_SPI_CS_GPIO_Port, &GPIO_InitStruct);


		/*Configure GPIO pin : BUTTON_INT_Pin */
		GPIO_InitStruct.Pin = BUTTON_INT_Pin;
		GPIO_InitStruct.Mode = GPIO_MODE_IT_FALLING;
		GPIO_InitStruct.Pull = GPIO_PULLUP;
		HAL_GPIO_Init(BUTTON_INT_GPIO_Port, &GPIO_InitStruct);

		/* EXTI interrupt init*/
		HAL_NVIC_SetPriority(EXTI15_10_IRQn, 5, 0);
		HAL_NVIC_EnableIRQ(EXTI15_10_IRQn);

		/*Configure GPIO pin : BNO055_INT_Pin */
		GPIO_InitStruct.Pin = LIS2DE12_INT_Pin;
		GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING_FALLING;
		GPIO_InitStruct.Pull = GPIO_NOPULL;
		HAL_GPIO_Init(LIS2DE12_INT_Port, &GPIO_InitStruct);
		HAL_GPIO_WritePin(LIS2DE12_INT_Port, LIS2DE12_INT_Pin, GPIO_PIN_RESET);

		/* EXTI interrupt init*/
		HAL_NVIC_SetPriority(EXTI9_5_IRQn, 5, 0);
		HAL_NVIC_EnableIRQ(EXTI9_5_IRQn);

		GPIO_InitStruct.Pin = LOAD_SWITCH_Pin;
		GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
		GPIO_InitStruct.Pull = GPIO_NOPULL;
		HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);
		HAL_GPIO_WritePin(LOAD_SWITCH_Port, LOAD_SWITCH_Pin, GPIO_PIN_SET);

		initialized = true;
	}

	return returnStatus(status, eSucInitStatus);
} //GPIO_Init

GPIO_TypeDef * GPIO_GetConnectorAnalogPort(connectors_t connector)
{
    return connectorPins[connector].analogPort;
}

uint32_t GPIO_GetConnectorAnalogPin(connectors_t connector)
{
    return connectorPins[connector].analogPin;
}

uint32_t GPIO_GetConnectorAnalogChannel(connectors_t connector)
{
    return connectorPins[connector].analogChannel;
}

GPIO_TypeDef * GPIO_GetConnectorGPIOPort(connectors_t connector)
{
    return connectorPins[connector].gpioPort;
}

uint32_t GPIO_GetConnectorGPIOPin(connectors_t connector)
{
    return connectorPins[connector].gpioPin;
}

status_t GPIO_GetNameFromConnector(connectors_t connector, char * out, size_t len)
{
    status_t status = StatusCodePath; // this will be set to OK if we find our match
    
    if ((uint16_t)connector < NUM_CONNECTORS) {
        if (len > strlen(connectorNames[connector].pValue)) {
            strcpy(out, connectorNames[connector].pValue);
            
            status = StatusOk;
        }
    }
    
    return status;
}

status_t GPIO_GetConnectorFromName(char * string, size_t len, connectors_t * out)
{
    status_t status = StatusCodePath; // this will be set to OK if we find our match
    
    for (int i = 0; i < NUM_CONNECTORS; i++) {
        if((0 == strncmp(string, connectorNames[i].pValue, strlen(connectorNames[i].pValue))) &&
                (len >= strlen(connectorNames[i].pValue))) {
            *out = (connectors_t)i;
            status = StatusOk;
            break;
        }
    }
    
    return status;
}

void GPIO_SetupConnectorGPIOInput(connectors_t connector, bool pullUp)
{
    // Setup initialization info
    GPIO_InitTypeDef GPIO_InitStruct = {
            .Pin = connectorPins[connector].gpioPin,
            .Mode = GPIO_MODE_INPUT,
            .Pull = GPIO_NOPULL,
            .Speed = GPIO_SPEED_FREQ_LOW,
    };
    // Enable pull up if desired
    if (pullUp) {
        GPIO_InitStruct.Pull = GPIO_PULLUP;
    }
    
    HAL_GPIO_Init(connectorPins[connector].gpioPort, &GPIO_InitStruct);
}

bool GPIO_GetConnectorGPIOInputState(connectors_t connector)
{
    if (HAL_GPIO_ReadPin(connectorPins[connector].gpioPort, connectorPins[connector].gpioPin) == 
            GPIO_PIN_RESET) 
    {
        return false;
    } else {
        return true;
    }
}

/// SAEC Kinetic Vision, Inc. ----------- END OF FILE
