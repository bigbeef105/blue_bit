/**
  @file     Tc58Buffer.h

  @copyright  (C) 2019 Kinetic Vision, Cincinnati Ohio.
               This software is property of SAEC Kinetic Vision, Inc
               and is considered confidential.

  @brief      TC58 Flash page buffering software unit "H" file.

  @author     Sherman Couch

  @defgroup   Tc58BufferSoftwareUnit Tc58Buffer Software Unit (SU), buffers "n" sectors to a single physical page read / write.

              KeyPoint: This is a "block" remapper.

  Configuration Information
  =========================

  Config Item    | Value
  -------------- | -----
  Config #       | NA
  Revision       | NA
  Revised, Date  | NA
  QA, Date       | TBD
  Approved, Date | NA
  Released, Date | NA

  Call Stackup (---) Data Flow (~~~)
  ==================================

  # Call Stack

   Here is the call stackup.

NvPartition                Tc58FlashLogical SU
      |                           |
      | Remap Geometry (NV)       | Remap Geometry (FS)
      |                           V
      +---------------------> Tc58Remap SU <~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~<-+
                                  |                                            $
                                  | Remapped Geometry                          $
                                  V                                            $
                             Tc58Buffer SU                                     $
								  |                                            $
f_mkfs							  | Physical Geometry (Buffered)               $
  |	Page Erasures				  V                                      +----------+
  +--------------------- TC58FlashPhysical >~~~~~~~~~~~~~~~~~~~~~~~~~~~~>| PAGE MAP |
								  |                                      +----------+
								  | Physical Geometry
								  | (Not Buffered)
								  V
								 SPI
							  (Hardware)

  Significant Modification History (Most recent at top)
  =====================================================

  Date         | Initials | Details
  ------------ | -------- | -------
  10 Sep 2019  | SC       | Refactor "remap" into "buffer".
  06 Sep 2019  | SC       | Retool "remap" to accept "remap addresses" and internally be a buffering layer.
  20 Aug 2019  | SC       | Original

  */

// Define to prevent recursive inclusion -------------------------------------
#ifndef __TC58_BUFFER_H
#define __TC58_BUFFER_H

// Exported macro ------------------------------------------------------------
// Exported types ------------------------------------------------------------

// Exported types ------------------------------------------------------------

// Exported constants --------------------------------------------------------

// Exported objects ----------------------------------------------------------

// Exported functions --------------------------------------------------------

///  @brief Initializes the software unit
///  @details This function will only return the values shown.
///  @return StatusOK, all is well
///  @return StatusDiskNoInit, maps at a higher level to: #define STA_NOINIT 0x01 (Drive not initialized)
///  @return StatusDiskNoDisk, maps at a higher level to: #define STA_NODISK 0x02 (No medium in the drive)
///  @return StatusDiskProtect, maps at a higher level to: #define STA_PROTECT 0x04 (Write protected)
status_t Tc58Buffer_Init (void);

///  @brief Read one (possibly buffered) sector from the TC58 flash device
///  @param[in] addr
///  @param[in] pBuffer, a pointer to the sector to be read.
///  @return StatusOk
///  @return StatusResultDiskError, maps at a higher level to: DRESULT (type), value: RES_ERROR = 1
///  @return StatusResultWriteProtect, maps at a higher level to: DRESULT (type), value: RES_WRPRT = 2
///  @return StatusResultNotReady, maps at a higher level to: DRESULT (type), value: RES_NOTRDY = 3
///  @return StatusResultInvalidParameter,  maps at a higher level to: DRESULT (type), value: RES_PARERR = 4
status_t Tc58Buffer_ReadOneSector(Tc58RemapAddress_t addr, uint8_t *pBuffer);

///  @brief Write one (possibly buffered) sector to the TC58 flash device
///  @param[in] addr
///  @param[in] pBuffer
///  @return StatusOk
///  @return StatusResultDiskError, maps at a higher level to: DRESULT (type), value: RES_ERROR = 1
///  @return StatusResultWriteProtect, maps at a higher level to: DRESULT (type), value: RES_WRPRT = 2
///  @return StatusResultNotReady, maps at a higher level to: DRESULT (type), value: RES_NOTRDY = 3
///  @return StatusResultInvalidParameter,  maps at a higher level to: DRESULT (type), value: RES_PARERR = 4
status_t Tc58Buffer_WriteOneSector(Tc58RemapAddress_t addr, uint8_t *pBuffer);

///  @brief Writes any buffered sectors to the TC58 flash device
///  @return StatusOk
///  @return StatusResultDiskError, maps at a higher level to: DRESULT (type), value: RES_ERROR = 1
///  @return StatusResultWriteProtect, maps at a higher level to: DRESULT (type), value: RES_WRPRT = 2
///  @return StatusResultNotReady, maps at a higher level to: DRESULT (type), value: RES_NOTRDY = 3
///  @return StatusResultInvalidParameter,  maps at a higher level to: DRESULT (type), value: RES_PARERR = 4
status_t Tc58Buffer_SynchronizeStorage(void);

///  @brief Resets the internal page buffer
///  @return StatusOk
status_t Tc58Buffer_Reset(void);

///  @brief Returns the status of the TC58 flash
///  @details This function will only return the values shown.
///  @return StatusOK, all is well
///  @return StatusDiskNoInit, maps at a higher level to: #define STA_NOINIT 0x01 (Drive not initialized)
///  @return StatusDiskNoDisk, maps at a higher level to: #define STA_NODISK 0x02 (No medium in the drive)
///  @return StatusDiskProtect, maps at a higher level to: #define STA_PROTECT 0x04 (Write protected)
status_t Tc58Buffer_ReturnStatus(void);



#endif // __TC58_BUFFER_H

/// SAEC Kinetic Vision, Inc. ----------- END OF FILE

