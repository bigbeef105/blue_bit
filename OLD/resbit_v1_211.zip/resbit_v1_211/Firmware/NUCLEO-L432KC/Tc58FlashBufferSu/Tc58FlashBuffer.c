/**
  @file    Tc58FlashBuffer.c

  @author  Sherman Couch

  @file       Tc58FlashBuffer.c

  @copyright  (C) 2019 Kinetic Vision, Cincinnati Ohio.
               This software is property of SAEC Kinetic Vision, Inc
               and is considered confidential.

  @brief      Page buffering software unit "C" file.

  @ingroup Tc58FlashPageBufferSoftwareUnit


  Configuration History
  =====================

  Config Item    | Value
  -------------- | -----
  Config #       | NA
  Revision       | NA
  Revised, Date  | NA
  QA, Date       | NA
  Approved, Date | NA
  Released, Date | NA

 Significant Modification History (Most Recent at top)
 -----------------------------------------------------

 Date        | Initials | Description
 ----------- | -------- | -----------
 11 Sep 2019 | SC       | Connect "bottom" edge of this SU to "remap".  Now "remap" bottom edge connects to "physical".
 10 Sep 2019 | SC       | Recast "Remap_" SU into "Buffer_" SU.
 06 Sep 2019 | SC       | Remap now accepts 512 sectors as input, and buffers pages for the physical driver
 21 Aug 2019 | SC       | Refactored TC58 driver stack to create a block remapping layer.

 Theory of Operation
 -------------------
 The Tc58FlashPhysical layer:
       - encapsulates the details of operation concerning the Toshiba "TC58CVG" flash
         part,
       - presents a block and sector oriented "read/write" to higher level components, and
       - uses the SPI interface "below layer" in order .

  */

// Includes ------------------------------------------------------------------

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <stdint.h>

// Project software unit includes
#include "../StatusSu/Status.h"
#include "../Tc58FlashUtilitiesSu/Tc58FlashUtilities.h"
#include "../Tc58FlashPhysicalSu/Tc58FlashIoControl.h"
#include "../SwUnitControlSu/SwUnitControl.h"
#include "../ConsoleSu/Console.h"
#include "../Tc58BlockSu/Tc58Block.h"
#include "Tc58FlashBuffer.h"


// Private function prototypes -----------------------------------------------

// Private macros ------------------------------------------------------------

// This macro feeds status information for tracking purposes to software unit control.
#define returnStatus(__status__,__source__) SwUnitControl_WriteStatus(eSucTc58FlashBufferSu,__source__,__status__,__LINE__);


// Private types -------------------------------------------------------------

typedef enum {
	bufferFree,
	bufferRead,
	bufferModified,
	bufferingDeadPage,
} pageBufferState_t;

// Private constants ---------------------------------------------------------

// Private function prototypes -----------------------------------------------

// Private constants ---------------------------------------------------------

// Private variables ---------------------------------------------------------

static bool initialized = false;

// The buffered page can contain up to 8 sectors of 512 bytes per sector.

static uint8_t lPageBuffer[TC58_MAX_BYTES_PER_PAGE];
static pageBufferState_t lPageBufferState;
static Tc58PageAddress_t lPageBufferAddress;

static bool lDebugTrace = false;

// Private function bodies ---------------------------------------------------

// Public functions bodies ---------------------------------------------------

status_t Tc58Buffer_ReadOneSector(Tc58RemapAddress_t addr, uint8_t *pBuffer)
{
	if (lDebugTrace) {
		uint8_t buff[50];
		sprintf(buff, "<R %u/%u/%u>", addr.block, addr.page, addr.sector);
		Console_WriteString(buff);
	}

	status_t status;
    status = StatusOk;

    if (!initialized) {
        status = StatusNotInitialized;
    }

    if (StatusOk == status) {

    	switch(lPageBufferState) {

    		case bufferFree:

				// Read a full page of data (which contains the desired sector) into the local page buffer
				lPageBufferAddress.block = addr.block;
				lPageBufferAddress.page = addr.page;
				status = Tc58Block_ReadOnePage(lPageBufferAddress, lPageBuffer);
				if (StatusOk != status) {
					lPageBufferState = bufferingDeadPage;
					break;
				}

				// Change buffer state (indicated "read" data is now in the buffer).
				lPageBufferState = bufferRead;

				// Return one sector of data from the local page buffer into the output sector data buffer
				memcpy (pBuffer, lPageBuffer + addr.sector*TC58_BYTES_PER_SECTOR_512, TC58_BYTES_PER_SECTOR_512);

				break;

			case bufferRead:

				// If the sector being read is not in the local page buffer, then ...
				if ( (lPageBufferAddress.block != addr.block) ||
					 (lPageBufferAddress.page != addr.page) ) {

					// Bring the correct page into the local page buffer. Read a full page
					// (which contains the desired sector) into the local page buffer
					// Record the page address of the data now in the local page buffer.

					lPageBufferAddress.block = addr.block;
					lPageBufferAddress.page = addr.page;
					status = Tc58Block_ReadOnePage(lPageBufferAddress, lPageBuffer);
					if (StatusOk != status) {
						lPageBufferState = bufferingDeadPage;
						break;
					}
				}

				// Return data from the page buffer into the output buffer
				memcpy (pBuffer, lPageBuffer + addr.sector*TC58_BYTES_PER_SECTOR_512, TC58_BYTES_PER_SECTOR_512);

				break;

			case bufferModified:
				// The local page buffer currently contains data which has been modified.
				// If the sector being read is not in the local page buffer, then ...
				if ( (lPageBufferAddress.block != addr.block) ||
					 (lPageBufferAddress.page != addr.page) ) {

					// Before reading in the page (which contains the desired read sector),
					// write the (modified) local page buffer to flash.
					//
					// Note: The status result of this write operation is formally ignored.
					//
					Tc58Block_WriteOnePage(lPageBufferAddress, lPageBuffer);

					// Bring the correct page into the local page buffer. Read a full page
					// (which contains the desired sector) into the local page buffer
					lPageBufferAddress.block = addr.block;
					lPageBufferAddress.page = addr.page;
					status = Tc58Block_ReadOnePage(lPageBufferAddress, lPageBuffer);
					if (StatusOk != status) {
						lPageBufferState = bufferingDeadPage;
						break;
					}

					// Record the new page buffer state.
					lPageBufferState = bufferRead;
				}

				// Return data from the page buffer into the output buffer
				memcpy (pBuffer, lPageBuffer + addr.sector*TC58_BYTES_PER_SECTOR_512, TC58_BYTES_PER_SECTOR_512);

				break;

			case bufferingDeadPage:

				// If the sector being read is on the dead page, then ...
				if ( (lPageBufferAddress.block == addr.block) &&
					 (lPageBufferAddress.page == addr.page) ) {
					status = StatusResultDiskError;
					break;
				}

				// the sector being read is not on the dead page.
				// Bring the correct page into the local page buffer. Read a full page
				// (which contains the desired sector) into the local page buffer
				// Record the page address of the data now in the local page buffer.

				lPageBufferAddress.block = addr.block;
				lPageBufferAddress.page = addr.page;
				status = Tc58Block_ReadOnePage(lPageBufferAddress, lPageBuffer);
				if (StatusOk != status) {
					break;
				}

				// Return data from the page buffer into the output buffer
				memcpy (pBuffer, lPageBuffer + addr.sector*TC58_BYTES_PER_SECTOR_512, TC58_BYTES_PER_SECTOR_512);

				// Record the new page buffer state.
				lPageBufferState = bufferRead;

				break;
    	}
    }

	// We care about tracking this status, use macro to feed status to SW Unit control.
    return returnStatus(status, eSucReadStatus);

} // Tc58Buffer_ReadSectors

status_t Tc58Buffer_WriteOneSector(Tc58RemapAddress_t addr, uint8_t *pWriteBuffer)
{
	if (lDebugTrace) {
		uint8_t buff[50];
		sprintf(buff, "<W %u/%u/%u>", addr.block, addr.page, addr.sector);
		Console_WriteString(buff);
	}

	status_t status;
    status = StatusOk;

    if (!initialized) {
        status = StatusNotInitialized;
    }

    if (StatusOk == status) {

    	switch(lPageBufferState) {

    		case bufferFree:

				// Read a full page of data (which contains the desired sector) into the local page buffer
    			lPageBufferAddress.block = addr.block;
    			lPageBufferAddress.page = addr.page;
				status = Tc58Block_ReadOnePage(lPageBufferAddress, lPageBuffer);
				if (StatusOk != status) {
					lPageBufferState = bufferingDeadPage;
					break;
				}

				// Now put the "write" data into the local page buffer
				memcpy (lPageBuffer + addr.sector*TC58_BYTES_PER_SECTOR_512, pWriteBuffer, TC58_BYTES_PER_SECTOR_512);

				// Change buffer state (indicated "write" data is now in the buffer).
				lPageBufferState = bufferModified;

				break;

			case bufferRead:

				// If the sector being written is not in the local page buffer, then ...
				if ( (lPageBufferAddress.block != addr.block) ||
					 (lPageBufferAddress.page != addr.page) ) {

					// Bring the correct page into the local page buffer. Read a full page
					// (which contains the desired sector) into the local page buffer
					lPageBufferAddress.block = addr.block;
					lPageBufferAddress.page = addr.page;
					status = Tc58Block_ReadOnePage(lPageBufferAddress, lPageBuffer);
					if (StatusOk != status) {
						lPageBufferState = bufferingDeadPage;
						break;
					}
				}

				// Now put the "write" data into the local page buffer
				memcpy (lPageBuffer + addr.sector*TC58_BYTES_PER_SECTOR_512, pWriteBuffer, TC58_BYTES_PER_SECTOR_512);

				// Change buffer state (indicated "write" data is now in the buffer).
				lPageBufferState = bufferModified;

				break;

			case bufferModified:
				// The local page buffer currently contains data which has been modified.
				// If the sector being read is not in the local page buffer, then ...
				if ( (lPageBufferAddress.block != addr.block) ||
					 (lPageBufferAddress.page != addr.page) ) {

					// Before reading in the page (which contains the desired sector for the current write),
					// write the (modified) local page buffer to flash.
					//
					// Note: The status result of this write operation is formally ignored.
					//

					Tc58Block_WriteOnePage(lPageBufferAddress, lPageBuffer);

					// Bring the correct page into the local page buffer. Read a full page
					// (which contains the desired sector) into the local page buffer
					lPageBufferAddress.block = addr.block;
					lPageBufferAddress.page = addr.page;
					status = Tc58Block_ReadOnePage(lPageBufferAddress, lPageBuffer);
					if (StatusOk != status) {
						lPageBufferState = bufferingDeadPage;
						break;
					}

				}

				// Now put the "write" data into the local page buffer
    			memcpy (lPageBuffer + addr.sector*TC58_BYTES_PER_SECTOR_512, pWriteBuffer, TC58_BYTES_PER_SECTOR_512);

				// Maintin buffer modified state (indicated "write" data is now in the buffer).
				lPageBufferState = bufferModified;
				break;

			case bufferingDeadPage:

				// If the sector being written is on the dead page, then ...
				if ( (lPageBufferAddress.block == addr.block) &&
					 (lPageBufferAddress.page == addr.page) ) {
					status = StatusResultDiskError;
					break;
				}

				// the sector being written is not on the dead page.
				// Bring the correct page into the local page buffer. Read a full page
				// (which contains the desired sector) into the local page buffer
				// Record the page address of the data now in the local page buffer.

				lPageBufferAddress.block = addr.block;
				lPageBufferAddress.page = addr.page;
				status = Tc58Block_ReadOnePage(lPageBufferAddress, lPageBuffer);
				if (StatusOk != status) {
					break;
				}

				// Now put the "write" data into the local page buffer
    			memcpy (lPageBuffer + addr.sector*TC58_BYTES_PER_SECTOR_512, pWriteBuffer, TC58_BYTES_PER_SECTOR_512);

				// Record the new page buffer state.
				lPageBufferState = bufferModified;


#if 0
			default:
				status = StatusFirmwareLogic;
				break;
#endif
    	}
    }
	// We care about tracking this status, use macro to feed status to SW Unit control.
    return returnStatus(status, eSucWriteStatus);

} // Tc58Buffer_WriteOneSector

status_t Tc58Buffer_SynchronizeStorage(void)
{
	if (lDebugTrace) {
		Console_WriteString("<SYNC>");
	}

	status_t status;
    status = StatusOk;

    if (!initialized) {
        status = StatusNotInitialized;
    }

    if (StatusOk == status) {

    	// if there is write data buffered, then
    	if (bufferModified == lPageBufferState) {

    		// write the (modified) local page buffer to flash.
			status = Tc58Block_WriteOnePage(lPageBufferAddress, lPageBuffer);
    	}
    }

	if (StatusOk == status) {
		lPageBufferState = bufferFree;
	}


	// We care about tracking this status, use macro to feed status to SW Unit control.
    return returnStatus(status, eSucIoctlStatus);

} // Tc58Buffer_SynchronizeStorage

status_t Tc58Buffer_Reset(void)
{
	if (lDebugTrace) {
		Console_WriteString("<RESET>");
	}

	status_t status;
    status = StatusOk;

    if (!initialized) {
        status = StatusNotInitialized;
    }

    if (StatusOk == status) {
		lPageBufferState = bufferFree;
    }

	// We care about tracking this status, use macro to feed status to SW Unit control.
    return returnStatus(status, eSucIoctlStatus);

} // Tc58Buffer_SynchronizeStorage

status_t Tc58Buffer_ReturnStatus(void)
{
    status_t status;

    status = StatusOk;

    if (!initialized) {
        status = StatusNotInitialized;
    }

    if (StatusOk == status) {
    	status = Tc58Block_ReturnStatus( );
    }

	// We care about tracking this status, use macro to feed status to SW Unit control.
    return returnStatus(status, eSucIoctlStatus);

} // Tc58Buffer_ReturnStatus


status_t Tc58Buffer_Init(void)
{
    status_t status;
    status = StatusOk;

    if (initialized) {
        status = StatusAlreadyInitialized;
    }

	if (StatusOk == status) {
    	initialized = true;
    	lPageBufferState = bufferFree;
    }

    // We care about tracking this status, use macro to feed status to SW Unit control.
    return returnStatus(status, eSucInitStatus);

} // Tc58Buffer_Init


/// SAEC Kinetic Vision, Inc  ----------- END OF FILE

