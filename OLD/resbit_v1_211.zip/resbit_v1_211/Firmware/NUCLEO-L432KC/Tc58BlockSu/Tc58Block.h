/**
  @file     Tc58Block.h

  @copyright  (C) 2019 Kinetic Vision, Cincinnati Ohio.
               This software is property of SAEC Kinetic Vision, Inc
               and is considered confidential.

  @brief      TC58 Flash block "remap" software unit "H" file.

  @author     Sherman Couch

  @defgroup   Tc58BlockSoftwareUnit Remaps block numbers (in page read / write operations) to avoid bad blocks on the chip.
              KeyPoint: This is a "block" remapping layer.  Bad blocks are detected at "Block Erase" time, and recorded in
              a table (a bad block map).

  Configuration Information
  =========================

  Config Item    | Value
  -------------- | -----
  Config #       | NA
  Revision       | NA
  Revised, Date  | NA
  QA, Date       | TBD
  Approved, Date | NA
  Released, Date | NA

  Call Stackup (---) Data Flow (~~~)
  ==================================

                                Chan N FS
                                  |
                                  | Sector Geometry
                                  V
NvPartition                Tc58FlashLogical SU
      |                           |
      | Remap Geometry (NV)       | Desired Block / Page / Sector
      |                           V
      +---------------------> Tc58Buffer SU
                                  |
                                  | Desired Block
                                  V
                              Tc58 Block SU --------------------------- Page Map IOCTL API
                                  |                                            ^
TBD: f_mkfs		                  | Desired Blocks / Page / Sector             |
  |	               				  V                                            |
  +---------------------> TC58FlashPhysical                                    |
								  |                                            |
								  | Remapped to physical Geometry--------------+
								  | (Not Buffered)
								  V
								 SPI
							  (Hardware)


  Significant Modification History (Most recent at top)
  =====================================================

  Date         | Initials | Details
  ------------ | -------- | -------
  05 Nov 2019  | SC       | Add interface to convert a block number to a remapped block number.
  10 Sep 2019  | SC       | Original

  */

// Define to prevent recursive inclusion -------------------------------------
#ifndef __TC58_BLOCK_H
#define __TC58_BLOCK_H

// Exported macro ------------------------------------------------------------

// Exported types ------------------------------------------------------------

// Exported types ------------------------------------------------------------

typedef enum {
	Tc58BlockIoctlGetRemappedBlock,
	Tc58BlockIoctlGetScratchPadBlockNum,
	Tc58BlockIoctlZapBlockFromRemap,
	Tc58BlockIoctlGetRemapFixedBlockNumber,
} Tc58_Block_Ioctl_t;

// Exported constants --------------------------------------------------------

// Exported objects ----------------------------------------------------------

// Exported functions --------------------------------------------------------

///  @brief Returns the status of the TC58 flash
///  @details This function will only return the values shown.
///  @return StatusOK, all is well
///  @return StatusDiskNoInit, maps at a higher level to: #define STA_NOINIT 0x01 (Drive not initialized)
///  @return StatusDiskNoDisk, maps at a higher level to: #define STA_NODISK 0x02 (No medium in the drive)
///  @return StatusDiskProtect, maps at a higher level to: #define STA_PROTECT 0x04 (Write protected)
status_t Tc58Block_ReturnStatus(void);

///  @brief Initializes the software unit
///  @details This function will only return the values shown.
///  @return StatusOK, all is well
///  @return StatusDiskNoInit, maps at a higher level to: #define STA_NOINIT 0x01 (Drive not initialized)
///  @return StatusDiskNoDisk, maps at a higher level to: #define STA_NODISK 0x02 (No medium in the drive)
///  @return StatusDiskProtect, maps at a higher level to: #define STA_PROTECT 0x04 (Write protected)
status_t Tc58Block_Init (void);

///  @brief Erases all blocks in the device, rebuilds remap table and stores that table
///  @return StatusOk
status_t Tc58Block_EraseAndRemapDevice(void);

///  @brief Read one page from the TC58 flash device
///  @param[in] addr
///  @param[in] pBuffer, a pointer to the sector to be read.
///  @return StatusOk
///  @return StatusResultDiskError, maps at a higher level to: DRESULT (type), value: RES_ERROR = 1
///  @return StatusResultWriteProtect, maps at a higher level to: DRESULT (type), value: RES_WRPRT = 2
///  @return StatusResultNotReady, maps at a higher level to: DRESULT (type), value: RES_NOTRDY = 3
///  @return StatusResultInvalidParameter,  maps at a higher level to: DRESULT (type), value: RES_PARERR = 4
status_t Tc58Block_ReadOnePage(Tc58PageAddress_t addr, uint8_t *pBuffer);

///  @brief Write a page to flash device
///  @param[in] addr
///  @param[in] pBuffer
///  @return StatusOk
///  @return StatusResultDiskError, maps at a higher level to: DRESULT (type), value: RES_ERROR = 1
///  @return StatusResultWriteProtect, maps at a higher level to: DRESULT (type), value: RES_WRPRT = 2
///  @return StatusResultNotReady, maps at a higher level to: DRESULT (type), value: RES_NOTRDY = 3
///  @return StatusResultInvalidParameter,  maps at a higher level to: DRESULT (type), value: RES_PARERR = 4
status_t Tc58Block_WriteOnePage(Tc58PageAddress_t addr, uint8_t *pBuffer);

///  @brief Performs ioctl operations on device
///  @param[in] ioctlCode Tc58BlockIoctlGetRemappedBlock
///  @param[in] blockNumberIn1
///  @param[out] *pBlockNumberOut
///  @return StatusOk
status_t Tc58Block_Ioctl(Tc58_Block_Ioctl_t ioctlCode, uint16_t blockNumberIn1, uint16_t *pBlockNumberOut);

#endif // __TC58_BLOCK_H

/// SAEC Kinetic Vision, Inc. ----------- END OF FILE

