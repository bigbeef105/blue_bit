/**
  @file    Tc58Block.c

  @author  Sherman Couch

  @copyright  (C) 2019 Kinetic Vision, Cincinnati Ohio.
               This software is property of SAEC Kinetic Vision, Inc
               and is considered confidential.

  @brief      Tc58BlockSoftwareUnit software unit "C" file.

  @ingroup    Tc58BlockSoftwareUnit


  Configuration History
  =====================

  Config Item    | Value
  -------------- | -----
  Config #       | NA
  Revision       | NA
  Revised, Date  | NA
  QA, Date       | NA
  Approved, Date | NA
  Released, Date | NA

 Significant Modification History (Most Recent at top)
 -----------------------------------------------------

 Date        | Initials | Description
 ----------- | -------- | -----------
 11 Nov 2019 | SC       | Remap table grown into true remap table, formerly a skip table.
 17 Sep 2019 | SC       | Store / retrieve the block remap table.
 10 Sep 2019 | SC       | Created a SU which can re-map blocks.

 Theory of Operation
 -------------------
 This software unit is responsible for providing a set of block operations to the higher layer
 which has high assurance of read/write success. It does this by maintaining a list of how
 blocks are mapped.

 Block Map
 ---------
 Consider the following block map of a TC58CVGS0H, which has 2048 blocks per unit.
 Other device types simply have larger file system block allocations, and commensurately
 larger remap pools.

 Index (Block Number)  | Table Value                           | Description
 -------------         | ------------------------------------- | -----------
 0                     | 0 (or index # in pool if remapped)    | File system: first block
 ...                   | ...                                   | File system: additional blocks
 1499                  | 1499 (or index # in pool if remapped) | File system: final block
 1500                  | 1500 (or index # in pool if remapped) | Scratch pad block
 1501                  | 1501 (or 0xFFFF if used to remap)     | Spare pool: first block
 ...                   | ...                                   | Spare pool: additional blocks
 2045                  | 2045 (or 0xFFFF if used to remap)     | Spare pool: final block
 2047                  | 2047 (cannot be remapped)             | This is where the block map table is stored

  */

// Includes ------------------------------------------------------------------

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <stdint.h>

// Project software unit includes
#include "../StatusSu/Status.h"
#include "../ConsoleSu/Console.h"
#include "../Tc58FlashUtilitiesSu/Tc58FlashUtilities.h"
#include "../Tc58FlashPhysicalSu/Tc58FlashPhysical.h"
#include "../Tc58FlashPhysicalSu/Tc58FlashIoControl.h"
#include "../SwUnitControlSu/SwUnitControl.h"
#include "Tc58Block.h"

// Private function prototypes -----------------------------------------------

// Private macros ------------------------------------------------------------
#define TC58_PAGES_PER_BLOCK 64

// This macro feeds status information for tracking purposes to software unit control.
#define returnStatus(__status__,__source__) SwUnitControl_WriteStatus(eSucTc58BlockSu,__source__,__status__,__LINE__);

// Private types -------------------------------------------------------------
typedef enum {
	remapMagicNumber1 = 0x1492fa1a,
	remapMagicNumber2 = 0x273f11f2,
	remapMagicNumber3 = 0x31abdfa3,
	remapMagicNumber4 = 0xbadc0ffe,

	invalid = 0xC0FFEE,
} remapMagicNumber_t;

typedef struct {
	remapMagicNumber_t magicNumber1;
    uint32_t numberOfValidBlocks;
	uint16_t physicalBlock[TC58_BLOCKS_PER_UNIT];
	remapMagicNumber_t magicNumber2;
	remapMagicNumber_t magicNumber3;
	remapMagicNumber_t magicNumber4;
} remapTable_t;

#define BLOCK_NOT_AVAILABLE 0xFFFF

// Private constants ---------------------------------------------------------
// #define LOCAL_DEBUG_TRACE

// Private function prototypes -----------------------------------------------
static status_t cliDumpRemapTable(uint16_t argc, uint8_t **argv);
static status_t cliBlankCheckRemapTable(uint16_t argc, uint8_t **argv);
static status_t cliRemapFileSystemBlockTable(uint16_t argc, uint8_t **argv);
static status_t cliTraceBlockWrites(uint16_t argc, uint8_t **argv);
static status_t cliTraceBlockReads(uint16_t argc, uint8_t **argv);
static status_t cliFailBlockWrite(uint16_t argc, uint8_t **argv);
static status_t cliFailBlockRead(uint16_t argc, uint8_t **argv);

static status_t block_Erase(uint16_t blockNumber);


// Restricted function prototypes --------------------------------------------

///  @brief Erases a block, restricted for use by remap layer.
///  @param[in] block, the block number to be erased
///  @return StatusOk
status_t Tc58Physical_EraseBlockRestricted(uint16_t blockNumber);

// Private constants ---------------------------------------------------------

static const consoleCommand_t commandList[] = {
	{"dmap", "dump remap table\r\n\t"
			"usage: dmap", cliDumpRemapTable
	},

	{"bc", "blank-check remapped table\r\n\t"
			"usage: bc", cliBlankCheckRemapTable
	},

	{"rfsb", "remap file system block\r\n\t"
			"usage: rfsb blockInFileSystem", cliRemapFileSystemBlockTable
	},

	{"tbw", "trace block writes\r\n\t"
			"usage: tbw {off|on}", cliTraceBlockWrites
	},

	{"tbr", "trace block reads\r\n\t"
			"usage: tbr {off|on}", cliTraceBlockReads
	},

	{"fbw", "fail block write\r\n\t"
			"usage: fbw { off| on [block# page#] }", cliFailBlockWrite
	},

	{"fbr", "fail block reads\r\n\t"
			"usage: fbr [0=off|1=on]", cliFailBlockRead
	},

	{ NULL, NULL, NULL
    },
};

// Private variables ---------------------------------------------------------

// Note: When any of these variables has the value "BLOCK_NOT_AVAILABLE", that
//       disables the underlying cli controlled feature.
static uint16_t traceBlockRead = BLOCK_NOT_AVAILABLE;
static uint16_t traceBlockWrite = BLOCK_NOT_AVAILABLE;
static uint16_t failBlockRead = BLOCK_NOT_AVAILABLE;

static Tc58PageAddress_t failBlockWrite = {.block = BLOCK_NOT_AVAILABLE};

static consoleRegistration_t exportedReg;
static bool initialized = false;
static remapTable_t lRemapTable;

// Private function bodies ---------------------------------------------------

static status_t uint32_ConvertAtoi(uint8_t *a, uint32_t *pN)
{
	uint32_t n;

	if (NULL == a) {
		return StatusNullParameter;
	}

	// Number format 0x__?
	if ( (strlen(a) > 2) && ('0' == a[0]) && ('x' == a[1]) ) {
		sscanf(&a[2], "%lx", &n);
	} else {
		n = atoi(a);
	}

	*pN = n;

	return StatusOk;
} //uint32_ConvertAtoi

static status_t getRemapBlockNumber(uint16_t desiredBlock, uint16_t *pRemappedBlockNumber)
{
	status_t status;

	status = StatusOk;

    // Validate parameters
    if (StatusOk == status) {
    	if (desiredBlock > BI_LAST_REMAPPABLE_BLOCK) {
    		status = StatusBlockNumber;
    	}
    }

    if (StatusOk == status) {
		if (NULL == pRemappedBlockNumber) {
			status = StatusParameter2;
		}
    }


    // Validate table integrity
    if (StatusOk == status) {
    	if ( (lRemapTable.magicNumber1 != remapMagicNumber1) ||
    		 (lRemapTable.magicNumber2 != remapMagicNumber2) ) {
    		status = StatusRemapTable;
    	}
    }

    // Retrieve remapped block number
    if (StatusOk == status) {

    	uint16_t remappedBlock;
		remappedBlock = lRemapTable.physicalBlock[desiredBlock];

		// Paradigm: Detect issues with remapping; this block rememap, if not return status
		if (BLOCK_NOT_AVAILABLE == remappedBlock) {
			status = StatusRemap;
		} else {
			// Setup return
			*pRemappedBlockNumber = remappedBlock;
		}
    }

	// We care about tracking this status, use macro to feed status to SW Unit control.
	return status;

} // getRemapBlockNumber

status_t zapBlockFromRemap(uint16_t blockNumberIn)
{
	status_t status;
	status = StatusOk;

    // Validate parameters
    if (StatusOk == status) {
    	if (blockNumberIn >= BI_REMAP_BLOCK_FIXED_BLOCK) {
    		status = StatusBlockNumber;
    	}
    }

    // Validate table integrity
    if (StatusOk == status) {
    	if ( (lRemapTable.magicNumber1 != remapMagicNumber1) ||
       		 (lRemapTable.magicNumber2 != remapMagicNumber2) ||
    		 (lRemapTable.magicNumber3 != remapMagicNumber3) ) {
    		status = StatusRemapTable;
    	}
    }

	lRemapTable.physicalBlock[blockNumberIn] = BLOCK_NOT_AVAILABLE;

	// Write the new remap table to flash
	Tc58PageAddress_t addr;
	addr.block = BI_REMAP_BLOCK_FIXED_BLOCK;
	addr.page = 0;

	// Note the status assignement (below) overrides the "status assumption" (above).
	status = Tc58FlashPhysical_Write(addr, &lRemapTable, sizeof(lRemapTable));
	return status;

} // zapBlockFromRemap



status_t forceRemapFromPool(uint16_t block, uint16_t *pRemappedBlockNumber, uint16_t inUsePageNumber, uint8_t *pInUsePageData)
{
	status_t status;
	status = StatusOk;

    // Validate parameters
    if (StatusOk == status) {
    	if (block > BI_LAST_REMAPPABLE_BLOCK) {
    		status = StatusBlockNumber;
    	}
    }

    if (StatusOk == status) {
		if (NULL == pRemappedBlockNumber) {
			status = StatusParameter2;
		}
    }

    // Validate table integrity
    if (StatusOk == status) {
    	if ( (lRemapTable.magicNumber1 != remapMagicNumber1) ||
    		 (lRemapTable.magicNumber2 != remapMagicNumber2) ) {
    		status = StatusRemapTable;
    	}
    }

	// Pass through the pool, and use first available block found in the pool.  Code
    // has a "status assumption" that the block pool is full, unless an available block is found in the pool.
    // that "status assumption" is corrected (below) --- look for the comment.  SC
	status = StatusBlockPoolFull;
	for (uint32_t poolBlock = BI_POOL_FIRST_BLOCK; poolBlock <= BI_POOL_LAST_BLOCK; poolBlock++) {

		// If we have we found an available block in the pool, then update the block table.
		if (BLOCK_NOT_AVAILABLE != lRemapTable.physicalBlock[poolBlock]) {
			lRemapTable.physicalBlock[block] = poolBlock;
			lRemapTable.physicalBlock[poolBlock] = BLOCK_NOT_AVAILABLE;

			// Write the new remap table to flash
	    	Tc58PageAddress_t addr;
			addr.block = BI_REMAP_BLOCK_FIXED_BLOCK;
			addr.page = 0;

			// Note the status assignement (below) overrides the "status assumption" (above).
			status = Tc58FlashPhysical_Write(addr, &lRemapTable, sizeof(lRemapTable));
			break;
		}
	}

    // Return the remapped block number
    if (StatusOk == status) {
		*pRemappedBlockNumber = lRemapTable.physicalBlock[block];

		char buff[50];
    	sprintf(buff, "Remaped %u to %u\r\n" , block, *pRemappedBlockNumber);
    	Console_WriteString(buff);

    	if (BI_SCRATCHPAD_BLOCK == block) {

    		// Special case, if the block remapped was the Scratchpad block, inform the physical driver of the change.
    		uint32_t scratchPadBlock32Bits;
    		scratchPadBlock32Bits = lRemapTable.physicalBlock[BI_SCRATCHPAD_BLOCK];
    		status = Tc58Flash_DoIoControl(Tc58IoctlPutScratchPadBlockNumber, &scratchPadBlock32Bits);

    	} else {

#warning Possible stack risk, large buffer on stack
    		uint8_t pageBuffer[TC58_MAX_BYTES_PER_PAGE];

	    	Tc58PageAddress_t original;
			original.block = block;

	    	Tc58PageAddress_t remapped;
	    	remapped.block = *pRemappedBlockNumber;

    	    // Final step, except for scratchpad block, copy any residual data from original block to remapped block
    		for (uint16_t page = 0; page < TC58_PAGES_PER_BLOCK; page++) {

    			if (page == inUsePageNumber) {
        			// Splice the page "in use" into the remapped block
    				if (NULL != pInUsePageData) {
    					Tc58FlashPhysical_WriteOnePage(remapped, pInUsePageData);
    				}
    			} else {

    				// Put original page data into the remapped block
					original.page = page;
    				remapped.page = page;

    				Tc58FlashPhysical_ReadOnePage(original, pageBuffer);
    				Tc58FlashPhysical_WriteOnePage(remapped, pageBuffer);
    			}
    		}
    	}
	}

	return status;

} // forceRemapFromPool




static status_t cliTraceBlockWrites(uint16_t argc, uint8_t **argv)
{
	status_t status;

	status = StatusOk;

	// usage: tbw {off|on}
	if (argc < 2) {

		if (traceBlockWrite != BLOCK_NOT_AVAILABLE) {
			Console_WriteString("on\r\n");
		} else {
			Console_WriteString("off\r\n");
		}

	} else {

		if (0 == strcmp(argv[1], "on")) {
			// The "(BLOCK_NOT_AVAILABLE - 1)" value enables tracing,
			// and the last block is not going to show a valid block.
			// This will make more sense when you look at the
			// block write logic.
			traceBlockWrite = (BLOCK_NOT_AVAILABLE - 1);
		}
		else if (0 == strcmp(argv[1], "off")) {
			traceBlockWrite = BLOCK_NOT_AVAILABLE;
		} else {
			status = StatusParameterValue;
		}

	}
	return status;

} // cliTraceBlockWrites

static status_t cliTraceBlockReads(uint16_t argc, uint8_t **argv)
{
	status_t status;

	status = StatusOk;

	// usage: tbw {off|on}
	if (argc < 2) {

		if (traceBlockRead != BLOCK_NOT_AVAILABLE) {
			Console_WriteString("on\r\n");
		} else {
			Console_WriteString("off\r\n");
		}

	} else {

		if (0 == strcmp(argv[1], "on")) {
			// The "(BLOCK_NOT_AVAILABLE - 1)" value enables tracing,
			// and the last block is not going to show a valid block.
			// This will make more sense when you look at the
			// block read logic.
			traceBlockRead = (BLOCK_NOT_AVAILABLE - 1);
		}
		else if (0 == strcmp(argv[1], "off")) {
			traceBlockRead = BLOCK_NOT_AVAILABLE;
		} else {
			status = StatusParameterValue;
		}

	}
	return status;

} // cliTraceBlockReads

static status_t cliFailBlockWrite(uint16_t argc, uint8_t **argv)
{
	// usage: fbw { off|on [block#] }

	static status_t status;

	status = StatusOk;

	if (0 == strcmp("off", argv[1])) {
		failBlockWrite.block = BLOCK_NOT_AVAILABLE;
	}

	if (argc < 4) {
		if (BLOCK_NOT_AVAILABLE == failBlockWrite.block) {
			Console_WriteString("off\r\n");
		} else {
			char buff[50];
			sprintf(buff, "Block: %d, Page: %d\r\n", failBlockWrite.block, failBlockWrite.page);
			Console_WriteString(buff);
		}
	}

	else {
		if (0 == strcmp("on", argv[1])) {
			uint32_t i32;
			status = uint32_ConvertAtoi(argv[2], &i32);
			if (StatusOk == status) {
				failBlockWrite.block = (uint16_t) i32;
			}

			status = uint32_ConvertAtoi(argv[3], &i32);
			if (StatusOk == status) {
				failBlockWrite.page = (uint16_t) i32;
			}
		}
	}

	return status;

} // cliFailBlockWrite

static status_t cliFailBlockRead(uint16_t argc, uint8_t **argv)
{
	// usage: fbw { off|on [block#] }

	static status_t status;

	status = StatusOk;

	if (argc < 2) {

		if (BLOCK_NOT_AVAILABLE == failBlockRead) {
			Console_WriteString("off\r\n");
		} else {
			char buff[50];
			sprintf(buff, "%d\r\n", failBlockRead);
			Console_WriteString(buff);
		}
	}

	else {
		if (0 == strcmp("off", argv[1])) {
			failBlockRead = BLOCK_NOT_AVAILABLE;
		}
		else if (0 == strcmp("on", argv[1])) {
			uint32_t block32;
			status = uint32_ConvertAtoi(argv[2], &block32);
			if (StatusOk == status) {
				failBlockRead = (uint16_t) block32;
			}
		}
	}

	return status;

} // cliFailBlockRead

static status_t cliRemapFileSystemBlockTable(uint16_t argc, uint8_t **argv)
{
	char buff[50];

	uint16_t remappedBlockNumber;
	uint32_t blockNo;
    status_t status;
    status = StatusOk;

    if (argc != 2) {
    	status = StatusParameter1;
    }

    if (StatusOk == status) {
    	status = uint32_ConvertAtoi(argv[1], &blockNo);
    }

    if (StatusOk == status) {
    	status = forceRemapFromPool( (uint16_t) blockNo, &remappedBlockNumber, 0, NULL);
    }

    if (StatusOk == status) {
    	sprintf(buff, "block %u repmapped to %u\r\n", (uint16_t) blockNo, remappedBlockNumber);
    	Console_WriteString(buff);
    }

    return status;

} // cliRemapFileSystemBlockTable


static status_t cliDumpRemapTable(uint16_t argc, uint8_t **argv)
{
	char buff[50];

    status_t status;
    status = StatusOk;

	sprintf(buff, "magic 1 %08x\r\n", remapMagicNumber1);
	Console_WriteString(buff);
	sprintf(buff, "magic 2 %08x\r\n", remapMagicNumber2);
	Console_WriteString(buff);
	sprintf(buff, "magic 3 %08x\r\n", remapMagicNumber3);
	Console_WriteString(buff);
	sprintf(buff, "magic 4 %08x\r\n", remapMagicNumber4);
	Console_WriteString(buff);

    for (uint16_t block = 0; block < TC58_BLOCKS_PER_UNIT; block++) {

        uint16_t remappedBlock;
        if (StatusOk == status) {
        	status = getRemapBlockNumber(block, &remappedBlock);
        }

        // Be kind to Chan N (higher level), remap all status for upstream
        if (StatusOk != status) {
        	status = StatusResultDiskError;
        }

    	// Start a new line?
		if (0 == (block % 10)) {
			sprintf(buff, "\r\n%-4u : ", block);
			Console_WriteString(buff);
		}

		if (BLOCK_NOT_AVAILABLE != lRemapTable.physicalBlock[block]) {
			sprintf(buff, "%6u", lRemapTable.physicalBlock[block]);
		} else {
			sprintf(buff, "%6s", "----");
		}
		Console_WriteString(buff);
    }

    return status;

} // cliDumpRemapTable

bool isBlank(uint8_t *pageBuffer, uint32_t pageSize)
{
	bool blank;

	blank = true;
	for (uint32_t i = 0; i < pageSize; i++) {
		if (0xFF != pageBuffer[i]) {
			blank = false;
			break;
		}
	}
	return blank;
}

static status_t cliBlankCheckRemapTable(uint16_t argc, uint8_t **argv)
{
#warning Possible stack risk, large buffer on stack
	uint8_t pageBuffer[TC58_MAX_BYTES_PER_PAGE];

	char buff[50];

    status_t status;
    status = StatusOk;

	uint32_t pageSize;
    if (StatusOk == status) {
    	status = Tc58Flash_DoIoControl(Tc58IoctlGetTc58PageSize, &pageSize);
    }

	uint32_t pagesPerBlock;
    if (StatusOk == status) {
    	status = Tc58Flash_DoIoControl(Tc58IoctlGetSectorsPerBlock, &pagesPerBlock);
    }

    sprintf(buff, "Page Size: %lu, pagesPerBlock: %lu\r\n", pageSize, pagesPerBlock);
	Console_WriteString(buff);

    if (StatusOk == status) {

		for (uint16_t block = 0; block <= BI_FILE_SYSTEM_LAST_BLOCK; block++) {

			// Start a new line?
			if (0 == (block % 10)) {
				sprintf(buff, "\r\n%-4u : ", block);
				Console_WriteString(buff);
			}

			// setup remapped "block" in address's "block" field
			Tc58PageAddress_t addr;
			addr.block = lRemapTable.physicalBlock[block];
			if (BLOCK_NOT_AVAILABLE == addr.block) {
				sprintf(buff, "%6s", "Map?");
				Console_WriteString(buff);
				continue;
			}

			uint32_t page;
			for (page = 0; page < pagesPerBlock; page++) {

				addr.page = page;

				// Since we've already remapped, the next operation is on a physical page
				status = Tc58FlashPhysical_ReadOnePage(addr, pageBuffer);
				if (StatusOk != status) {
					sprintf(buff, "%6s", "Map?");
					Console_WriteString(buff);
					break;
				}

				if (!(isBlank(pageBuffer, pageSize))) {
					sprintf(buff, "%6s", "X");
					Console_WriteString(buff);
					break;
				}
			}

			// If we passed through all pages in the entire block, and no issues
			// were found, show spaces in the dumped map.
			if (page == pagesPerBlock) {
				sprintf(buff, "%6s", "-");
				Console_WriteString(buff);
			}
		}
    }

    return status;

} // cliBlankCheckRemapTable

static status_t block_Erase(uint16_t blockNumber)
{
    status_t status;

	if (blockNumber > TC58_BLOCKS_PER_UNIT) {
		status = StatusParameter1;
	} else {
    	status = Tc58Physical_EraseBlockRestricted (blockNumber);
    }

	// We care about tracking this status, use macro to feed status to SW Unit control.
	return returnStatus(status, eSucIoctlStatus);

} // block_Erase

// Public functions bodies ---------------------------------------------------

status_t Tc58Block_ReturnStatus(void)
{
    status_t status;
    status = StatusOk;

    if (!initialized) {
        status = StatusDiskNoInit;
    }

	if (status == StatusOk) {
    	status = Tc58FlashPhysical_ReturnStatus( );
    }

    // We care about tracking this status, use macro to feed status to SW Unit control.
    return returnStatus(status, eSucIoctlStatus);

} // Tc58Logical_ReturnStatus



status_t Tc58Block_ReadOnePage(Tc58PageAddress_t addr, uint8_t *pReadBuffer)
{
#ifdef LOCAL_DEBUG_TRACE
	uint8_t buff[50];
	sprintf(buff, "<RR %u/%u>", addr.block, addr.page);
	Console_WriteString(buff);
#endif

	status_t status;
    status = StatusOk;

    if (!initialized) {
        status = StatusNotInitialized;
    }

    // Is the block being read subject to a forced failure?
	if (addr.block == failBlockRead) {
		failBlockRead = BLOCK_NOT_AVAILABLE;
    	status = StatusResultDiskError;
	}

    uint16_t remappedBlock;
    if (StatusOk == status) {
    	status = getRemapBlockNumber(addr.block, &remappedBlock);

    }

	if (traceBlockRead != BLOCK_NOT_AVAILABLE) {
		if (traceBlockRead != addr.block) {
			traceBlockRead = addr.block;

			uint8_t buff[50];
			sprintf(buff, "<RB %u>", addr.block);
			Console_WriteString(buff);

			if (addr.block != remappedBlock) {
				sprintf(buff, "[%u]", remappedBlock);
				Console_WriteString(buff);
			}
		}
	}

    if (StatusOk == status) {
		addr.block = remappedBlock;
		status = Tc58FlashPhysical_ReadOnePage(addr, pReadBuffer);
	}

    // Be kind to Chan N (higher level), remap all status for upstream
    if (StatusOk != status) {
    	status = StatusResultDiskError;
    }

	// We care about tracking this status, use macro to feed status to SW Unit control.
    return returnStatus(status, eSucReadStatus);

} // Tc58Block_ReadOnePage

status_t Tc58Block_WriteOnePage(Tc58PageAddress_t addr, uint8_t *pWriteBuffer)
{
#ifdef LOCAL_DEBUG_TRACE
	uint8_t buff[50];
	sprintf(buff, "<WR %u/%u>", addr.block, addr.page);
	Console_WriteString(buff);
#endif

	if (traceBlockWrite != BLOCK_NOT_AVAILABLE) {
		if (traceBlockWrite != addr.block) {
			traceBlockWrite = addr.block;

			uint8_t buff[50];
			sprintf(buff, "<WB %u>", addr.block);
			Console_WriteString(buff);
		}
	}


	status_t status;
    status = StatusOk;

    if (!initialized) {
        status = StatusNotInitialized;
    }

    if (StatusOk == status) {

    	// Write one physical page, if it fails, attempt up to 5 times to remap
    	for (uint16_t attempt = 1; attempt <= 5; attempt++) {

    	    uint16_t remappedBlock;
    	    if (StatusOk == status) {
    	    	status = getRemapBlockNumber(addr.block, &remappedBlock);
    	    }

    	    if (StatusOk == status) {
    	    	Tc58PageAddress_t remappedAddr;
    			remappedAddr.block = remappedBlock;
    			remappedAddr.page = addr.page;

    	    	status = Tc58FlashPhysical_WriteOnePage(remappedAddr, pWriteBuffer);
    	    }

    	    // Is the address being written subject to a forced failure?
    		if ( (addr.block == failBlockWrite.block) &&
    			 (addr.page == failBlockWrite.page) )	{
    			failBlockWrite.block = BLOCK_NOT_AVAILABLE;
    	    	status = StatusResultDiskError;
    		}

			// The remainder of the code in this block (below) deals with detecting
			// and recovering (remapping and copy adjusting) from write failures.
			// So, if the previous "WriteOnePage" succeeded, then skip the remainder of this code.
			if (StatusOk == status) {
				break;
			}

			uint8_t buff[80];
			sprintf(buff, "status: %u -> attempt: %u, ", status, attempt);
			Console_WriteString(buff);

			if (status == StatusFlashScratchPadBlock) {
				status = forceRemapFromPool(BI_SCRATCHPAD_BLOCK, &remappedBlock, addr.page, pWriteBuffer);
				sprintf(buff, "Status %u, Scratchpad block: %u, remapped to: %u\r\n", status, BI_SCRATCHPAD_BLOCK, remappedBlock);

			} else {
				status = forceRemapFromPool(addr.block, &remappedBlock, addr.page, pWriteBuffer);
				sprintf(buff, "Status %u, block: %u remapped %u\r\n", status, addr.block, remappedBlock);
			}
			Console_WriteString(buff);

			// If remap was successful, then move all data from original page to the remapped page...
			if (StatusOk == status) {

				#warning Possible stack risk, large buffer on stack
				uint8_t pageBuffer[TC58_MAX_BYTES_PER_PAGE];
				Tc58PageAddress_t addrSource;
				Tc58PageAddress_t addrDestination;

				addrSource = addr;
				addrDestination.block = remappedBlock;

				for (uint16_t page = 0; page < 64; page++) {

					addrSource.page = page;
					addrDestination.page = page;

					Tc58FlashPhysical_ReadOnePage(addrSource, pageBuffer);
					Tc58FlashPhysical_WriteOnePage(addrDestination, pageBuffer);
				}
			}
    	}
	}

    // Be kind to Chan N (higher level), remap all status for upstream
    if (StatusOk != status) {
    	status = StatusResultDiskError;
    }

	// We care about tracking this status, use macro to feed status to SW Unit control.
    return returnStatus(status, eSucWriteStatus);

} // Tc58Block_WriteOnePage

status_t Tc58Block_EraseAndRemapDevice(void)
{
	char buff[50];

    status_t status;
    status = StatusOk;

	// Step 1) Prepare remap table
	if (StatusOk == status) {

		memset(&lRemapTable, 0, sizeof(lRemapTable));

	    // Pass 1 - Pass through all blocks formatting as you go
		for (uint16_t block = 0; block < TC58_BLOCKS_PER_UNIT; block++) {

			status_t eraseStatus;
			eraseStatus = block_Erase(block);

	    	// If the block looks good...
			if (StatusOk == eraseStatus) {

				// ... then store its own block number in its own entry the remap table
				lRemapTable.physicalBlock[block] = block;

			} else {

				// ... otherwise mark this block as being "USED" (invalid)
				lRemapTable.physicalBlock[block] = BLOCK_NOT_AVAILABLE;

				sprintf(buff, "Block %u, Status %d\r\n", block, eraseStatus);
				Console_WriteString(buff);

			}
		}

		// Pass 2 - Pass through only relocatable blocks, and remap any unavailable blocks found there into the pool
		uint16_t poolBlock = BI_POOL_FIRST_BLOCK;
		for (uint32_t block = BI_FIRST_REMAPPABLE_BLOCK; block <= BI_LAST_REMAPPABLE_BLOCK; block++) {

			// Does this block need a re-assignment?
			if (BLOCK_NOT_AVAILABLE == lRemapTable.physicalBlock[block]) {

				status = StatusOk;
				do {

					// If we've used half the pool just to format, thats too much
					if (poolBlock > BI_POOL_MID_POINT) {
						status = StatusTooManyBadBlocks;
						break;
					}
					else if (BLOCK_NOT_AVAILABLE == lRemapTable.physicalBlock[poolBlock]) {
						poolBlock++;
					} else {
						lRemapTable.physicalBlock[block] = poolBlock;
						lRemapTable.physicalBlock[poolBlock++] = BLOCK_NOT_AVAILABLE;
						break;
					}

				}  while (StatusOk == status);

				// Too many bad blocks?
				if (StatusTooManyBadBlocks == status) {
					break;
				}
			}
		}
	}

	// Now that the chip has been erased, zap page buffer
	if (StatusOk == status) {
		status = Tc58Flash_DoIoControl(Tc58IoctlPageBufferReset, NULL);

		// If buffer returns status because its not initialized, that's OK. Remap that to StatusOk.
		if (StatusNotInitialized == status) {
			status = StatusOk;
		}
	}

	// Store the remap table
	if (StatusOk == status) {

		lRemapTable.magicNumber1 = remapMagicNumber1;
		lRemapTable.magicNumber2 = remapMagicNumber2;
		lRemapTable.magicNumber3 = remapMagicNumber3;
		lRemapTable.magicNumber4 = remapMagicNumber4;

		// The remap table is stored in the last block's, first page of flash
    	Tc58PageAddress_t addr;
		addr.block = lRemapTable.physicalBlock[BI_REMAP_BLOCK_FIXED_BLOCK];
		addr.page = 0;
		status = Tc58FlashPhysical_Write(addr, (uint8_t *) &lRemapTable, sizeof(lRemapTable)-4);

		// If not OK, remap status to indicate a roached remap table block
		if (StatusOk != status) {
			status = StatusFlashRamapTableBlock;
		} else {
			uint32_t mkfsIndication;
			mkfsIndication = true;
			status = Tc58Flash_DoIoControl(Tc58IoctlPutMkfsIndication, &mkfsIndication);
		}
	}

	return status;

} // Tc58Block_EraseAndRemapDevice


status_t Tc58Block_Init(void)
{
    status_t status;
    status = StatusOk;

    if (initialized) {
        status = StatusAlreadyInitialized;
    }

    // Inital access to remap table
	if (StatusOk == status) {

		// Read the remap table into RAM
		Tc58PageAddress_t addr;
		addr.block = BI_REMAP_BLOCK_FIXED_BLOCK;
		addr.page = 0;
		status = Tc58FlashPhysical_Read(addr, (uint8_t *) &lRemapTable, sizeof(lRemapTable)-4);

		// If not OK, remap status to indicate a roached
		if (StatusOk != status) {
			status = StatusFlashRamapTableBlock;
		}
	}

	// If we have successfully read, check for remap table.
	if (StatusOk == status) {

		// If the remap magic number signatures are not OK, then attempt to erase and remap the device
		if ( (remapMagicNumber1 != lRemapTable.magicNumber1) ||
		     (remapMagicNumber2 != lRemapTable.magicNumber2) ) {
			status = Tc58Block_EraseAndRemapDevice ();
		}
	}

	// The remap table is now setup, make sure the lower level (physical) driver knows
	// where the scratchpad is located.
	if (StatusOk == status) {
		uint32_t scratchPadBlock32Bits;
		scratchPadBlock32Bits = lRemapTable.physicalBlock[BI_SCRATCHPAD_BLOCK];
		status = Tc58Flash_DoIoControl(Tc58IoctlPutScratchPadBlockNumber, &scratchPadBlock32Bits);
	}

	// Provide the physical driver with the number of file system blocks
	if (StatusOk == status) {
		uint32_t numberFsBlocks;
		numberFsBlocks = BI_FILE_SYSTEM_LAST_BLOCK - BI_FILE_SYSTEM_FIRST_BLOCK + 1;
		status = Tc58Flash_DoIoControl(Tc58IoctlPutNumberOfFsBlocks, &numberFsBlocks);
	}

	// Setup CLI commands and initialize cli variables.
	if (StatusOk == status) {
		status = Console_ExportCommandsToCli (&exportedReg, commandList);

		// Initialize or re-initialize
		traceBlockWrite = BLOCK_NOT_AVAILABLE;
		traceBlockRead = BLOCK_NOT_AVAILABLE;
		failBlockWrite.block = BLOCK_NOT_AVAILABLE;
		failBlockRead = BLOCK_NOT_AVAILABLE;

		initialized = true;
	}

    // We care about tracking this status, use macro to feed status to SW Unit control.
    return returnStatus(status, eSucInitStatus);

} // Tc58Block_Init

status_t Tc58Block_Ioctl(Tc58_Block_Ioctl_t ioctlCode, uint16_t blockNumberIn, uint16_t *pBlockNumberOut)
{
	status_t status;

	status = StatusOk;

	switch (ioctlCode)
	{
		case Tc58BlockIoctlGetRemappedBlock:
			if (blockNumberIn > BI_LAST_REMAPPABLE_BLOCK) {
				status = StatusBlockNumber;
				break;
			}

			if (NULL == pBlockNumberOut) {
				status = StatusParameter3;
				break;
			}

			*pBlockNumberOut = lRemapTable.physicalBlock[blockNumberIn];
			break;

		case Tc58BlockIoctlGetScratchPadBlockNum:
			if (NULL == pBlockNumberOut) {
				status = StatusParameter3;
				break;
			}

			*pBlockNumberOut = lRemapTable.physicalBlock[BI_SCRATCHPAD_BLOCK];
			break;


		case Tc58BlockIoctlZapBlockFromRemap:
			status = zapBlockFromRemap(blockNumberIn);
			break;

		case Tc58BlockIoctlGetRemapFixedBlockNumber:
			if (NULL == pBlockNumberOut) {
				status = StatusParameter2;
			} else {
				*pBlockNumberOut = BI_REMAP_BLOCK_FIXED_BLOCK;
			}
			break;

		// The ioctl code is incorrect.
		default:
			status = StatusParameter1;
			break;
	}

	return status;

} // Tc58Block_Ioctl

/// SAEC Kinetic Vision, Inc  ----------- END OF FILE

