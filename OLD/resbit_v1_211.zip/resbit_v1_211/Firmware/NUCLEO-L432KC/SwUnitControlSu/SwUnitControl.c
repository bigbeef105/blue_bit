/**
  @file       SwUnitControl.c

  @copyright  (C) 2019 Kinetic Vision, Cincinnati Ohio.
               This software is property of SAEC Kinetic Vision, Inc
               and is considered confidential.

  @brief      "SwUnitControl", software unit "C" file.

  @author     Sherman Couch

  @ingroup    SwUnitsGroup

  Configuration History
  =====================

  Config Item    | Value
  -------------- | -----
  Config #       | NA
  Revision       | NA
  Revised, Date  | NA
  QA, Date       | NA
  Approved, Date | NA
  Released, Date | NA

  Significant Modification History (Most recent at top)
  =====================================================

  Date         | Initials | Details
  ------------ | -------- | -------
  01 Aug 2019  | SC       |

  Theory of Operation
  ===================
  - Provides methods and data types for managing configuration of software units.
  - Provides methods and data types for obtaining status software units.

  */

// Includes ------------------------------------------------------------------

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

#include "../StatusSu/Status.h"
#include "../ConsoleSu/Console.h"

#include "SwUnitControl.h"

// Private macros ------------------------------------------------------------

#define MAGIC_NUMBER_1 0x04121861
#define MAGIC_NUMBER_2 0x04091865

#define ARRAY_DIMENSION(__a__) (sizeof(__a__)/sizeof(__a__[0]))

// Private types -------------------------------------------------------------

/// Stored and retrieved from FLASH (outside of the file system).
/// Important: When the data structure is re-mapped, be sure to change the magic numbers, this
///            will ensure that the structure is re-initialized when the new firmware
///            starts for the first time.
typedef struct {

	// used internally to establish data structure confidence
	uint32_t magicNumber1;

	bool enabled[SUC_NUMBER_OF_SW_UNITS_LIST];

	// used internally to establish data structure confidence
	uint32_t magicNumber2;

} swUnitsConfig_t;

typedef struct {
	uint32_t initStatusOk;
	uint32_t initNotStatusOk;
	uint16_t initNotOkLineOfCode;
	status_t initNotOkStatusCode;

	uint32_t readStatusOk;
	uint32_t readNotStatusOk;
	uint16_t readNotOkLineOfCode;
	status_t readNotOkStatusCode;

	uint32_t writeStatusOk;
	uint32_t writeNotStatusOk;
	uint16_t writeNotOkLineOfCode;
	status_t writeNotOkStatusCode;

	uint32_t ioctlStatusOk;
	uint32_t ioctlNotStatusOk;
	uint16_t ioctlNotOkLineOfCode;
	status_t ioctlNotOkStatusCode;

} swUnitsStatistics_t;

/// Each software unit has a simple status member associated with it.
typedef struct {
	status_t initStatus;

	// Tracks whether the correspondig s/w unit is enabled for execution
	bool enabled;

	// Statistics of the SU
	swUnitsStatistics_t stats;

} swUnitsStatus_t;


// Private function prototypes -----------------------------------------------
static status_t cliEnable(uint16_t argc, uint8_t **argv);
static status_t cliStats(uint16_t argc, uint8_t **argv);
static status_t cliLineOfCode(uint16_t argc, uint8_t **argv);

// Private constants ---------------------------------------------------------
static const consoleCommand_t commandList[] = {

	{
		.pCommand = "enable",
		.pUsage = "enable software unit\r\n\t" "usage: enable [swuNumber] [0|1]",
		.pHandlerFn = cliEnable,
	},


	{
		.pCommand = "loc",
		.pUsage = "line of code with status not OK. Format: line/XX.  XX = 2 digit status code.\r\n\t" "usage: loc [zero]",
		.pHandlerFn = cliLineOfCode,
	},


    {
		.pCommand = "stats",
		.pUsage = "statistics software units\r\n\t"	"usage: stats [zero]",
		.pHandlerFn = cliStats,
    },

	// Marks last element in the list
    { NULL, NULL, NULL },
};

static const uint8_t *pSuNames[SUC_NUMBER_OF_SW_UNITS_LIST] = {
	[eSucAdcSu] = "ADC",
	[eSucConsoleSu] = "Console",
	[eSucDataAggregSu] = "Dat Agr",
	[eSucDataReceiverSu] = "Data Rx",
	[eSucFifoSu] = "CSV FIFO",
	[eSucGpioSu] = "GPIO",
	[eSucI2cSu] = "I2C",
	[eSucBno055Su] = "BNO055",
	[eSucLis2de12Su] = "LIS2DE12",
	[eSucMs5837] = "MS5837",
	[eSucRtcSu] = "RTC",
	[eSucTc58FlashLogicalSu] = "TC58 Log",
	[eSucTc58FlashBufferSu] = "TC58 Bff",
	[eSucTc58BlockSu] = "TC58 Blk",
	[eSucTc58FlashPhysicalSu] = "TC58 Phy",
	[eSucTc58FlashUtilitySu] = "TC58 Utl",
	[eSucTimerSu] = "Timer",
	[eSucUsartSu] = "Usart",
	[eSucSwUnitControlSu] = "Su Ctrl",
	[eSucPowerSu] = "Power",
	[eSucUserInterfaceSu] = "UI",
	[eSucNvPartitionSu] = "NVP",
	[eSucBlueBitsSu] = "BlueBits",
	[eSucCrcSu] = "CRC",
	[eSucMessagerSu] = "Msgr",
	[eSucPacketSu] = "Packet",
	[eSucProtocolHalSu] = "PrHal",
	[eSucProtocolHandlerSu] = "PrHdlr",
	[eSucSysTimeSu] = "SysTime",
	[eSucSplitBufferSu] = "SBuffer",
	[eSucBase64Su] = "Base64",
	[eSucSummaryDataSu] = "SumData",
	[eSucWakeSummarySu] = "WakeSumm",
	[eSucHallThreshSummarySu] = "HallSumm",
};


// Private constants ---------------------------------------------------------

// Private variables ---------------------------------------------------------

static bool initialized = false;

static consoleRegistration_t exportedReg = {
    (consoleCommand_t *) commandList, // .pList =
    NULL, // .pNext =
};

// Statistics are stored in this "stats" structure.
static swUnitsStatistics_t stats[SUC_NUMBER_OF_SW_UNITS_LIST];

// Private function bodies ---------------------------------------------------

static status_t cliLineOfCode(uint16_t argc, uint8_t **argv)
{
	uint8_t buff[132];
	status_t status;

	status = StatusOk;

	// Stats can be displayed or zeroized.  Which one are we doing?
	if (argc > 1) {
		if (0 == strcmp("zero", argv[1])) {
			for (uint16_t i = 0; i < ARRAY_DIMENSION(pSuNames); i++) {
				stats[i].initNotOkLineOfCode = 0;
				stats[i].readNotOkLineOfCode = 0;
				stats[i].writeNotOkLineOfCode = 0;
				stats[i].ioctlNotOkLineOfCode = 0;

				stats[i].initNotOkStatusCode = 0;
				stats[i].readNotOkStatusCode = 0;
				stats[i].writeNotOkStatusCode = 0;
				stats[i].ioctlNotOkStatusCode = 0;
			}

		} else {
			status = StatusParameter1;
		}
	} else {

		sprintf(buff, "%-10s%13s%13s%13s%13s\r\n",
			"SW",
			"Init",
			"Read",
			"Write",
			"Ioctl");
		Console_WriteString(buff);

		for (uint16_t i = 0; i < ARRAY_DIMENSION(pSuNames); i++) {
			sprintf(buff, "%-10s%10u/%02u%10u/%02u%10u/%02u%10u/%02u",
				pSuNames[i],
				stats[i].initNotOkLineOfCode,
				stats[i].initNotOkStatusCode,
				stats[i].readNotOkLineOfCode,
				stats[i].readNotOkStatusCode,
				stats[i].writeNotOkLineOfCode,
				stats[i].writeNotOkStatusCode,
				stats[i].ioctlNotOkLineOfCode,
				stats[i].ioctlNotOkStatusCode);

			Console_WriteString(buff);
			Console_WriteString("\r\n");
		}
	}

	return status;

} // cliLineOfCode

static status_t cliStats(uint16_t argc, uint8_t **argv)
{
	uint8_t buff[132];
	status_t status;

	status = StatusOk;

	// Stats can be displayed or zeroized.  Which one are we doing?
	if (argc > 1) {
		if (0 == strcmp("zero", argv[1])) {
			uint8_t *p;
			uint16_t sizeofStats;

			sizeofStats = sizeof(stats);
			p = (uint8_t *) &stats;

			while (sizeofStats--) {
				*p++ = 0;
			}
		} else {
			status = StatusParameter1;
		}
	} else {

		sprintf(buff, "%-8s%13s%16s%16s%16s\r\n",
			"SW",
			"Init",
			"Read",
			"Write",
			"Ioctl");
		Console_WriteString(buff);

		sprintf(buff, "%-8s%8s%8s%8s%8s%8s%8s%8s%8s\r\n",
			"Unit",
			"Ok",
			"NotOk",
			"Ok",
			"NotOk",
			"Ok",
			"NotOk",
			"Ok",
			"NotOk");
		Console_WriteString(buff);

		for (uint16_t i = 0; i < ARRAY_DIMENSION(pSuNames); i++) {
			sprintf(buff, "%-8s%8lu%8lu%8lu%8lu%8lu%8lu%8lu%8lu",
				pSuNames[i],
				stats[i].initStatusOk,
				stats[i].initNotStatusOk,
				stats[i].readStatusOk,
				stats[i].readNotStatusOk,
				stats[i].writeStatusOk,
				stats[i].writeNotStatusOk,
				stats[i].ioctlStatusOk,
				stats[i].ioctlNotStatusOk);

			Console_WriteString(buff);
			Console_WriteString("\r\n");
		}
	}

	return status;

} // cliStats

static status_t cliEnable(uint16_t argc, uint8_t **argv)
{
	return StatusOk;

} // cliEnable

// Public functions bodies ---------------------------------------------------

status_t SwUnitControl_Init(void)
{
    status_t status;
    status = StatusOk;

    if (initialized) {
        status = StatusAlreadyInitialized;
    }

    if (status == StatusOk) {
    	status = Console_ExportCommandsToCli (&exportedReg, commandList);
    }

    if (status == StatusOk) {

    	// Record a successful initialization
    	initialized = true;
    }

	return status;

} // SwUnitControl_Init


// Note: by design, this function reflects the input status "statusIn", back to the caller.
status_t SwUnitControl_WriteStatus(SwUnitControlId_t suId, SwUnitControlStatusType_t statusType, status_t statusIn, uint16_t lineOfCode)
{
    status_t status;
    status = StatusOk;

    // Note: By design, "writing status" does not "care" regarding initialization status.
    //       Do not check initializaton status.

    // Check parameter 1
    if (status == StatusOk) {
        if (suId >= SUC_NUMBER_OF_SW_UNITS_LIST) {
        	status = StatusParameter1;
        }
    }

    // Check parameter 2
    if (status == StatusOk) {
		if (statusType >= SUC_NUMBER_OF_STATUS_TYPES) {
        	status = StatusParameter2;
		}
    }

    // If OK, process status passed, into a statistic passed in
    if (status == StatusOk)
    {
    	if (statusIn == StatusOk) {
			switch (statusType) {
				case eSucInitStatus:
					stats[suId].initStatusOk++;
					break;

				case eSucReadStatus:
					stats[suId].readStatusOk++;
					break;

				case eSucWriteStatus:
					stats[suId].writeStatusOk++;
					break;

				case eSucIoctlStatus:
					stats[suId].ioctlStatusOk++;
					break;
				default:
					break;
			}

		} else {

			// Status que empties are ignored (neither OK, nor not OK)
			if (statusIn != StatusQueueEmpty) {
				switch (statusType) {
					case eSucInitStatus:
						stats[suId].initNotStatusOk++;
						stats[suId].initNotOkLineOfCode = lineOfCode;
						stats[suId].initNotOkStatusCode = statusIn;
						break;

					case eSucReadStatus:
						stats[suId].readNotStatusOk++;
						stats[suId].readNotOkLineOfCode = lineOfCode;
						stats[suId].readNotOkStatusCode = statusIn;
						break;

					case eSucWriteStatus:
						stats[suId].writeNotStatusOk++;
						stats[suId].writeNotOkLineOfCode = lineOfCode;
						stats[suId].writeNotOkStatusCode = statusIn;
						break;

					case eSucIoctlStatus:
						stats[suId].ioctlNotStatusOk++;
						stats[suId].ioctlNotOkLineOfCode = lineOfCode;
						stats[suId].ioctlNotOkStatusCode = statusIn;
						break;
					default:
						break;
				}
			}
		}
    } else {
        // If the input parameters are faulty, the programmer needs to fix this. Although
        // this is technically an out of band error, return this status so that the
        // programmer finds the defect.

    	return status;
    }

    // Status information processed, return input status.
	return statusIn;

} // SwUnitControl_WriteStatus


/// SAEC Kinetic Vision, Inc  ----------- END OF FILE
