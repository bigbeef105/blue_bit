/**
  @file       DualPressTemp.c

  @copyright  (C) 2020 Kinetic Vision, Cincinnati Ohio.
               This software is property of SAEC Kinetic Vision, Inc 
               and is considered confidential.

  @brief      DualPressTemp software unit "C" file.

  @author     aloebs

  @ingroup    DualPressTempSoftwareUnit 

  Configuration History
  =====================

  Config Item    | Value
  -------------- | -----
  Config #       | NA
  Revision       | NA
  Revised, Date  | NA
  QA, Date       | NA
  Approved, Date | NA
  Released, Date | NA

  Significant Modification History (Most recent at top)
  =====================================================

  Date         | Initials | Details
  ------------ | -------- | -------
  May 13, 2020 | ASL      | Original

  Theory of Operation
  ===================
  Manages multiplexer and Ms5837 operation to run dual pressure/temp sensors

*/

// Includes ------------------------------------------------------------------

#include "DualPressTemp.h"

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

#include "../MultiplexerSu/Multiplexer.h"
#include "../Ms5837Su/Ms5837.h"

// Private macros ------------------------------------------------------------

// Private constants ---------------------------------------------------------

// Private types -------------------------------------------------------------
typedef enum {
    dualPTReadStateStart = 0,
    dualPTReadStateSelectSensor0,
    dualPTReadStateReadSensor0,
    dualPTReadStateSelectSensor1,
    dualPTReadStateReadSensor1,
} dualPTReadStates_t;

// Private constants ---------------------------------------------------------

// Private variables ---------------------------------------------------------
static bool initialized = false;
static uint8_t sensorChannel0;
static uint8_t sensorChannel1;

static dualPTReadStates_t dualPTReadState;

static bool storePressure;
static bool storeTemp;

static connectorDataHandler_t * dataHandlerOut = NULL;
static void (*readCallback)(void);

static connectorDataHandler_t dataHandlerHold = { 0 };

// Private function prototypes -----------------------------------------------
static void childCallback(void);
static status_t handleReadState(bool start);

static status_t readMs5837(ms5837Ids_t sensorId);
static status_t shiftHoldData(ms5837Ids_t sensorId);

// Private function bodies ---------------------------------------------------
static void childCallback(void)
{
    handleReadState(false);
}
        
static status_t handleReadState(bool start)
{
    status_t status = StatusOk;
    
    if (start) dualPTReadState = dualPTReadStateStart;
    
    switch (dualPTReadState) {
        case dualPTReadStateStart:
            dualPTReadState = dualPTReadStateSelectSensor0;
            status = Multiplexer_SetChannelAsync(sensorChannel0, childCallback);
            break;
        case dualPTReadStateSelectSensor0:
            dualPTReadState = dualPTReadStateReadSensor0;
            status = readMs5837(ms5837Id_0);
            break;
        case dualPTReadStateReadSensor0:
            status = shiftHoldData(ms5837Id_0);
            if (StatusOk == status) {
                dualPTReadState = dualPTReadStateSelectSensor1;
                status = Multiplexer_SetChannelAsync(sensorChannel1, childCallback);
            }
            break;
        case dualPTReadStateSelectSensor1:
            dualPTReadState = dualPTReadStateReadSensor1;
            status = readMs5837(ms5837Id_1);
            break;
        case dualPTReadStateReadSensor1:
            status = shiftHoldData(ms5837Id_1);
            // Shield callback with status OK since we call below on bad statuses
            if (StatusOk == status) {
                if (readCallback) readCallback();
            }
            break;
        default:
            status = StatusCodePath;
            break;
    }
    
    // upon bad status, exit to callback
    if (StatusOk != status) {
        if (readCallback) readCallback();
    }
    
    return status;
}

static status_t readMs5837(ms5837Ids_t sensorId)
{
    if (storePressure) {
        if (storeTemp) {
            // Press and temp
            return Ms5837_ReadPressureTemp(sensorId, &dataHandlerHold, childCallback);
        } else {
            // Only pressure
            return Ms5837_ReadPressure(sensorId, &dataHandlerHold, childCallback);
        }
    } else {
        // Only temp
            return Ms5837_ReadTemp(sensorId, &dataHandlerHold, childCallback);
    }
}

static status_t shiftHoldData(ms5837Ids_t sensorId)
{
    if (!dataHandlerOut) {
        return StatusCodePath; // shouldn't be able to reach here
    }
    
    if (storePressure && storeTemp) {
        if (ms5837Id_0 == sensorId) {
            dataHandlerOut->data[0].float32 = dataHandlerHold.data[0].float32;
            dataHandlerOut->data[1].float32 = dataHandlerHold.data[1].float32;
        } else {
            dataHandlerOut->data[2].float32 = dataHandlerHold.data[0].float32;
            dataHandlerOut->data[3].float32 = dataHandlerHold.data[1].float32;
        }
    } else {
        if (ms5837Id_0 == sensorId) {
            dataHandlerOut->data[0].float32 = dataHandlerHold.data[0].float32;
        } else {
            dataHandlerOut->data[1].float32 = dataHandlerHold.data[0].float32;
        }
    }
    
    return StatusOk;
}

// Public functions bodies ---------------------------------------------------
status_t DualPressTemp_Init(void)
{
    status_t status = StatusOk;
            
    status = Ms5837_Init();
    if (StatusOk == status) {
        status = Multiplexer_Init();
    }
    if (StatusOk == status) {
        int channelBit = 0;
        
        // Hunt first sensor
        while (StatusOk == status) {
        	if (channelBit == MULTIPLEXER_NUM_CHANNELS) {
        		// Exit if we've exceeded max
				status = StatusInstanceNotFound;
        	} else {
				// Set the channel
				uint8_t channel = 1 << channelBit;
				status = Multiplexer_SetChannel(channel);
				if (StatusOk == status) {
					// Check if there's an ms5837 on this channel
					status_t channelStatus = Ms5837_SetupSensor(ms5837Id_0);
					if (StatusOk == channelStatus) {
						// We found the ms5837
						sensorChannel0 = channel;
						break; // exit loop
					} else {
						channelBit++;
					}
				}
        	}
        }
        
        // Hunt second sensor
        channelBit++;
        while (StatusOk == status) {
        	if (channelBit == MULTIPLEXER_NUM_CHANNELS) {
        		// Exit if we've exceeded max
				status = StatusInstanceNotFound;
        	} else {
				// Set the channel
				uint8_t channel = 1 << channelBit;
				status = Multiplexer_SetChannel(channel);
				if (StatusOk == status) {
					// Check if there's an ms5837 on this channel
					status_t channelStatus = Ms5837_SetupSensor(ms5837Id_1);
					if (StatusOk == channelStatus) {
						// We found the ms5837
						sensorChannel1 = channel;
						break; // exit loop
					} else {
						channelBit++;
					}
				}
        	}
        }
    }
    
    if (StatusOk == status) {
        initialized = true;
    }
    
    return status;
}

status_t DualPressTemp_ReadPressure(connectorDataHandler_t * dataOut, void (*callback)(void))
{
    status_t status = StatusOk;
    
    if (!dataOut || !callback) {
        status = StatusNullParameter;
    }
    
    if (StatusOk == status) {
        dataHandlerOut = dataOut;
        readCallback = callback;
        
        storePressure = true;
        storeTemp = false;
        
        status = handleReadState(true);
    }
    
    return status;
}

status_t DualPressTemp_ReadTemp(connectorDataHandler_t * dataOut, void (*callback)(void))
{
    status_t status = StatusOk;
    
    if (!dataOut || !callback) {
        status = StatusNullParameter;
    }
    
    if (StatusOk == status) {
        dataHandlerOut = dataOut;
        readCallback = callback;
        
        storePressure = false;
        storeTemp = true;
        
        status = handleReadState(true);
    }
    
    return status;
}

status_t DualPressTemp_ReadPressureTemp(connectorDataHandler_t * dataOut, void (*callback)(void))
{
    status_t status = StatusOk;
    
    if (!dataOut || !callback) {
        status = StatusNullParameter;
    }
    
    if (StatusOk == status) {
        dataHandlerOut = dataOut;
        readCallback = callback;
        
        storePressure = true;
        storeTemp = true;
        
        status = handleReadState(true);
    }
    
    return status;
}

/// SAEC Kinetic Vision, Inc. ----------- END OF FILE
