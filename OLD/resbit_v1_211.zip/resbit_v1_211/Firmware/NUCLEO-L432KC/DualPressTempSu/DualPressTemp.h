/**
  @file       DualPressTemp.h

  @copyright  (C) 2020 Kinetic Vision, Cincinnati Ohio.
               This software is property of SAEC Kinetic Vision, Inc 
               and is considered confidential.

  @brief      DualPressTemp software unit "H" file.

  @author     aloebs

  @defgroup   DualPressTempSoftwareUnit

  Configuration History
  =====================

  Config Item    | Value
  -------------- | -----
  Config #       | NA
  Revision       | NA
  Revised, Date  | NA
  QA, Date       | NA
  Approved, Date | NA
  Released, Date | NA

  Significant Modification History (Most recent at top)
  =====================================================

  Date         | Initials | Details
  ------------ | -------- | -------
  May 13, 2020 | ASL      | Original

  Theory of Operation
  ===================
  Manages multiplexer and Ms5837 operation to run dual pressure/temp sensors

  */

// Define to prevent recursive inclusion -------------------------------------
#ifndef __DUALPRESSTEMP_H_
#define __DUALPRESSTEMP_H_

#include "../DataAggregatorSu/DataAggregator.h"
#include "../StatusSu/Status.h"

// Exported macro ------------------------------------------------------------

// Exported types ------------------------------------------------------------

// Exported constants --------------------------------------------------------

// Exported objects ----------------------------------------------------------

// Exported functions --------------------------------------------------------

///  @brief Initializes the DualPressTemp software unit
status_t DualPressTemp_Init(void);

///  @brief Reads pressure from both sensors
status_t DualPressTemp_ReadPressure(connectorDataHandler_t * dataOut, void (*callback)(void));

///  @brief Reads temperature from both sensors
status_t DualPressTemp_ReadTemp(connectorDataHandler_t * dataOut, void (*callback)(void));

///  @brief Reads pressure and temperature from both sensors
status_t DualPressTemp_ReadPressureTemp(connectorDataHandler_t * dataOut, void (*callback)(void));

#endif // __DUALPRESSTEMP_H_

/// SAEC Kinetic Vision, Inc. ----------- END OF FILE
