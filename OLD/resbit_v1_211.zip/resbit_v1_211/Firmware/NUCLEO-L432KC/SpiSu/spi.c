/**
  @file       Spi.c

  @copyright  (C) 2019 Kinetic Vision, Cincinnati Ohio.
               This software is property of SAEC Kinetic Vision, Inc
               and is considered confidential.

  @brief      Spi software unit "C" file.
  @author     Sherman Couch
  @ingroup    SpiName

  Configuration History
  =====================

  Config Item    | Value
  -------------- | -----
  Config #       | NA
  Revision       | NA
  Revised, Date  | NA
  QA, Date       | NA
  Approved, Date | NA
  Released, Date | NA

  Significant Modification History (Most recent at top)
  =====================================================

  Date         | Initials | Details
  ------------ | -------- | -------
  22 Jul 2019  | SC       | Original

  Theory of Operation
  ===================
  Spi communication is needed for interfacing with the external flash storage chip.

  */

// Includes ------------------------------------------------------------------

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

#include "stm32l4xx_hal.h"
#include "../StatusSu/Status.h"
#include "../SpiSu/spi.h"

// Private function prototypes -----------------------------------------------

// Private macros ------------------------------------------------------------

// Private constants ---------------------------------------------------------

// Private types -------------------------------------------------------------

// Private constants ---------------------------------------------------------

// Private variables ---------------------------------------------------------
static bool initialized = false;
SPI_HandleTypeDef hspi1;

// Private function bodies ---------------------------------------------------

// Public functions bodies ---------------------------------------------------
void HAL_SPI_MspInit(SPI_HandleTypeDef* spiHandle)
{
    GPIO_InitTypeDef GPIO_InitStruct = {0};
    if(spiHandle->Instance==SPI1)
    {
		/* SPI1 clock enable */
		__HAL_RCC_SPI1_CLK_ENABLE();
		
		/**SPI1 GPIO Configuration
		PA6     ------> SPI1_MISO
		PA7     ------> SPI1_MOSI
		PB3 (JTDO-TRACESWO)     ------> SPI1_SCK
		*/
		GPIO_InitStruct.Pin = GPIO_PIN_6|GPIO_PIN_7;
		GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
		GPIO_InitStruct.Pull = GPIO_PULLDOWN;
		GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
		GPIO_InitStruct.Alternate = GPIO_AF5_SPI1;
		HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

		GPIO_InitStruct.Pin = GPIO_PIN_3;
		GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
		GPIO_InitStruct.Pull = GPIO_NOPULL;
		GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
		GPIO_InitStruct.Alternate = GPIO_AF5_SPI1;
		HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);
    }
}

void HAL_SPI_MspDeInit(SPI_HandleTypeDef* spiHandle)
{
    if(spiHandle->Instance==SPI1)
    {
		/* Peripheral clock disable */
		__HAL_RCC_SPI1_CLK_DISABLE();

		/**SPI1 GPIO Configuration
		PA6     ------> SPI1_MISO
		PA7     ------> SPI1_MOSI
		PB3 (JTDO-TRACESWO)     ------> SPI1_SCK
		*/
		HAL_GPIO_DeInit(GPIOA, GPIO_PIN_6|GPIO_PIN_7);
		HAL_GPIO_DeInit(GPIOB, GPIO_PIN_3);
    }
} 

status_t Spi_Write(void *txBuffer, uint16_t bufferLength)
{
	status_t status;

    HAL_StatusTypeDef halStatus;
	halStatus = HAL_SPI_Transmit (&hspi1, (uint8_t*)txBuffer, bufferLength, 5000);

	// Remap from HAL status to project status type.
	if (HAL_OK == halStatus) {
		status = StatusOk;
	} else {
		status = StatusHal;
	}

	return status;
}

status_t Spi_WriteAndRead(void *txBuffer, void *rxBuffer, uint16_t length)
{
	status_t status;

    HAL_StatusTypeDef halStatus;
	halStatus = HAL_SPI_TransmitReceive (&hspi1, txBuffer, rxBuffer, length, 5000);

	// Remap from HAL status to project status type.
	if (HAL_OK == halStatus) {
		status = StatusOk;
	} else {
		status = StatusHal;
	}

	return status;
}

status_t Spi_Read(void *pBuffer, uint16_t sizeRequested)
{
	status_t status;

    HAL_StatusTypeDef halStatus;
	halStatus = HAL_SPI_Receive (&hspi1, (uint8_t*)pBuffer, sizeRequested, 5000);

	// Remap from HAL status to project status type.
	if (HAL_OK == halStatus) {
		status = StatusOk;
	} else {
		status = StatusHal;
	}

	return status;
}



status_t Spi_Init(void) {

    status_t status;
    status = StatusOk;

    if (initialized) {
        status = StatusAlreadyInitialized;
    }

    if (StatusOk == status) {
		hspi1.Instance = SPI1;
		hspi1.Init.Mode = SPI_MODE_MASTER;
		hspi1.Init.Direction = SPI_DIRECTION_2LINES;
		hspi1.Init.DataSize = SPI_DATASIZE_8BIT;
		hspi1.Init.CLKPolarity = SPI_POLARITY_LOW;
		hspi1.Init.CLKPhase = SPI_PHASE_1EDGE;
		hspi1.Init.NSS = SPI_NSS_SOFT;
		hspi1.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_2; // 13 Aug 2019 (SC) - Formerly: SPI_BAUDRATEPRESCALER_2;
		hspi1.Init.FirstBit = SPI_FIRSTBIT_MSB;
		hspi1.Init.TIMode = SPI_TIMODE_DISABLE;
		hspi1.Init.CRCCalculation = SPI_CRCCALCULATION_DISABLE;
		hspi1.Init.CRCPolynomial = 7;
		hspi1.Init.CRCLength = SPI_CRC_LENGTH_DATASIZE;
		hspi1.Init.NSSPMode = SPI_NSS_PULSE_ENABLE;
		if (HAL_SPI_Init(&hspi1) != HAL_OK)
		{
			status = StatusHal;
		}
    }

    if (StatusOk == status) {
    	initialized = true;
    }

	return status;
}

status_t Spi_DeInit(void){
    status_t status = StatusOk;

    if (initialized) {
    	HAL_StatusTypeDef halStatus = HAL_SPI_DeInit(&hspi1);
    	if(HAL_OK != halStatus){
    		status = StatusHal;
    	}
		initialized = false;
    }
    return status;
}

/// SAEC Kinetic Vision, Inc. ----------- END OF FILE
