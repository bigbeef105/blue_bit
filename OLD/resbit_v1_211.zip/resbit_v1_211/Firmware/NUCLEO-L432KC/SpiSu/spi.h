/**
  @file       Spi.h

  @copyright  (C) 2019 Kinetic Vision, Cincinnati Ohio.
               This software is property of SAEC Kinetic Vision, Inc
               and is considered confidential.

  @brief      Spi software unit "H" file.
  @author     Sherman Couch
  @defgroup   SpiName Serial peripheral Interface for flash storage communication

  Configuration History
  =====================

  Config Item    | Value
  -------------- | -----
  Config #       | NA
  Revision       | NA
  Revised, Date  | NA
  QA, Date       | NA
  Approved, Date | NA
  Released, Date | NA

  Significant Modification History (Most recent at top)
  =====================================================

  Date         | Initials | Details
  ------------ | -------- | -------
  22 Jul 2019  | SC       | Original.

  Theory of Operation
  ===================
  Spi communication is needed for interfacing with the external flash storage chip.

  */

// Define to prevent recursive inclusion -------------------------------------
#ifndef __SPI_H
#define __SPI_H

// Exported macro ------------------------------------------------------------

// Exported types ------------------------------------------------------------

// Exported constants --------------------------------------------------------

// Exported objects ----------------------------------------------------------

// Exported functions --------------------------------------------------------

///  @brief Initializes the Spi software unit
///  @details If this is needed, a verbose description of method. Otherwise just omit.
///  @todo If needed
///  @return StatusOk, StatusAlreadyInitialized
status_t Spi_Init(void);

///  @brief DeInitializes the Spi software unit
///  @return StatusOk, StatusHal.
status_t Spi_DeInit(void);

///  @brief Writes to the Spi device
///  @param args[in out]  buff - Pointer to a data data buffer which contains data
///                              to be written to the Spi device
///  @param args[in]      length - length of “buff”
///  @param
///  @return StatusOk, StatusHal.
status_t Spi_Write(void *buff, uint16_t length);

///  @brief Simultaneous write and read of a spi device
///  @param args[in]  txBuffer Pointer to a data data buffer which contains data
///                              to be written to the Spi device
///  @param args[out] rxBuffer Pointer to a data data buffer which contains data
///                            to be read from the Spi device
///  @param args[in]  length   Number of bytes to write and read.
///  @return StatusOk, StatusHal.
status_t Spi_WriteAndRead(void *txBuffer, void *rxBuffer, uint16_t length);

///  @brief Reads from a spi device
///  @param args[out] rxBuffer Pointer to a data data buffer which contains data
///                            to be read from the Spi device
///  @param args[in]  length   Number of bytes to read.
///  @return StatusOk, StatusHal.
status_t Spi_Read(void *rxBuffer, uint16_t length);

#endif // __SPI_H

/// SAEC Kinetic Vision, Inc. ----------- END OF FILE


status_t spi_Initialize(void);
