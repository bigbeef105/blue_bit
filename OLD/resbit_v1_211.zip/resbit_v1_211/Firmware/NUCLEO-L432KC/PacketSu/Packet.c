/**
  @file       Packet.c

  @copyright  (C) 2020 Kinetic Vision, Cincinnati Ohio.
               This software is property of SAEC Kinetic Vision, Inc
               and is considered confidential.

  @brief      Packet software unit "C" file.

  @author     Andrew Loebs

  @ingroup    PacketSoftwareUnit

  Configuration History
  =====================

  Config Item    | Value
  -------------- | -----
  Config #       | NA
  Revision       | NA
  Revised, Date  | NA
  QA, Date       | NA
  Approved, Date | NA
  Released, Date | NA

  Significant Modification History (Most recent at top)
  =====================================================

  Date         | Initials | Details
  ------------ | -------- | -------
  10 Feb 2020  | ASL      | Original

  Theory of Operation
  ===================
  Handles packing and unpacking messages between the Resbit and BLE MCU.

*/

// Includes ------------------------------------------------------------------

#include "Packet.h"

#include <string.h> // memcpy

#include "../SwUnitControlSu/SwUnitControl.h" // SwUnitControl_WriteStatus()
#include "../CrcSu/Crc.h" // CRC_SEED, Crc_Calc()

// Private function prototypes -----------------------------------------------
static status_t statusFromResCode(uint8_t resCode);

// Private macros ------------------------------------------------------------
#define returnStatus(__status__,__source__) SwUnitControl_WriteStatus(eSucPacketSu,__source__,__status__,__LINE__);

// Private constants ---------------------------------------------------------
#define PACKET_CRC_OFFSET                   2

#define RES_CODE_SUCCESS                    0x00
#define RES_CODE_CRC                        0x01
#define RES_CODE_INVALID_NUM_PACKETS        0x02
#define RES_CODE_INVALID_PACKET_NUM         0x03
#define RES_CODE_INVALID_DATA_LEN           0x04
#define RES_CODE_PACKET_ORDER               0x05
#define RES_CODE_DATA_LEN_MISMATCH          0x06
#define RES_CODE_UNKNOWN                    0x7F

// Private types -------------------------------------------------------------

// Private constants ---------------------------------------------------------

// Private variables ---------------------------------------------------------

// Private function bodies ---------------------------------------------------
static status_t statusFromResCode(uint8_t resCode)
{
    status_t status = StatusOk;

    switch (resCode) {
        case RES_CODE_SUCCESS:
            status = StatusOk;
            break;
        case RES_CODE_CRC:
            status = StatusComsCRC;
            break;
        case RES_CODE_INVALID_NUM_PACKETS:
            status = StatusComsInvalidNumPackets;
            break;
        case RES_CODE_INVALID_PACKET_NUM:
            status = StatusComsInvalidPacketNum;
            break;
        case RES_CODE_INVALID_DATA_LEN:
            status = StatusComsInvalidDataLen;
            break;
        case RES_CODE_PACKET_ORDER:
            status = StatusComsPacketOrder;
            break;
        case RES_CODE_DATA_LEN_MISMATCH:
            status = StatusComsDataLenMismatch;
            break;
        default:
            status = StatusComsUnknown;
            break;
    }

    return status;
}


// Public functions bodies ---------------------------------------------------
status_t Packet_Pack(packet_t * dest, const uint8_t * src, size_t len,
                           int numPackets, int packetNum)
{
    status_t status = StatusOk;

    // Input validation
    if ((dest == NULL) || (src == NULL))
        status = StatusNullParameter;
    if (len < 1)
        status = StatusBufferLength;

    if (Status_IsOk(status)) {
        dest->numPackets = numPackets;
        dest->packetNum = packetNum;
        dest->dataLen = len;
        memcpy(dest->data, src, len);

        dest->crc = CRC_SEED;
        uint8_t * crcStartAddress = dest->bytes + PACKET_CRC_OFFSET;
        status = Crc_Calc(&dest->crc, crcStartAddress,
                          len + PACKET_HEADER_LEN - PACKET_CRC_OFFSET);
    }

    return returnStatus(status, eSucIoctlStatus);
}

status_t Packet_ParseHeader(const packet_t * src, size_t len)
{
    status_t status = StatusOk;

    // Input validation
    if (src == NULL)
        status = StatusNullParameter;

    // Validate CRC
    if (Status_IsOk(status)) {
        uint16_t crc = CRC_SEED;
        const uint8_t * crcStartAddress = src->bytes + PACKET_CRC_OFFSET;
        status = Crc_Calc(&crc, crcStartAddress, len - PACKET_CRC_OFFSET);
        if (Status_IsOk(status)) {
            if (crc != src->crc) {
                status = StatusComsCRC;
            }
        }
    }
    // Validate number of packets
    if (Status_IsOk(status)) {
        if (0 == src->numPackets)
            status = StatusComsInvalidNumPackets;
    }
    // Validate packet num
    if (Status_IsOk(status)) {
        if (src->packetNum >= src->numPackets)
            status = StatusComsInvalidPacketNum;
    }
    // Validate data length
    if (Status_IsOk(status)) {
        size_t expectedLen = len - PACKET_HEADER_LEN;
        if (0 == src->dataLen)
            status = StatusComsInvalidDataLen;
        else if (expectedLen != src->dataLen)
            status = StatusComsDataLenMismatch;
    }

    return returnStatus(status, eSucIoctlStatus);
}

status_t Packet_ParseBody(uint8_t * dest, size_t maxLen, const packet_t * src)
{
    status_t status = StatusOk;

    // Input validation
    if ((dest == NULL) || (src == NULL))
        status = StatusNullParameter;
    else if (maxLen < 1)
        status = StatusBufferLength;

    // Make sure destination buffer has enough space
    if (Status_IsOk(status)) {
        if (src->dataLen > maxLen)
            status = StatusBufferLength;
    }

    // Copy data to destination buffer
    if (Status_IsOk(status)) {
        memcpy(dest, src->data, (size_t)src->dataLen);
    }

    return returnStatus(status, eSucIoctlStatus);
}

uint8_t Packet_GetResponseCode(status_t status)
{
    uint8_t resCode = 0;

    switch (status) {
        case StatusOk:
            resCode = RES_CODE_SUCCESS;
            break;
        case StatusComsCRC:
            resCode = RES_CODE_CRC;
            break;
        case StatusComsInvalidNumPackets:
            resCode = RES_CODE_INVALID_NUM_PACKETS;
            break;
        case StatusComsInvalidPacketNum:
            resCode = RES_CODE_INVALID_PACKET_NUM;
            break;
        case StatusComsInvalidDataLen:
            resCode = RES_CODE_INVALID_DATA_LEN;
            break;
        case StatusComsPacketOrder:
            resCode = RES_CODE_PACKET_ORDER;
            break;
        case StatusComsDataLenMismatch:
            resCode = RES_CODE_DATA_LEN_MISMATCH;
            break;
        default:
            resCode = RES_CODE_UNKNOWN;
            break;
    }

    return resCode;
}

status_t Packet_GenerateResponse(response_t * dest, uint8_t responseCode)
{
    status_t status = StatusOk;

    if (dest == NULL)
        status = StatusNullParameter;

    if (Status_IsOk(status)) {
        dest->code = responseCode;
        dest->crc = CRC_SEED;
        status = Crc_Calc(&dest->crc, &dest->code, 1);
    }

    return returnStatus(status, eSucIoctlStatus);
}

status_t Packet_ParseResponse(const response_t * res)
{
    status_t status = StatusOk;

    if (res == NULL)
        status = StatusNullParameter;

    uint16_t crc = CRC_SEED;
    if (Status_IsOk(status)) {
        status = Crc_Calc(&crc, &res->code, 1);
    }
    if (Status_IsOk(status)) {
        if (crc != res->crc)
            status = StatusComsResponseError;
    }
    if (Status_IsOk(status)) {
        status = statusFromResCode(res->code);
    }

    return returnStatus(status, eSucIoctlStatus);
}

/// SAEC Kinetic Vision, Inc. ----------- END OF FILE
