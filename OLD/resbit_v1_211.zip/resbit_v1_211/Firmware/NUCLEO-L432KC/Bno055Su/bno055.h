/**
  @file       bno055.h

  @copyright  (C) 2019 Kinetic Vision, Cincinnati Ohio.
               This software is property of SAEC Kinetic Vision, Inc
               and is considered confidential.

  @brief      Imu Bno055 software unit "H" file.
  @author     Parker Kamer
  @defgroup   ImuSu Inertial measurement unit data collection and interrupt handling

  Configuration History
  =====================

  Config Item    | Value
  -------------- | -----
  Config #       | NA
  Revision       | NA
  Revised, Date  | NA
  QA, Date       | NA
  Approved, Date | NA
  Released, Date | NA

  Significant Modification History (Most recent at top)
  =====================================================

  Date         | Initials | Details
  ------------ | -------- | -------
  23 Jul 2019  | SC/PK    | Update using standardized templates/function naming.
  01 Jul 2019  | PK       | Original

  Theory of Operation
  ===================
  The Bno055 IMU will be used to gather motion/orientation data to be logged into the
  external flash memory. The IMU will also trigger interrupts when active/inactive in order
  for the MCU to handle low power states and data logging processes.

  */

// Define to prevent recursive inclusion -------------------------------------
#ifndef __IMU_BNO055_SU_H
#define __IMU_BNO055_SU_H

#include "../DataAggregatorSu/DataAggregator.h"

// Exported macro ------------------------------------------------------------

// Exported types ------------------------------------------------------------
typedef union {
	struct {
		unsigned mapX : 2;
		unsigned mapY : 2;
		unsigned mapZ : 2;
		unsigned res1 : 2;
		unsigned signZ : 1;
		unsigned signY : 1;
		unsigned signX : 1;
		unsigned res2 : 5;
	} bits;
	uint8_t bytes[2];
} bno055AxisMapSignConfig_t;

typedef enum {
	bno055AxisMapValueX = 0,
	bno055AxisMapValueY,
	bno055AxisMapValueZ,
} bno055AxisMapValues_t;

typedef enum {
	bno055AxisSignValuePos = 0,
	bno055AxisSignValueNeg,
} bno055AxisSignValues_t;

typedef struct {
	float accData[3];
	float gyrData[3];
	float magData[3];
	float quatData[4];
	float eulerData[3];
}imuDataHandler_t;

typedef enum {
	imuIoctlLowPow,
	imuIoctlNormalPow,
	imuIoctlSuspendPow,
	imuIoctlReadPow,

	imuIoctlDataRdy,

	NUM_IMU_IOCTL
} imuIoctl_t;

// Exported constants --------------------------------------------------------
#define BNO055_ACC_UNIT_MG	1
#define BNO055_ACC_UNIT_MS2	100
#define BNO055_MAG_UNIT_UT	16
#define BNO055_GYR_UNIT_DPS 16
#define BNO055_GYR_UNIT_RPS 900
#define BNO055_QUAT_UNIT_QUAT 16384
#define BNO055_EUL_UNIT_D 16
#define BNO055_EUL_UNIT_R 900
// Exported objects ----------------------------------------------------------
extern volatile bool StreamTestFlag;
// Exported functions --------------------------------------------------------

///  @brief Initializes the BNO055 IMU
///  @return StatusOk, StatusAlreadyInitialized, StatusImuChipId,
/// 		 StatusHal, StatusHalTimeout
status_t Bno055_Init(void);

///  @brief Read all data from IMU into dataOut, calls callback when complete
///  @return StatusOk, StatusHal
status_t Bno055_ReadData(imuSettings_t * settings, imuDataHandler_t * dataOut, void (*callback)(void));

///  @brief Read the accelerometer data from the BNO055
///  @param [in out] ptrReturnData - Pointer to a buffer which contains data
/// 								 read from the accelerometer registers
///  @return StatusOk, StatusHal
status_t Bno055_ReadAccData(float *ptrReturnData);

///  @brief Read the gyroscope data from the BNO055
///  @param [in out] ptrReturnData - Pointer to a buffer which contains data
/// 								 read from the gyroscope registers
///  @return StatusOk, StatusHal
status_t Bno055_ReadGyrData(float *ptrReturnData);

///  @brief Read the magnetometer data from the BNO055
///  @param [in out] ptrReturnData - Pointer to a buffer which contains data
/// 								 read from the magnetometer registers
///  @return StatusOk, StatusHal
status_t Bno055_ReadMagData(float *ptrReturnData);

///  @brief Read the sensor fusion data (Quaternions) from the BNO055
///  @param [in out] ptrReturnData - Pointer to a buffer which contains data
/// 								 read from the sensor fusion registers
///  @return StatusOk, StatusHal
status_t Bno055_ReadQuatData(float *ptrReturnData);

///  @brief Read the sensor fusion data (Euler Angles) from the BNO055
///  @param [in out] ptrReturnData - Pointer to a buffer which contains data
/// 								 read from the sensor fusion registers
///  @return StatusOk, StatusHal
status_t Bno055_ReadEulerData( float *ptrReturnData );

///  @brief Initializes the gpio software unit
///  @param [in] axisConfig - axis configuration value
///  @param [in] signConfig - sign configuration value
///  @return StatusOk, StatusHal
status_t Bno055_SetAxisDirections(uint8_t axisConfig, uint8_t signConfig);

///  @brief Initializes the gpio software unit
///  @param [in out] axisConfig - Pointer to a variable which will hold
/// 							  the axis configuration value
///  @param [in out] signConfig- Pointer to a variable which will hold
/// 							 the sign configuration value
///  @return StatusOk, StatusHal
status_t Bno055_GetAxisDirections(uint8_t* axisConfig, uint8_t* signConfig);

///  @brief Handle IO control commands for the bno055
///  @param [in out] ioctlCode - Command id
///  @param [in out] outData- Output data from the ioctl command
///  @return StatusOk, StatusHal
status_t Bno055_Ioctl(imuIoctl_t ioctlCode,  uint8_t* outData);

///  @brief Calibrate the accelerometer and the gyroscope on the bno055
///  @return StatusOk, StatusHal
status_t Bno055_CalibrateMode(void);

#endif // __IMU_BNO055_SU_H

/// SAEC Kinetic Vision, Inc. ----------- END OF FILE
