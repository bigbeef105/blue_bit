/**
  @file       bno055.c

  @copyright  (C) 2019 Kinetic Vision, Cincinnati Ohio.
               This software is property of SAEC Kinetic Vision, Inc
               and is considered confidential.

  @brief      Imu Bno055 software unit "C" file.
  @author     Parker Kamer
  @ingroup    ImuSu

  Configuration History
  =====================

  Config Item    | Value
  -------------- | -----
  Config #       | NA
  Revision       | NA
  Revised, Date  | NA
  QA, Date       | NA
  Approved, Date | NA
  Released, Date | NA

  Significant Modification History (Most recent at top)
  =====================================================

  Date         | Initials | Details
  ------------ | -------- | -------
  23 Jul 2019  | SC/PK    | Update using standardized templates/function naming.
  01 Jul 2019  | PK       | Original

  Theory of Operation
  ===================
  The Bno055 IMU will be used to gather motion/orientation data to be logged into the
  external flash memory. The IMU will also trigger interrupts when active/inactive in order
  for the MCU to handle low power states and data logging processes.

*/

// Includes ------------------------------------------------------------------
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <math.h>

#include "stm32l4xx_hal.h"
#include "../Middlewares/Third_Party/FatFs/src/ff.h"
#include "../StatusSu/Status.h"
#include "../ConsoleSu/Console.h"
#include "../GpioSu/Gpio.h"
#include "../I2cSu/i2c.h"
#include "../SwUnitControlSu/SwUnitControl.h"
#include "../PowerSu/power.h"
#include "../RtcSu/rtc.h"
#include "../ConfigSu/Config.h"
#include "../DataAggregatorSu/DataAggregator.h"
#include "../UserInterfaceSu/UserInterface.h"
#include "../UtilitySu/Utility.h"
#include "fatfs.h"

#include "bno055.h"

// Private macros ------------------------------------------------------------
/// This macro feeds status information for tracking purposes to software unit control.
#define returnStatus(__status__,__source__) SwUnitControl_WriteStatus(eSucBno055Su,__source__,__status__,__LINE__);

// Private constants ---------------------------------------------------------
#define BNO055_I2C_ADDRESS 			0x28 << 1
#define BNO055_CHIP_ID_VAL 			0xA0
#define BNO055_I2C_TIMEOUT_VAL		20 // ms

// Private types -------------------------------------------------------------
typedef enum {
    chipId,
    accId,
    magId,
    gyrId,
    swRevIdLsb,
    swRevIdMsb,
    blRevId,
    page0Id,
    accXLsb,
    accXMsb,
    accYLsb,
    accYMsb,
    accZLsb,
    accZMsb,
    magXLsb,
    magXMsb,
    magYLsb,
    magYMsb,
    magZLsb,
    magZMsb,
    gyrXLsb,
    gyrXMsb,
    gyrYLsb,
    gyrYMsb,
    gyrZLsb,
    gyrZMsb,
    eulHeadingLsb,
    eulHeadingMsb,
    eulRollLsb,
    eulRolMsb,
    eulPitchLsb,
    eulPitchMsb,
    quatDataWLsb,
    quatDataWMsb,
    quatDataXLsb,
    quatDataXMsb,
    quatDataYLsb,
    quatDataYMsb,
    quatDataZLsb,
    quatDataZMsb,
    liaDataXLsb,
    liaDataXMsb,
    liaDataYLsb,
    liaDataYMsb,
    liaDataZLsb,
    liaDataZMsb,
    grvDataXLsb,
    grvDataXMsb,
    grvDataYLsb,
    grvDataYMsb,
    grvDataZLsb,
    grvDataZMsb,
    temp,
    calibStat,
    stResult,
    intSta,
    sysClkStatus,
    sysStatus,
    sysErr,
    unitSel,
    //0x3C Reserved
    oprMode = 0x3D,
    pwrMode,
    sysTrigger,
    tempSource,
    axisMapConfig,
    axisMapSign,
    //0x43 - 0x54 Reserved
    accOffsetXLsb = 0x55,
    accOffsetXMsb,
    accOffsetYLsb,
    accOffsetYMsb,
    accOffsetZLsb,
    accOffsetZMsb,
    magOffsetXLsb,
    magOffsetXMsb,
    magOffsetYLsb,
    magOffsetYMsb,
    magOffsetZLsb,
    magOffsetZMsb,
    gyrOffsetXLsb,
    gyrOffsetXMsb,
    gyrOffsetYLsb,
    gyrOffsetYMsb,
    gyrOffsetZLsb,
    gyrOffsetZMsb,
    accRadiusLsb,
    accRadiusMsb,
    magRadiusLsb,
    magRadiusMsb,
    //0x6B - 0x7F Reserved
}bno055RegisterMap0_t;

typedef enum {
    //0x00 - 0x06 Reserved
    page1Id = 0x07,
    accConfig,
    magConfig,
    gyrConfig0,
    gyrConfig1,
    accSleepConfig,
    gyrSleepConfig,
    reserved0e,
    intMsk,
    intEn,
    accAmThres,
    accIntSettings,
    accHgDuration,
    accHgThres,
    accNmThres,
    accNmSet,
    gyrIntSeting,
    gyrHrXSet,
    gyrDurX,
    gyrHrYSet,
    gyrDurY,
    gyrHrZSet,
    gyrDurZ,
    gyrAmThres,
    gyrAmSet,
    //0x20 - 0x4F Reserved
    uniqueId = 0x50 //0x50 - 0x5F
    //0x60 - 0x7F Reserved
}bno055RegisterMap1_t;

//Operation Mode Values
typedef enum {
    oprModeConfigMode,
    oprModeAccOnly,
    oprModeMagOnly,
    oprModeGyrOnly,
    oprModeAccMag,
    oprModeAccGyro,
    oprModeMagGyro,
    oprModeAmg,
    oprModeImu,
    oprModeCompass,
    oprModeM4g,
    oprModeNdofFmcOff,
    oprModeNdof
}oprModeValues_t;

//Power Mode Values
typedef enum {
    pwrModeNormal,
    pwrModeLowPower,
    pwrModeSuspended
}pwrModeValues_t;

//Accel Config Data
typedef enum {
    accRange2G,
    accRange4G,
    accRange8G,
    accRange16G,
}accRangeValues_t;
typedef enum {
    acc7_81hz,
    acc15_63hz,
    acc31_25hz,
    acc62_5hz,
    acc125hz,
    acc250hz,
    acc500hz,
    acc1000hz
}accBandwidthValues_t;
typedef enum {
    accNormalMode,
    accSuspendMode,
    accLowPower1Mode,
    accStandbyMode,
    accLowPower2Mod,
    accDeepSuspend
}accOperationModeValues_t;
typedef enum {
    accLinearMs2,
    accGravityMg
}acc_unit_values;

//Gyro Config Data
typedef enum {
    gyrRange2000dps,
    gyrRange1000dps,
    gyrRange500dps,
    gyrRange250dps,
    gyrRange125dps
}gyrRangeValues_t;
typedef enum {
    gyr523hz,
    gyr230hz,
    gyr116hz,
    gyr47hz,
    gyr23hz,
    gyr12hz,
    gyr64hz,
    gyr32hz
}gyrBandwidthValues_t;
typedef enum {
    gyrNormalMode,
    gyrFastPwrUp,
    gyrDeepSuspend,
    gyrSuspendMode,
    gyrAdvancePwrSaveMode
}gyrOperationModeValues_t;
typedef enum {
    gyrAngularRateDps,
    gyrAngularRateRps
}gyrUnitValues_t;

//Mag Config Data
typedef enum {
    mag2hz,
    mag6hz,
    mag8hz,
    mag10hz,
    mag15hz,
    mag20hz,
    mag25hz,
    mag30hz,
}magDataOutputRateValues_t;
typedef enum {
    magLowPwrMode,
    magRegularMode,
    magEnhancedRegularMode,
    magHighAccuracy
}magOperationModeValues_t;
typedef enum {
    magPwrModeNormal,
    magPwrModeSleep,
    magPwrModeSuspend,
    magPwrModeForced
}magPowerModeValues_t;

//Other Unit Values
typedef enum {
    eulerAnglesDegrees,
    eulerAnglesRadians
}eulerUnitValues_t;
typedef enum {
    tempDegreesC,
    tempDegreesF
}tempUnitValues_t;
typedef enum {
    fusionDataFormatWindows,
    fusionDataFormatAndroid
}fusionFormatUnitValues_t;

//Accel Settings
typedef union {
    struct{
        uint8_t accRange:2;
        uint8_t accBandwidth:3;
        uint8_t accOperationMode:3;
    }bits;
    uint8_t byte;
}accConfig_t;

typedef struct {
    uint8_t accUnitConversion;
    accConfig_t accConfig;
}accSettings_t;

//Gyro Settings
typedef union {
    struct{
        uint8_t gyrRange:3;
        uint8_t gyrBandwidth:3;
    }bits;
    uint8_t byte;
}gyrConfig_t;

typedef struct {
    uint8_t gyrUnitConversion;
    gyrConfig_t gyrConfig;
    uint8_t gyrOperationMode;
}gyrSettings_t;

//Mag Settings
typedef union {
    struct{
        uint8_t magOutputRate:3;
        uint8_t magOperationMode:2;
        uint8_t magPowerMode:2;
    }bits;
    uint8_t byte;
}magConfig_t;

typedef struct {
    magConfig_t magConfig;
}magSettings_t;

//Unit Selection
typedef union{
    struct{
        uint8_t accUnits:1;
        uint8_t gyrUnits:1;
        uint8_t eulerUnits:1;
        uint8_t reserved1:1;
        uint8_t tempUnits:1;
        uint8_t reserved2:2;
        uint8_t fusionFormat:1;
    }bits;
    uint8_t byte;
}unitSel_t;

//Interrupt Settings
typedef union {
    struct{
        uint8_t reserved0:1;
        uint8_t reserved1:1;
        uint8_t gyroAnyMotion:1;
        uint8_t gyrHighRate:1;
        uint8_t reserved4:1;
        uint8_t accHighG:1;
        uint8_t accAnyMotion:1;
        uint8_t accNoMotion:1;
    }bits;
    uint8_t byte;
}interruptModeSettings_t;

typedef union {
    struct{
        uint8_t anyMotionDur:2;
        uint8_t xAxisAnyMotionNoMotion:1;
        uint8_t yAxisAnyMotionNoMotion:1;
        uint8_t zAxisAnyMotionNoMotion:1;
        uint8_t xAxisHighG:1;
        uint8_t yAxisHighG:1;
        uint8_t zAxisHighG:1;
    }bits;
    uint8_t byte;
}accInterruptSettings_t;

typedef union {
    struct{
        uint8_t slowMotionNoMotionSel:1;
        uint8_t slowMotionNoMotionDur:6;
        uint8_t reserved7:1;
    }bits;
    uint8_t byte;
}accNmSettings_t;

//Master Settings Struct
typedef struct {
    pwrModeValues_t pwrSetting;//power mode value
    oprModeValues_t oprSetting;//operation mode value

    accSettings_t bno055Acc;
    gyrSettings_t bno055Gyr;
    magSettings_t bno055Mag;

    interruptModeSettings_t intConfig;
    accInterruptSettings_t accIntConfig;
    accNmSettings_t accNmConfig;
    uint8_t accAmThreshold;
    uint8_t accNmThreshold;

    unitSel_t unitSel;
}bno055Settings_t;

typedef enum {
    accXLsbIndex = 0,
    accXMsbIndex,
    accYLsbIndex,
    accYMsbIndex,
    accZLsbIndex,
    accZMsbIndex,
    magXLsbIndex,
    magXMsbIndex,
    magYLsbIndex,
    magYMsbIndex,
    magZLsbIndex,
    magZMsbIndex,
    gyrXLsbIndex,
    gyrXMsbIndex,
    gyrYLsbIndex,
    gyrYMsbIndex,
    gyrZLsbIndex,
    gyrZMsbIndex,
    eulHeadingLsbIndex,
    eulHeadingMsbIndex,
    eulRollLsbIndex,
    eulRolMsbIndex,
    eulPitchLsbIndex,
    eulPitchMsbIndex,
    quatDataWLsbIndex,
    quatDataWMsbIndex,
    quatDataXLsbIndex,
    quatDataXMsbIndex,
    quatDataYLsbIndex,
    quatDataYMsbIndex,
    quatDataZLsbIndex,
    quatDataZMsbIndex,
    
    I2C_BUFFER_LEN,
} i2cBufferIndices_t;

// Private function prototypes -----------------------------------------------
static status_t writeRegister(uint8_t reg, uint8_t data);
static status_t changeRegisterPage(uint8_t pageNum);
static status_t initBno055Settings(bno055Settings_t *ptrSettings);
static status_t configurePowerMode( uint8_t settingsByte );
static status_t readPowerMode( uint8_t* settingsByte);
static status_t configureOperationMode( oprModeValues_t settingsByte );
static status_t setCalibration(uint8_t* pBuffer, bno055RegisterMap0_t startReg);

static void overlappedCallback(status_t status);
static status_t processData(imuSettings_t * settings, imuDataHandler_t * dataOut, uint8_t * rawBuffer, size_t len);

// Private variables ---------------------------------------------------------
bno055Settings_t Bno055CurrSettings;

static bool initialized = false;

static float GyroBias[3]  = {0, 0, 0};
static int16_t AccelBias[3] = {0, 0, 0};

static uint8_t I2CReadBuffer[I2C_BUFFER_LEN];
static uint8_t I2CWriteBuffer[2];

static i2cHandle_t i2cHandle;
static volatile overlapped_t i2cOverlapped;

imuSettings_t * imuSettings;
imuDataHandler_t * dataHandlerOut;
void (*readDataCallback)(void);

// Private function bodies ---------------------------------------------------
static status_t writeRegister(uint8_t reg, uint8_t data)
{
	status_t status;
	uint8_t returnData;

	uint8_t registerInfo[2] = {reg, data};

	status = I2C_Write(i2cHandle, registerInfo, 2, BNO055_I2C_TIMEOUT_VAL);

	if(status == StatusOk){
		//Confirm correct settings
		status = I2C_MemRead(i2cHandle, reg, 1, &returnData, 1,
				BNO055_I2C_TIMEOUT_VAL);
		if(StatusOk == status){
			if(returnData != data){
				status = StatusHal;
			}
		}
	}

	return status;
}

static status_t changeRegisterPage(uint8_t page_num)
{
	return writeRegister(page0Id, page_num);
}

static status_t initBno055Settings(bno055Settings_t *ptrSettings)
{
	//ptrSettings->oprSetting = oprModeAccOnly;
	//ptrSettings->oprSetting = oprModeAmg;
	//ptrSettings->oprSetting = oprModeConfigMode;
	ptrSettings->oprSetting = oprModeNdof;

	//ptrSettings->pwrSetting = pwrModeLowPower; //run in normal mode while testing other software units
	//ptrSettings->pwrSetting = pwrModeNormal;
	ptrSettings->pwrSetting = pwrModeSuspended;

	//Unit Selection
	ptrSettings->unitSel.bits.accUnits = accGravityMg;
	ptrSettings->unitSel.bits.gyrUnits = gyrAngularRateDps;
	ptrSettings->unitSel.bits.eulerUnits = eulerAnglesDegrees;
	ptrSettings->unitSel.bits.tempUnits = tempDegreesF;
	ptrSettings->unitSel.bits.fusionFormat = fusionDataFormatWindows;

	//Accel Settings
	ptrSettings->bno055Acc.accConfig.bits.accRange = accRange2G;
	ptrSettings->bno055Acc.accConfig.bits.accBandwidth = acc125hz;
	ptrSettings->bno055Acc.accConfig.bits.accOperationMode = accNormalMode;
	ptrSettings->bno055Acc.accUnitConversion = BNO055_ACC_UNIT_MG;

	//Gyro Settings
	ptrSettings->bno055Gyr.gyrConfig.bits.gyrRange = gyrRange2000dps;
	ptrSettings->bno055Gyr.gyrConfig.bits.gyrBandwidth = gyr523hz;
	ptrSettings->bno055Gyr.gyrOperationMode = gyrNormalMode;
	ptrSettings->bno055Gyr.gyrUnitConversion = BNO055_GYR_UNIT_DPS;

	//Mag Settings
	ptrSettings->bno055Mag.magConfig.bits.magOutputRate = mag30hz;
	ptrSettings->bno055Mag.magConfig.bits.magOperationMode = magRegularMode;
	ptrSettings->bno055Mag.magConfig.bits.magPowerMode = magPwrModeForced;

	//Interrupt Settings
	ptrSettings->intConfig.bits.reserved0 = 0;
	ptrSettings->intConfig.bits.reserved1 = 0;
	ptrSettings->intConfig.bits.gyroAnyMotion = 0;
	ptrSettings->intConfig.bits.gyrHighRate = 0;
	ptrSettings->intConfig.bits.reserved4 = 0;
	ptrSettings->intConfig.bits.accHighG = 0;
	ptrSettings->intConfig.bits.accAnyMotion = 0;
	ptrSettings->intConfig.bits.accNoMotion = 0;

	ptrSettings->accIntConfig.bits.anyMotionDur = 0x3;
	ptrSettings->accIntConfig.bits.xAxisAnyMotionNoMotion = 0;//1;
	ptrSettings->accIntConfig.bits.yAxisAnyMotionNoMotion = 0;//1;
	ptrSettings->accIntConfig.bits.zAxisAnyMotionNoMotion = 0;//1;
	ptrSettings->accIntConfig.bits.xAxisHighG = 0;
	ptrSettings->accIntConfig.bits.yAxisHighG = 0;
	ptrSettings->accIntConfig.bits.zAxisHighG = 0;

	ptrSettings->accNmConfig.bits.slowMotionNoMotionSel = 1;
	ptrSettings->accNmConfig.bits.slowMotionNoMotionDur = 0x5;
	ptrSettings->accNmConfig.bits.reserved7 = 0;

	ptrSettings->accAmThreshold = 0x0A; //39.1mg
	ptrSettings->accNmThreshold = 0x0A; //39.1mg

	return StatusOk;
}

static status_t configurePowerMode( uint8_t settingsByte)
{
	return writeRegister(pwrMode, settingsByte);
}

static status_t readPowerMode( uint8_t* settingsByte)
{
	return I2C_MemRead(i2cHandle, pwrMode, 1, settingsByte, 1,
			BNO055_I2C_TIMEOUT_VAL);
}

static status_t configureOperationMode( oprModeValues_t settingsByte)
{
	return writeRegister(oprMode, settingsByte);
}

static status_t setCalibration(uint8_t* pBuffer, bno055RegisterMap0_t startReg)
{
	status_t status = StatusOk;
	for(int i = 0; i < 6; i++){
		status = writeRegister(startReg+i, pBuffer[i]);
	}
	return returnStatus(status, eSucWriteStatus);
}

static void overlappedCallback(status_t status)
{
	// TODO: handle bad statuses
    processData(imuSettings, dataHandlerOut, I2CReadBuffer, sizeof(I2CReadBuffer));
    if (readDataCallback) {
        readDataCallback();
    }
}

static status_t processData(imuSettings_t * settings, imuDataHandler_t * dataOut, uint8_t * rawBuffer, size_t len)
{
    status_t status = StatusOk;
    
    if (!settings || !dataOut || !rawBuffer) {
        status = StatusNullParameter;
    }
    if (len < I2C_BUFFER_LEN) {
        status = StatusBufferLength;
    }
    
    if (StatusOk == status) {
        //Accel ========================================================================================================
        if (settings->accelEnabled) {
            int16_t accelX = (int16_t)((((int32_t)(int8_t)(I2CReadBuffer[1])) << 8) | (I2CReadBuffer[0]));
            int16_t accelY = (int16_t)((((int32_t)(int8_t)(I2CReadBuffer[3])) << 8) | (I2CReadBuffer[2]));
            int16_t accelZ = (int16_t)((((int32_t)(int8_t)(I2CReadBuffer[5])) << 8) | (I2CReadBuffer[4]));
        
            dataOut->accData[0] = (float)accelX / Bno055CurrSettings.bno055Acc.accUnitConversion;
            dataOut->accData[1] = (float)accelY / Bno055CurrSettings.bno055Acc.accUnitConversion;
            dataOut->accData[2] = (float)accelZ / Bno055CurrSettings.bno055Acc.accUnitConversion;
        }
    
        //Mag ==========================================================================================================
        if (settings->magEnabled) {
            int16_t magX = (int16_t)((((int32_t)(int8_t)(I2CReadBuffer[7])) << 8) | (I2CReadBuffer[6]));
            int16_t magY = (int16_t)((((int32_t)(int8_t)(I2CReadBuffer[9])) << 8) | (I2CReadBuffer[8]));
            int16_t magZ = (int16_t)((((int32_t)(int8_t)(I2CReadBuffer[11])) << 8) | (I2CReadBuffer[10]));
        
            dataOut->magData[0] = (float)magX / BNO055_MAG_UNIT_UT;
            dataOut->magData[1] = (float)magY / BNO055_MAG_UNIT_UT;
            dataOut->magData[2] = (float)magZ / BNO055_MAG_UNIT_UT;
        }
    
        //Gyro =========================================================================================================
        if (settings->gyroEnabled) {
            int16_t gyroX = (int16_t)((((int32_t)(int8_t)(I2CReadBuffer[13])) << 8) | (I2CReadBuffer[12]));
            int16_t gyroY = (int16_t)((((int32_t)(int8_t)(I2CReadBuffer[15])) << 8) | (I2CReadBuffer[14]));
            int16_t gyroZ = (int16_t)((((int32_t)(int8_t)(I2CReadBuffer[17])) << 8) | (I2CReadBuffer[16]));
        
            dataOut->gyrData[0] = (float)gyroX / Bno055CurrSettings.bno055Gyr.gyrUnitConversion;
            dataOut->gyrData[1] = (float)gyroY / Bno055CurrSettings.bno055Gyr.gyrUnitConversion;
            dataOut->gyrData[2] = (float)gyroZ / Bno055CurrSettings.bno055Gyr.gyrUnitConversion;
        }
    
        //Quat =========================================================================================================
        // We need to process this if the euler data is requested
        float qData[4];
        if (settings->quatEnabled || settings->eulerEnabled) {
            int16_t quatW = (int16_t)((((int32_t)(int8_t)(I2CReadBuffer[25])) << 8) | (I2CReadBuffer[24]));
            int16_t quatX = (int16_t)((((int32_t)(int8_t)(I2CReadBuffer[27])) << 8) | (I2CReadBuffer[26]));
            int16_t quatY = (int16_t)((((int32_t)(int8_t)(I2CReadBuffer[29])) << 8) | (I2CReadBuffer[28]));
            int16_t quatZ = (int16_t)((((int32_t)(int8_t)(I2CReadBuffer[31])) << 8) | (I2CReadBuffer[30]));
        
            dataOut->quatData[0] = qData[0] = (float)quatW / BNO055_QUAT_UNIT_QUAT;
            dataOut->quatData[1] = qData[1] = (float)quatX / BNO055_QUAT_UNIT_QUAT;
            dataOut->quatData[2] = qData[2] = (float)quatY / BNO055_QUAT_UNIT_QUAT;
            dataOut->quatData[3] = qData[3] = (float)quatZ / BNO055_QUAT_UNIT_QUAT;
        }
    
        //Euler Angles =================================================================================================
        if (settings->eulerEnabled) {
            float eData[3];
            // yaw (z-axis rotation)
            eData[0] = -atan2f(qData[0] * qData[0] - qData[1] * qData[1] + qData[2] * qData[2] - qData[3] * qData[3],
                              2.0f * (qData[1] * qData[2] - qData[0] * qData[3]));
        
            //Convert to degrees per second
            dataOut->eulerData[0] = eData[0] * 180 / M_PI;
            dataOut->eulerData[0] += -6.0f;
            if(dataOut->eulerData[0] < 0){
                dataOut->eulerData[0] += 360.0f;
            }
        
            // pitch (y-axis rotation)
            eData[2] = asinf(2.0f * (qData[2] * qData[3] + qData[0] * qData[1]));
            //Convert to degrees per second
            dataOut->eulerData[2] = eData[2] * 180 / M_PI;
        
            // roll (x-axis rotation)
            eData[1] = atan2f(2.0f * (qData[0] * qData[2] - qData[1] * qData[3]),
                             qData[0] * qData[0] - qData[1] * qData[1] - qData[2] * qData[2] + qData[3] * qData[3]);
            //Convert to degrees per second
            dataOut->eulerData[1] = eData[1] * 180 / M_PI;
        }
    }
    
    return status;
}

#if 1
static status_t writeCalibFile(void)
{
	status_t status = StatusOk;
	FATFS* USBDISKFatFs;
	FIL* calibFile;
	FRESULT res;
	char buff[50];
	UINT stringSize = 0;
	UINT bw = 0;

	USBDISKFatFs = FATFS_GetFileSystem();
	calibFile = FATFS_GetConfigFile();

	res = f_mount(USBDISKFatFs, "", 1);
	if(FR_OK != res){
		status = StatusFatFsMount;
	}

	if (StatusOk == status) {
		res = f_open(calibFile, "tare.txt", FA_OPEN_EXISTING | FA_WRITE);
		if(FR_OK != res){
			status = StatusFatFsOpen;
		}
	}

	if (StatusOk == status) {
		memset(buff,0x00,50);
		stringSize = sprintf(buff,"Accel Bias=%i,%i,%i \r\n",AccelBias[0],AccelBias[1],AccelBias[2]);
		res = f_write(calibFile, buff,stringSize,&bw);
		if(FR_OK != res){
			status = StatusFatFsWrite;
		}
	}
	if (StatusOk == status) {
		char biasString[3][10];
		memset(buff,0x00,50);
		memset(biasString[0],0x00,10);
		memset(biasString[1],0x00,10);
		memset(biasString[2],0x00,10);
		Utility_FtoaBase10(GyroBias[0], biasString[0], fPrecision_3);
		Utility_FtoaBase10(GyroBias[1], biasString[1], fPrecision_3);
		Utility_FtoaBase10(GyroBias[2], biasString[2], fPrecision_3);
		stringSize = sprintf(buff,"Gyro Bias=%s,%s,%s \r\n",biasString[0],biasString[1],biasString[2]);

		res = f_write(calibFile, buff,stringSize,&bw);
		if(FR_OK != res){
			status = StatusFatFsWrite;
		}
	}
	if (StatusOk == status) {
		res = f_close(calibFile);
		if(FR_OK != res){
			status = StatusFatFsClose;
		}
	}

	if (StatusOk == status) {
		res = f_mount(0, "", 1);
		if(FR_OK != res){
			status = StatusFatFsMount;
		}
	}

	return status;
}

static status_t readCalibFile(void)
{
	status_t status = StatusOk;
	FRESULT res;
	FATFS* USBDISKFatFs;
	FIL* calibFile;
	char buff[50];
	uint8_t buffIndex=0;
	static bool fileRead = false;

	USBDISKFatFs = FATFS_GetFileSystem();
	calibFile = FATFS_GetConfigFile();

	if(!fileRead){
		res = f_mount(USBDISKFatFs, "", 1);
		if(FR_OK != res){
			status = StatusFatFsMount;
		}

		if(FR_OK == f_stat("tare.txt", NULL)){
			f_open(calibFile, "tare.txt", FA_OPEN_EXISTING | FA_READ);
			while(1){
				if( NULL != f_gets(buff ,sizeof(buff), calibFile))
				{
					if(0 == strncmp(buff, "Accel Bias", strlen( "Accel Bias")))
					{
						for(buffIndex = 0; buffIndex < sizeof(buff); buffIndex++){
							if( buff[buffIndex] == '='){
								buffIndex++;
								uint8_t numIndex = buffIndex;
								uint8_t biasIndex = 0;
								char intString[10];
								while(numIndex <= strlen(buff)){
									if(buff[numIndex] == ','|| buff[numIndex] == '\r'){
										memcpy(intString, buff+buffIndex, numIndex-buffIndex);
										AccelBias[biasIndex] = atoi(intString);
										biasIndex++;
										buffIndex = numIndex + 1;
									}
									numIndex++;
								}
								break;
							}
						}
					}
					else if(0 == strncmp(buff, "Gyro Bias", strlen( "Gyro Bias"))){
						for(buffIndex = 0; buffIndex < sizeof(buff); buffIndex++){
							if( buff[buffIndex] == '='){
								buffIndex++;
								uint8_t numIndex = buffIndex;
								uint8_t biasIndex = 0;
								char intString[10];
								while(numIndex <= strlen(buff)){
									if(buff[numIndex] == ',' || buff[numIndex] == '\r'){
										memcpy(intString, buff+buffIndex, numIndex-buffIndex);
										GyroBias[biasIndex] = atof(intString);
										biasIndex++;
										buffIndex = numIndex + 1;
									}
									numIndex++;
								}
								break;
							}
						}
					}
				}
				else{
					break;
				}
			}
			f_close(calibFile);
		}
		else{
			status = StatusFatFsOpen;
		}
		res = f_mount(0, "", 1);
		if(FR_OK != res){
			status = StatusFatFsMount;
		}
		fileRead = true;
	}

	return status;
}
#endif

// Public functions bodies ---------------------------------------------------
status_t Bno055_Init(void)
{
	status_t status;
	status = StatusOk;

	static bool onStartUp = false;

	if(initialized){
		status = StatusAlreadyInitialized;
	}
	else
	{
		orientationSettings_t configBoardOrientation[3];
		Config_Ioctl(configIoctlGetOrientation, configBoardOrientation);

		if(!onStartUp){
			initBno055Settings(&Bno055CurrSettings);

			//BNO055 startup time
			HAL_Delay(400);

			onStartUp = 1;
		}
		// Create I2C instance
		status = I2C_CreateHandle(&i2cHandle, BNO055_I2C_ADDRESS);
		if (StatusOk == status) {
			//Make sure the register map is set up correctly
			status = changeRegisterPage(0);
		}

		if (StatusOk == status) {
			//Read chip ID
			uint8_t i2cReturnData;
			status = I2C_MemRead(i2cHandle, chipId, 1, &i2cReturnData, 1,
					BNO055_I2C_TIMEOUT_VAL);

			if((i2cReturnData != BNO055_CHIP_ID_VAL) || (status != StatusOk)){
				status = StatusImuChipId;
			}
		}

		if(StatusOk == status){
			//Start in Config mode
			status = configureOperationMode( oprModeConfigMode );

			if(StatusOk == status){
				HAL_Delay(19);

				status = configurePowerMode( pwrModeNormal );

				if(StatusOk == status){
					//Axis Check
					uint8_t axisConfig[2] = {0,0};
					uint8_t axisConfigCheck[2] = {0,0};

					status = Config_RemapBoardAxis(configBoardOrientation, axisConfig);
					if(StatusOk == status){
						status = Bno055_SetAxisDirections(36, 0);
					}
					if(StatusOk == status){
						status = Bno055_SetAxisDirections(axisConfig[0], axisConfig[1]);
					}
					if(StatusOk == status){
						status = Bno055_GetAxisDirections(axisConfigCheck, axisConfigCheck+1);
					}
				}
			}
			if(StatusOk == status){
				//Configure Unit Selection
				status = writeRegister(unitSel, Bno055CurrSettings.unitSel.byte);
			}
#ifndef SWO_PROFILE_BUILD
			//Tare values
			if(StatusOk == readCalibFile()){
				uint8_t accOffset[6];
				accOffset[0] = AccelBias[0] & 0xFF;
				accOffset[1] = (AccelBias[0] >> 8) & 0xFF;
				accOffset[2] = AccelBias[1] & 0xFF;
				accOffset[3] = (AccelBias[1] >> 8) & 0xFF;
				accOffset[4] = AccelBias[2] & 0xFF;
				accOffset[5] = (AccelBias[2] >> 8) & 0xFF;
				setCalibration(accOffset, accOffsetXLsb);

				uint8_t gyrOffset_U8[6];
				uint16_t gyrOffset_S16[3];
				gyrOffset_S16[0] = (int16_t) (GyroBias[0] * Bno055CurrSettings.bno055Gyr.gyrUnitConversion);
				gyrOffset_S16[1] = (int16_t) (GyroBias[1] * Bno055CurrSettings.bno055Gyr.gyrUnitConversion);
				gyrOffset_S16[2] = (int16_t) (GyroBias[2] * Bno055CurrSettings.bno055Gyr.gyrUnitConversion);

				gyrOffset_U8[0] = gyrOffset_S16[0] & 0xFF;
				gyrOffset_U8[1] = (gyrOffset_S16[0] >> 8) & 0xFF;
				gyrOffset_U8[2] = gyrOffset_S16[1] & 0xFF;
				gyrOffset_U8[3] = (gyrOffset_S16[1] >> 8) & 0xFF;
				gyrOffset_U8[4] = gyrOffset_S16[2] & 0xFF;
				gyrOffset_U8[5] = (gyrOffset_S16[2] >> 8) & 0xFF;
				setCalibration(gyrOffset_U8, gyrOffsetXLsb);
			}
#endif // SWO_PROFILE_BUILD

			//Change the register map to page 1
			if(StatusOk == status){
				status = changeRegisterPage(1);
			}
			//Configure IMU Components
			if(StatusOk == status){
				status = writeRegister(accConfig, Bno055CurrSettings.bno055Acc.accConfig.byte);
			}
			if(StatusOk == status){
				status = writeRegister(gyrConfig0, Bno055CurrSettings.bno055Gyr.gyrConfig.byte);
			}
			if(StatusOk == status){
				status = writeRegister(gyrConfig1, Bno055CurrSettings.bno055Gyr.gyrOperationMode);
			}
			if(StatusOk == status){
				status = writeRegister(magConfig, Bno055CurrSettings.bno055Mag.magConfig.byte);
			}

			//Change the register map back to page 0
			if(StatusOk == status){
				status = changeRegisterPage(0);
			}

			//Configure Power Mode
			if(StatusOk == status){
				status = configurePowerMode( pwrModeSuspended );
			}

			if(StatusOk == status){
				 initialized = true;
			}
		}
	}

	return returnStatus(status, eSucInitStatus);
} //IMU_InitBno055

status_t Bno055_ReadData(imuSettings_t * settings, imuDataHandler_t * dataOut, void (*callback)(void)) 
{
	status_t status = StatusOk;
	
	if (!settings || !dataOut || !callback) {
	    status = StatusNullParameter;
	}

	if (StatusOk == status) {
	    imuSettings = settings;
	    dataHandlerOut = dataOut;
	    readDataCallback = callback;
	    
        I2CWriteBuffer[0] = accXLsb;
    
        i2cOverlapped.callback = overlappedCallback;
        i2cOverlapped.timeout = BNO055_I2C_TIMEOUT_VAL;
        i2cOverlapped.outBuffer = I2CWriteBuffer;
        i2cOverlapped.outBufferSize = 1;
        i2cOverlapped.inBuffer = I2CReadBuffer;
        i2cOverlapped.inBufferSize = sizeof(I2CReadBuffer);
    
        status = I2C_MemReadAsync(i2cHandle, &i2cOverlapped);
	}

	return returnStatus(status, eSucReadStatus);
}

status_t Bno055_ReadAccData(float *ptrReturnData)
{
	status_t status = StatusOk;
	uint8_t aData[6];

	status = I2C_MemRead(i2cHandle, accXLsb, 1, aData, 6,
			BNO055_I2C_TIMEOUT_VAL);

	if(StatusOk == status){
		int16_t accelX = (int16_t)((((int32_t)(int8_t)(aData[1])) << 8) | (aData[0]));
		int16_t accelY = (int16_t)((((int32_t)(int8_t)(aData[3])) << 8) | (aData[2]));
		int16_t accelZ = (int16_t)((((int32_t)(int8_t)(aData[5])) << 8) | (aData[4]));

		ptrReturnData[0] = (float)accelX / Bno055CurrSettings.bno055Acc.accUnitConversion;
		ptrReturnData[1] = (float)accelY / Bno055CurrSettings.bno055Acc.accUnitConversion;
		ptrReturnData[2] = (float)accelZ / Bno055CurrSettings.bno055Acc.accUnitConversion;
	}

	return returnStatus(status, eSucReadStatus);
}

status_t Bno055_ReadGyrData(float *ptrReturnData)
{
	status_t status = StatusOk;
	uint8_t gData[6];

	status = I2C_MemRead(i2cHandle, gyrXLsb, 1, gData, 6,
			BNO055_I2C_TIMEOUT_VAL);

	if(StatusOk == status){
		//Convert data to Dps
		int16_t gyroX = (int16_t)((((int32_t)(int8_t)(gData[1])) << 8) | (gData[0]));
		int16_t gyroY = (int16_t)((((int32_t)(int8_t)(gData[3])) << 8) | (gData[2]));
		int16_t gyroZ = (int16_t)((((int32_t)(int8_t)(gData[5])) << 8) | (gData[4]));

		ptrReturnData[0] = (float)gyroX / Bno055CurrSettings.bno055Gyr.gyrUnitConversion;
		ptrReturnData[1] = (float)gyroY / Bno055CurrSettings.bno055Gyr.gyrUnitConversion;
		ptrReturnData[2] = (float)gyroZ / Bno055CurrSettings.bno055Gyr.gyrUnitConversion;
	}
	return returnStatus(status, eSucReadStatus);
}

status_t Bno055_ReadMagData(float *ptrReturnData)
{
	status_t status = StatusOk;
	uint8_t mData[6];

	status = I2C_MemRead(i2cHandle, magXLsb, 1, mData, 6,
			BNO055_I2C_TIMEOUT_VAL);

	if(StatusOk == status){
		//Convert data to uT
		int16_t magX = (int16_t)((((int32_t)(int8_t)(mData[1])) << 8) | (mData[0]));
		int16_t magY = (int16_t)((((int32_t)(int8_t)(mData[3])) << 8) | (mData[2]));
		int16_t magZ = (int16_t)((((int32_t)(int8_t)(mData[5])) << 8) | (mData[4]));

		ptrReturnData[0] = (float)magX / BNO055_MAG_UNIT_UT;
		ptrReturnData[1] = (float)magY / BNO055_MAG_UNIT_UT;
		ptrReturnData[2] = (float)magZ / BNO055_MAG_UNIT_UT;
	}

	return returnStatus(status, eSucReadStatus);
}

status_t Bno055_ReadQuatData( float *ptrReturnData )
{
	status_t status = StatusOk;
	uint8_t qData[8];

	status = I2C_MemRead(i2cHandle, quatDataWLsb, 1, qData, 8,
			BNO055_I2C_TIMEOUT_VAL);

	if(StatusOk == status){
		//Convert data to uT
		int16_t quatW = (int16_t)((((int32_t)(int8_t)(qData[1])) << 8) | (qData[0]));
		int16_t quatX = (int16_t)((((int32_t)(int8_t)(qData[3])) << 8) | (qData[2]));
		int16_t quatY = (int16_t)((((int32_t)(int8_t)(qData[5])) << 8) | (qData[4]));
		int16_t quatZ = (int16_t)((((int32_t)(int8_t)(qData[7])) << 8) | (qData[6]));

		ptrReturnData[0] = (float)quatW / BNO055_QUAT_UNIT_QUAT;
		ptrReturnData[1] = (float)quatX / BNO055_QUAT_UNIT_QUAT;
		ptrReturnData[2] = (float)quatY / BNO055_QUAT_UNIT_QUAT;
		ptrReturnData[3] = (float)quatZ / BNO055_QUAT_UNIT_QUAT;
	}

	return returnStatus(status, eSucReadStatus);
}

status_t Bno055_ReadEulerData( float *ptrReturnData )
{
	status_t status;

	float qData[4];
	float eData[3];

	status = Bno055_ReadQuatData( qData );

	//Convert quat to euler angle
	if(StatusOk == status){
		// yaw (z-axis rotation)
		eData[0] = -atan2f(qData[0] * qData[0] - qData[1] * qData[1] + qData[2] * qData[2] - qData[3] * qData[3],
		                  2.0f * (qData[1] * qData[2] - qData[0] * qData[3]));

		//Convert to degrees per second
		ptrReturnData[0] = eData[0] * 180 / M_PI;
		ptrReturnData[0] += -6.0f;
		if(ptrReturnData[0] < 0){
			ptrReturnData[0] += 360.0f;
		}

		// pitch (y-axis rotation)
		eData[2] = asinf(2.0f * (qData[2] * qData[3] + qData[0] * qData[1]));
		//Convert to degrees per second
		ptrReturnData[2] = eData[2] * 180 / M_PI;

		// roll (x-axis rotation)
		eData[1] = atan2f(2.0f * (qData[0] * qData[2] - qData[1] * qData[3]),
		                 qData[0] * qData[0] - qData[1] * qData[1] - qData[2] * qData[2] + qData[3] * qData[3]);
		//Convert to degrees per second
		ptrReturnData[1] = eData[1] * 180 / M_PI;

	}

	return returnStatus(status, eSucReadStatus);
}

status_t Bno055_SetAxisDirections(uint8_t axisConfig, uint8_t signConfig)
{
	status_t status;

	status = writeRegister(axisMapConfig, axisConfig);
	if(StatusOk == status){
		status = writeRegister(axisMapSign, signConfig);
	}
	return returnStatus(status, eSucWriteStatus);
}

status_t Bno055_GetAxisDirections(uint8_t* axisConfig, uint8_t* signConfig)
{
	status_t status;

	status = I2C_MemRead(i2cHandle, axisMapConfig, 1, axisConfig, 1,
			BNO055_I2C_TIMEOUT_VAL);

	if(StatusOk == status){
		status = I2C_MemRead(i2cHandle, axisMapSign, 1, signConfig, 1,
				BNO055_I2C_TIMEOUT_VAL);
	}

	return returnStatus(status, eSucReadStatus);
}

status_t Bno055_Ioctl(imuIoctl_t ioctlCode, uint8_t* outData){
	status_t status = StatusOk;
	uint8_t regValue;

	switch(ioctlCode){
		case imuIoctlLowPow:
			status = readPowerMode( &regValue );
			if(pwrModeSuspended == regValue){
				status = configurePowerMode( pwrModeLowPower );
				if(StatusOk == status){
					status = configureOperationMode( Bno055CurrSettings.oprSetting );
					HAL_Delay(7);
				}
			}
			else if(pwrModeNormal == regValue){
				status = configureOperationMode( oprModeConfigMode );
				if(StatusOk == status){
					HAL_Delay(19);
					status = configurePowerMode( pwrModeLowPower );
				}
				if(StatusOk == status){
					status = configureOperationMode( Bno055CurrSettings.oprSetting );
					HAL_Delay(7);
				}
			}
			break;

		case imuIoctlNormalPow:
			status = readPowerMode( &regValue );
			if(pwrModeSuspended == regValue){
				status = configurePowerMode( pwrModeNormal );
				if(StatusOk == status){
					status = configureOperationMode( Bno055CurrSettings.oprSetting );
					HAL_Delay(7);
				}
				HAL_Delay(100);
			}
			else if(pwrModeLowPower == regValue){
				status = configureOperationMode( oprModeConfigMode );
				if(StatusOk == status){
					HAL_Delay(19);
					status = configurePowerMode( pwrModeNormal );
				}
				if(StatusOk == status){
					status = configureOperationMode( Bno055CurrSettings.oprSetting );
					HAL_Delay(7);
				}
			}
			break;

		case imuIoctlSuspendPow:
			status = readPowerMode( &regValue );
			if(pwrModeSuspended != regValue){
				status = configureOperationMode( oprModeConfigMode );
				if(StatusOk == status){
					HAL_Delay(19);
					status = configurePowerMode( pwrModeSuspended );
				}
			}
			break;

		case imuIoctlReadPow:
			status = readPowerMode(outData);
			break;

		case imuIoctlDataRdy:
			//*outData = ImuDataRdy;
			break;

		default:
			break;
	}

	return returnStatus(status, eSucIoctlStatus);
}

status_t Bno055_CalibrateMode(void)
{
	status_t status = StatusOk;

	float aData[3];
	float gData[3];

	int32_t aSum[3] = {0, 0, 0};
	float gSum[3] = {0.0, 0.0, 0.0};


	//Setup Device
	status = Bno055_Ioctl(imuIoctlNormalPow, NULL);

	uint16_t sampleCount = 40;

	status = configureOperationMode( oprModeConfigMode );
	HAL_Delay(19);
	for(int i = 0; i < 6; i++){
		status = writeRegister(accOffsetXLsb+i, 0);
		if(StatusOk != status){
			break;
		}
	}
	configureOperationMode( Bno055CurrSettings.oprSetting );
	HAL_Delay(7);

	//accumulate samples
	for(int i = 0; i < sampleCount; i++)
	{
		HAL_Delay(50);

		Bno055_ReadAccData(aData);
		Bno055_ReadGyrData(gData);

		aSum[0] += aData[0];
		aSum[1] += aData[1];
		aSum[2] += aData[2];
	    gSum[0] += gData[0];
	    gSum[1] += gData[1];
	    gSum[2] += gData[2];
	}

	if(StatusOk == status){

		AccelBias[0] = aSum[0] / sampleCount; // Normalize sums to get average count biases
		AccelBias[1] = aSum[1] / sampleCount;
		AccelBias[2] = aSum[2] / sampleCount;
		GyroBias[0]  = gSum[0] / sampleCount;
		GyroBias[1]  = gSum[1] / sampleCount;
		GyroBias[2]  = gSum[2] / sampleCount;

		for(uint8_t i=0; i<3; i++) // Remove gravity from the "Az" accelerometer bias calculation; works for general case
		{
			if(AccelBias[i] > 1000/2)
			{
				AccelBias[i] -= 1000;
			}
			if(AccelBias[i] < -1000/2)
			{
				AccelBias[i] += 1000;
			}
		}

		status = configureOperationMode( oprModeConfigMode );
		HAL_Delay(19);
	}

	if(StatusOk == status)
	{
		//Gyro ==========================================================================================
		uint8_t gyrOffset_U8[6];
		int16_t gyrOffset_S16[3];

		gyrOffset_S16[0] = (int16_t) (GyroBias[0] * Bno055CurrSettings.bno055Gyr.gyrUnitConversion);
		gyrOffset_S16[1] = (int16_t) (GyroBias[1] * Bno055CurrSettings.bno055Gyr.gyrUnitConversion);
		gyrOffset_S16[2] = (int16_t) (GyroBias[2] * Bno055CurrSettings.bno055Gyr.gyrUnitConversion);

		gyrOffset_U8[0] = gyrOffset_S16[0] & 0xFF;
		gyrOffset_U8[1] = (gyrOffset_S16[0] >> 8) & 0xFF;
		gyrOffset_U8[2] = gyrOffset_S16[1] & 0xFF;
		gyrOffset_U8[3] = (gyrOffset_S16[1] >> 8) & 0xFF;
		gyrOffset_U8[4] = gyrOffset_S16[2] & 0xFF;
		gyrOffset_U8[5] = (gyrOffset_S16[2] >> 8) & 0xFF;

		setCalibration(gyrOffset_U8, gyrOffsetXLsb);

		//Accel =========================================================================================
		if(StatusOk == status){
			uint8_t accOffset_U8[6];
			int16_t accOffset_S16[3];

			accOffset_S16[0] = (int16_t) AccelBias[0];
			accOffset_S16[1] = (int16_t) AccelBias[1];
			accOffset_S16[2] = (int16_t) AccelBias[2];

			accOffset_U8[0] = accOffset_S16[0] & 0xFF;
			accOffset_U8[1] = (accOffset_S16[0] >> 8) & 0xFF;
			accOffset_U8[2] = accOffset_S16[1] & 0xFF;
			accOffset_U8[3] = (accOffset_S16[1] >> 8) & 0xFF;
			accOffset_U8[4] = accOffset_S16[2] & 0xFF;
			accOffset_U8[5] = (accOffset_S16[2] >> 8) & 0xFF;

			setCalibration(accOffset_U8, accOffsetXLsb);
		}
		if(StatusOk == status){
			status = Bno055_Ioctl(imuIoctlSuspendPow, NULL);
		}
	}

	if(StatusOk == status){
		writeCalibFile();
	}

	// Blink LED
	status = Status_Preserve(status, UserInterface_BlinkLed(ledPatternCalibrateStep));

	return status;
}

/// SAEC Kinetic Vision, Inc. ----------- END OF FILE
