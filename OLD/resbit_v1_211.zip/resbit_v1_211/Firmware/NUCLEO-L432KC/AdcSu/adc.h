/**
  @file       adc.h

  @copyright  (C) 2019 Kinetic Vision, Cincinnati Ohio.
               This software is property of SAEC Kinetic Vision, Inc
               and is considered confidential.

  @brief      ADC software unit "H" file.

  @author     Parker Kamer

  @defgroup   AdcSu Analog to digital converter

  Configuration History
  =====================

  Config Item    | Value
  -------------- | -----
  Config #       | NA
  Revision       | NA
  Revised, Date  | NA
  QA, Date       | NA
  Approved, Date | NA
  Released, Date | NA

  Significant Modification History (Most recent at top)
  =====================================================

  Date         | Initials | Details
  ------------ | -------- | -------
  24 Jul 2019  | PK       | Original

  Theory of Operation
  ===================
  The ADC will have several channels configured so that analog data from
  multiple external sensor can be converted and logged into a file.
  The adc will also be used to calculate battery life.

  */

// Define to prevent recursive inclusion -------------------------------------
#ifndef __ADC_SU_H
#define __ADC_SU_H

#include <stdint.h>

#include "../StatusSu/Status.h"
#include "../GpioSu/gpio.h"
#include "../DataAggregatorSu/DataAggregator.h"

// Exported macro ------------------------------------------------------------

// Exported types ------------------------------------------------------------
typedef struct {
	float vBattery;
	float temperature;
	memBlock32_t connectorData[NUM_CONNECTORS];
}adcDataHandler_t;

// Exported constants --------------------------------------------------------

// Exported objects ----------------------------------------------------------

// Exported functions --------------------------------------------------------

/**
 * @brief Initializes adc & analog peripherals
 * @return StatusOk, StatusAlreadyInitialized, StatusHal, StautsAdcActiveChannel,
 * 		   StautsAdcNotActiveChannel, StautsAdcMaxActiveChannels, StatusAdcNoActiveChannels
 */
status_t ADC_Init(adcSettings_t * settings);

/// @brief Turns on ADC measurements and peripherals for study data aggregation
status_t ADC_StudyDataOn(void);

/// @brief Turns off ADC measurements and peripherals for study data aggregation
status_t ADC_StudyDataOff(void);

/// @brief Turns on ADC, reads vbatt, turns off ADC
status_t ADC_ReadVBattBlocking(uint32_t timeoutMs, float * out);

/// @brief Turns on ADC, reads connector data for "numSamples", averages output, turns off ADC
status_t ADC_ReadConnectorBlocking(connectors_t connector, bool scaleData,
		uint16_t numSamples, uint32_t timeoutMs, memBlock32_t * out);

/// @brief Reads all enabled adc channels then calls callback function
status_t ADC_ReadData(adcDataHandler_t * dataOut, void (*callback)(void));

/// @brief Returns true if analog trigger is enabled
bool ADC_GetTrigEnabled(void);

/// @brief Returns true if trigger type is relative
bool ADC_GetTrigRelative(void);

/// @brief Returns true if analog trigger is active
bool ADC_GetTrigActive(void);

/// @brief Returns true if analog trigger has been passed since last data aggregation on
bool ADC_GetTrigPassed(void);

/// @brief Returns number of trigger pulls since last reset
uint32_t ADC_GetTrigCount(void);

/// @brief Returns last time analog trigger was active
uint32_t ADC_GetLastTrigTime(void);

/// @brief Sets up trigger state for protect mode
status_t ADC_SetupProtectModeTrigger(void);

/// @brief Returns true if protect mode trigger condition has been meet
bool ADC_GetProtectModeTriggerPassed(void);

#endif // __ADC_SU_H

/// SAEC Kinetic Vision, Inc. ----------- END OF FILE
