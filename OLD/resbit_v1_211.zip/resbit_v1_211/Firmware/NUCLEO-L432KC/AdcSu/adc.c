/**
  @file       adc.c

  @copyright  (C) 2019 Kinetic Vision, Cincinnati Ohio.
               This software is property of SAEC Kinetic Vision, Inc
               and is considered confidential.

  @brief      ADC software unit "C" file.

  @author     Parker Kamer

  @ingroup    AdcSu

  Configuration History
  =====================

  Config Item    | Value
  -------------- | -----
  Config #       | NA
  Revision       | NA
  Revised, Date  | NA
  QA, Date       | NA
  Approved, Date | NA
  Released, Date | NA

  Significant Modification History (Most recent at top)
  =====================================================

  Date         | Initials | Details
  ------------ | -------- | -------
  24 Jul 2019  | PK       | Original

  Theory of Operation
  ===================
  The ADC will have several channels configured so that analog data from
  multiple external sensor can be converted and logged into a file.

*/

// Includes ------------------------------------------------------------------

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <math.h>

#include "stm32l4xx_hal.h"
#include "../Middlewares/Third_Party/FatFs/src/ff.h"
#include "../StatusSu/Status.h"
#include "../ConsoleSu/Console.h"
#include "../SwUnitControlSu/SwUnitControl.h"
#include "../GpioSu/Gpio.h"
#include "../RtcSu/rtc.h"
#include "../ConfigSu/Config.h"
#include "../PowerSu/power.h"
#include "../Ms5837Su/Ms5837.h"
#include "../FDC2214Su/FDC2214.h"
#include "adc.h"
#include "../Hx711Su/Hx711.h"
#include "../FDC2214Su/FDC2214.h"
#include "../HallSu/Hall.h"
#include "../MultiplexerSu/Multiplexer.h"
#include "../SysTimeSu/SysTime.h"

// Private macros ------------------------------------------------------------
/// This macro feeds status information for tracking purposes to software unit control.
#define returnStatus(__status__,__source__) SwUnitControl_WriteStatus(eSucAdcSu,__source__,__status__,__LINE__);

#define VBAT_SAMPLETIME         ADC_SAMPLETIME_47CYCLES_5
#define VREF_TEMP_SAMPLETIME    ADC_SAMPLETIME_47CYCLES_5
#define PERIPHERAL_SAMPLETIME   ADC_SAMPLETIME_47CYCLES_5

#define VSUP_VOLTAGE_MULTIPLIER 2.0f // we're halving the voltage with 10k resistors
#define VBAT_SCHOTTKY_VDROP     0.25f
#define VREF_NOMINAL            3.30f
#define ADC_DIVISOR             4095.0f

#define MAX_ADC_CHANNELS        6
#define NUM_ADC_RANKS			7

#define PROTECT_READ_TIMEOUT	1000 // ms

#define TRIG_FALLING_EDGE_HYST	0.75f // percent of threshold

#define VBAT_HISTORY_LEN		32 // samples

// Private types -------------------------------------------------------------
typedef enum {
	trigStateNone = 0,
	trigStateLow,
	trigStateHigh,
} trigState_t;

typedef struct {
	// Read from config -- populated on startup
	bool enabled;
	bool relative;
	float threshold;
	connectors_t connector;
	
	// Reset at data agg on, updated every data sample
	bool reset;
	float min;
	float max;
	float current;
	
	trigState_t state;
	uint32_t lastActive;
	uint32_t count;
} triggerData_t;

typedef struct {
	uint16_t history[VBAT_HISTORY_LEN];
	uint16_t index;
	uint16_t numSamples;
} vbatData_t;

// Private function prototypes -----------------------------------------------
static status_t initAdcHardware(ADC_HandleTypeDef * adc, uint8_t numConversions);
static status_t deInitAdcHardware(ADC_HandleTypeDef * adc);
static uint8_t getChannelCount(adcSettings_t * settings);
static status_t configureChannel(ADC_HandleTypeDef * adc, uint32_t channel, uint32_t rank, uint32_t samplingTime);

static status_t setupTriggerData(adcSettings_t * settings, triggerData_t * trigData);
static status_t resetTriggerData(triggerData_t * trigData);
static status_t updateTriggerData(triggerData_t * trigData, float data);

static status_t enableAdcMeasurements(adcSettings_t * settings, bool enable);
static status_t enableVBattMeasurement(bool enable);
static status_t enableConnectorMeasurement(connectors_t connector, extSensorTypes_t sensorType, bool enable,
		bool isBlocking);

static status_t scaleAdcData(adcSettings_t * settings, adcDataHandler_t * dataOut, uint16_t * rawData, size_t len);
static status_t scaleConnectorData(connectors_t connector, extSensorTypes_t sensorType, uint16_t raw, 
		memBlock32_t * out);

static void vbatDataAppend(uint16_t raw);
static float vbatDataGetSmoothed(void);

// Private constants ---------------------------------------------------------
static const uint32_t rankList [NUM_ADC_RANKS] = {
        ADC_REGULAR_RANK_1,
        ADC_REGULAR_RANK_2,
        ADC_REGULAR_RANK_3,
        ADC_REGULAR_RANK_4,
        ADC_REGULAR_RANK_5,
        ADC_REGULAR_RANK_6,
        ADC_REGULAR_RANK_7
};

// Private variables ---------------------------------------------------------
ADC_HandleTypeDef hadc1;

static adcSettings_t * adcSettings;
static uint8_t numAdcChannels = 0;
static uint16_t rawBuffer[MAX_ADC_CHANNELS];
static uint8_t currentConversion = 0;

static triggerData_t triggerData;
static vbatData_t vbatData = {0};

static adcDataHandler_t * dataHandlerOut = NULL;
static void (*readCallback)(void) = NULL;


static bool initialized = false;

// ISR's
void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef *hadc) 
{
    rawBuffer[currentConversion] = HAL_ADC_GetValue(hadc);
    currentConversion++;
    
    if (currentConversion >= numAdcChannels) {
        // Stop ADC
        HAL_ADC_Stop_IT(hadc);
        // Disable measurements (sleep hall sensors, drop vsup sample ctrl low)
        enableAdcMeasurements(adcSettings, false);
        // Scale data
        if (dataHandlerOut) {
            scaleAdcData(adcSettings, dataHandlerOut, rawBuffer, numAdcChannels);
        }
        // Update trigger data
        updateTriggerData(&triggerData, dataHandlerOut->connectorData[triggerData.connector].float32);
        // Call callback
        if (readCallback) {
            readCallback();
        }
    } else {
        // Start next conversion
        HAL_ADC_Start_IT(hadc);
    }
}

// Private function bodies ---------------------------------------------------
static status_t initAdcHardware(ADC_HandleTypeDef * adc, uint8_t numConversions)
{
    hadc1.Instance = ADC1;
    hadc1.Init.ClockPrescaler = ADC_CLOCK_SYNC_PCLK_DIV4;
    hadc1.Init.Resolution = ADC_RESOLUTION_12B;
    hadc1.Init.DataAlign = ADC_DATAALIGN_RIGHT;
    hadc1.Init.ScanConvMode = ADC_SCAN_ENABLE;
    hadc1.Init.EOCSelection = ADC_EOC_SINGLE_CONV;
    hadc1.Init.LowPowerAutoWait = ENABLE;
    hadc1.Init.ContinuousConvMode = DISABLE;
    hadc1.Init.NbrOfConversion = numConversions;
    hadc1.Init.DiscontinuousConvMode = ENABLE;
    hadc1.Init.NbrOfDiscConversion = numConversions;
    hadc1.Init.ExternalTrigConv = ADC_SOFTWARE_START;
    hadc1.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_NONE;
    hadc1.Init.DMAContinuousRequests = DISABLE;
    hadc1.Init.Overrun = ADC_OVR_DATA_PRESERVED;

    hadc1.Init.OversamplingMode = ENABLE;
    hadc1.Init.Oversampling.Ratio = ADC_OVERSAMPLING_RATIO_16;
    hadc1.Init.Oversampling.RightBitShift = ADC_RIGHTBITSHIFT_4;
    hadc1.Init.Oversampling.TriggeredMode = ADC_TRIGGEREDMODE_SINGLE_TRIGGER;
    hadc1.Init.Oversampling.OversamplingStopReset = ADC_REGOVERSAMPLING_RESUMED_MODE;

    HAL_StatusTypeDef halStatus = HAL_ADC_Init(adc);
    if (HAL_OK == halStatus) {
        halStatus = HAL_ADCEx_Calibration_Start(adc, ADC_SINGLE_ENDED);
    }
    if (HAL_OK == halStatus) {
        return StatusOk;
    } else {
        return StatusHal;
    }
}

static status_t deInitAdcHardware(ADC_HandleTypeDef * adc)
{
	status_t status = StatusOk;

	// Force stop
	HAL_ADC_Stop(adc);

	HAL_StatusTypeDef halStatus = HAL_ADC_DeInit(adc);
	if(HAL_OK != halStatus){
		status = StatusHal;
	}
	if(StatusOk == status){
		HAL_StatusTypeDef halStatus = HAL_ADCEx_EnterADCDeepPowerDownMode(adc);
		if(HAL_OK != halStatus){
			status = StatusHal;
		}
	}

	return status;
}

static uint8_t getChannelCount(adcSettings_t * settings)
{
    uint8_t retVal = 0;
    if (settings->vBattEnabled) retVal++;
    if (settings->tempEnabled) retVal += 2;
    for (int i = 0; i < NUM_CONNECTORS; i++) {
        if (settings->connectorSettings.sensorTypes[i] != sensorNull) {
            retVal++;
        }
    }
    
    if (retVal > MAX_ADC_CHANNELS) {
        retVal = MAX_ADC_CHANNELS; // TODO: throw error so that developers/users know what went wrong (although this should never happen)
    }
    
    return retVal;
}

static status_t configureChannel(ADC_HandleTypeDef * adc, uint32_t channel, uint32_t rank, uint32_t samplingTime)
{
    ADC_ChannelConfTypeDef config = {0};
    config.Channel = channel;
    config.Rank = rank;
    config.SamplingTime = samplingTime;
    config.SingleDiff = ADC_SINGLE_ENDED;
    config.OffsetNumber = ADC_OFFSET_NONE;
    config.Offset = 0;

    HAL_StatusTypeDef halStatus = HAL_ADC_ConfigChannel(adc, &config);
    if (HAL_OK == halStatus) {
        return StatusOk;
    } else {
        return StatusHal;
    }
}

static status_t setupTriggerData(adcSettings_t * settings, triggerData_t * trigData)
{
	status_t status = StatusOk;
	
	// Get connector
	connectors_t connector;
	status = Config_Ioctl(configIoctlGetAnalogTrig, (uint8_t *)&connector);
	if (StatusOk == status) {
		// See if sensor is analog to determine if trigger is enabled or not
		if (settings->connectorSettings.sensorTypes[connector] != sensorNull) {
			trigData->enabled = true;
			trigData->connector = connector;
		} else {
			trigData->enabled = false;
			return status; // we're done
		}
	}
	// Get threshold type
	if (StatusOk == status) {
		thresholdTypes_t thresholdType;
		status = Config_Ioctl(configIoctlGetThresholdType, (uint8_t *)&thresholdType);
		if (StatusOk == status) {
			trigData->relative = (thresholdRelative == thresholdType) ? true : false;
		}
	}
	// Get threshold value
	if (StatusOk == status) {
		uint16_t thresholdVal;
		status = Config_Ioctl(configIoctlGetTrigThreshold, (uint8_t *)&thresholdVal);
		if (StatusOk == status) {
			trigData->threshold = (float)thresholdVal / 100.0f;
		}
	}
	
	return status;
}

static status_t resetTriggerData(triggerData_t * trigData)
{
	trigData->reset = true;
	trigData->count = 0;
	trigData->state = trigStateNone;
	
	return StatusOk;
}

static status_t updateTriggerData(triggerData_t * trigData, float data)
{
	status_t status = StatusOk;
	
	if (trigData->enabled) {
		// Update min/max
		if (trigData->reset) {
			// This is new data -- set min/max
			trigData->min = data;
			trigData->max = data;
			trigData->reset = false;
		} else if (data > trigData->max) {
			trigData->max = data;
		} else if (data < trigData->min) {
			trigData->min = data;
		}
		
		// Update trig state, count
		trigState_t newState;
		if (trigData->relative) {
			// Update state
			if (data >= (trigData->min + trigData->threshold)) {
				newState = trigStateHigh;
			} else if (data <= (trigData->max - trigData->threshold)) {
				newState = trigStateLow;
			} else {
				newState = trigStateNone;
			}
			// Update count
			if (((trigStateHigh == newState) && (trigStateHigh != trigData->state)) ||
					((trigStateLow == newState) && (trigStateLow != trigData->state))) 
			{
				trigData->count++;
			}
		} else {
			if (trigStateHigh != trigData->state) {
				// Trig state low or fresh out of reset
				newState = (data >= trigData->threshold) ? trigStateHigh : trigStateLow;
			} else {
				// Apply falling edge hysteresis
				newState = (data <= (trigData->threshold * TRIG_FALLING_EDGE_HYST)) ? 
						trigStateLow : trigStateHigh;
			}
			if ((trigStateHigh == newState) && (trigStateHigh != trigData->state)) {
				// Rising edge
				trigData->count++;
			} else if ((trigStateLow == newState) && (trigStateHigh == trigData->state)) {
				// Falling edge
				trigData->lastActive = SysTime_GetMs();
			}
		}
		trigData->state = newState;
		
		// Update current
		trigData->current = data;
	}
	
	return status;
}

static status_t enableAdcMeasurements(adcSettings_t * settings, bool enable)
{
    status_t status = StatusOk;
    
    if (settings->vBattEnabled) {
        status = enableVBattMeasurement(enable);
    }
    for (int i = 0; i < NUM_CONNECTORS; i++) {
    	if (sensorNull != settings->connectorSettings.sensorTypes[i]) {
    		status = Status_Preserve(status, 
    				enableConnectorMeasurement((connectors_t)i, 
    						settings->connectorSettings.sensorTypes[i], enable, false));
    	}
    }
    
    return status;
}

static status_t enableVBattMeasurement(bool enable)
{
	if (enable) {
		HAL_GPIO_WritePin(VSUP_SAMPLE_CNTRL_Port, VSUP_SAMPLE_CNTRL_Pin, GPIO_PIN_SET);
	} else {
		HAL_GPIO_WritePin(VSUP_SAMPLE_CNTRL_Port, VSUP_SAMPLE_CNTRL_Pin, GPIO_PIN_RESET);
	}
	
	return StatusOk;
}

static status_t enableConnectorMeasurement(connectors_t connector, extSensorTypes_t sensorType, bool enable,
		bool isBlocking)
{
	status_t status = StatusOk;
	
	switch (sensorType) {
		case sensorHall:
			if (enable) {
				status = Hall_EnableRead(connector);
			} else {
				status = Hall_DisableRead(connector);
			}
			break;
		case sensorLongRangeHall:
			if (isBlocking) {
				if (enable) {
					status = Hall_EnableRead(connector);
				} else {
					status = Hall_DisableRead(connector);
				}
			}
		default:
			break;
	}
	
	return status;
}

static status_t scaleAdcData(adcSettings_t * settings, adcDataHandler_t * dataOut, uint16_t * rawData, size_t len)
{
    status_t status = StatusOk;
    
    size_t index = 0;
    // Batt
    if (settings->vBattEnabled && (index < len)) {
    	// Add sample to history
    	vbatDataAppend(rawData[index]);
    	// Get smoothed data (moving average)
    	dataOut->vBattery = vbatDataGetSmoothed();
        index++;
    }
    // Temp
    if (settings->tempEnabled && (index < (len - 1))) { // account for extra conversion from vrefint
        uint32_t vRefInt = __HAL_ADC_CALC_VREFANALOG_VOLTAGE(rawData[index], ADC_RESOLUTION_12B);
        index++;
        int32_t tempInt = __HAL_ADC_CALC_TEMPERATURE(vRefInt, rawData[index], ADC_RESOLUTION_12B);
        dataOut->temperature = (float)tempInt;
        index++;
    }
    // Connectors
    for (int i = 0; (i < NUM_CONNECTORS) && (index < len); i++) {
    	if (sensorNull != settings->connectorSettings.sensorTypes[i]) {
    		status = Status_Preserve(status,
    				scaleConnectorData((connectors_t)i, settings->connectorSettings.sensorTypes[i],
    						rawData[index], &dataOut->connectorData[i]));
    		index++;
    	}
    }
    
    return status;
}

static status_t scaleConnectorData(connectors_t connector, extSensorTypes_t sensorType, uint16_t raw, 
		memBlock32_t * out)
{
	status_t status = StatusOk;

	switch (sensorType) {
		case sensorHall:
		case sensorLongRangeHall:
			status = Hall_ScaleData(connector, raw, &out->float32);
			break;
		case sensorAnalog:
			out->float32 = ((float)raw * VREF_NOMINAL) / ADC_DIVISOR;
			break;
		default:
			out->float32 = 0.0f;
			status = StatusCodePath; // this should be unreachable
			break;
	}
	
	return status;
}

static void vbatDataAppend(uint16_t raw)
{
	// Append and update index
	vbatData.history[vbatData.index++] = raw;
	if (vbatData.index >= VBAT_HISTORY_LEN) {
		vbatData.index = 0;
	}
	
	// Update num samples
	if (vbatData.numSamples < VBAT_HISTORY_LEN) {
		vbatData.numSamples++;
	}
}

static float vbatDataGetSmoothed(void)
{
	// Get moving average
	uint32_t sum = 0;
	for (int i = 0; (i < vbatData.numSamples) && (i < VBAT_HISTORY_LEN); i++) {
		sum += vbatData.history[i];
	}
	float avg = (float)sum / vbatData.numSamples;
	
	// Scale average
	float vSup = (avg * VREF_NOMINAL * VSUP_VOLTAGE_MULTIPLIER) / ADC_DIVISOR;
	return (vSup + VBAT_SCHOTTKY_VDROP);
}

// Public functions bodies ---------------------------------------------------
void HAL_ADC_MspInit(ADC_HandleTypeDef* hadc)
{
  if(ADC1 == hadc->Instance)
  {
    /* Peripheral clock enable */
    __HAL_RCC_ADC_CLK_ENABLE();

    HAL_NVIC_SetPriority(ADC1_IRQn, 2, 0);
    HAL_NVIC_EnableIRQ(ADC1_IRQn);
  }

} //HAL_ADC_MspInit

void HAL_ADC_MspDeInit(ADC_HandleTypeDef* hadc)
{
  if(ADC1 == hadc->Instance)
  {
    /* Peripheral clock disable */
    __HAL_RCC_ADC_CLK_DISABLE();

    HAL_NVIC_DisableIRQ(ADC1_IRQn);
  }

} //HAL_ADC_MspDeInit

status_t ADC_Init(adcSettings_t * settings)
{
	status_t status = StatusOk;

	if(initialized){
		status = StatusAlreadyInitialized;
	} else {
		// Store settings
		adcSettings = settings;
	}
	
	// Configure pins
    GPIO_InitTypeDef GPIO_InitStruct = {0};
    GPIO_InitStruct.Pin = VSUP_SAMPLE_CNTRL_Pin;
    GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    HAL_GPIO_Init(VSUP_SAMPLE_CNTRL_Port, &GPIO_InitStruct);
    HAL_GPIO_WritePin(VSUP_SAMPLE_CNTRL_Port, VSUP_SAMPLE_CNTRL_Pin, GPIO_PIN_RESET);

    GPIO_InitStruct.Pin = VSUP_SAMPLE_Pin;
    GPIO_InitStruct.Mode = GPIO_MODE_ANALOG_ADC_CONTROL;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    HAL_GPIO_Init(VSUP_SAMPLE_Port, &GPIO_InitStruct);
	
	// Init analog peripherals
    for(int i = 0; i < NUM_CONNECTORS; i++){
        if (StatusOk == status) {
            switch (adcSettings->connectorSettings.sensorTypes[i]) {
                case sensorAnalog:
                    ;GPIO_InitTypeDef analogInit = { 
                            GPIO_GetConnectorAnalogPin((connectors_t)i),
                            GPIO_MODE_ANALOG_ADC_CONTROL,
                            GPIO_NOPULL,
                    };
                    HAL_GPIO_Init(GPIO_GetConnectorAnalogPort((connectors_t)i), &analogInit);
                    break;
                case sensorHall:
                    status = Hall_Init((connectors_t)i, false);
                    break;
                case sensorLongRangeHall:
                    status = Hall_Init((connectors_t)i, true);
                    break;
                default:
                    break;
            }
        }
    }
    
    // Configure trigger data
    if (StatusOk == status) {
    	status = setupTriggerData(adcSettings, &triggerData);
    }

    if (StatusOk == status) {
        initialized = true;
    }

	return returnStatus(status, eSucInitStatus);
} //ADC_Init

status_t ADC_StudyDataOn(void)
{
	// Count num channels
    numAdcChannels = getChannelCount(adcSettings);
    // Init ADC hardware
	status_t status = initAdcHardware(&hadc1, numAdcChannels);
    // Configure core channels
    uint8_t rankIndex = 0;
    if (StatusOk == status) {
        if (adcSettings->vBattEnabled) {
            status = configureChannel(&hadc1, VSUP_SAMPLE_AnalogChannel, rankList[rankIndex], 
                    VBAT_SAMPLETIME);
            rankIndex++;
        }
    }
    if (StatusOk == status) {
        if (adcSettings->tempEnabled) {
            status = configureChannel(&hadc1, ADC_CHANNEL_VREFINT, rankList[rankIndex], 
                    VREF_TEMP_SAMPLETIME);
            rankIndex++;
            status = configureChannel(&hadc1, ADC_CHANNEL_TEMPSENSOR, rankList[rankIndex], 
                    VREF_TEMP_SAMPLETIME);
            rankIndex++;
        }
    }
    
    // Configure peripheral channels, turn long range hall on
    for (int i = 0; i < NUM_CONNECTORS; i++) {
        if (StatusOk == status) {
            switch (adcSettings->connectorSettings.sensorTypes[i]) {
                case sensorAnalog:
                    status = configureChannel(&hadc1, 
                            GPIO_GetConnectorAnalogChannel((connectors_t)i), 
                            rankList[rankIndex], PERIPHERAL_SAMPLETIME);
                    rankIndex++;
                    break;
                case sensorHall:
					status = configureChannel(&hadc1, 
							GPIO_GetConnectorAnalogChannel((connectors_t)i), 
							rankList[rankIndex], PERIPHERAL_SAMPLETIME);
					rankIndex++;
                    break;
                case sensorLongRangeHall:
                    status = Hall_EnableRead((connectors_t)i);
                    if (StatusOk == status) {
                        status = configureChannel(&hadc1, 
                                GPIO_GetConnectorAnalogChannel((connectors_t)i), 
                                rankList[rankIndex], PERIPHERAL_SAMPLETIME);
                        rankIndex++;
                    }
                    break;
                default:
                    break;
            }
        }
    }
    
    // Reset trigger data
    if (StatusOk == status) {
    	status = resetTriggerData(&triggerData);
    }
    
    return returnStatus(status, eSucIoctlStatus);
}

status_t ADC_StudyDataOff(void)
{
	// De-init ADC hardware
	status_t status = deInitAdcHardware(&hadc1);
	// Turn off any long range hall sensors, force normal hall sensors off (although they should be off
	// at end of data aggreagtion)
	for (int i = 0; i < NUM_CONNECTORS; i++) {
        switch (adcSettings->connectorSettings.sensorTypes[i]) {
        	case sensorHall:
            case sensorLongRangeHall:
            	// preserve first bad status
				status = Status_Preserve(status, Hall_DisableRead((connectors_t)i));
                break;
            default:
                break;
        }
    }
	
	// Force VSUP off
	HAL_GPIO_WritePin(VSUP_SAMPLE_CNTRL_Port, VSUP_SAMPLE_CNTRL_Pin, GPIO_PIN_RESET);
	
	return returnStatus(status, eSucIoctlStatus);
}

status_t ADC_ReadVBattBlocking(uint32_t timeoutMs, float * out)
{
	// Configure adc
	status_t status = initAdcHardware(&hadc1, 1);
	if (StatusOk == status) {
		status = configureChannel(&hadc1, VSUP_SAMPLE_AnalogChannel, rankList[0], 
				VBAT_SAMPLETIME);
	}
	// Enable measurement
	if (StatusOk == status) {
		status = enableVBattMeasurement(true);
	}
	// Measure
	if (StatusOk == status) {
		uint32_t start = SysTime_GetMs();
		// Saturate vbat history
		for (int i = 0; i < VBAT_HISTORY_LEN; i++) {
			// check timeout
			int64_t remaining = timeoutMs - SysTime_GetElapsed(start); // snapshot this value
			if (remaining < 0) {
				status = StatusHalTimeout;
				break;
			}
			// perform conversion
			HAL_ADC_Start(&hadc1);
			HAL_StatusTypeDef statusConv = HAL_ADC_PollForConversion(&hadc1, (uint32_t)remaining);
			// check return value
			if (HAL_OK == statusConv) {
				// Add to history
				vbatDataAppend(HAL_ADC_GetValue(&hadc1));
			}
			else if (HAL_TIMEOUT == statusConv) {
				status = StatusHalTimeout;
				break;
			} 
			else {
				status = StatusHal;
				break;
			}
		}
		HAL_ADC_Stop(&hadc1);
		// Get smoothed value
		*out = vbatDataGetSmoothed();
	}
	
	// Disable measurement and turn off ADC regardless of status
	status = Status_Preserve(status, enableVBattMeasurement(false));
	status = Status_Preserve(status, deInitAdcHardware(&hadc1));
	
	return returnStatus(status, eSucReadStatus);
}

status_t ADC_ReadConnectorBlocking(connectors_t connector, bool scaleData,
		uint16_t numSamples, uint32_t timeoutMs, memBlock32_t * out)
{
	// Configure adc
	status_t status = initAdcHardware(&hadc1, 1);
	if (StatusOk == status) {
		status = configureChannel(&hadc1, GPIO_GetConnectorAnalogChannel(connector), 
				rankList[0], PERIPHERAL_SAMPLETIME);
	}
	// Enable measurement
	if (StatusOk == status) {
		status = enableConnectorMeasurement(connector, 
				adcSettings->connectorSettings.sensorTypes[connector], true, true);
	}
	// Measure
	uint32_t sum = 0;
	if (StatusOk == status) {
		uint32_t start = SysTime_GetMs();
		for (int i = 0; i < numSamples; i++) {
			// check timeout
			int64_t remaining = timeoutMs - SysTime_GetElapsed(start); // snapshot this value
			if (remaining < 0) {
				status = StatusHalTimeout;
				break;
			}
			// perform conversion
			HAL_ADC_Start(&hadc1);
			HAL_StatusTypeDef statusConv = HAL_ADC_PollForConversion(&hadc1, (uint32_t)remaining);
			// check return value
			if (HAL_OK == statusConv) {
				sum += HAL_ADC_GetValue(&hadc1);
			}
			else if (HAL_TIMEOUT == statusConv) {
				status = StatusHalTimeout;
				break;
			} 
			else {
				status = StatusHal;
				break;
			}
		}
		HAL_ADC_Stop(&hadc1);
	}
	// Write data out
	if (StatusOk == status) {
		float avg = (float)sum / (float)numSamples;
		if (scaleData) {
			status = scaleConnectorData(connector, 
					adcSettings->connectorSettings.sensorTypes[connector], 
					(uint16_t)avg, 
					out);
		} else {
			out->uint32 = (uint32_t)avg;
		}
	}
	
	// Disable measurement and turn off ADC regardless of status
	status = Status_Preserve(status, enableConnectorMeasurement(connector, 
			adcSettings->connectorSettings.sensorTypes[connector], false, true));
	status = Status_Preserve(status, deInitAdcHardware(&hadc1));
	
	return returnStatus(status, eSucReadStatus);
}

status_t ADC_ReadData(adcDataHandler_t * dataOut, void (*callback)(void))
{
	status_t status = StatusOk;
	if(!dataOut || !callback){
		status = StatusNullParameter;
	}
	
	if (initialized) {
        if (StatusOk == status) {
            dataHandlerOut = dataOut;
            readCallback = callback;
            currentConversion = 0;
            
            // Enable measurements
            status = enableAdcMeasurements(adcSettings, true);
            // Start conversion
            HAL_ADC_Start_IT(&hadc1);
        }
	} else {
	    status = StatusCodePath; // we shouldn't be able to get here..
	}

	return returnStatus(status, eSucReadStatus);
}

bool ADC_GetTrigEnabled(void)
{
	return triggerData.enabled;
}

bool ADC_GetTrigRelative(void)
{
	return triggerData.relative;
}

bool ADC_GetTrigActive(void)
{
	bool active = false;
	
	// Filter out invalid conditions
	if (triggerData.enabled && !triggerData.relative && !triggerData.reset) {
		if (triggerData.current >= triggerData.threshold) {
			active = true;
		}
	}
	
	return active;
}

uint32_t ADC_GetTrigCount(void)
{
	return triggerData.count;
}

bool ADC_GetTrigPassed(void)
{
	bool passed = false;
	
	// Filter out invalid conditions
	if (triggerData.enabled && !triggerData.reset) {
		if (triggerData.relative) {
			// Relative mode
			passed = ((triggerData.max - triggerData.min) >= triggerData.threshold);
		} else {
			// Absolute mode
			passed = (triggerData.max >= triggerData.threshold);
		}
	}
	
	return passed;
}

uint32_t ADC_GetLastTrigTime(void)
{
	uint32_t lastTime = 0;
	
	// Filter out invalid conditions
	if (triggerData.enabled && !triggerData.relative && !triggerData.reset) {
		if (triggerData.current >= triggerData.threshold) {
			lastTime = SysTime_GetMs(); // now!
		} else if (triggerData.max >= triggerData.threshold) {
			lastTime = triggerData.lastActive;
		}
	}
	
	return lastTime;
}

status_t ADC_SetupProtectModeTrigger(void)
{
	if (triggerData.enabled) {
		resetTriggerData(&triggerData);
		return StatusOk;
	} else {
		return StatusConfigSettings;
	}
}

bool ADC_GetProtectModeTriggerPassed(void)
{
	// Read trigger
	memBlock32_t trigData;
	status_t status = ADC_ReadConnectorBlocking(triggerData.connector, true, 
			1, PROTECT_READ_TIMEOUT, &trigData);

	if (StatusOk == status) {
		// Update trigger data
		status = updateTriggerData(&triggerData, trigData.float32);
		if (StatusOk == status) {
			// Return passed
			return ADC_GetTrigPassed();
		}
	}
	
	// If we made it here we encountered a bad status. Pass this to the caller as a
	// no-trigger pass event
	return false;
}

/// SAEC Kinetic Vision, Inc. ----------- END OF FILE
