/**
  @file       Multiplexer.h

  @copyright  (C) 2019 Kinetic Vision, Cincinnati Ohio.
               This software is property of SAEC Kinetic Vision, Inc
               and is considered confidential.

  @brief      Multiplexer software unit "H" file.

  @author     Parker Kamer

  @defgroup   MultiplexerSu

  Configuration History
  =====================

  Config Item    | Value
  -------------- | -----
  Config #       | NA
  Revision       | NA
  Revised, Date  | NA
  QA, Date       | NA
  Approved, Date | NA
  Released, Date | NA

  Significant Modification History (Most recent at top)
  =====================================================

  Date         | Initials | Details
  ------------ | -------- | -------
  18 Nov 2019  | PK       | Original

  Theory of Operation
  ===================
  This device will allow for multiple devices with the same slave address
  to be interfaced with. It currently supports 2 (subject to change) i2c channels

  */

// Define to prevent recursive inclusion -------------------------------------
#ifndef __MULTIPLEXER_H
#define __MULTIPLEXER_H

// Exported macro ------------------------------------------------------------

// Exported types ------------------------------------------------------------

// Exported constants --------------------------------------------------------
#define MULTIPLEXER_NUM_CHANNELS	8

// Exported objects ----------------------------------------------------------

// Exported functions --------------------------------------------------------

/// @brief Initializes the multiplexer
/// @return StatusOk, StatusHal
status_t Multiplexer_Init(void);

/// @brief Set the active channel bit field
/// @param args[in] channelField - bitfield associated with the active multiplexer channels
/// @return StatusOk, StatusHal
status_t Multiplexer_SetChannel(uint8_t channelField);

/// @brief Get the active channel bit field
/// @param args[out] channelField - bitfield associated with the active multiplexer channels
/// @return StatusOk, StatusHal
status_t Multiplexer_GetChannel(uint8_t* channelField);

/// @brief Set the active channel bit field
/// @param args[in] channelField - bitfield associated with the active multiplexer channels
/// @param args[in] callback - callback function to be executed upon completion of the operation
/// @return StatusOk, StatusHal
status_t Multiplexer_SetChannelAsync(uint8_t channelField, void (*callback)(void));

/// @brief Get the active channel bit field
/// @param args[out] channelField - bitfield associated with the active multiplexer channels
/// @param args[in] callback - callback function to be executed upon completion of the operation
/// @return StatusOk, StatusHal
status_t Multiplexer_GetChannelAsync(uint8_t * channelField, void (*callback)(void));


#endif // __MULTIPLEXER_H

/// SAEC Kinetic Vision, Inc. ----------- END OF FILE


