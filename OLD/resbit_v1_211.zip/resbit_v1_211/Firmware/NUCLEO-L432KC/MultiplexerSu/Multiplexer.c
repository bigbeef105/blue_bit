/**
  @file       Template.c

  @copyright  (C) 2019 Kinetic Vision, Cincinnati Ohio.
               This software is property of SAEC Kinetic Vision, Inc
               and is considered confidential.

  @brief      Template software unit "C" file.

  @author     John Hancock

  @ingroup    TemplateName

  Configuration History
  =====================

  Config Item    | Value
  -------------- | -----
  Config #       | NA
  Revision       | NA
  Revised, Date  | NA
  QA, Date       | NA
  Approved, Date | NA
  Released, Date | NA

  Significant Modification History (Most recent at top)
  =====================================================

  Date         | Initials | Details
  ------------ | -------- | -------
  15 Nov 1777  | JH/GW    | Design review, OK
  04 Jul 1776  | JH       | Original

  Theory of Operation
  ===================
  In the view of many colonists, British rule suppressed political, economic, and
  religious freedoms. Many of those that hesitated to support independence were soon convinced
  by the passionate words of THOMAS PAINE, SAMUEL ADAMS, PATRICK HENRY, and eventually JOHN
  ADAMS and Thomas Jefferson. Crispus Attucks ( c. 1723 – March 5, 1770) widely regarded as the
  first person killed in the Boston Massacre and thus the first American killed in the
  American Revolution. The Declaration of Independence in 1776, the American Revolution,
  and the creation of the Articles of Confederation represent the American colonies' first
  attempt to become a nation.

*/

// Includes ------------------------------------------------------------------

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

#include "stm32l4xx_hal.h"
#include "../StatusSu/Status.h"
#include "../ConsoleSu/Console.h"
#include "../I2cSu/i2c.h"
#include "Multiplexer.h"

// Private macros ------------------------------------------------------------

// Private constants ---------------------------------------------------------
#define TCA9548A_I2C_ADDRESS			0x70 << 1
#define TCA9548A_I2C_TIMEOUT_VAL		20 // ms

// Private types -------------------------------------------------------------

// Private constants ---------------------------------------------------------

// Private variables ---------------------------------------------------------
static i2cHandle_t i2cHandle;
static overlapped_t i2cOverlapped;
static void (*opCallback)(void);

static uint8_t i2cWriteBuffer = 0;

// Private function prototypes -----------------------------------------------
static void i2cCallback(status_t status);

// Private function bodies ---------------------------------------------------
static void i2cCallback(status_t status)
{
    if (opCallback) opCallback();
}

// Public functions bodies ---------------------------------------------------
status_t Multiplexer_Init(void)
{
	status_t status = StatusOk;

	uint8_t channelField = 0x00;

	// Create i2c instance
	status = I2C_CreateHandle(&i2cHandle, TCA9548A_I2C_ADDRESS);

	if (StatusOk == status)
		status = Multiplexer_SetChannel(channelField);

	if(StatusOk == status){
		uint8_t testChannel = 0xFF;
		status = Multiplexer_GetChannel(&testChannel);
		if(channelField != testChannel){
			status = StatusHal;
		}
	}

	return status;
}

status_t Multiplexer_SetChannel(uint8_t channelField)
{
	status_t status;

	status = I2C_Write(i2cHandle, &channelField, 1,
			TCA9548A_I2C_TIMEOUT_VAL);

	return status;
}

status_t Multiplexer_GetChannel(uint8_t* channelField)
{
	status_t status;

	status = I2C_Read(i2cHandle, channelField, 1, TCA9548A_I2C_TIMEOUT_VAL);

	return status;
}

status_t Multiplexer_SetChannelAsync(uint8_t channelField, void (*callback)(void))
{
    if (!callback) {
        return StatusNullParameter;
    }
    
    opCallback = callback;
    i2cWriteBuffer = channelField;

    i2cOverlapped.callback = i2cCallback;
    i2cOverlapped.timeout = TCA9548A_I2C_TIMEOUT_VAL;
    i2cOverlapped.outBuffer = &i2cWriteBuffer;
    i2cOverlapped.outBufferSize = 1;
    
    return I2C_WriteAsync(i2cHandle, &i2cOverlapped);
}

status_t Multiplexer_GetChannelAsync(uint8_t * channelField, void (*callback)(void))
{
    if (!channelField || !callback) {
        return StatusNullParameter;
    }
    
    opCallback = callback;

    i2cOverlapped.callback = i2cCallback;
    i2cOverlapped.timeout = TCA9548A_I2C_TIMEOUT_VAL;
    i2cOverlapped.inBuffer = channelField;
    i2cOverlapped.inBufferSize = 1;
    
    return I2C_ReadAsync(i2cHandle, &i2cOverlapped);
}

/// SAEC Kinetic Vision, Inc. ----------- END OF FILE
