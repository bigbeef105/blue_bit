/**
  @file       utility.c

  @copyright  (C) 2019 Kinetic Vision, Cincinnati Ohio.
               This software is property of SAEC Kinetic Vision, Inc
               and is considered confidential.

  @brief      Imu Bno055 software unit "C" file.
  @author     Parker Kamer
  @ingroup    UtilitySu

  Configuration History
  =====================

  Config Item    | Value
  -------------- | -----
  Config #       | NA
  Revision       | NA
  Revised, Date  | NA
  QA, Date       | NA
  Approved, Date | NA
  Released, Date | NA

  Significant Modification History (Most recent at top)
  =====================================================

  Date         | Initials | Details
  ------------ | -------- | -------
  20 Dec 2019  | PK       | Original

  Theory of Operation
  ===================
  TBD

*/

// Includes ------------------------------------------------------------------
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <math.h>

#include "stm32l4xx_hal.h"
#include "../StatusSu/Status.h"
#include "Utility.h"

// Private function prototypes -----------------------------------------------

// Private macros ------------------------------------------------------------

// Private constants ---------------------------------------------------------

// Private types -------------------------------------------------------------

// Private variables ---------------------------------------------------------

// Private function bodies ---------------------------------------------------
static void swapString(uint8_t* pString, uint32_t stringSize)
{
	//Rearrange string
	uint8_t endIndex = stringSize - 1;
	uint8_t startIndex = 0;

	while(1){

		if(endIndex <= startIndex){
			break;
		}
		char temp = pString[endIndex];
		pString[endIndex] = pString[startIndex];
		pString[startIndex] = temp;

		endIndex--;
		startIndex++;
	}
}//swapString

// Public functions bodies ---------------------------------------------------
uint32_t Utility_ItoaBase10(int32_t value, uint8_t* pString, uint8_t minDigits)
{
	bool isNegative = false;
	uint8_t digit = 0;
	uint32_t stringIndex = 0;

	// Handle negative numbers
	if (value < 0){
		isNegative = true;
		value = -(value);
	}

	// Convert integer
	while (value){
		digit = value % 10;
		pString[stringIndex++] = digit + '0';
		value /= 10;
	}
	// Pad zeros
	while(stringIndex < minDigits){
		pString[stringIndex++] = '0';
	}
	// Apply negative sign
	if(isNegative == true){
		pString[stringIndex++] = '-';
	}

	swapString(pString, stringIndex);

	return stringIndex;

}//Utility_ItoaBase10_U32

uint32_t Utility_FtoaBase10(float value, uint8_t* pString, fPrecision_t precision)
{
	uint32_t stringIndex = 0;

	if (value < 0){
		pString[stringIndex++] = '-';
		value = -(value);
	}

	// Get the integer portion
	int integer = value;
	// Convert integer
	stringIndex += Utility_ItoaBase10(integer, pString + stringIndex, 1);
	// Get fraction
	float tmpFrac = value - integer;
	int decimal;
	switch (precision) {
		case fPrecision_0:
			// Do nothing
			break;
		case fPrecision_1:
			// Add decimal point
			pString[stringIndex++] = '.';
			// Get 1 fractional digit
			decimal = tmpFrac * 10;
			stringIndex += Utility_ItoaBase10(decimal, pString + stringIndex, 1);
			break;
		case fPrecision_2:
			// Add decimal point
			pString[stringIndex++] = '.';
			// Get 1 fractional digit
			decimal = tmpFrac * 100;
			stringIndex += Utility_ItoaBase10(decimal, pString + stringIndex, 2);
			break;
		case fPrecision_3:
			// Add decimal point
			pString[stringIndex++] = '.';
			// Get 1 fractional digit
			decimal = tmpFrac * 1000;
			stringIndex += Utility_ItoaBase10(decimal, pString + stringIndex, 3);
			break;
	}

	return stringIndex;

}//Utility_FtoaBase10
