/**
  @file       Utility.h

  @copyright  (C) 2019 Kinetic Vision, Cincinnati Ohio.
               This software is property of SAEC Kinetic Vision, Inc
               and is considered confidential.

  @brief      Utility software unit "H" file.

  @author     Parker Kamer

  @defgroup   UtilitySu

  Configuration History
  =====================

  Config Item    | Value
  -------------- | -----
  Config #       | NA
  Revision       | NA
  Revised, Date  | NA
  QA, Date       | NA
  Approved, Date | NA
  Released, Date | NA

  Significant Modification History (Most recent at top)
  =====================================================

  Date         | Initials | Details
  ------------ | -------- | -------
  20 Dec 2019  | PK       | Original

  Theory of Operation
  ===================
  This software unit will be used for common functionality need across
  multiple software units.

  */

// Define to prevent recursive inclusion -------------------------------------
#ifndef __UTILITY_H
#define __UTILITY_H

// Exported macro ------------------------------------------------------------

// Exported types ------------------------------------------------------------
typedef enum {
	fPrecision_0 = 0,
	fPrecision_1,
	fPrecision_2,
	fPrecision_3,
} fPrecision_t;

// Exported constants --------------------------------------------------------

// Exported objects ----------------------------------------------------------

// Exported functions --------------------------------------------------------

/// @brief Convert an integer into an ascii string
/// @param args[in] value - integer value
/// @param args[out] pString - ascii string
/// @param args[in] minDigits - minimum digits (will be 0 padded if needed)
/// @return Size of the string
uint32_t Utility_ItoaBase10(int32_t value, uint8_t* pString, uint8_t minDigits);

/// @brief Convert a floating point value into an ascii string
/// @param args[in] value - floating point value
/// @param args[out] pString - ascii string
/// @param args[in] precision - digits of precision
/// @return Size of the string
uint32_t Utility_FtoaBase10(float value, uint8_t* pString, fPrecision_t precision);

#endif // __UTILITY_H

/// SAEC Kinetic Vision, Inc. ----------- END OF FILE





