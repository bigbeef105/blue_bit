/**
  @file       FDC2214.h

  @copyright  (C) 2019 Kinetic Vision, Cincinnati Ohio.
               This software is property of SAEC Kinetic Vision, Inc
               and is considered confidential.

  @brief      FDC2214 liquid level sensor software unit "H" file.

  @author     Parker Kamer

  @defgroup   FDC2214Su

  Configuration History
  =====================

  Config Item    | Value
  -------------- | -----
  Config #       | NA
  Revision       | NA
  Revised, Date  | NA
  QA, Date       | NA
  Approved, Date | NA
  Released, Date | NA

  Significant Modification History (Most recent at top)
  =====================================================

  Date         | Initials | Details
  ------------ | -------- | -------
  12 Dec 2019  | PK       | Original

  Theory of Operation
  ===================
  Device will provide capacitive analog data used for liquid level detection.

  */

// Define to prevent recursive inclusion -------------------------------------
#ifndef __FDC2214_H
#define __FDC2214_H

#include "../StatusSu/Status.h"
#include "../GpioSu/gpio.h"
#include "../DataAggregatorSu/DataAggregator.h"

// Exported macro ------------------------------------------------------------

// Exported types ------------------------------------------------------------

// Exported constants --------------------------------------------------------

// Exported objects ----------------------------------------------------------

// Exported functions --------------------------------------------------------

/// @brief Initialize the fdc2214 liquid level sensor
/// @param args[in] connector - J connector the FDC2214 is connected to
/// @return StatusOk
status_t FDC2214_Init(connectors_t connector);

/// @brief Turns on the FDC2214
status_t FDC2214_PowerOn(void);

/// @brief Turns off the FDC2214
status_t FDC2214_PowerOff(void);

/// @brief Reads data from the device asynchronously, writes result into dataOut, 
///         calls callback when done
status_t FDC2214_ReadData(connectorDataHandler_t * dataOut, void (*callback)(void));


#endif // __FDC2214_H

/// SAEC Kinetic Vision, Inc. ----------- END OF FILE


