/**
  @file       FDC2214.c

  @copyright  (C) 2019 Kinetic Vision, Cincinnati Ohio.
               This software is property of SAEC Kinetic Vision, Inc
               and is considered confidential.

  @brief      FDC2214 liquid level sensor software unit "C" file.

  @author     Parker Kamer

  @ingroup    FDC2214Su

  Configuration History
  =====================

  Config Item    | Value
  -------------- | -----
  Config #       | NA
  Revision       | NA
  Revised, Date  | NA
  QA, Date       | NA
  Approved, Date | NA
  Released, Date | NA

  Significant Modification History (Most recent at top)
  =====================================================

  Date         | Initials | Details
  ------------ | -------- | -------
  12 Dec 2019  | PK       | Original

  Theory of Operation
  ===================
  TBD

*/

// Includes ------------------------------------------------------------------

#include "FDC2214.h"

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

#include <math.h>

#include "stm32l4xx_hal.h"
#include "../StatusSu/Status.h"
#include "../I2cSu/i2c.h"
#include "../DataAggregatorSu/DataAggregator.h"


// Private macros ------------------------------------------------------------

// Private constants ---------------------------------------------------------
#define FDC2214_I2C_ADDR_0  	 	0x2A << 1
#define FDC2214_I2C_ADDR_1   		0x2B << 1

#define FDC2214_I2C_TIMEOUT_VAL		20 // ms
// Address is 0x2A (default) or 0x2B (if ADDR is high)

//registers TODO: make this an enum
#define FDC2214_DEVICE_ID           		0x7F
#define FDC2214_MUX_CONFIG          		0x1B
#define FDC2214_CONFIG              		0x1A
#define FDC2214_RCOUNT_CH0          		0x08
#define FDC2214_RCOUNT_CH1          		0x09
#define FDC2214_RCOUNT_CH2          		0x0A
#define FDC2214_RCOUNT_CH3          		0x0B
#define FDC2214_OFFSET_CH0		          	0x0C
#define FDC2214_OFFSET_CH1          		0x0D
#define FDC2214_OFFSET_CH2    			    0x0E
#define FDC2214_OFFSET_CH3         			0x0F
#define FDC2214_SETTLECOUNT_CH0     		0x10
#define FDC2214_SETTLECOUNT_CH1     		0x11
#define FDC2214_SETTLECOUNT_CH2     		0x12
#define FDC2214_SETTLECOUNT_CH3     		0x13
#define FDC2214_CLOCK_DIVIDERS_CH0  		0x14
#define FDC2214_CLOCK_DIVIDERS_CH1  		0x15
#define FDC2214_CLOCK_DIVIDERS_CH2  		0x16
#define FDC2214_CLOCK_DIVIDERS_CH3  		0x17
#define FDC2214_STATUS              		0x18
#define FDC2214_DATA_CH0_MSB	            0x00
#define FDC2214_DATA_CH0_LSB    		    0x01
#define FDC2214_DATA_CH1_MSB	            0x02
#define FDC2214_DATA_CH1_LSB    		    0x03
#define FDC2214_DATA_CH2_MSB	            0x04
#define FDC2214_DATA_CH2_LSB    		    0x05
#define FDC2214_DATA_CH3_MSB	            0x06
#define FDC2214_DATA_CH3_LSB    		    0x07
#define FDC2214_DRIVE_CH0           		0x1E
#define FDC2214_DRIVE_CH1           		0x1F
#define FDC2214_DRIVE_CH2           		0x20
#define FDC2214_DRIVE_CH3           		0x21

// mask for 28bit data to filter out flag bits
#define FDC2214_DATA_CHx_MASK_DATA         	0x0FFF
#define FDC2214_DATA_CHx_MASK_ERRAW        	0x1000
#define FDC2214_DATA_CHx_MASK_ERRWD        	0x2000

#define DEFAULT_CHANNEL                     2
#define NUM_CHANNELS                        4

#define WRITE_BUFFER_SIZE                   2
#define READ_BUFFER_SIZE                    4

#define NUM_DATA_READY_RETRIES              3

// Private types -------------------------------------------------------------
typedef enum {
    fdcReadStateStart = 0,
    fdcReadStateDataReady,
    fdcReadStateReadMsb,
    fdcReadStateReadLsb,
} fdcReadStates_t;

// Private variables ---------------------------------------------------------
static uint32_t sdPin = 0;
static GPIO_TypeDef* sdPort = NULL;

static uint8_t i2cWriteBuffer[WRITE_BUFFER_SIZE];
static uint8_t i2cReadBuffer[READ_BUFFER_SIZE];

static uint32_t channelData[NUM_CHANNELS] = { 0 };

static i2cHandle_t i2cHandle;
static volatile overlapped_t i2cOverlapped;

static fdcReadStates_t fdcReadState;
static uint16_t dataReadyRetries = 0;
static connectorDataHandler_t * dataHandlerOut = NULL;
static void (*readCallback)(void) = NULL;

// Private function prototypes -----------------------------------------------
static status_t loadSettings(uint8_t chanMask, uint8_t autoscanSeq, uint8_t deglitchValue, bool intOsc);
static void overlappedCallback(status_t status);

static status_t handleReadState(bool start);
static status_t finishRead(void);

static status_t readDataReady(uint8_t channel);
static status_t requestMsbData(uint8_t channel);
static status_t requestLsbData(uint8_t channel);
static status_t processChannelDataFromI2cBuffer(uint8_t channel);

static bool isReady(uint8_t channel, uint8_t fdcStatusB0, uint8_t fdcStatusB1);

// Private function bodies ---------------------------------------------------
static status_t loadSettings(uint8_t chanMask, uint8_t autoscanSeq, uint8_t deglitchValue, bool intOsc)
{
	status_t status = StatusOk;
	uint8_t txData[3];
	//Configuration register
	//	Active channel Select: b00 = ch0; b01 = ch1; b10 = ch2; b11 = ch3;
	//  |Sleep Mode: 0 - device active; 1 - device in sleep;
	//  ||Reserved, reserved, set to 1
	//  |||Sensor Activation Mode: 0 - drive sensor with full current. 1 - drive sensor with current set by DRIVE_CURRENT_CHn
	//  ||||Reserved, set to 1
	//  |||||Reference clock: 0 - use internal; 1 - use external clock
	//  ||||||Reserved, set to 0
	//  |||||||Disable interrupt. 0 - interrupt output on INTB pin; 1 - no interrupt output
	//  ||||||||High current sensor mode: 0 - 1.5mA max. 1 - > 1.5mA, not available if Autoscan is enabled
	//  |||||||||      Reserved, set to 000001
	//  |||||||||      |
	//  CCS1A1R0IH000000 -> 0001 1110 1000 0001 -> 0x1E81 	ExtOsc
	//  CCS1A1R0IH000000 -> 0001 1100 1000 0001 -> 0x1C81	IntOsc
	if (intOsc) {
		txData[0] = FDC2214_CONFIG;
		txData[1] = 0x1C;
		txData[2] = 0x81;
		status = I2C_Write(i2cHandle, txData, 3,
				FDC2214_I2C_TIMEOUT_VAL); //write16FDC(FDC2214_CONFIG, 0x1C81);  //set config
	} else {
		txData[0] = FDC2214_CONFIG;
		txData[1] = 0x1E;
		txData[2] = 0x81;
		status = I2C_Write(i2cHandle, txData, 3,
				FDC2214_I2C_TIMEOUT_VAL); //write16FDC(FDC2214_CONFIG, 0x1E81);  //set config
	}
	if(StatusOk == status){
		//If channel 1 selected, init it..
		if (chanMask & 0x01) {

			//settle count maximized, slow application
			txData[0] = FDC2214_SETTLECOUNT_CH0;
			txData[1] = 0x00;
			txData[2] = 0x64;
			status = I2C_Write(i2cHandle, txData, 3,
					FDC2214_I2C_TIMEOUT_VAL); //write16FDC(FDC2214_SETTLECOUNT_CH0, 0x64);

			if(StatusOk == status){
				//rcount maximized for highest accuracy
				txData[0] = FDC2214_RCOUNT_CH0;
				txData[1] = 0xFF;
				txData[2] = 0xFF;
				status = I2C_Write(i2cHandle, txData, 3,
						FDC2214_I2C_TIMEOUT_VAL); //write16FDC(FDC2214_RCOUNT_CH0, 0xFFFF);
			}

			if(StatusOk == status){
				//no offset
				txData[0] = FDC2214_OFFSET_CH0;
				txData[0] = 0x00;
				txData[1] = 0x00;
				status = I2C_Write(i2cHandle, txData, 3,
						FDC2214_I2C_TIMEOUT_VAL); //write16FDC(FDC2214_OFFSET_CH0, 0x0000);
			}

			if(StatusOk == status){
				// Set clock dividers
				//  Reserved
				//  | Sensor Frequency Select. b01 = /1 = sensor freq 0.01 to 8.75MHz; b10 = /2 = sensor freq 0.01 to 10 or 5 to 10 MHz
				//  | | Reserved
				//  | | |         Reference divider. Must be > 1. fref = fclk / this register`
				//  | | |         |
				// 00FF00RRRRRRRRRR -> 0010000000000001 -> 0x2001
				txData[0] = FDC2214_CLOCK_DIVIDERS_CH0;
				txData[1] = 0x20;
				txData[2] = 0x01;
				status = I2C_Write(i2cHandle, txData, 3,
						FDC2214_I2C_TIMEOUT_VAL); //write16FDC(FDC2214_CLOCK_DIVIDERS_CH0, 0x2001);
			}

			if(StatusOk == status){
				//set drive register
				txData[0] = FDC2214_DRIVE_CH0;
				txData[1] = 0xF8;
				txData[2] = 0x00;
				status = I2C_Write(i2cHandle, txData, 3,
						FDC2214_I2C_TIMEOUT_VAL); //write16FDC(FDC2214_CONFIG, 0x1C81);  //set config//write16FDC(FDC2214_DRIVE_CH0, 0xF800);
			}
		}
	}
	if(StatusOk == status){
		// Init chan2, if selected by channel init mask
		if (chanMask & 0x02) {
			/*write16FDC(FDC2214_SETTLECOUNT_CH1, 0x64);
			write16FDC(FDC2214_RCOUNT_CH1, 0xFFFF);
			write16FDC(FDC2214_OFFSET_CH1, 0x0000);
			write16FDC(FDC2214_CLOCK_DIVIDERS_CH1, 0x2001);
			write16FDC(FDC2214_DRIVE_CH1, 0xF800);*/
			//settle count maximized, slow application
			txData[0] = FDC2214_SETTLECOUNT_CH1;
			txData[1] = 0x00;
			txData[2] = 0x64;
			status = I2C_Write(i2cHandle, txData, 3,
					FDC2214_I2C_TIMEOUT_VAL);
			if(StatusOk == status){
				//rcount maximized for highest accuracy
				txData[0] = FDC2214_RCOUNT_CH1;
				txData[1] = 0xFF;
				txData[2] = 0xFF;
				status = I2C_Write(i2cHandle, txData, 3,
						FDC2214_I2C_TIMEOUT_VAL);
			}
			if(StatusOk == status){
				//no offset
				txData[0] = FDC2214_OFFSET_CH1;
				txData[0] = 0x00;
				txData[1] = 0x00;
				status = I2C_Write(i2cHandle, txData, 3,
						FDC2214_I2C_TIMEOUT_VAL);
			}
			if(StatusOk == status){
				// Set clock dividers
				txData[0] = FDC2214_CLOCK_DIVIDERS_CH1;
				txData[1] = 0x20;
				txData[2] = 0x01;
				status = I2C_Write(i2cHandle, txData, 3,
						FDC2214_I2C_TIMEOUT_VAL);
			}
			if(StatusOk == status){
				//set drive register
				txData[0] = FDC2214_DRIVE_CH1;
				txData[1] = 0xF8;
				txData[2] = 0x00;
				status = I2C_Write(i2cHandle, txData, 3,
						FDC2214_I2C_TIMEOUT_VAL);
			}
		}
	}
	if(StatusOk == status){
		if (chanMask & 0x04) {
			/*write16FDC(FDC2214_SETTLECOUNT_CH2, 0x64);
			write16FDC(FDC2214_RCOUNT_CH2, 0xFFFF);
			write16FDC(FDC2214_OFFSET_CH2, 0x0000);
			write16FDC(FDC2214_CLOCK_DIVIDERS_CH2, 0x2001);
			write16FDC(FDC2214_DRIVE_CH2, 0xF800);*/
			//settle count maximized, slow application
			txData[0] = FDC2214_SETTLECOUNT_CH2;
			txData[1] = 0x00;
			txData[2] = 0x64;
			status = I2C_Write(i2cHandle, txData, 3,
					FDC2214_I2C_TIMEOUT_VAL);
			if(StatusOk == status){
				//rcount maximized for highest accuracy
				txData[0] = FDC2214_RCOUNT_CH2;
				txData[1] = 0xFF;
				txData[2] = 0xFF;
				status = I2C_Write(i2cHandle, txData, 3,
						FDC2214_I2C_TIMEOUT_VAL);
			}
			if(StatusOk == status){
				//no offset
				txData[0] = FDC2214_OFFSET_CH2;
				txData[0] = 0x00;
				txData[1] = 0x00;
				status = I2C_Write(i2cHandle, txData, 3,
						FDC2214_I2C_TIMEOUT_VAL);
			}
			if(StatusOk == status){
				// Set clock dividers
				txData[0] = FDC2214_CLOCK_DIVIDERS_CH2;
				txData[1] = 0x20;
				txData[2] = 0x01;
				status = I2C_Write(i2cHandle, txData, 3,
						FDC2214_I2C_TIMEOUT_VAL);
			}
			if(StatusOk == status){
				//set drive register
				txData[0] = FDC2214_DRIVE_CH2;
				txData[1] = 0xF8;
				txData[2] = 0x00;
				status = I2C_Write(i2cHandle, txData, 3,
						FDC2214_I2C_TIMEOUT_VAL);
			}
		}
	}
	if(StatusOk == status){
		if (chanMask & 0x08) {
			/*write16FDC(FDC2214_SETTLECOUNT_CH3, 0x64);
			write16FDC(FDC2214_RCOUNT_CH3, 0xFFFF);
			write16FDC(FDC2214_OFFSET_CH3, 0x0000);
			write16FDC(FDC2214_CLOCK_DIVIDERS_CH3, 0x2001);
			write16FDC(FDC2214_DRIVE_CH3, 0xF800);*/
			//settle count maximized, slow application
			txData[0] = FDC2214_SETTLECOUNT_CH3;
			txData[1] = 0x00;
			txData[2] = 0x64;
			status = I2C_Write(i2cHandle, txData, 3,
					FDC2214_I2C_TIMEOUT_VAL);
			if(StatusOk == status){
				//rcount maximized for highest accuracy
				txData[0] = FDC2214_RCOUNT_CH3;
				txData[1] = 0xFF;
				txData[2] = 0xFF;
				status = I2C_Write(i2cHandle, txData, 3,
						FDC2214_I2C_TIMEOUT_VAL);
			}
			if(StatusOk == status){
				//no offset
				txData[0] = FDC2214_OFFSET_CH3;
				txData[0] = 0x00;
				txData[1] = 0x00;
				status = I2C_Write(i2cHandle, txData, 3,
						FDC2214_I2C_TIMEOUT_VAL);
			}
			if(StatusOk == status){
				// Set clock dividers
				txData[0] = FDC2214_CLOCK_DIVIDERS_CH3;
				txData[1] = 0x20;
				txData[2] = 0x01;
				status = I2C_Write(i2cHandle, txData, 3,
						FDC2214_I2C_TIMEOUT_VAL);
			}
			if(StatusOk == status){
				//set drive register
				txData[0] = FDC2214_DRIVE_CH3;
				txData[1] = 0xF8;
				txData[2] = 0x00;
				status = I2C_Write(i2cHandle, txData, 3,
						FDC2214_I2C_TIMEOUT_VAL);
			}
		}
	}
	if(StatusOk == status){
		// Autoscan: 0 = single channel, selected by CONFIG.ACTIVE_CHAN
		// | Autoscan sequence. b00 for chan 1-2, b01 for chan 1-2-3, b10 for chan 1-2-3-4
		// | |         Reserved - must be b0001000001
		// | |         |  Deglitch frequency. b001 for 1 MHz, b100 for 3.3 MHz, b101 for 10 Mhz, b111 for 33 MHz
		// | |         |  |
		// ARR0001000001DDD -> b0000 0010 0000 1000 -> h0208
		uint16_t muxVal = 0x0208 | ((uint16_t)autoscanSeq << 13) | deglitchValue;
		//
		txData[0] = FDC2214_MUX_CONFIG;
		txData[1] = (muxVal & 0xFF00) >> 8;
		txData[2] = muxVal & 0x00FF;
		status = I2C_Write(i2cHandle, txData, 3,
				FDC2214_I2C_TIMEOUT_VAL);//write16FDC(FDC2214_MUX_CONFIG, muxVal);  //set mux config for channels
	}

	return status;
}

static void overlappedCallback(status_t status)
{
	handleReadState(false);
}

static status_t handleReadState(bool start)
{
    status_t status = StatusOk;
    
    if (start) fdcReadState = fdcReadStateStart;
    
    switch (fdcReadState) {
        case fdcReadStateStart:
            fdcReadState = fdcReadStateDataReady;
            dataReadyRetries = NUM_DATA_READY_RETRIES;
            
            status = readDataReady(DEFAULT_CHANNEL);
            break;
        case fdcReadStateDataReady:
            if (isReady(DEFAULT_CHANNEL, i2cReadBuffer[0], i2cReadBuffer[1])) {
                fdcReadState = fdcReadStateReadMsb;
                status = requestMsbData(DEFAULT_CHANNEL);
            } else {
                dataReadyRetries--;
                // Retry is not over limit
                if (dataReadyRetries > 0) {
                    status = readDataReady(DEFAULT_CHANNEL);
                } else {
                    // Return with previous data
                    status = finishRead();
                }
            }
            break;
        case fdcReadStateReadMsb:
            fdcReadState = fdcReadStateReadLsb;
            status = requestLsbData(DEFAULT_CHANNEL);
            break;
        case fdcReadStateReadLsb:
            // We're done
            status = processChannelDataFromI2cBuffer(DEFAULT_CHANNEL);
            // preserve any bad status from the above call, but always call callback
            if (StatusOk == status) {
                status = finishRead();
            } else {
                finishRead(); // don't overwrite status
            }
            break;
        default:
            status = StatusCodePath;
            break;
    }
    
    return status;
}

static status_t finishRead(void)
{
    status_t status = StatusOk;
    if (dataHandlerOut && readCallback) {
        dataHandlerOut->data[0].uint32 = channelData[DEFAULT_CHANNEL];
        readCallback();
    } else {
        status = StatusCodePath; // shouldn't be able to reach this
    }
    
    return status;
}

static status_t readDataReady(uint8_t channel)
{
    status_t status = StatusOk;

    if(StatusOk == status){
        i2cWriteBuffer[0] = FDC2214_STATUS;

        i2cOverlapped.callback = overlappedCallback;
        i2cOverlapped.timeout = FDC2214_I2C_TIMEOUT_VAL;
        i2cOverlapped.outBuffer = i2cWriteBuffer;
        i2cOverlapped.outBufferSize = 1;
        i2cOverlapped.inBuffer = i2cReadBuffer;
        i2cOverlapped.inBufferSize = 2;

        status = I2C_MemReadAsync(i2cHandle, &i2cOverlapped);
    }

    return status;
}

static status_t requestMsbData(uint8_t channel)
{
    status_t status = StatusOk;

    uint8_t address;

    switch (channel){
        case (0):
            address = FDC2214_DATA_CH0_MSB;
            break;
        case (1):
            address = FDC2214_DATA_CH1_MSB;
            break;
        case (2):
            address = FDC2214_DATA_CH2_MSB;
            break;
        case (3):
            address = FDC2214_DATA_CH3_MSB;
            break;
        default:
            status = StatusParameter1;
            break;
    }

    if(StatusOk == status){
        i2cWriteBuffer[0] = address;

        i2cOverlapped.callback = overlappedCallback;
        i2cOverlapped.timeout = FDC2214_I2C_TIMEOUT_VAL;
        i2cOverlapped.outBuffer = i2cWriteBuffer;
        i2cOverlapped.outBufferSize = 1;
        i2cOverlapped.inBuffer = i2cReadBuffer;
        i2cOverlapped.inBufferSize = 2;

        status = I2C_MemReadAsync(i2cHandle, &i2cOverlapped);
    }

    return status;
}

static status_t requestLsbData(uint8_t channel)
{
    status_t status = StatusOk;

    uint8_t address;

    switch (channel){
        case (0):
            address = FDC2214_DATA_CH0_LSB;
            break;
        case (1):
            address = FDC2214_DATA_CH1_LSB;
            break;
        case (2):
            address = FDC2214_DATA_CH2_LSB;
            break;
        case (3):
            address = FDC2214_DATA_CH3_LSB;
            break;
        default:
            status = StatusParameter1;
            break;
    }

    if(StatusOk == status){
        i2cWriteBuffer[0] = address;

        i2cOverlapped.callback = overlappedCallback;
        i2cOverlapped.timeout = FDC2214_I2C_TIMEOUT_VAL;
        i2cOverlapped.outBuffer = i2cWriteBuffer;
        i2cOverlapped.outBufferSize = 1;
        i2cOverlapped.inBuffer = i2cReadBuffer + 2;
        i2cOverlapped.inBufferSize = 2;

        status = I2C_MemReadAsync(i2cHandle, &i2cOverlapped);
    }

    return status;
}

static status_t processChannelDataFromI2cBuffer(uint8_t channel)
{
    if (channel >= NUM_CHANNELS)
        return StatusCodePath; // bug in code
    
    uint32_t temp32;

    temp32 = i2cReadBuffer[0] << 24;
    temp32 |= i2cReadBuffer[1] << 16;
    temp32 |= i2cReadBuffer[2] << 8;
    temp32 |= i2cReadBuffer[3];
    
    channelData[channel] = temp32;

    return StatusOk;
}

static bool isReady(uint8_t channel, uint8_t fdcStatusB0, uint8_t fdcStatusB1)
{
    uint16_t bitUnreadConv = 0xFFFF;
    switch (channel){
        case (0):
            bitUnreadConv = 0x0008; //denotes unread CH0 reading in STATUS register
            break;
        case (1):
            bitUnreadConv = 0x0004; //denotes unread CH1 reading in STATUS register
            break;
        case (2):
            bitUnreadConv = 0x0002; //denotes unread CH2 reading in STATUS register
            break;
        case (3):
            bitUnreadConv = 0x0001; //denotes unread CH3 reading in STATUS register
            break;
        default:
            // Leave at FFFF -- this will always return false
            break;
    }
    
    uint16_t fdcStatus = (fdcStatusB0 << 8) | fdcStatusB1;
    if (bitUnreadConv & fdcStatus) {
        return true;
    } else {
        return false;
    }
}

// Public functions bodies ---------------------------------------------------
status_t FDC2214_Init(connectors_t connector)
{
	status_t status = StatusOk;

	// Setup shutdown pin (active-high)
	sdPin = GPIO_GetConnectorGPIOPin(connector);
	sdPort = GPIO_GetConnectorGPIOPort(connector);
	GPIO_InitTypeDef sdInit = {
			.Pin = sdPin,
			.Mode = GPIO_MODE_OUTPUT_PP,
			.Pull = GPIO_NOPULL,
	};
	HAL_GPIO_DeInit(sdPort, sdPin);
	HAL_GPIO_Init(sdPort, &sdInit);
	
	// Turn on device
	HAL_GPIO_WritePin(sdPort, sdPin, GPIO_PIN_RESET);
	
	// Read Chip ID from first address
	uint8_t devId_8[2];
	uint16_t devID_16;
	status = I2C_CreateHandle(&i2cHandle, FDC2214_I2C_ADDR_0);
	if (StatusOk == status) {
		status = I2C_MemRead(i2cHandle, FDC2214_DEVICE_ID, 1, devId_8, 2,
				FDC2214_I2C_TIMEOUT_VAL);

		// If unsuccessful, try second address
		if (StatusOk != status) {
			status = I2C_CloseHandle(i2cHandle);
			if (StatusOk == status) {
				status = I2C_CreateHandle(&i2cHandle, FDC2214_I2C_ADDR_1);
			}
			if (StatusOk == status) {
				status = I2C_MemRead(i2cHandle, FDC2214_DEVICE_ID, 1,
						devId_8, 2, FDC2214_I2C_TIMEOUT_VAL);
			}
		}
	}
	if(StatusOk == status)
	{
		devID_16 = devId_8[0] << 8;
		devID_16 |= devId_8[1];

		if(devID_16 != 0x3054 ){
			if(devID_16 != 0x3055){
				status = StatusI2cChipId;
			}
		}
	}

	if(StatusOk == status){
		status = loadSettings(0xF, 0x6, 0x5, true);
	}
	
	// Turn off device
	HAL_GPIO_WritePin(sdPort, sdPin, GPIO_PIN_SET);

	return status;
}

status_t FDC2214_PowerOn(void)
{
	if (!sdPort) {
		return StatusCodePath; // this shouldn't be reachable
	}
	HAL_GPIO_WritePin(sdPort, sdPin, GPIO_PIN_RESET);
	return StatusOk;
}

status_t FDC2214_PowerOff(void)
{
	if (!sdPort) {
		return StatusCodePath; // this shouldn't be reachable
	}
	HAL_GPIO_WritePin(sdPort, sdPin, GPIO_PIN_SET);
	return StatusOk;
}

status_t FDC2214_ReadData(connectorDataHandler_t * dataOut, void (*callback)(void))
{
    if (!dataOut || !callback) {
        return StatusNullParameter;
    } else {
        dataHandlerOut = dataOut;
        readCallback = callback;
        return handleReadState(true);
    }
}

/// SAEC Kinetic Vision, Inc. ----------- END OF FILE


