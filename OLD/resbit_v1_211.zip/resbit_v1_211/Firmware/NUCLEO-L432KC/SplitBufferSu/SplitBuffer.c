/**
  @file       SplitBuffer.c

  @copyright  (C) 2020 Kinetic Vision, Cincinnati Ohio.
               This software is property of SAEC Kinetic Vision, Inc
               and is considered confidential.

  @brief      SplitBuffer software unit "C" file.

  @author     Andrew Loebs

  @ingroup    SplitBufferSoftwareUnit

  Configuration History
  =====================

  Config Item    | Value
  -------------- | -----
  Config #       | NA
  Revision       | NA
  Revised, Date  | NA
  QA, Date       | NA
  Approved, Date | NA
  Released, Date | NA

  Significant Modification History (Most recent at top)
  =====================================================

  Date         | Initials | Details
  ------------ | -------- | -------
  29 Jan 2020  | ASL      | Original

  Theory of Operation
  ===================
  Manages a buffer of variable length memory blocks as a queue. Offers the advantage of giving
  each entry contiguous memory. Must be sized for at least 2*n where n is the maximum entry size.

*/

// Includes ------------------------------------------------------------------

#include "SplitBuffer.h"

#include <string.h> // memset, memcpy

#include "../SwUnitControlSu/SwUnitControl.h" // SwUnitControl_WriteStatus()

// Private function prototypes -----------------------------------------------
static void tailsClear(uint16_t * tails);
static uint16_t tailsPopFront(uint16_t * tails);
static status_t tailsPushBack(uint16_t * tails, size_t entryLen,
                              size_t splitLen, uint16_t * lastTail);

// Private macros ------------------------------------------------------------
#define returnStatus(__status__,__source__) SwUnitControl_WriteStatus(eSucSplitBufferSu,__source__,__status__,__LINE__);

// Private constants ---------------------------------------------------------

// Private types -------------------------------------------------------------

// Private constants ---------------------------------------------------------

// Private variables ---------------------------------------------------------

// Private function bodies ---------------------------------------------------
static void tailsClear(uint16_t * tails)
{
    memset(tails, 0, sizeof(uint16_t) * SBMEMBER_MAX_ENTRIES);
}

static uint16_t tailsPopFront(uint16_t * tails)
{
    uint16_t ret = tails[0];
    // Shift left
    for (int i = 0;
         (i < (SBMEMBER_MAX_ENTRIES - 1)) && (tails[i] != 0);
         i++)
    {
        tails[i] = tails[i + 1];
    }
    tails[SBMEMBER_MAX_ENTRIES - 1] = 0; // previous loop doesn't reach last element, and this is always 0 after pop..

    return ret;
}

static status_t tailsPushBack(uint16_t * tails, size_t entryLen,
                              size_t splitLen, uint16_t * lastTail)
{
    status_t status = StatusOk;
    bool pushed = false;

    if (tails[0] == 0) {
        if (entryLen <= splitLen) {
            tails[0] = entryLen;
            *lastTail = 0;
            pushed = true;
        } else {
            status = StatusBufferFull;
        }
    }

    if (Status_IsOk(status) && !pushed) {
        // Look for empty read end index
        for (int i = 0; i < (SBMEMBER_MAX_ENTRIES - 1); i++) {
            if (tails[i + 1] == 0) {
                uint16_t newIndex = tails[i] + entryLen;
                if (newIndex <= splitLen) {
                    tails[i + 1] = newIndex;
                    *lastTail = tails[i];
                    pushed = true;
                }
                break;
            }
        }
        if (!pushed) {
            status = StatusBufferFull;
        }
    }

    return status;
}

// Public functions bodies ---------------------------------------------------
status_t SplitBuffer_Setup(splitBuffer_t * sb, uint8_t * bufferMem, size_t len)
{
    status_t status = StatusOk;

    if (!sb || !bufferMem)
        status = StatusNullParameter;
    else if (len < 2)
        status = StatusBufferLength;

    sb->buffer = bufferMem;
    sb->bufferLen = len;
    sb->splitLen = len / 2;

    sb->near.buffer = sb->buffer;
    sb->near.head = 0;
    tailsClear(sb->near.tails);

    sb->far.buffer = &(sb->buffer[sb->splitLen]);
    sb->far.head = 0;
    tailsClear(sb->far.tails);

    sb->write = &sb->near;
    sb->read = &sb->near;

    return returnStatus(status, eSucIoctlStatus);
}

//static void tailsClear(uint16_t * tails);
//static size_t tailsPopFront(uint16_t * tails);
//static status_t tailsPushBack(uint16_t * tails, size_t entryLen,
//                              uint16_t maxIndex);
status_t SplitBuffer_Enqueue(splitBuffer_t * sb, uint8_t * dataIn, size_t len)
{
    status_t status = StatusOk;

    // Input validation
    if (!sb || !dataIn)
        status = StatusNullParameter;
    else if (len < 1)
        status = StatusBufferLength;

    uint16_t lastTail = 0;
    if (Status_IsOk(status))
        status = tailsPushBack(sb->write->tails, len, sb->splitLen, &lastTail);

    if (StatusBufferFull == status) {
        if (sb->write == sb->read) {
            // Attempt to place in other buffer
            splitMember_t * emptyBuff = (sb->write == &sb->near) ?
                &sb->far : &sb->near;
            status = tailsPushBack(emptyBuff->tails, len, sb->splitLen, &lastTail);
            if (Status_IsOk(status)) {
                sb->write = emptyBuff; // op was successful, switch write buffer
            }
        }
    }

    if (Status_IsOk(status))
        memcpy(&sb->write->buffer[lastTail], dataIn, len);

    return returnStatus(status, eSucIoctlStatus);
}

status_t SplitBuffer_Dequeue(splitBuffer_t * sb, uint8_t * dataOut,
                             size_t maxBytes, size_t * bytesWritten)
{
    status_t status = StatusOk;

    // Input validation
    if (!sb || !dataOut || !bytesWritten)
        status = StatusNullParameter;

    int32_t writeLen;
    if (Status_IsOk(status)) {
        if (SplitBuffer_IsEmpty(sb)) {
            *bytesWritten = 0;
            status = StatusBufferEmpty;
        } else {
            uint16_t tailIndex = tailsPopFront(sb->read->tails);
            if (tailIndex == 0) {
                sb->read = (sb->read == &sb->near) ? &sb->far : &sb->near;
                tailIndex = tailsPopFront(sb->read->tails);
            }
            writeLen = tailIndex - sb->read->head; // put it in large, signed container so we can check for negatives

            if (writeLen < 0)
                status = StatusCodePath; // this is an error in the split buffer logic
            else if (writeLen > maxBytes)
                status = StatusBufferLength;
        }
    }

    if (Status_IsOk(status)) {
        memcpy(dataOut, &sb->read->buffer[sb->read->head], writeLen);
        *bytesWritten = writeLen;

        // Move head
        if (sb->read->tails[0] == 0)
            sb->read->head = 0; // empty
        else
            sb->read->head += writeLen;
    }

    return returnStatus(status, eSucIoctlStatus);
}

status_t SplitBuffer_GetHead(splitBuffer_t * sb, uint8_t ** headPtr,
                             size_t * headSize)
{
    status_t status = StatusOk;

    // Input validation
    if (!sb || !headPtr || !headSize)
        status = StatusNullParameter;

    int32_t entryLen;
    if (Status_IsOk(status)) {
        if (SplitBuffer_IsEmpty(sb)) {
            *headSize = 0;
            status = StatusBufferEmpty;
        } else {
            if (sb->read->tails[0] == 0) {
                sb->read = (sb->read == &sb->near) ? &sb->far : &sb->near;
            }
            entryLen = sb->read->tails[0] - sb->read->head; // put it in large, signed container so we can check for negatives

            if (entryLen < 0)
                status = StatusCodePath; // this is an error in the split buffer logic
        }
    }

    if (Status_IsOk(status)) {
        *headPtr = &sb->read->buffer[sb->read->head];
        *headSize = entryLen;
    }

    return returnStatus(status, eSucIoctlStatus);
}

status_t SplitBuffer_FreeHead(splitBuffer_t * sb)
{
    status_t status = StatusOk;

    // Input validation
    if (!sb)
        status = StatusNullParameter;

    if (Status_IsOk(status)) {
        if (SplitBuffer_IsEmpty(sb)) {
            status = StatusBufferEmpty;
        } else {
            uint16_t tailIndex = tailsPopFront(sb->read->tails);
            if (tailIndex == 0) {
                sb->read = (sb->read == &sb->near) ? &sb->far : &sb->near;
                tailIndex = tailsPopFront(sb->read->tails);
            }
            // Move head
            if (sb->read->tails[0] == 0)
                sb->read->head = 0; // empty
            else
                sb->read->head = tailIndex;
        }
    }

    return returnStatus(status, eSucIoctlStatus);
}

bool SplitBuffer_IsEmpty(splitBuffer_t * sb)
{
    return (sb->read == sb->write) && (sb->read->tails[0] == 0);
}

/// SAEC Kinetic Vision, Inc. ----------- END OF FILE
