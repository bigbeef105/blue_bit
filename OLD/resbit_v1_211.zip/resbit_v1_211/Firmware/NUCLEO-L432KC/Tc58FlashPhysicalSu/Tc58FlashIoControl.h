/**
  @file     Tc58FlashIoControl.h

  @copyright  (C) 2019 Kinetic Vision, Cincinnati Ohio.
              This software is property of SAEC Kinetic Vision, Inc
              and is considered confidential.

  @brief      A TC58 Flash Interface, but is restricted to Io Control operations only.

  @author     Sherman Couch

  @ingroup   Tc58FlashPhysicalSoftwareUnit

  Configuration Information
  =========================

  Config Item    | Value
  -------------- | -----
  Config #       | NA
  Revision       | NA
  Revised, Date  | NA
  QA, Date       | TBD
  Approved, Date | NA
  Released, Date | NA

  Significant Modification History (Most recent at top)
  =====================================================

  Date         | Initials | Details
  ------------ | -------- | -------
  21 Aug 2019  | SC       | Inserted "remap" layer between logical and physical drivers.
  24 Jul 2019  | SC       | Original.

  Theory of Operation
  ===================
  The only client for the "Physical" driver, is the the "remap" driver.

  */

// Define to prevent recursive inclusion -------------------------------------
#ifndef __TC58_FLASH_IO_CTRL_H
#define __TC58_FLASH_IO_CTRL_H

// Exported macro ------------------------------------------------------------

// Exported types ------------------------------------------------------------
typedef enum {

	// Generic command (Used by FatFs) -

	// ========================================================
	// These ioctl commands return status, and a uint32_t value
	// ========================================================

	Tc58IoctlGetSectorCount = 1, 				// #define GET_SECTOR_COUNT		1	Get media size (needed at _USE_MKFS == 1)
	Tc58IoctlGetSectorSize = 2, 				// #define GET_SECTOR_SIZE		2	Get sector size (needed at _MAX_SS != _MIN_SS)
	Tc58IoctlGetBlockSize = 3, 					// #define GET_BLOCK_SIZE		3	Get erase block size (needed at _USE_MKFS == 1)
	Tc58IoctlMmcGetType = 10, 					// #define MMC_GET_TYPE			10	Get card type
	Tc58IoctlMmcGetCsd = 11, 					// #define MMC_GET_CSD			11	Get CSD
	Tc58IoctlMmcGetCide = 12, 					// #define MMC_GET_CID			12	Get CID
	Tc58IoctlMmcGetOcr = 13, 					// #define MMC_GET_OCR			13	Get OCR
	Tc58IoctlMmcGetSdStat = 14, 				// #define MMC_GET_SDSTAT		14	Get SD status
	Tc58IoctlAtaGetRev = 20, 					// #define ATA_GET_REV			20	Get F/W revision
	Tc58IoctlAtaGetModel = 21, 					// #define ATA_GET_MODEL		21	Get model name
	Tc58IoctlAtaGetSn = 22, 					// #define ATA_GET_SN			22	Get serial number

	Tc58IoctlGetSectorsPerBlock = 30,			// This information is needed inside the logical driver
	Tc58IoctlGetManufacturerId = 31,			// This information is needed (future growth) inside the logical driver
	Tc58IoctlGetDeviceId = 32,					// This information is needed (future growth) inside the logical driver
	Tc58IoctlGetSectorsPerPage = 33,			// This information is needed inside the logical driver

	Tc58IoctlPutNumberOfFsBlocks = 36,			// Places the total number of blocks known to the file system, into the physical driver
	Tc58IoctlPageBufferReset = 37,				// Resets the page buffer layer

	Tc58IoctlGetTc58PageSize = 38,				// Returns the Toshiba TC58's page size
	Tc58IoctlGetTc58BlockSize = 39,				// Returns the Toshiba TC58's block size
	Tc58IoctlGetTc58BlocksPerUnit = 40,
	Tc58IoctlGetMkfsIndication = 41,          	// Returns indication if "f_mkfs" needs to be run (0 = false)
	Tc58IoctlPutMkfsIndication = 42,          	// Allows storing "f_mkfs" indication
	Tc58IoctlPutScratchPadBlockNumber = 43,		// Puts the scratch pad block number into the physical layer
	Tc58IoctlGetLastFailedBlockNumber = 44,     // Retrieves the block number of the last failed block
	Tc58IoctlFormat = 45,                       // Formats all blocks in the TC58 part
	Tc58IoctlReFormat = 46,                     // Retains the remap block (2047), but formats all other blocks in the TC58 part

	// =======================================================
	// These commands return return status, and no other value
	// =======================================================

	Tc58IoctlCtrlSync = 0, 						// CTRL_SYNC					0	Complete pending write process (needed at _FS_READONLY == 0)
	Tc58IoctlTrim = 4, 							// #define CTRL_TRIM			4	Inform device that the data on the block of sectors is no longer used (needed at _USE_TRIM == 1)
	Tc58IoctlCtrlPower = 5, 					// #define CTRL_POWER			5	Get/Set power status
	Tc58IoctlCtrlLock = 6, 						// #define CTRL_LOCK			6	Lock/Unlock media removal
	Tc58IoctlCtrlEject = 7, 					// #define CTRL_EJECT			7	Eject media
	Tc58IoctlCtrlFormat = 8, 					// #define CTRL_FORMAT			8	Create physical format on the media

} Tc58FlashIoctlCode_t;

// Exported constants --------------------------------------------------------

// Exported objects ----------------------------------------------------------

// Exported functions --------------------------------------------------------

///  @brief Does IOCTL on a TC58 flash part
///  @details This function will only return a uint32_t for the IO control codes which require one
///  @param[in] controlCode
///  @param[in] pReturnValue
///  @param[out] *pReturnValue
///  @return StatusOK, all is well
///  @return StatusResultDiskError, maps at a higher level to: DRESULT (type), value: RES_ERROR = 1
///  @return StatusResultWriteProtect, maps at a higher level to: DRESULT (type), value: RES_WRPRT = 2
///  @return StatusResultNotReady, maps at a higher level to: DRESULT (type), value: RES_NOTRDY = 3
///  @return StatusResultInvalidParameter,  maps at a higher level to: DRESULT (type), value: RES_PARERR = 4
status_t Tc58Flash_DoIoControl(Tc58FlashIoctlCode_t controlCode, uint32_t *pReturnValue);


#endif // __TC58_FLASH_IO_CTRL_H

/// SAEC Kinetic Vision, Inc. ----------- END OF FILE

