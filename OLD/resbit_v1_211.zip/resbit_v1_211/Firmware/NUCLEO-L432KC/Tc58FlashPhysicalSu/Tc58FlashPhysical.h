/**
  @file     Tc58FlashPhysical.h

  @copyright  (C) 2019 Kinetic Vision, Cincinnati Ohio.
               This software is property of SAEC Kinetic Vision, Inc
               and is considered confidential.

  @brief      TC58 Flash software unit "H" file.

  @author     Sherman Couch

  @defgroup   Tc58FlashPhysicalSoftwareUnit Tc58FlashPhysical Software Unit (SU),
              encapsulates the details of physical access to the TC58 flash.

  Configuration Information
  =========================

  Config Item    | Value
  -------------- | -----
  Config #       | NA
  Revision       | NA
  Revised, Date  | NA
  QA, Date       | TBD
  Approved, Date | NA
  Released, Date | NA

  Significant Modification History (Most recent at top)
  =====================================================

  Date         | Initials | Details
  ------------ | -------- | -------
  07 Nov 2019  | SC       | Retrieve last failed block ioctl.
  06 Sep 2019  | SC       | Retooled to simply read/write pages, no sector operations.
  20 Aug 2019  | SC       | Supports more than 1 consecutive sector of erase.
  18 Jul 2019  | SC       | Refactored to use the standardized Doxygen headers.
  23 Jun 2019  | SC       | Original

  Theory of Operation
  ===================
  The Toshiba TC58 flash presents a rather tricky set of chip level interfaces.
  This software unit encapsulates those interfaces.  It presents a view of the
  chip client software units which is a conventional read/write/seek interface.

  Important
  =========
  The only client for the "Physical" driver, is the the "Logical" driver.  That being
  said, there is an "io control" function which can be called from "disk io".  That
  "io control" function lives at the physical layer, but can be called from higher
  layers, therefore it has its own include file.

  */

// Define to prevent recursive inclusion -------------------------------------
#ifndef __TC58_PHYSICAL_H
#define __TC58_PHYSICAL_H

// Exported macro ------------------------------------------------------------

// Exported types ------------------------------------------------------------

typedef struct {
	uint8_t manufacturerId;
	uint8_t deviceId;
	uint32_t bytesPerPageEccOn;
	uint32_t bytesPerPageEccOff;
	uint32_t bytesPerPage;
	uint32_t pagesPerBlock;
	uint32_t sectorsPerPage;
	uint16_t blocksPerUnit;

} Tc58PhysicalGeometry_t;


// Exported constants --------------------------------------------------------

// Exported objects ----------------------------------------------------------

// Exported functions --------------------------------------------------------

///  @brief Initializes the software unit. The "Tc58PhysicalGeometry_t" structure will be populated.
///  @details This function will only return the values shown.
///  @return StatusOK, all is well
///  @return StatusDiskNoInit, maps at a higher level to: #define STA_NOINIT 0x01 (Drive not initialized)
///  @return StatusDiskNoDisk, maps at a higher level to: #define STA_NODISK 0x02 (No medium in the drive)
///  @return StatusDiskProtect, maps at a higher level to: #define STA_PROTECT 0x04 (Write protected)
status_t Tc58FlashPhysical_Init (void);

status_t Tc58FlashPhysical_DeInit(void);

///  @brief Returns the "Tc58PhysicalGeometry_t" structure.
///  @details This function will only return the values shown.
///  @return StatusNotInitialized
///  @return StatusOK, all is well
status_t Tc58FlashPhysical_GetGeometry (Tc58PhysicalGeometry_t *pGeometry);

///  @brief Returns the status of the TC58 flash
///  @details This function will only return the values shown.
///  @return StatusOK, all is well
///  @return StatusDiskNoInit, maps at a higher level to: #define STA_NOINIT 0x01 (Drive not initialized)
///  @return StatusDiskNoDisk, maps at a higher level to: #define STA_NODISK 0x02 (No medium in the drive)
///  @return StatusDiskProtect, maps at a higher level to: #define STA_PROTECT 0x04 (Write protected)
status_t Tc58FlashPhysical_ReturnStatus(void);

///  @brief Reads one page from a TC58 flash device
///  @details The access paradigm is exactly one sector per page.
///  @param[in]     addrRead
///  @param[in]     pBuffer, a pointer to the sector to be read.
///  @return StatusOk
///  @return StatusResultDiskError, maps at a higher level to: DRESULT (type), value: RES_ERROR = 1
///  @return StatusResultInvalidParameter,  maps at a higher level to: DRESULT (type), value: RES_PARERR = 4
///  @return StatusResultNotInitialized,  maps at a higher level to: DRESULT (type), value: RES_PARERR = 4
status_t Tc58FlashPhysical_ReadOnePage(Tc58PageAddress_t addrRead, uint8_t *pBuffer);

///  @brief Writes page to a TC58 flash device
///  @details The access paradigm is exactly one sector per page.
///  @param[in] addrWrite
///  @param[in] pBuffer, a pointer to the page to be written.
///  @return StatusOk
///  @return StatusResultDiskError, maps at a higher level to: DRESULT (type), value: RES_ERROR = 1
///  @return StatusResultInvalidParameter,  maps at a higher level to: DRESULT (type), value: RES_PARERR = 4
///  @return StatusResultNotInitialized,  maps at a higher level to: DRESULT (type), value: RES_PARERR = 4
status_t Tc58FlashPhysical_WriteOnePage(Tc58PageAddress_t addrWrite, uint8_t *pBuffer);

///  @brief Writes data to a TC58 flash device
///  @param[in] addrWrite
///  @param[in] pBuffer, a pointer to the page to be written.
///  @return StatusOk
///  @return StatusResultDiskError, maps at a higher level to: DRESULT (type), value: RES_ERROR = 1
///  @return StatusResultInvalidParameter,  maps at a higher level to: DRESULT (type), value: RES_PARERR = 4
///  @return StatusResultNotInitialized,  maps at a higher level to: DRESULT (type), value: RES_PARERR = 4
status_t Tc58FlashPhysical_Write(Tc58PageAddress_t a, void *pBuffer, uint16_t numBytes);

///  @brief Reads data from a TC58 flash device
///  @param[in] addrWrite
///  @param[in] pBuffer, a pointer to the page to be written.
///  @return StatusOk
///  @return StatusResultDiskError, maps at a higher level to: DRESULT (type), value: RES_ERROR = 1
///  @return StatusResultInvalidParameter,  maps at a higher level to: DRESULT (type), value: RES_PARERR = 4
///  @return StatusResultNotInitialized,  maps at a higher level to: DRESULT (type), value: RES_PARERR = 4
status_t Tc58FlashPhysical_Read(Tc58PageAddress_t a, void *pBuffer, uint16_t numBytes);

#endif // __TC58_PHYSICAL_H

/// SAEC Kinetic Vision, Inc. ----------- END OF FILE

