/**
  @file    Tc58FlashPhysical.c

  @author  Sherman Couch

  @copyright  (C) 2019 Kinetic Vision, Cincinnati Ohio.
               This software is property of SAEC Kinetic Vision, Inc
               and is considered confidential.

  @brief      Tc58FlashPhysical software unit "C" file.

  @ingroup Tc58FlashPhysicalSoftwareUnit


  Configuration History
  =====================

  Config Item    | Value
  -------------- | -----
  Config #       | NA
  Revision       | NA
  Revised, Date  | NA
  QA, Date       | NA
  Approved, Date | NA
  Released, Date | NA

 Significant Modification History (Most Recent at top)
 -----------------------------------------------------

 Date        | Initials | Description
 ----------- | -------- | -----------
 06 Sep 2019 | SC       | Retooled to simply read/write pages, no sector operations.
 03 Sep 2019 | SC       | Sector sizes now matched so that each page has one sector.
 05 Aug 2019 | SC       | Enhanced to also support the TOSHIBA NAND FLASH: TC58CVG1S3HxAIx
 23 Jun 2019 | SC       | Original, supports basic TOSHIBA NAND FLASH: TC58CVB2S0HxAIx

 Theory of Operation
 -------------------
 The Tc58FlashPhysical layer:
       - encapsulates the details of operation concerning the Toshiba "TC58CVG" flash
         part,
       - presents a block and sector oriented "read/write" to higher level components, and
       - uses the SPI interface "below layer" in order .

  */

// Includes ------------------------------------------------------------------

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <stdint.h>

#include "stm32l4xx_hal.h"

// Project software unit includes
#include "../StatusSu/Status.h"
#include "../SpiSu/spi.h"
#include "../Tc58FlashUtilitiesSu/Tc58FlashUtilities.h"
#include "../SwUnitControlSu/SwUnitControl.h"
#include "../ConsoleSu/Console.h"
#include "Tc58FlashPhysical.h"
#include "Tc58FlashIoControl.h"

#warning The physical driver knows a tad too much about the block driver, this is an opportunity for future improvement. SC
#include "../Tc58BlockSu/Tc58Block.h"

// Private macros ------------------------------------------------------------

#define MANUFACTURER_ID_TOSHIBA 0x98
#define DEVICE_ID_TC58CVG2S0H 0xCD
#define DEVICE_ID_TC58CVG1S3H 0xCB

// Device geometry
#define TC58_BLOCKS_PER_UNIT 2048
#define TC58_PAGES_PER_BLOCK 64

// This macro feeds status information for tracking purposes to software unit control.
#define returnStatus(__status__,__source__) SwUnitControl_WriteStatus(eSucTc58FlashPhysicalSu,__source__,__status__,__LINE__);

// Feature table - B0h description (consult TS58 data sheet for more info).
#define FEAT_B0_ECC_ENABLE                  0x10
#define FEAT_B0_ID_READ_ENABLE              0x40

// Feature table - c0h Address description (consult TS58 data sheet for more info).
#define FEAT_C0_OPERATION_IN_PROGRESS_RO 	0x01
#define FEAT_C0_WRITE_ENABLE_LATCH_RW 		0x02
#define FEAT_C0_ERASE_RO_ISSUE				0x04
#define FEAT_C0_PROGRAM_RO_ISSUE			0x08

// Four values of the two bits of "ECCS0/ECCS1" (per datasheet)
#define FEAT_C0_ECC_STATUS_0_RO_OK			0x00 // OK
#define FEAT_C0_ECC_STATUS_1_RO_OK			0x10 // OK
#define FEAT_C0_ECC_STATUS_2_RO_ISSUE		0x20 // Issue
#define FEAT_C0_ECC_STATUS_3_RO_ISSUE       0x30 // Issue

#define FEAT_C0_ECC_STATUS_MASK             0x30

// Feature table addresses
#define FEATURE_ADDR_A0_BLOCK_LOCK			0xA0
#define FEATURE_ADDR_B0_MISC_ENABLES        0xB0
#define FEATURE_ADDR_C0_STATUS				0xC0

#define DEVICE_MODEL "TC58CVG2S0HRAIG"
#define PARAMETER_PAGE_DEVICE_MODEL_OFFSET 44

//#define DEBUG_TRACE

// Private types -------------------------------------------------------------

typedef enum {
	tc58CmdProgramLoad = 2,
	tc58CmdReadBuffer1 = 3,
	tc58CmdWriteDisable = 4,
	tc58CmdWriteEnable = 6,
	tc58CmdReadBuffer2 = 0x0b,
	tc58CmdGetFeature = 0x0f,
	tc58CmdProgramExecute = 0x10,
	tc58CmdSetFeature = 0x1f,
	tc58CmdReadCellArray = 0x13,
	tc58CmdProtectExecute = 0x2a,
	tc58CmdReadBufferX2 = 0x3b,
	tc58CmdReadBufferX4 = 0x6b,
	tc58CmdProgramLoadRandomData = 0x84,
	tc58CmdReadId = 0x9f,
	tc58CmdBlockErase = 0xd8,
	tc58CmdReset2 = 0xfe,
	tc58CmdReset1 = 0xff,
} tc58Command_t;

typedef struct {

	// 0 - 3, Signature - 4Eh, 41h, 4Eh, 44h
	uint8_t signature[4];

	// 4 - 31, Reserved - All 00h
	uint8_t reserved1[31-4 +1];

    // 32 - 43, Device manufacturer - 54h, 4Fh, 53h, 48h, 49h, 42h, 41h, 20h, 20h, 20h, 20h, 20h
    uint8_t deviceManufacturer[43-32 +1];

	// 44 - 63, Device model - TC58CVG2S0HRAIG (WSON8) 54h, 43h, 35h, 38h, 43h, 56h, 47h, 32h, 53h, 30h, 48h, 52h, 41h, 49h, 47h, 20h, 20h, 20h, 20h, 20h
    //                       - TC58CVG2S0HQAIE (SOP16) 54h, 43h, 35h, 38h, 43h, 56h, 47h, 32h, 53h, 30h, 48h, 51h, 41h, 49h, 45h, 20h, 20h, 20h, 20h, 20h
	uint8_t deviceModel[63-44 +1];

	// 64, Manufacturer ID - 98h
	uint8_t manufacturerId;

	// 65 - 79, Reserved - All 00h
	uint8_t reserved2[79-65 +1];

	// 80 - 83, Number of data bytes per page - 00h, 10h, 00h, 00h
	uint8_t dataBytesPerPage[4];

	// 84 - 85, Number of spare bytes per page - 80h, 00h
	uint8_t spareBytesPerPage[2];

	// 86 - 89, Number of data bytes per partial page -  00h, 02h, 00h, 00h
	uint8_t bytesPerPartialPage[4];

	// 90 - 91, Number of spare bytes per partial page - 10h, 00h
	uint8_t spareBytesPerPartialPage[2];

	// 92 - 95, Number of pages per block - 40h, 00h, 00h, 00h
	uint8_t pagesPerBlock[4];

	// 96 - 99, Number of blocks per unit - 00h, 08h, 00h, 00h
	uint32_t blocksPerUnit;

	// 100, Number of logical units - 01h
	uint8_t numberLogicalUnits[1];

	// 101, Reserved - 00h
	uint8_t reserved3[1];

	// 102, Number of bits per cell - 01h
	uint8_t bitsPerCell[1];

	// 103 - 104, Bad blocks maximum per unit - 28h, 00h
	uint8_t maxBadBlocksPerUnit[2];

	// 105 - 106, Block endurance - 01h, 05h
	uint8_t blockEndurance[2];

	// 107, Guaranteed valid blocks at beginning of target - 01h
	uint8_t guaranteeValidBlocksBeginTarget[1];

	// 108 - 109, Reserved - All 00h
	uint8_t reserved4[2];

	// 110, Number of programs per page - 04h
	uint8_t numberProgramsPerPage[1];

	// 111, Reserved - 00h
	uint8_t reserved5[1];

	// 112, Number of ECC bits - 00h
	uint8_t numberOfEccBits[1];

	// 113 - 127, Reserved - All 00h
	uint8_t reserved6[127-113 +1];

	// 128, I/O pin capacitance - 04h
	uint8_t ioPinCapacitance[1];

	// 129 - 132, Reserved - All 00h
	uint8_t reserved7[4];

	// 133 - 134, tPROG maximum page program time - 58h, 02h
	uint8_t tprogMaxPageProgramTime[2];

	// 135 - 136, tBERS maximum block erase time -  58h, 1Bh
	uint8_t tbersMasxBlockEraseTime[2];

	// 137 - 138, tR maximum page read time - 18h, 01h
	uint8_t trMaxPageReadTime[2];

	// 139 - 253, Reserved - All 00h
	uint8_t reserved8[253-139 +1];

	// 254 - 255, Integrity CRC - TC58CVG2S0HRAIG (WSON8) F5h, E1h
	//                            TC58CVG2S0HQAIE (SOP16) F6h, EAh
	uint8_t integrityCrc[2];

	// 256 - 511, Value of bytes 0–255 -
	// uint8_t reserved9[511-256 +1];

	// 512 - 767, Value of bytes 0–255 -
	// uint8_t reserved10[797-512 +1];

} parameterPage_t;

// Private constants ---------------------------------------------------------
static const uint8_t featureAddresses[] = { FEATURE_ADDR_A0_BLOCK_LOCK, FEATURE_ADDR_B0_MISC_ENABLES, FEATURE_ADDR_C0_STATUS, 0x10, 0x20, 0x30, 0x40, 0x50, 0x60, 0x70};

static const Tc58PhysicalGeometry_t supportedDevices[] = {
	{.manufacturerId = MANUFACTURER_ID_TOSHIBA, .deviceId = DEVICE_ID_TC58CVG2S0H, .bytesPerPageEccOn = 4224, .bytesPerPageEccOff = 4352, .bytesPerPage = 4096, .pagesPerBlock = TC58_PAGES_PER_BLOCK, .sectorsPerPage = 8, .blocksPerUnit = TC58_BLOCKS_PER_UNIT},
	{.manufacturerId = MANUFACTURER_ID_TOSHIBA, .deviceId = DEVICE_ID_TC58CVG1S3H, .bytesPerPageEccOn = 2112, .bytesPerPageEccOff = 2176, .bytesPerPage = 2048, .pagesPerBlock = TC58_PAGES_PER_BLOCK, .sectorsPerPage = 4, .blocksPerUnit = TC58_BLOCKS_PER_UNIT},
};

// Private function prototypes -----------------------------------------------

static status_t eraseBlock (uint16_t blockNumber);

static status_t disablePageHighSpeedMode ();

static status_t setFeature (uint8_t address, uint8_t value);

static status_t cliIdCommand(uint16_t argc, uint8_t **argv);

// Erases flash
static status_t cliEraseBlockCommand(uint16_t argc, uint8_t **argv);

// Dump feature table
static status_t cliDumpFeatureTableCommand(uint16_t argc, uint8_t **argv);

status_t cliMemTest(uint16_t argc, uint8_t **argv);

// read parameter page
static status_t cliReadParameterPage(uint16_t argc, uint8_t **argv);

static status_t cliForceScratchpadFailCommand(uint16_t argc, uint8_t **argv);

static status_t cliForceWriteBlockFailCommand(uint16_t argc, uint8_t **argv);

static status_t cliGetPhysicalIssueBlockCommand(uint16_t argc, uint8_t **argv);

static status_t writeEnable(void);
static status_t writeDisable(void);
static status_t getFeature (uint8_t address, uint8_t *pValue);

static status_t programExecute(uint16_t blockAddress0_10, uint8_t pageAddress0_5);
static status_t readCellArray(uint16_t blockAddress0_10, uint8_t pageAddress0_5);

static status_t readBuffer(uint16_t columnAddress, void *pBuffer, uint16_t sizeRequested, uint16_t associatedBlockNumber);
static status_t programLoad(uint16_t columnAddress, void *pBuffer, uint16_t bytesToLoad, uint16_t associatedBlockNumber);

// returns # of sectors: a1 minus a2
// static status_t sectorDistance(Tc58PageAddress_t a1, Tc58PageAddress_t a2, int32_t *pDistance);

static status_t internalPageMove (Tc58PageAddress_t destination, Tc58PageAddress_t source);

static status_t readParameterPage(parameterPage_t *pParameterPage);

static status_t eraseOnePage(Tc58PageAddress_t addr);

// Private constants ---------------------------------------------------------

static const consoleCommand_t commandList[] = {
    { "flash-id", "usage: help flash-id", cliIdCommand
    },

	{ "dft", "dump / change feature table\r\n\t"
		"usage: dft [#feature #value]", cliDumpFeatureTableCommand
	},

	{ "ferase", "flash erase, erases an entire block\r\n\t"
			"usage: erase #17BitAddress", cliEraseBlockCommand
	},

	{"rpp", "read parameter page\r\n\t"
			"usage: rpp", cliReadParameterPage
	},

	{"fspf", "force scratchpad block fail\r\n\t"
			"usage: fspf [#countDown]", cliForceScratchpadFailCommand
	},

	{"fwrf", "force write block fail\r\n\t"
			"usage: fspf [#countDown]", cliForceWriteBlockFailCommand
	},

	{"gpib", "get physical issue block\r\n\t"
			"usage: gpib", cliGetPhysicalIssueBlockCommand
	},

	{"mem-test", "Test mem for bad blocks\r\n\t"
			"usage: map", cliMemTest
	},

    { NULL, NULL, NULL
    },
};

// Private variables ---------------------------------------------------------

static bool initialized = false;
static bool cliInitialized = false;
static bool noDisk = false;
static uint32_t mkfsIndication;

static consoleRegistration_t exportedReg = {
    (consoleCommand_t *) commandList, // .pList =
    NULL, // .pNext =
};

static Tc58PhysicalGeometry_t physicalGeometry;

static uint32_t sectorCountForFileSystem;
static uint32_t numberOfFsBlocks;
static uint16_t scratchPadBlockNumber;

// Anytime an issue is detected using the "Feature Table C0 Byte", loadup the block which generated the issue.
static uint16_t failedBlockNumberPerFeatC0;

static uint32_t forceScratchpadFailCountdown;
static uint32_t forceWriteBlockFailCountdown;

// Private function bodies ---------------------------------------------------

// Formats all blocks in the TC58 part
static status_t format(void)
{
    status_t status;
    status = StatusOk;

    if (!initialized) {
        status = StatusNotInitialized;
    }

    // Format is accomplished by zapping the remap table (here), and then doing a reset.
    // Upon reset logic in "Tc58Block" will detect the zapped remap table, and rebuild
    // the remap table and the format the drive (using f_mkfs).
    if (StatusOk == status) {

	    status = eraseBlock(BI_REMAP_BLOCK_FIXED_BLOCK);


#if 0
        uint32_t validBlocks;
        validBlocks = 0;

        for (uint32_t block = 0;block < physicalGeometry.blocksPerUnit; block++) {
            status_t eraseStatus;

		    eraseStatus = eraseBlock((uint16_t) block);
        	if (StatusOk != eraseStatus) {
    		    char buff[50];
    			sprintf(buff, "\r\nBlock %lu, erase status %u\r\n", block, eraseStatus);
    		    Console_WriteString(buff);

        	} else {
    		    Console_WriteString(".");
        		validBlocks++;
        	}
        }

        if (validBlocks < MIN_NUMBER_OF_VALID_BLOCKS) {
    		status = StatusFlashBelowMinValidBlocks;
    	}

#endif
    }

    // If we're OK to this point, reset the CPU.
    if (StatusOk == status) {
    	// The adroit Cortex M engineer will recognize this as a CPU reset.
    	while (1) {
    		SCB->AIRCR = 0x05FA0004;
    	}
    }

    return status;

} // format

// Formats all blocks in the TC58 part
static status_t reFormat(void)
{
    status_t status;
    status = StatusOk;

    if (!initialized) {
        status = StatusNotInitialized;
    }

    // First zap the remap block
	if (StatusOk == status) {
		status = eraseBlock((uint16_t) BI_REMAP_BLOCK_FIXED_BLOCK);

		// Remap status, its useful to know that the remap block is defective
		if (StatusOk != status) {
			status = StatusRemapBlock;
		}
	}

    if (StatusOk == status) {
        uint32_t validBlocks;
        validBlocks = 0;
        for (uint32_t block = 0; block < BI_REMAP_BLOCK_FIXED_BLOCK; block++) {
            status_t eraseStatus;

		    eraseStatus = eraseBlock((uint16_t) block);
        	if (StatusOk != eraseStatus) {
    		    char buff[50];
    			sprintf(buff, "\r\nBlock %lu, erase status %u\r\n", block, eraseStatus);
    		    Console_WriteString(buff);
        	} else {
    		    Console_WriteString(".");
        		validBlocks++;
        	}
        }

    	if (validBlocks < MIN_NUMBER_OF_VALID_BLOCKS) {
    		status = StatusFlashBelowMinValidBlocks;
    	}
    }

    // If we're OK to this point, reset the CPU.
    if (StatusOk == status) {
    	// The adroit Cortex M engineer will recognize this as a CPU reset.
    	while (1) {
    		SCB->AIRCR = 0x05FA0004;
    	}
    }

    return status;

} // reFormat

static status_t uint32_ConvertAtoi(uint8_t *a, uint32_t *pN)
{
	uint32_t n;

	if (NULL == a) {
		return StatusNullParameter;
	}

	// Number format 0x__?
	if ( (strlen(a) > 2) && ('0' == a[0]) && ('x' == a[1]) ) {
		sscanf(&a[2], "%lx", &n);
	} else {
		n = atoi(a);
	}

	*pN = n;

	return StatusOk;
} //uint32_ConvertAtoi


static status_t eraseOnePage(Tc58PageAddress_t addr)
{
	status_t 		status;
	Tc58PageAddress_t 	scratchPad;
	Tc58PageAddress_t 	source;

    status = StatusOk;

	// For each block in the erase sequence:
	// 		Step 1 - Erase the scratchpad.
	// 		Step 2 - Copy pages from the block (which are not the page to be erased), to the scratchpad
	// 		Step 3 - Erase the source block of the sector to be erased.
	// 		Step 4 - Copy the scratchpad down to the block

	// Step 1 - Erase the scratchpad.
    if (StatusOk == status) {
    	scratchPad.block = scratchPadBlockNumber;
    	scratchPad.page = 0;

    	status = eraseBlock (scratchPad.block);

    	// Remap erase status to consider the scratchpad
    	if (StatusOk != status) {
    		status = StatusFlashScratchPadBlock;
    	}

		// Force the scratchpad to failure?
		if (forceScratchpadFailCountdown) {
			forceScratchpadFailCountdown--;
			if (0 == forceScratchpadFailCountdown) {
				failedBlockNumberPerFeatC0 = scratchPad.block;
				status = StatusFlashScratchPadBlock;
			}
		}
    }


	// Step 2 - Copy pages from the block (which are not the page to be erased), to the scratchpad
	if (StatusOk == status) {
		source.block = addr.block;
		for (uint16_t page = 0; page < TC58_PAGES_PER_BLOCK; page++) {

			// Only move pages to the scratch which are not the target erase page
			if (page != addr.page ) {
				scratchPad.page = page;
				source.page = page;
				status = internalPageMove (scratchPad, source);

		    	// Remap erase status to consider the scratchpad
		    	if (StatusDestination == status) {
		    		status = StatusFlashScratchPadBlock;
		    	}
			}
		}
	}

	// 	Step 3 - Erase the source block of the sector to be erased.
	if (StatusOk == status) {
    	status = eraseBlock (addr.block);
	}

	// 	Step 4 - Copy the entire scratchpad down to the block (the erased sector should be all 1 bits (FFh).
	if (StatusOk == status) {
		for (uint16_t page = 0; page < TC58_PAGES_PER_BLOCK; page++) {
			scratchPad.page = page;
			addr.page = page;
			status = internalPageMove (addr, scratchPad);
		}
	}

	// We care about tracking this status, use macro to feed status to SW Unit control.
	return returnStatus(status, eSucIoctlStatus);

} // eraseOnePage

#if 0
static status_t enablePageHighSpeedMode ()
{
	uint8_t featureByteB0;
	status_t status;

	status = getFeature(FEATURE_ADDR_B0_MISC_ENABLES, &featureByteB0);

	if (StatusOk == status) {
		featureByteB0 |= 2;
		status = setFeature(FEATURE_ADDR_B0_MISC_ENABLES, featureByteB0);
	}

	return status;
}
#endif

static status_t disablePageHighSpeedMode ()
{
	uint8_t featureByteB0;
	status_t status;

	status = getFeature(FEATURE_ADDR_B0_MISC_ENABLES, &featureByteB0);

	if (StatusOk == status) {
		featureByteB0 &= ~2;
		featureByteB0 |= FEAT_B0_ECC_ENABLE;
		status = setFeature(FEATURE_ADDR_B0_MISC_ENABLES, featureByteB0);
	}

	return status;
}

// Returns status indicating if a shas any zero bits (not erased), or erased (all 1 bits).

// Note: Block range 0 .. 7FFh
static status_t eraseBlock (uint16_t blockNumber)
{
	uint8_t txBuffer[4];

	uint8_t buff[50];

	status_t status;
	status = StatusOk;

	// Validate input address
	if (blockNumber >= TC58_BLOCKS_PER_UNIT) {
		status = StatusBlockNumber;
	}

    // Do Screening reads...
    if (StatusOk == status) {
    	status = readCellArray (blockNumber, 0);
	    if (StatusOk != status) {
			sprintf(buff, "[Status0=%u]", status);
			Console_WriteString(buff);
	    }
    }

    if (StatusOk == status) {
		status = readCellArray (blockNumber, 63);
	    if (StatusOk != status) {
			sprintf(buff, "[Status63=%u]", status);
			Console_WriteString(buff);
	    }
    }

	// Zap the "block lock"
    if (StatusOk == status) {
		status = setFeature(FEATURE_ADDR_A0_BLOCK_LOCK, 0);
    }

	// A block erase operation requires writes to be enbled
	if (StatusOk == status) {
		status = writeEnable();
	}

	if (StatusOk == status) {
		txBuffer[0] = tc58CmdBlockErase;

		txBuffer[1] = blockNumber >> 10;
		txBuffer[2] = blockNumber >> 2;
		txBuffer[3] = blockNumber << 6;

	    // Send the erase command...
	    HAL_GPIO_WritePin (GPIOA, GPIO_PIN_8, GPIO_PIN_RESET);
	    status = Spi_Write (txBuffer, sizeof(txBuffer));
	    HAL_GPIO_WritePin (GPIOA, GPIO_PIN_8, GPIO_PIN_SET);
	}

	//   Step 2. Use Get Feature (0Fh) : Reading the status (OIP bit) of the device, to poll operation in progress.
	if (StatusOk == status) {
		uint32_t count;
		uint8_t featureByteC0;

		// Poll for completion...
		for (count = 0; ; count++){

			// This operation is usually done after a count of 3, but in case it
			// gets stuck, handle "flash part timeout" condition.
			if (count > 500) {
				status = StatusTc58FlashTimeout;
				break;
			}

			// In order to inspect the OIP bit, get feature byte C0
			status = getFeature(0xC0, &featureByteC0);

			// Exit loop if get of feature byte is not OK
			if (StatusOk != status) {
				break;
			}

			// When an erase fail is indicated by the feature byte, setup status variable
			if  (featureByteC0 & FEAT_C0_ERASE_RO_ISSUE) {
				failedBlockNumberPerFeatC0 = blockNumber;
				status = StatusErase;
				break;
			}

			// Important: check the operation in progress bit BEFORE looking at the write enable

			// If the operation is no longer in progress (bit is 0), then break out of the loop
			if (0 == (featureByteC0 & FEAT_C0_OPERATION_IN_PROGRESS_RO)) {
				break;
			}

			// If write enable bit was not set, it should have been, then set status
			if (0 == (featureByteC0 & FEAT_C0_WRITE_ENABLE_LATCH_RW)) {
				failedBlockNumberPerFeatC0 = blockNumber;
				status = StatusWriteEnable;
				break;
			}
		}
	}

    return status;

} // eraseBlock



static status_t readBuffer(uint16_t columnAddress, void *pBuffer, uint16_t sizeRequested, uint16_t associatedBlockNumber)
{
	uint8_t txBuffer[4];

	status_t status;
	status = StatusOk;

	txBuffer[0] = tc58CmdReadBuffer1;
	txBuffer[1] = columnAddress >> 8;
	txBuffer[2] = columnAddress & 0xFF;
	txBuffer[3] = 0; // "dummy byte"


	// Select the FLASH
    HAL_GPIO_WritePin (GPIOA, GPIO_PIN_8, GPIO_PIN_RESET);

    // Send the read command with the column address
    if (StatusOk == status) {
		status = Spi_Write((uint8_t*)txBuffer, sizeof(txBuffer));
    }

    // Read data into the read buffer
    if (StatusOk == status) {
        status = Spi_Read(pBuffer, sizeRequested);
    }

    // De-select the FLASH
    HAL_GPIO_WritePin (GPIOA, GPIO_PIN_8, GPIO_PIN_SET);

    // Check Status of operation
	uint8_t featureByteC0;
    if (StatusOk == status) {
		status = getFeature(0xC0, &featureByteC0);
    }

#warning SHERMAN DISABLED READ STATUS CHECKING AS A TEST ON EVENING OF 13 NOV (SC)
#if 0
	if (StatusOk == status) {
		uint8_t eccStatus;
		eccStatus = FEAT_C0_ECC_STATUS_MASK & featureByteC0;

		if ( (eccStatus == FEAT_C0_ECC_STATUS_2_RO_ISSUE) ||
			 (eccStatus == FEAT_C0_ECC_STATUS_3_RO_ISSUE) ) {
			failedBlockNumberPerFeatC0 = associatedBlockNumber;
			status = StatusResultDiskError;
		}
	}
#endif

    return status;

} // readBuffer

static status_t programLoad(uint16_t columnAddress, void *pBuffer, uint16_t bytesToLoad, uint16_t associatedBlockNumber)
{
	uint8_t txBuffer[3];

	status_t status;
	status = StatusOk;

	// Select the FLASH
	HAL_GPIO_WritePin (GPIOA, GPIO_PIN_8, GPIO_PIN_RESET);

	// Send the load command with the 13 bit column address
    if (StatusOk == status) {
		txBuffer[0] = tc58CmdProgramLoad;
		txBuffer[1] = columnAddress >> 8;
		txBuffer[2] = columnAddress & 0xFF;

    	status = Spi_Write (txBuffer, sizeof(txBuffer));
    }

    // Write data from the buffer
    if (StatusOk == status) {
		status = Spi_Write (pBuffer, bytesToLoad);
    }

	HAL_GPIO_WritePin (GPIOA, GPIO_PIN_8, GPIO_PIN_SET);

	//   Use Get Feature (0Fh) : Reading the status (OIP bit) of the device, to poll operation in progress.
	if (StatusOk == status) {
		uint32_t count;
		count = 0;
		uint8_t featureByteC0;
		do {

			count++;

			// This operation is usually done after a count of 3, but in case it
			// gets stuck, handle "flash part timeout" condition.
			if (count > 500) {
				status = StatusTc58FlashTimeout;
				break;
			}

			// In order to inspect the OIP bit, get feature byte C0
			status = getFeature(FEATURE_ADDR_C0_STATUS, &featureByteC0);

			// Exit loop if get of feature byte is not OK
			if (StatusOk != status) {
				break;
			}

			// Check the programming status
			if (featureByteC0 & FEAT_C0_PROGRAM_RO_ISSUE) {
				failedBlockNumberPerFeatC0 = associatedBlockNumber;
				status = StatusTc58ProgramLoad;
				break;
			}

		} while (featureByteC0 & FEAT_C0_OPERATION_IN_PROGRESS_RO);
	}

    return status;

} // programLoad

static status_t writeEnable(void)
{
	uint8_t txBuffer;

	status_t status;
	status = StatusOk;

	txBuffer = tc58CmdWriteEnable;

	// Select the FLASH
    HAL_GPIO_WritePin (GPIOA, GPIO_PIN_8, GPIO_PIN_RESET);

    // Send the read command with the column address
    if (StatusOk == status) {
		status = Spi_Write(&txBuffer, sizeof(txBuffer));
    }

    // De-select the FLASH
    HAL_GPIO_WritePin (GPIOA, GPIO_PIN_8, GPIO_PIN_SET);

    return status;

} // writeEnable

static status_t writeDisable(void)
{
	uint8_t txBuffer;

	status_t status;
	status = StatusOk;

	txBuffer = tc58CmdWriteDisable;

	// Select the FLASH
    HAL_GPIO_WritePin (GPIOA, GPIO_PIN_8, GPIO_PIN_RESET);

    // Send the read command with the column address
    if (StatusOk == status) {
		status = Spi_Write(&txBuffer, sizeof(txBuffer));
    }

    // De-select the FLASH
    HAL_GPIO_WritePin (GPIOA, GPIO_PIN_8, GPIO_PIN_SET);

    return status;

} // writeDisable


static status_t setFeature (uint8_t address, uint8_t value)
{
	uint8_t txBuffer[3];

	status_t status;
	status = StatusOk;

	txBuffer[0] = tc58CmdSetFeature;
	txBuffer[1] = address;
	txBuffer[2] = value;

    // Select the FLASH
    HAL_GPIO_WritePin (GPIOA, GPIO_PIN_8, GPIO_PIN_RESET);

    status = Spi_Write (txBuffer, sizeof(txBuffer));

    // De-select the FLASH
    HAL_GPIO_WritePin (GPIOA, GPIO_PIN_8, GPIO_PIN_SET);

    return status;

} // setFeature

static status_t getFeature (uint8_t address, uint8_t *pValue)
{
	uint8_t txBuffer[3];
	uint8_t rxBuffer[3];

	status_t status;
	status = StatusOk;

	txBuffer[0] = tc58CmdGetFeature;
	txBuffer[1] = address;
	txBuffer[2] = 0;

    // Select the FLASH
    HAL_GPIO_WritePin (GPIOA, GPIO_PIN_8, GPIO_PIN_RESET);

    status = Spi_WriteAndRead(txBuffer, rxBuffer, sizeof(txBuffer));

    // De-select the FLASH
    HAL_GPIO_WritePin (GPIOA, GPIO_PIN_8, GPIO_PIN_SET);

    // return feature value read
    if (StatusOk == status) {
    	*pValue = rxBuffer[2];
    }

    return status;

} // getFeature

static status_t readIdSetupGeometry()
{
	uint8_t aTxBuffer[4] = {tc58CmdReadId, 0, 0, 0};
	uint8_t aRxBuffer[4];
	parameterPage_t parameterPage;


	status_t status;
	status = StatusOk;

    // Select the FLASH
    HAL_GPIO_WritePin (GPIOA, GPIO_PIN_8, GPIO_PIN_RESET);
    HAL_Delay(5);

    status = Spi_WriteAndRead (aTxBuffer, aRxBuffer, sizeof(aTxBuffer));

    // De-select the FLASH
    HAL_GPIO_WritePin (GPIOA, GPIO_PIN_8, GPIO_PIN_SET);

    // Verify manufacturer ID and device ID information
    if (StatusOk == status) {
    	bool supportedDevice = false;
		for (uint16_t i = 0; i < (sizeof(supportedDevices)/sizeof(supportedDevices[0])); i++) {

			// If the device discovered is a supported device, then
			if ( (supportedDevices[i].manufacturerId == aRxBuffer[2]) &&
			     (supportedDevices[i].deviceId == aRxBuffer[3]) ) {

				// Record the physical geometry associated with that device
				physicalGeometry = supportedDevices[i];

				// OK, based upon the manufacturer and device IDs, it looks like we've found a supported
				// part.  Now read the parameter page from the device.
		    	status = readParameterPage(&parameterPage);
		    	if (StatusOk != status) {
		    		break;
		    	}

		    	if (parameterPage.manufacturerId != MANUFACTURER_ID_TOSHIBA) {
		    		status = StatusFlashType;
		    		break;
		    	}

				// note that the device is supported.
				supportedDevice = true;


				// Update the physical geometry with info from the parameter page
				physicalGeometry.blocksPerUnit = parameterPage.blocksPerUnit;

				break;
			 }
		}
		if (!supportedDevice) {
			status = StatusDeviceId;
		}
    }

    return status;

} // readIdSetupGeometry

// Note: There are 17 address bits[0:16]
static status_t readCellArray (uint16_t blockAddress0_10, uint8_t pageAddress0_5)
{
	uint8_t txBuffer[4];

	uint32_t rowAddress0_16;

	// A "page" of flash is either 4224 or 4352 bytes (depending upon whether ECC is enabled).
    // That corresponds to 8 sectors of 512 bytes each inside each "page", not including the wasted
    // space at the end of a page.  The "row Address", really addresses a page.  Its a Toshiba
    // misnomer.

	rowAddress0_16 = (((uint32_t) blockAddress0_10) << 6) + (uint32_t) pageAddress0_5;

	status_t status;
	status = StatusOk;

	// Validate input address
	if (rowAddress0_16 >= (physicalGeometry.blocksPerUnit * physicalGeometry.pagesPerBlock)) {
		status = StatusPageNumber;
	}

	if (StatusOk == status) {
		txBuffer[0] = tc58CmdReadCellArray;
		txBuffer[1] = rowAddress0_16 >> 16; // 7 Dummy bits + 1 Address bit
		txBuffer[2] = rowAddress0_16 >> 8;
		txBuffer[3] = rowAddress0_16 & 0xFF;

	    // Select the FLASH, SPI "transmit", de-select the FLASH
	    HAL_GPIO_WritePin (GPIOA, GPIO_PIN_8, GPIO_PIN_RESET);
	    status = Spi_Write(txBuffer, sizeof(txBuffer));
	    HAL_GPIO_WritePin (GPIOA, GPIO_PIN_8, GPIO_PIN_SET);
	}

	//   Step 2. Use Get Feature (0Fh) : Reading the status (OIP bit) of the device, to poll operation in progress.
	if (StatusOk == status) {
		uint32_t count;
		count = 0;
		uint8_t featureByteC0;
		do {

			count++;

			// This operation is usually done after a count of 3, but in case it
			// gets stuck, handle "flash part timeout" condition.
			if (count > 500) {
				status = StatusTc58FlashTimeout;
				break;
			}

			// In order to inspect the OIP bit, get feature byte C0
			status = getFeature(0xC0, &featureByteC0);

			if (StatusOk == status) {
				uint8_t eccStatus;
				eccStatus = FEAT_C0_ECC_STATUS_MASK & featureByteC0;

				if ( (eccStatus == FEAT_C0_ECC_STATUS_2_RO_ISSUE) ||
					 (eccStatus == FEAT_C0_ECC_STATUS_3_RO_ISSUE) ) {
					failedBlockNumberPerFeatC0 = blockAddress0_10;
					status = StatusResultDiskError;
				}
			}

			// Exit loop if get of feature byte is not OK
			if (StatusOk != status) {
				break;
			}

		} while (featureByteC0 & FEAT_C0_OPERATION_IN_PROGRESS_RO);
	}

    return status;

} // readCellArray


static status_t programExecute (uint16_t blockAddress0_10, uint8_t pageAddress0_5)
{
	uint8_t txBuffer[4];

	uint32_t rowAddress0_16;

	// A "page" of flash is either 4224 or 4352 bytes (depending upon whether ECC is enabled).
    // That corresponds to 8 sectors of 512 bytes each inside each "page", not including the wasted
    // space at the end of a page.  The "row Address", really addresses a page.  Its a Toshiba
    // misnomer.

	rowAddress0_16 = (((uint32_t) blockAddress0_10) << 6) + (uint32_t) pageAddress0_5;

	status_t status;
	status = StatusOk;

	// Validate input address
	if (rowAddress0_16 >= (physicalGeometry.blocksPerUnit * physicalGeometry.pagesPerBlock)) {
		status = StatusPageNumber;
	}

	if (StatusOk == status) {
		txBuffer[0] = tc58CmdProgramExecute;
		txBuffer[1] = rowAddress0_16 >> 16; // 7 Dummy bits + 1 Address bit
		txBuffer[2] = rowAddress0_16 >> 8;
		txBuffer[3] = rowAddress0_16;

	    // Select the FLASH, SPI "transmit", de-select the FLASH
	    HAL_GPIO_WritePin (GPIOA, GPIO_PIN_8, GPIO_PIN_RESET);
	    status = Spi_Write(txBuffer, sizeof(txBuffer));
	    HAL_GPIO_WritePin (GPIOA, GPIO_PIN_8, GPIO_PIN_SET);
	}

	//   Step 2. Use Get Feature (0Fh) : Reading the status (OIP bit) of the device, to poll operation in progress.
	if (StatusOk == status) {
		uint32_t count;
		count = 0;
		uint8_t featureByteC0;
		do {

			count++;

			// This operation is usually done after a count of 3, but in case it
			// gets stuck, handle "flash part timeout" condition.
			if (count > 500) {
				status = StatusTc58FlashTimeout;
				break;
			}

			// In order to inspect the OIP bit, get feature byte C0
			status = getFeature(0xC0, &featureByteC0);

			// Exit loop if get of feature byte is not OK
			if (StatusOk != status) {
				break;
			}

			//   Use Get Feature (0Fh) to check the "WEL" bit in feature C0
			if (0 == (featureByteC0 & FEAT_C0_OPERATION_IN_PROGRESS_RO)) {

				// Operation not in progress...
				if (featureByteC0 & FEAT_C0_PROGRAM_RO_ISSUE) {
					failedBlockNumberPerFeatC0 = blockAddress0_10;
					status = StatusProgramFailed;
				}

			}

			if (StatusOk != status) {
				break;
			}

			// Keep polling while operation is seen "in progress"

		} while (featureByteC0 & FEAT_C0_OPERATION_IN_PROGRESS_RO);
	}

    return status;

} // programExecute


static status_t readParameterPage(parameterPage_t *pParameterPage)
{
	status_t status;
	status = StatusOk;

	// The device has a parameter page. The operation sequence is as follows.
	//
	//   Step 1. Set Feature (1Fh) with address B0h and set bit [6]. : To set the IDR_E bit in the feature table.

	uint8_t featureByteB0;
	if (StatusOk == status) {
		status = getFeature(FEATURE_ADDR_B0_MISC_ENABLES, &featureByteB0);
	}

	// Setup for parameter page read operation
	if (StatusOk == status) {
		featureByteB0 |= FEAT_B0_ID_READ_ENABLE;
		status = setFeature(FEATURE_ADDR_B0_MISC_ENABLES, featureByteB0);
	}

	if (StatusOk == status) {
		//   Step 2. Read Cell Array (13h) with address 01h. : To read the parameter page.
		//   Step 3. Get Feature (0Fh) : To read the status (OIP bit) of the device.
 		status = readCellArray(0, 0x01);
	}

	//   Step 4. Read Buffer (03h or 0Bh) with address 00h. : To output the parameter page.
	//            or Read Buffer x2 (3Bh)
	//            or Read Buffer x4 (6Bh)

	if (StatusOk == status) {

		// Be sure to associate a page which has an invalid number (final parameter) with parameter
		// page reads.  This is important because if the parameter page read fails, we DO NOT
		// want the block remap to remap the parameter page (because that just isn't possible).
		status = readBuffer(0, pParameterPage, sizeof(*pParameterPage), TC58_INVALID_PAGE_NUMBER);
	}

	//   Step 5. Set Feature (1Fh) with address B0h and clear bit [6] (ID_READ ENABLE), this is the setting for normal operation.
	featureByteB0 &= (~FEAT_B0_ID_READ_ENABLE);
	setFeature(FEATURE_ADDR_B0_MISC_ENABLES, featureByteB0);

	//
	// Note: Read Buffer, Read Buffer x2, Read Buffer x4 and Get Feature commands are repeatable commands.
	//

    return status;

} // readParameterPage


static status_t cliForceScratchpadFailCommand(uint16_t argc, uint8_t **argv)
{
    status_t status;
    status = StatusOk;

    if (argc < 2) {
    	char buff[50];
    	sprintf(buff, "%lu\r\n", forceScratchpadFailCountdown);
		Console_WriteString(buff);
    } else {
    	status = uint32_ConvertAtoi(argv[1], &forceScratchpadFailCountdown);
    }

    return status;

} // cliForceScratchpadFailCommand

static status_t cliForceWriteBlockFailCommand(uint16_t argc, uint8_t **argv)
{
    status_t status;
    status = StatusOk;

    if (argc < 2) {
    	char buff[50];
    	sprintf(buff, "%lu\r\n", forceWriteBlockFailCountdown);
		Console_WriteString(buff);
    } else {
    	status = uint32_ConvertAtoi(argv[1], &forceWriteBlockFailCountdown);
    }

    return status;

} // cliForceWriteBlockFailCommand

static status_t cliGetPhysicalIssueBlockCommand(uint16_t argc, uint8_t **argv)
{
    status_t status;
    status = StatusOk;

	char buff[50];
	sprintf(buff, "%u\r\n", failedBlockNumberPerFeatC0);
	Console_WriteString(buff);

    return status;

} // cliGetPhysicalIssueBlockCommand

static status_t cliIdCommand(uint16_t argc, uint8_t **argv)
{
	uint8_t aTxBuffer[4] = {tc58CmdReadId, 0, 0, 0};
	uint8_t aRxBuffer[4];
	char buff[50];
    status_t status;
    status = StatusOk;

    if (!initialized) {
        status = StatusNotInitialized;
    }

    if (StatusOk == status) {
		// Select the FLASH
		HAL_GPIO_WritePin (GPIOA, GPIO_PIN_8, GPIO_PIN_RESET);

		status = Spi_WriteAndRead(aTxBuffer, aRxBuffer, sizeof(aTxBuffer));

		// De-select the FLASH
		HAL_GPIO_WritePin (GPIOA, GPIO_PIN_8, GPIO_PIN_SET);
    }

    if (StatusOk == status)
    {
		for (uint16_t i = 0; i < sizeof(aRxBuffer); i++) {
			sprintf(buff, "Rx Buffer %02x\r\n", aRxBuffer[i]);
			Console_WriteString(buff);
		}
    }

    return status;

} // cliIdCommand


static status_t cliReadParameterPage(uint16_t argc, uint8_t **argv)
{
    status_t status;
    parameterPage_t parameterPage;

    status = StatusOk;

    if (!initialized) {
        status = StatusNotInitialized;
    }

    if (StatusOk == status) {
    	status = readParameterPage(&parameterPage);
    }

    uint8_t *p;

    p = (uint8_t *) &parameterPage;

    for (uint16_t i = 0; i < sizeof(parameterPage); i++) {
    	uint8_t buff[50];

    	sprintf(buff, "%u - %02x\r\n", i, *p);
    	Console_WriteString(buff);

    	p++;
    }
    return status;

} // cliReadParameterPage


static status_t cliEraseBlockCommand(uint16_t argc, uint8_t **argv)
{
    status_t status;
	uint32_t startBlockNumber;
	uint32_t endBlockNumber;

    status = StatusOk;

    if (!initialized) {
        status = StatusNotInitialized;
    }

    // Parse 1st parameter and the optional second parameter
    if (StatusOk == status) {
    	if (argc == 2) {
    		status = uint32_ConvertAtoi(argv[1], &startBlockNumber);
    		endBlockNumber = startBlockNumber;
    	}
    	else if (argc == 3) {
    		status = uint32_ConvertAtoi(argv[1], &startBlockNumber);
    		if (StatusOk == status) {
        		status = uint32_ConvertAtoi(argv[2], &endBlockNumber);
    		}
    	}
    	else {
    		status = StatusParameterCount;
    	}
    }

    if (StatusOk == status) {
        for (uint32_t block = startBlockNumber;block <= endBlockNumber; block++) {

        	// Print block number
		    char buff[50];
			sprintf(buff, "<%lu>", block);
		    Console_WriteString(buff);

		    // Only erase the block if the screening reads succeeded.
		    if (StatusOk == status) {
				status = eraseBlock((uint16_t) block);
				if (StatusOk != status) {
					sprintf(buff, "[Status %u]", status);
					Console_WriteString(buff);
				}
		    }
        }
    }

    return status;

} // cliEraseBlockCommand

static status_t cliDumpFeatureTableCommand(uint16_t argc, uint8_t **argv)
{
    status_t status;
    status = StatusOk;

    if (!initialized) {
        status = StatusNotInitialized;
    }

    // Modifying a feature?
    if ((StatusOk == status) && (argc == 3)) {
    	uint32_t feature;
    	uint32_t value;

		status = uint32_ConvertAtoi(argv[1], &feature);
	    if (StatusOk == status) {
			status = uint32_ConvertAtoi(argv[2], &value);
			if (StatusOk == status) {
				if ((feature > 0xff)||(value > 0xff)) {
					status = StatusByteValue;
				}
			}
	    }

	    if (StatusOk == status) {
			status = setFeature(feature, value);
	    }
    }

    else if (StatusOk == status) {
		for (uint16_t i = 0; i < sizeof(featureAddresses); i++) {

			uint8_t featureByte;
			status = getFeature(featureAddresses[i], &featureByte);

		    if (StatusOk != status) {
		    	break;
		    }

		    char buff[50];
			sprintf(buff, "Feature %02xh = %02xh\r\n", featureAddresses[i], featureByte);
		    Console_WriteString(buff);
		}
    }

    return status;

} // cliDumpFeatureTableCommand

// Important, this function returns: either StatusSource, or StatusDestination.
status_t cliMemTest(uint16_t argc, uint8_t **argv)
{
    status_t status;
    status = StatusOk;

    Console_WriteString("Starting Mem Test\r\n");

    //1) Check ECC
    for(int i = 0; i < physicalGeometry.blocksPerUnit; i++){

    	for(int j = 0; j < 2; j++){
    		//Read a page
    		uint8_t pageBuff[physicalGeometry.bytesPerPage];
    		Tc58PageAddress_t addrRead;
    		if(0 == j){
    			addrRead.page = 0;
    		}
    		else{
    			addrRead.page = 63;
    		}
    		addrRead.block = i;

    		status = Tc58FlashPhysical_ReadOnePage(addrRead, pageBuff);

    		//Read the ECC Status
    		uint8_t featureByte;
    		status = getFeature(FEATURE_ADDR_C0_STATUS, &featureByte);
    		if(StatusOk != status){
    			break;
    		}

    		featureByte &= 0x30;
    		featureByte = featureByte >> 4;

    		if(0 != featureByte){
    		    char buff[30];
    			sprintf(buff, "Bad Block: %i %i ", addrRead.block, addrRead.page);
    		    Console_WriteString(buff);
    			sprintf(buff, "Feature Byte: %i \r\n", featureByte);
    		    Console_WriteString(buff);
    		    break;
    		}
    	}
    }
    Console_WriteString("Mem Test Finished\r\n");

	return status;

}// cliMemTest

static status_t internalPageMove (Tc58PageAddress_t destination, Tc58PageAddress_t source)
{
	// The Internal Data Move Operation is used to change the data in a page without data output.
	// Before using this operation, the users must disable the Page Read High Speed Mode.
	// The operation sequence is as follows.
	// 1. Set Feature (1Fh) : To disable Page Read High Speed Mode.
	// 2. Read Cell Array (13h) : To read data from the cell array to internal buffer.
	// 3. Get Feature (0Fh) : To read the status (OIP, ECCS0 and ECCS1 bits) of the device.
	// 4. Write Enable (06h) : To enable the write.
	// 5. Program Load Random Data (84h) : To change the data in the internal buffer.
	// 6. Program Execute (10h) : To program data from the buffer to the cell array.
	// 7. Get Feature (0Fh) : To read the status (OIP, PRG_F bits) of the device.

	status_t status;

	// 1. Set Feature (1Fh) : To disable Page Read High Speed Mode.
	// Done at initialization.

	// 2. Read Cell Array (13h) : To read data from the cell array to internal buffer.
	// 3. Get Feature (0Fh) : To read the status (OIP, ECCS0 and ECCS1 bits) of the device.
	status = readCellArray (source.block, source.page);

	// remap issues to now, to the source
	if (StatusOk != status) {
		status = StatusSource;
	}

	// 4. Write Enable (06h) : To enable the write.
	if (StatusOk == status) {

		// Because we only return source or desgination issues, do not store status from the "writeEnable()" operation
		writeEnable();
	}

	// 5. Program Load Random Data (84h) : To change the data in the internal buffer.
	// This is a move operation, we're not going to change the internal buffer

	// 6. Program Execute (10h) : To program data from the buffer to the cell array.
	// 7. Get Feature (0Fh) : To read the status (OIP, PRG_F bits) of the device.
	if (StatusOk == status) {
		status = programExecute (destination.block, destination.page);

		// remap issues to the destination
		if (StatusOk != status) {
			status = StatusDestination;
		}
	}

	return status;

} // internalPageMove


// Public functions bodies ---------------------------------------------------

// Important, this API method needs to only return certain statuses (documented in the H file).
status_t Tc58Flash_DoIoControl(Tc58FlashIoctlCode_t controlCode, uint32_t *pValue)
{
	uint8_t buff[50];

	status_t status;
	status = StatusOk;

	// For these IOCTL Values, a parameter is required.
	// ========================================================
	// These ioctl commands return status, and a uint32_t value
	// ========================================================
	switch (controlCode)
	{
		case Tc58IoctlGetSectorCount:
		case Tc58IoctlGetSectorSize:
		case Tc58IoctlGetBlockSize:
		case Tc58IoctlMmcGetType:
		case Tc58IoctlMmcGetCsd:
		case Tc58IoctlMmcGetCide:
		case Tc58IoctlMmcGetOcr:
		case Tc58IoctlMmcGetSdStat:
		case Tc58IoctlAtaGetRev:
		case Tc58IoctlAtaGetModel:
		case Tc58IoctlAtaGetSn:
		case Tc58IoctlPutNumberOfFsBlocks:
		case Tc58IoctlGetTc58PageSize:
		case Tc58IoctlGetTc58BlockSize:
		case Tc58IoctlGetMkfsIndication:
		case Tc58IoctlPutMkfsIndication:
		case Tc58IoctlGetTc58BlocksPerUnit:
		case Tc58IoctlPutScratchPadBlockNumber:
		case Tc58IoctlGetLastFailedBlockNumber:
			if (NULL == pValue) {
				status = StatusResultInvalidParameter;
			}
			break;

		default:
			break;
	}

	if (StatusOk == status) {
		if (!initialized) {
			status = StatusResultNotReady;
		}
	}

	if (StatusOk == status)
	{
		switch (controlCode)
		{
			// ========================================================
			// These ioctl commands place values into the physical driver.
			// ========================================================

			case Tc58IoctlPutNumberOfFsBlocks:
				numberOfFsBlocks = *pValue;
				sectorCountForFileSystem = numberOfFsBlocks * physicalGeometry.pagesPerBlock * physicalGeometry.sectorsPerPage;

				break;

			// ========================================================
			// These ioctl commands return status, and a uint32_t value
			// ========================================================

			case Tc58IoctlGetTc58BlocksPerUnit:
				*pValue = TC58_BLOCKS_PER_UNIT;
				break;

			case Tc58IoctlGetSectorCount:

				(*pValue) = sectorCountForFileSystem;
				// (*pValue) = (physicalGeometry.totalBlocks - TC58_NUMBER_BLOCKS_OUTSIDE_FS);
				// (*pValue) *= physicalGeometry.pagesPerBlock;
				sprintf(buff, "<Tc58IoctlGetSectorCount = %lu>", *pValue);
				Console_WriteString(buff);
				break;

			case Tc58IoctlGetSectorSize:
				*pValue = TC58_BYTES_PER_SECTOR_512;
				sprintf(buff, "<Tc58IoctlGetSectorSize = %lu>", *pValue);
				Console_WriteString(buff);
				break;

			case Tc58IoctlGetBlockSize:
				*pValue = /* physicalGeometry.sectorsPerPage * physicalGeometry.pagesPerBlock * */ TC58_BYTES_PER_SECTOR_512;
				sprintf(buff, "<Tc58IoctlGetBlockSize = %lu>", *pValue);
				Console_WriteString(buff);
				break;

			case Tc58IoctlMmcGetType:
				Console_WriteString("<Tc58IoctlMmcGetType>");
				*pValue = 0;
				break;

			case Tc58IoctlMmcGetCsd:
				Console_WriteString("<Tc58IoctlMmcGetCsd>");
				*pValue = 0;
				break;

			case Tc58IoctlMmcGetCide:
				Console_WriteString("<Tc58IoctlMmcGetCide>");
				*pValue = 0;
				break;

			case Tc58IoctlMmcGetOcr:
				Console_WriteString("<Tc58IoctlMmcGetOcr>");
				*pValue = 0;
				break;

			case Tc58IoctlMmcGetSdStat:
				Console_WriteString("<Tc58IoctlMmcGetSdStat>");
				*pValue = 0;
				break;

			case Tc58IoctlAtaGetRev:
				Console_WriteString("<Tc58IoctlAtaGetRev>");
				*pValue = 0;
				break;

			case Tc58IoctlAtaGetModel:
				Console_WriteString("<Tc58IoctlAtaGetModel>");
				*pValue = physicalGeometry.deviceId ;
				break;

			case Tc58IoctlAtaGetSn:
				Console_WriteString("<Tc58IoctlAtaGetSn>");
				*pValue = 1234;
				break;

			case Tc58IoctlCtrlSync: {
				extern status_t Tc58Buffer_SynchronizeStorage(void);
				Console_WriteString("<Tc58IoctlCtrlSync>");
				status = Tc58Buffer_SynchronizeStorage();
				break;
			}

			case Tc58IoctlPageBufferReset: {
				extern status_t Tc58Buffer_Reset(void);
				// Console_WriteString("<Tc58IoctlCtrlPageBufferReset>");
				status = Tc58Buffer_Reset();
				break;
			}

			case Tc58IoctlTrim:
				Console_WriteString("<Tc58IoctlTrim>");
				*pValue = 0;
				break;

			case Tc58IoctlCtrlPower:
				Console_WriteString("<Tc58IoctlCtrlPower>");
				*pValue = 0;
				break;
			case Tc58IoctlCtrlLock:
				Console_WriteString("<Tc58IoctlCtrlLock>");
				*pValue = 0;
				break;

			case Tc58IoctlCtrlEject:
				Console_WriteString("<Tc58IoctlCtrlEject>");
				*pValue = 0;
				break;

			case Tc58IoctlCtrlFormat:
				Console_WriteString("<Tc58IoctlCtrlFormat>");
				*pValue = 0;
				break;

			case Tc58IoctlGetSectorsPerBlock:
				*pValue = physicalGeometry.pagesPerBlock;
				break;

			case Tc58IoctlGetManufacturerId:
				*pValue = physicalGeometry.manufacturerId;
				break;

			case Tc58IoctlGetDeviceId:
				*pValue = physicalGeometry.deviceId;
				break;

			case Tc58IoctlGetSectorsPerPage:
				*pValue = physicalGeometry.pagesPerBlock;
				break;

			// Returns the Toshiba TC58's page size
			case Tc58IoctlGetTc58PageSize:
				*pValue = physicalGeometry.bytesPerPage;
				break;

			// Returns the Toshiba TC58's block size
			case Tc58IoctlGetTc58BlockSize:
				*pValue = physicalGeometry.bytesPerPage * physicalGeometry.pagesPerBlock;
				break;

			case Tc58IoctlGetMkfsIndication:
				*pValue = mkfsIndication;
				break;

			case Tc58IoctlPutMkfsIndication:
				mkfsIndication = *pValue;
				break;

			case Tc58IoctlPutScratchPadBlockNumber:
				scratchPadBlockNumber = (uint16_t) *pValue;
				break;

			case Tc58IoctlGetLastFailedBlockNumber:
				*pValue = failedBlockNumberPerFeatC0;
				break;

			case Tc58IoctlFormat:
				status = format();
				break;

			case Tc58IoctlReFormat:
				status = reFormat();
				break;


			// Important: So that the compiler catches missing ioctl support, no default case handling is coded.

		}
	}

	// We care about tracking this status, use macro to feed status to SW Unit control.
    return returnStatus(status, eSucIoctlStatus);

} // Tc58Flash_DoIoControl ( )

// Important, these are the only valid status returns.  Be sure to remap as needed.
// 		* StatusResultDiskError, maps at a higher level to: DRESULT (type), value: RES_ERROR = 1
//  	* StatusResultInvalidParameter,  maps at a higher level to: DRESULT (type), value: RES_PARERR = 4
//      * StatusResultNotInitialized,  maps at a higher level to: DRESULT (type), value: RES_PARERR = 4
status_t Tc58FlashPhysical_Read(Tc58PageAddress_t a, void *pBuffer, uint16_t numBytes)
{
	status_t status;
    status = StatusOk;

    if (!initialized) {
        status = StatusNotInitialized;
    }

    // Validate parameters
    if (StatusOk == status) {
    	if ( (a.block >= physicalGeometry.blocksPerUnit) ||
    	     (a.page >= physicalGeometry.pagesPerBlock) ){
			status = StatusResultInvalidParameter;
    	}
    }

	if (StatusOk == status) {

		for (uint16_t bytesRead = 0; bytesRead < numBytes; bytesRead += physicalGeometry.bytesPerPageEccOn) {

			status = readCellArray (a.block, a.page);

			// data starts at offset zero inside a page, that's just convention in this app.
			uint16_t pageOffset;
			uint16_t bytesToRead;

			pageOffset = 0;
			bytesToRead = (numBytes - bytesRead);
			if (bytesToRead > physicalGeometry.bytesPerPageEccOn) {
				bytesToRead = physicalGeometry.bytesPerPageEccOn;
			}

			status = readBuffer(pageOffset, pBuffer, bytesToRead, a.block);

			// Setup for next write
			pBuffer += bytesToRead;

#warning - Do not cross blocks with Tc58FlashPhysical_Read()
			// Increment the page address...
			a.page++;
		}
	}

	// We care about tracking this status, use macro to feed status to SW Unit control.
    return returnStatus(status, eSucReadStatus);

} // Tc58FlashPhysical_Read

// Important, these are the only valid status returns.  Be sure to remap as needed.
// 		* StatusResultDiskError, maps at a higher level to: DRESULT (type), value: RES_ERROR = 1
//  	* StatusResultInvalidParameter,  maps at a higher level to: DRESULT (type), value: RES_PARERR = 4
//      * StatusResultNotInitialized,  maps at a higher level to: DRESULT (type), value: RES_PARERR = 4
status_t Tc58FlashPhysical_ReadOnePage(Tc58PageAddress_t a, uint8_t *pBuffer)
{
#ifdef DEBUG_TRACE
	uint8_t buff[50];
	sprintf(buff, "<PR %u/%u>", a.block, a.page);
	Console_WriteString(buff);
#endif

	status_t status;
    status = StatusOk;

    if (!initialized) {
        status = StatusNotInitialized;
    }

    // Validate parameters
    if (StatusOk == status) {
    	if ( (a.block >= physicalGeometry.blocksPerUnit) ||
    	     (a.page >= physicalGeometry.pagesPerBlock) ){
			status = StatusResultInvalidParameter;
    	}
    }

	// Latch the initial row address
    if (StatusOk == status) {
    	status = readCellArray (a.block, a.page);
    }

    if (StatusOk == status) {
		status = readBuffer(0, pBuffer, physicalGeometry.bytesPerPage, a.block);
    }

	// We care about tracking this status, use macro to feed status to SW Unit control.
    return returnStatus(status, eSucReadStatus);

} // Tc58FlashPhysical_Read

// Important, these are the only valid status returns.  Be sure to remap as needed.
// 		* StatusResultDiskError, maps at a higher level to: DRESULT (type), value: RES_ERROR = 1
//  	* StatusResultInvalidParameter,  maps at a higher level to: DRESULT (type), value: RES_PARERR = 4
//      * StatusResultNotInitialized,  maps at a higher level to: DRESULT (type), value: RES_PARERR = 4
status_t Tc58FlashPhysical_WriteOnePage(Tc58PageAddress_t a, uint8_t *pBuffer)
{
#ifdef DEBUG_TRACE
	uint8_t buff[50];
	sprintf(buff, "<PW %u/%u>", a.block, a.page);
	Console_WriteString(buff);
#endif

    status_t status;
    status = StatusOk;

    if (!initialized) {
        status = StatusNotInitialized;
    }

    // Validate parameters
    if (StatusOk == status) {
    	if ( (a.block >= physicalGeometry.blocksPerUnit) ||
    	     (a.page >= physicalGeometry.pagesPerBlock) ) {
			status = StatusResultInvalidParameter;
    	}
    }

    // Erase the page before writing the page.
    if (StatusOk == status) {
    	status = eraseOnePage(a);
    }


    // A "page" of flash is either 4224 or 4352 bytes (depending upon whether ECC is enabled).
    if (StatusOk == status) {
    	status = readCellArray(a.block, a.page);
    }

    // Per Datasheet: "To enable the program operation"
    if (StatusOk == status) {
    	status = writeEnable();
    }

    if (StatusOk == status) {

    	uint16_t pageOffset;

    	// Sector data starts at offset zero inside a page
    	pageOffset = 0;
    	status = programLoad(pageOffset, pBuffer, physicalGeometry.bytesPerPage, a.block);
    }

	// Now Program data from the buffer to the cell array
	if (StatusOk == status) {
		status = programExecute(a.block, a.page);
	}

	// Regardless of status to this point, always attempt to disable the writes
	status_t writeDisableStatus;
	writeDisableStatus = writeDisable();

	if (StatusOk == status) {
		status = writeDisableStatus;
	}


	// We care about tracking this status, use macro to feed status to SW Unit control.
    return returnStatus(status, eSucWriteStatus);

} // Tc58FlashPhysical_WriteOnePage

// Important, these are the only valid status returns.  Be sure to remap as needed.
// 		* StatusResultDiskError, maps at a higher level to: DRESULT (type), value: RES_ERROR = 1
//  	* StatusResultInvalidParameter,  maps at a higher level to: DRESULT (type), value: RES_PARERR = 4
//      * StatusResultNotInitialized,  maps at a higher level to: DRESULT (type), value: RES_PARERR = 4
status_t Tc58FlashPhysical_Write(Tc58PageAddress_t a, void *pBuffer, uint16_t numBytes)
{
    status_t status;
    status = StatusOk;

    if (!initialized) {
        status = StatusNotInitialized;
    }

    // Validate parameters
    if (StatusOk == status) {
    	if ( (a.block >= physicalGeometry.blocksPerUnit) ||
    	     (a.page >= physicalGeometry.pagesPerBlock) ) {
			status = StatusResultInvalidParameter;
    	}
    }

    // Consider page size during this write operation, pass through all data, being sure that all data is properly written.
    if (StatusOk == status) {

		for (uint16_t bytesWritten = 0; bytesWritten < numBytes; bytesWritten += physicalGeometry.bytesPerPageEccOn) {

			// Erase the page before writing the page.
			status = eraseOnePage(a);
			if (StatusOk != status) {
				break;
			}

			status = readCellArray(a.block, a.page);
			if (StatusOk != status) {
				break;
			}

			// Per Datasheet: "To enable the program operation"
			status = writeEnable();
			if (StatusOk != status) {
				break;
			}

			// data starts at offset zero inside a page, that's just convention in this app.
			uint16_t pageOffset;
			uint16_t bytesToWrite;

			pageOffset = 0;
			bytesToWrite = (numBytes - bytesWritten);
			if (bytesToWrite > physicalGeometry.bytesPerPageEccOn) {
				bytesToWrite = physicalGeometry.bytesPerPageEccOn;
			}

			status = programLoad(pageOffset, pBuffer, bytesToWrite, a.block);
			if (StatusOk != status) {
				break;
			}

			// Now Program data from the buffer to the cell array
			status = programExecute(a.block, a.page);
			if (StatusOk != status) {
				break;
			}

			status = writeDisable();
			if (StatusOk != status) {
				break;
			}

			// Setup to write the next page ...
			pBuffer += bytesToWrite;

#warning - Do not cross blocks with Tc58FlashPhysical_Write()
			// Increment the page address...
			a.page++;
		}
    }

	// We care about tracking this status, use macro to feed status to SW Unit control.
    return returnStatus(status, eSucWriteStatus);

} // Tc58FlashPhysical_Write

// Important, this API method needs to only return certain statuses (documented in the H file).
status_t Tc58FlashPhysical_ReturnStatus(void)
{
    status_t status;

    status = StatusOk;

    if (!initialized) {
		status = StatusDiskNoDisk;
        // formerly: status = StatusDiskNoInit;
    }

    if (StatusOk == status) {
		if (noDisk) {
			status = StatusDiskNoDisk;
		}
    }

#if 0
    if (StatusOk == status) {
		if (locked) {
			status = StatusDiskProtect;
		}
    }
#endif

	// We care about tracking this status, use macro to feed status to SW Unit control.
    return returnStatus(status, eSucIoctlStatus);

} // Tc58FlashPhysical_ReturnStatus

status_t Tc58FlashPhysical_GetGeometry (Tc58PhysicalGeometry_t *pGeometry)
{
    status_t status;
    status = StatusOk;

    if (!initialized) {
        status = StatusNotInitialized;
    }

    if (status == StatusOk) {
		if (NULL == pGeometry) {
			status = StatusParameter1;
		}
    }

    if (status == StatusOk) {
    	(*pGeometry) = physicalGeometry;
    }

	// We care about tracking this status, use macro to feed status to SW Unit control.
    return returnStatus(status, eSucIoctlStatus);

} // Tc58FlashPhysical_GetGeometry


status_t Tc58Physical_EraseBlockRestricted(uint16_t blockNumber)
{
    status_t status;
    status = StatusOk;

    if (!initialized) {
        status = StatusNotInitialized;
    }

    if (StatusOk == status) {
    	status = eraseBlock (blockNumber);
    }

	// We care about tracking this status, use macro to feed status to SW Unit control.
	return returnStatus(status, eSucIoctlStatus);

} // Tc58FlashPhysical_EraseBlock

status_t Tc58FlashPhysical_Init(void)
{
    status_t status;
    status = StatusOk;

    if (initialized) {
        status = StatusAlreadyInitialized;
    }

    if (status == StatusOk) {
    	status = disablePageHighSpeedMode ();
    }

    if (status == StatusOk) {

    	// Verify the flash components ID information
        HAL_GPIO_WritePin (GPIOA, GPIO_PIN_8, GPIO_PIN_SET);

        // Assume a successful initialization
    	initialized = true;

    	status = readIdSetupGeometry();

    	// Remap any failures to "read and verify" into a "no disk" condition.
    	if (StatusOk != status) {
    		noDisk = true;
        	status = StatusDiskNoDisk;
    	} else {
    		noDisk = false;
    	}
    }

    // If NOT a succssful initialization
    if (status != StatusOk) {
    	initialized = false;
    }

    if (status == StatusOk) {
    	if(!cliInitialized){
    	   	status = Console_ExportCommandsToCli (&exportedReg, commandList);
    	   	if (status == StatusOk) {
    	   		cliInitialized = true;
    	   	}
    	}
    }

    // We care about tracking this status, use macro to feed status to SW Unit control.
    return returnStatus(status, eSucInitStatus);

} // Tc58FlashPhysical_Init

status_t Tc58FlashPhysical_DeInit(void)
{
	status_t status;
	status = StatusOk;

	initialized = false;

	return status;

}

/// SAEC Kinetic Vision, Inc  ----------- END OF FILE
