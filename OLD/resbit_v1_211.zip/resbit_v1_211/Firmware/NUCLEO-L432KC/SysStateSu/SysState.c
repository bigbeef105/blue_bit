/**
  @file       SysState.c

  @copyright  (C) 2020 Kinetic Vision, Cincinnati Ohio.
               This software is property of SAEC Kinetic Vision, Inc 
               and is considered confidential.

  @brief      SysState software unit "C" file.

  @author     aloebs

  @ingroup    SysStateSoftwareUnit 

  Configuration History
  =====================

  Config Item    | Value
  -------------- | -----
  Config #       | NA
  Revision       | NA
  Revised, Date  | NA
  QA, Date       | NA
  Approved, Date | NA
  Released, Date | NA

  Significant Modification History (Most recent at top)
  =====================================================

  Date         | Initials | Details
  ------------ | -------- | -------
  May 16, 2020 | ASL      | Original

  Theory of Operation
  ===================
  Manages system state

*/

// Includes ------------------------------------------------------------------

#include "SysState.h"

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

#include "../ConfigSu/Config.h"
#include "../ConsoleSu/Console.h"
#include "../Inc/main.h"
#include "../Inc/usb_device.h"
#include "../Middlewares/ST/STM32_USB_Device_Library/Core/Inc/usbd_core.h"
#include "../TimerSu/timer.h"
#include "../Bno055Su/bno055.h"
#include "../HallSu/Hall.h"
#include "../Hx711Su/HX711.h"
#include "../RtcSu/rtc.h"
#include "../DataReceiverSu/DataReceiver.h"
#include "../Lis2de12Su/lis2de12.h"
#include "../PowerSu/power.h"
#include "../BlueBitsSu/BlueBits.h"
#include "../SysTimeSu/SysTime.h"
#include "../AdcSu/adc.h"

// Private macros ------------------------------------------------------------

// Private constants ---------------------------------------------------------
#define DEEP_SLEEP_DEFAULT_TIME				1000 // ms
#define READ_VBATT_TIMEOUT					100 // ms

#define DATA_RECEIVE_FLUSH_TIMEOUT			100 // ms
#define BUTTON_KEEP_ALIVE_TIME				5000 // ms -- gives enough time for long button press

#define PROTECT_CHECK_INTERVAL				100 // ms

#define CONFIG_SEC_TIME_TO_SYS_TIME			1000 // sec -> ms
#define CONFIG_SEC_TIME_TO_RTC_TIME			1 // sec -> sec
#define CONFIG_MIN_TIME_TO_RTC_TIME			60 // min -> sec

// Private types -------------------------------------------------------------
typedef enum {
	systemStateInvalid = 0,
	systemStateIdle,
	systemStateStudyActive,
} systemState_t;

typedef enum {
	studyStateInvalid = 0,
	studyStateDeepSleep,
	studyStateWake,
	studyStateSleep,
	studyStateProtect,
} studyState_t;

typedef enum {
	wakeSourceTime = 0,
	wakeSourceMotion,
	wakeSourceButton,
} wakeSources_t;

typedef struct {
	status_t (*entry)(void);
	status_t (*exit)(void);
} stateTransitions_t;

typedef struct {
	wakeSources_t lastWakeSource;
	uint32_t rtcWakeTime;
	uint32_t sysWakeTime;
	uint32_t duration;
	bool motion;
	uint32_t lastMotionTime;
} wakeParams_t;

typedef struct {
	// Settings from config
	bool enabled;
	bool trigger;
	uint16_t wakeupLimit;
	uint16_t wakeupTickLimit;
	uint16_t wakeupResetInterval;
	uint16_t sleepDuration;
	
	// State variables
	uint32_t wakeupCountStart;
	uint16_t wakeupCount;
	uint32_t effectiveWakeStart;
} protectSettings_t;

// Private function prototypes -----------------------------------------------
static status_t cliStartStudyCommand(uint16_t argc, uint8_t **argv);
static status_t cliStopStudyCommand(uint16_t argc, uint8_t **argv);

static status_t systemStateTransition(systemState_t newState);
static status_t studyStateTransition(studyState_t newState);

static status_t idleEntry(void);
static status_t idleExit(void);

static status_t studyActiveEntry(void);
static status_t studyActiveExit(void);

static status_t deepSleepEntry(void);
static status_t deepSleepExit(void);
static status_t wakeEntry(void);
static status_t wakeExit(void);
static status_t sleepEntry(void);
static status_t sleepExit(void);
static status_t protectEntry(void);
static status_t protectExit(void);

static status_t setupWakeParams(void);
static bool checkSleepSignal(void);

static status_t setupProtectSignal(void);
static bool checkProtectSignal(bool sleepSignal);
static status_t handleProtectStateTrigger(uint32_t timeoutSec);

static publicState_t publicStateFromStudyState(studyState_t state);

// Private constants ---------------------------------------------------------
static const consoleCommand_t commandList[] = {
	{
		.pCommand = "SS",
		.pUsage = "usage: start logging data",
		.pHandlerFn = cliStartStudyCommand
	},
	{
		.pCommand = "ss",
		.pUsage = "usage: stop logging data",
		.pHandlerFn = cliStopStudyCommand
	},
    { NULL, NULL, NULL },
};

static const stateTransitions_t systemStateTransitions[] = {
	[systemStateInvalid] = { NULL },
	[systemStateIdle] = {idleEntry, idleExit},
	[systemStateStudyActive] = {studyActiveEntry, studyActiveExit},
};
static const stateTransitions_t studyStateTransitions[] = {
	[studyStateInvalid] = { NULL },
	[studyStateDeepSleep] = {deepSleepEntry, deepSleepExit},
	[studyStateWake] = {wakeEntry, wakeExit},
	[studyStateSleep] = {sleepEntry, sleepExit},
	[studyStateProtect] = {protectEntry, protectExit},
};

// Private variables ---------------------------------------------------------
static consoleRegistration_t exportedReg;

// State
static systemState_t systemState = systemStateInvalid;
static studyState_t studyState = studyStateInvalid;

// Extended state
static bool initOk = false;
static bool modeOperate = false;
static bool longButtonPress = false;
static bool stopStudySignal = false;

static bool timeWakeEnabled = false;
static uint32_t fixedTimeWake = 0;
static uint32_t fixedTimeSleep = 0;
static bool motionWakeEnabled = false;
static uint32_t motionMinWakeTime = 0;
static uint32_t noMotionBeforeSleep = 0;
static bool triggerEnabled = false;
static float battShutdownVoltage = 0.0f;
static bool usbSerialEnabled = false;

static wakeParams_t wakeParams = {
		.lastWakeSource = wakeSourceTime,
		.rtcWakeTime = 0,
		.sysWakeTime = 0,
		.duration = 0,
		.motion = false,
		.lastMotionTime = 0,
};
static protectSettings_t protectSettings; // this doesn't need to be initialized

// Private function bodies ---------------------------------------------------
static status_t cliStartStudyCommand(uint16_t argc, uint8_t **argv)
{
	status_t status = StatusOk;

	if (initOk && modeOperate && (systemStateIdle == systemState)) {
		// Enter study
		status = systemStateTransition(systemStateStudyActive);
	} else {
		status = UserInterface_BlinkLedAsync(ledPatternDeviceStatus);
	}

	return status;

}

static status_t cliStopStudyCommand(uint16_t argc, uint8_t **argv)
{
	status_t status = StatusOk;

	if (systemStateStudyActive == systemState) {
		// Exit study
		status = systemStateTransition(systemStateIdle);
	}

	return status;

}

static status_t systemStateTransition(systemState_t newState)
{
	// Call exit function
	status_t status = StatusOk;
	if (systemStateTransitions[systemState].exit) {
		status = systemStateTransitions[systemState].exit();
	}
	
	// Update state
	systemState = newState;
	
	// Call entry function
	if (systemStateTransitions[systemState].entry) {
		status = Status_Preserve(status, systemStateTransitions[systemState].entry());
	}
	
	return status;
}

static status_t studyStateTransition(studyState_t newState)
{
	// Call exit function
	status_t status = StatusOk;
	if (studyStateTransitions[studyState].exit) {
		status = studyStateTransitions[studyState].exit();
	}
	
	// Update state
	studyState = newState;
	
	// Send state to bluebits
	status = Status_Preserve(status, 
			BlueBits_SendPowerState(publicStateFromStudyState(studyState)));
	
	// Call entry function
	if (studyStateTransitions[studyState].entry) {
		status = Status_Preserve(status, studyStateTransitions[studyState].entry());
	}
	
	return status;
}

static status_t idleEntry(void)
{	
	return MX_USB_DEVICE_Init(false);
}

static status_t idleExit(void)
{
	return MX_USB_DEVICE_DeInit();
}

static status_t studyActiveEntry(void)
{
	status_t status = StatusOk;
	
	// Initialize study state
	studyState = studyStateInvalid;
	stopStudySignal = false;
	
	// Get wake/sleep settings from config
	wakeTriggerTypes_t wakeTriggers = NULL_TRIGGER_INIT;
	uint16_t temp = 0;
	status = Config_Ioctl(configIoctlGetWakeTrig, (uint8_t *)&wakeTriggers);
	// Get time wake parameters
	if (StatusOk == status) {
		if ((triggerTime == wakeTriggers) || (triggerBoth == wakeTriggers)) {
			timeWakeEnabled = true;
			
			status = Config_Ioctl(configIoctlGetFixedWakeupDuration, (uint8_t *)&temp);
			fixedTimeWake = (uint32_t)temp * CONFIG_SEC_TIME_TO_SYS_TIME;
			if (StatusOk == status) {
				status = Config_Ioctl(configIoctlGetFixedSleep, (uint8_t *)&temp);
				fixedTimeSleep = (uint32_t)temp * CONFIG_SEC_TIME_TO_RTC_TIME; // this uses RTC wakeup, which is in seconds
			}
		} else {
			timeWakeEnabled = false;
		}
	}
	// Get motion wake parameters
	if (StatusOk == status) {
		// We need this regardless of whether motion is enabled -- its used for trigger sleep timing as well
		status = Config_Ioctl(configIoctlGetNmSleep, (uint8_t *)&temp);
		noMotionBeforeSleep = (uint32_t)temp * CONFIG_SEC_TIME_TO_SYS_TIME;
		if (StatusOk == status) {
			if ((triggerShake == wakeTriggers) || (triggerBoth == wakeTriggers)) {
				motionWakeEnabled = true;
				
				status = Config_Ioctl(configIoctlGetWakeDur, (uint8_t *)&temp);
				motionMinWakeTime = (uint32_t)temp * CONFIG_SEC_TIME_TO_SYS_TIME;
			} else {
				motionWakeEnabled = false;
			}
		}
	}
	
	// Check for trigger enabled
	triggerEnabled = ADC_GetTrigEnabled();
	
	// Setup protect mode
	if (StatusOk == status) {
		status = setupProtectSignal();
	}
	
	// Check for deep sleep
	configEnableState_t deepSleepEnabled = settingDisable;
	if (StatusOk == status) {
		status = Config_Ioctl(configIoctlGetDeepSleepMode, (uint8_t *)&deepSleepEnabled);
	}
	
	// Get battery shutdown voltage
	if (StatusOk == status) {
		status = Config_Ioctl(configIoctlGetBatteryVoltage, (uint8_t *)&battShutdownVoltage);
	}
	
	// Get usb serial enabled/disabled
	if (StatusOk == status) {
		configEnableState_t enabled = settingDisable;
		status_t status = Config_Ioctl(configIoctlGetUsbSerialMode, &enabled);
		if (StatusOk == status) {
			usbSerialEnabled = (settingEnable == enabled);
			if (usbSerialEnabled) {
				// Turn on USB CDC
				status = MX_USB_DEVICE_Init(true);
			}
		}
	}
    
	// Make CSV file
	if (StatusOk == status) {
		uint32_t fileSizeKb = 0;
		status = Config_Ioctl(configIoctlGetFileSize, (uint8_t *)&fileSizeKb);
		if (StatusOk == status) {
			status = DataReceive_OpenCsvFile(fileSizeKb);
		}
	}
	
	// Get low power clock speed
	if (StatusOk == status) {
		clockSpeed_t lpClockSpeed;
		status = Config_Ioctl(configIoctlGetClockSpeed, (uint8_t *)&lpClockSpeed);
		if (StatusOk == status) {
			status = Power_SetLowPowerClockSpeed(lpClockSpeed);
		}
	}
	
	// Disable timer, Switch clock
	if (StatusOk == status) {
		status = Timer_DeInit();
	}
	if (StatusOk == status) {
		status = Power_SwitchClockMode(clockModeLowPower);
	}
	
	// Default wake source to time if enabled, else motion
	wakeParams.lastWakeSource = (timeWakeEnabled) ? wakeSourceTime : wakeSourceMotion;
	// Determine entry state
	if (StatusOk == status) {
		if ((settingEnable == deepSleepEnabled) && !usbSerialEnabled) { // in usb serial mode we don't sleep
			status = studyStateTransition(studyStateDeepSleep);
		} else {
			// Enable motion interrupt
			if (motionWakeEnabled) {
				status = Lis2de12_EnableMotionInterrupt(true);
			}
			// Enter wake study state
			status = Status_Preserve(status, studyStateTransition(studyStateWake));
		}
	}
	
	return status;
}

static status_t studyActiveExit(void)
{
	status_t status = StatusOk;
	
	// Exit sub-state
	status = studyStateTransition(studyStateInvalid); 
	// Disable motion interrupt
	status = Status_Preserve(status, Lis2de12_EnableMotionInterrupt(false));
	
	// Switch clock
	status = Status_Preserve(status, Power_SwitchClockMode(clockModeNormal));
	// Close CSV file
	status = Status_Preserve(status, DataReceive_CloseCsvFile());
	
	if (usbSerialEnabled) {
		// Turn off USB CDC
		MX_USB_DEVICE_DeInit();
	}
	
	// Blink LED
	UserInterface_ForceLedOff(); // cancel any previous blinks..
	status = Status_Preserve(status, UserInterface_BlinkLedAsync(ledPatternStudyEnd));
	
	return status;
}

static status_t deepSleepEntry(void)
{
	// Blink LED
	status_t status = UserInterface_BlinkLed(ledPatternDeepSleep);
	UserInterface_ForceLedOff(); // insurance policy
	
	// Get deep sleep time
	rtcDataHandler_t deepSleepTime;
	if (StatusOk == status) {
		status = Config_Ioctl(configIoctlGetDeepSleepDur, (uint8_t *)&deepSleepTime);
	}
	// Attempt to trigger deep sleep
	if (StatusOk == status) {
		status = RTC_SetAlarm(&deepSleepTime);
	}
	
	// If status is bad, have low power interrupt wake us
	if (StatusOk != status) {
		Timer_LowPowerInterrupt(DEEP_SLEEP_DEFAULT_TIME);
	}
	
	// Go to sleep
	status = Status_Preserve(status, Power_EnterLowPower());
	
	// We will enter wake study state on next tick() loop..
	return status;
}

static status_t deepSleepExit(void)
{
	status_t status = StatusOk;
	
	// Cancel RTC alarm just in case button woke us
	status = RTC_ClearAlarm();
	// Re-enable peripherals and clock
	status = Status_Preserve(status, Power_ExitLowPower(clockModeLowPower));
	
	// Enable motion interrupt
	if (motionWakeEnabled) {
		status = Status_Preserve(status, Lis2de12_EnableMotionInterrupt(true));
	}
	
	return status;
}

static status_t wakeEntry(void)
{
	// Blink wake pattern
	status_t status = UserInterface_BlinkLedAsync(ledPatternWakeup);
	
	// Check battery voltage
	if (StatusOk == status) {
		float batteryVoltage;
		status = ADC_ReadVBattBlocking(READ_VBATT_TIMEOUT, &batteryVoltage);
		if (StatusOk == status) {
			if (batteryVoltage <= battShutdownVoltage) {
				stopStudySignal = true;
			}
		}
	}
	
	// Setup wake params
	status = Status_Preserve(status, setupWakeParams());
	
	// Start data agg
	status = Status_Preserve(status, DataAggregator_On(usbSerialEnabled));
	
	return status;
}

static status_t wakeExit(void)
{
	// Turn off data aggregation
	status_t status = DataAggregator_Off();
	// Flush FIFO buffer (via data receiver)
	status = Status_Preserve(status, DataReceive_Flush(DATA_RECEIVE_FLUSH_TIMEOUT));
	// Check file expand
	status = Status_Preserve(status, DataReceive_CheckCsvExpand());
	
	return status;
}

static status_t sleepEntry(void)
{
	// Blink LED
	status_t status = UserInterface_BlinkLed(ledPatternSleep);
	UserInterface_ForceLedOff(); // insurance policy
	// Set wakeup timer if enabled
	if (timeWakeEnabled) {
		status = Status_Preserve(status, RTC_SetWakeupTimer(fixedTimeSleep));
	}
	status = Status_Preserve(status, Power_EnterLowPower());
	
	// We will enter wake study state on next tick() loop..
	return status;
}

static status_t sleepExit(void)
{
	status_t status = StatusOk;
	
	// Make sure wakeup timer is cancelled
	status = RTC_ClearWakeupTimer();
	
	// Re-enable peripherals and clock
	status = Status_Preserve(status, Power_ExitLowPower(clockModeLowPower));
	
	return status;
}

static status_t protectEntry(void)
{
	status_t status = UserInterface_BlinkLed(ledPatternProtect);
	UserInterface_ForceLedOff(); // insurance policy
	
	// Disable motion interrupt
	if (motionWakeEnabled) {
		status = Status_Preserve(status, Lis2de12_EnableMotionInterrupt(false));
	}
	
	if (protectSettings.trigger) {
		status = Status_Preserve(status, handleProtectStateTrigger(protectSettings.sleepDuration));
	} else {
		status = Status_Preserve(status, RTC_SetWakeupTimer(protectSettings.sleepDuration));
		status = Status_Preserve(status, Power_EnterLowPower());
	}
		
	
	return status;
}

static status_t protectExit(void)
{
	status_t status = StatusOk;
	
	// Make sure wakeup timer is cancelled
	status = RTC_ClearWakeupTimer();
	
	// Re-enable peripherals and clock
	if (!protectSettings.trigger) {
		status = Status_Preserve(status, Power_ExitLowPower(clockModeLowPower));
	}
	
	// Enable motion interrupt
	if (motionWakeEnabled) {
		status = Status_Preserve(status, Lis2de12_EnableMotionInterrupt(true));
	}
	
	// Reset wakeup count
	protectSettings.wakeupCount = 0;
	
	return status;
}

static status_t setupWakeParams(void)
{
	// Set wake time & wake duration
	wakeParams.sysWakeTime = SysTime_GetMs();
	if ((wakeSourceMotion == wakeParams.lastWakeSource) && motionWakeEnabled) {
		wakeParams.duration = motionMinWakeTime;
	} else if (wakeSourceButton == wakeParams.lastWakeSource){
		wakeParams.duration = BUTTON_KEEP_ALIVE_TIME;
	} else {
		wakeParams.duration = fixedTimeWake;
	}
	
	// Store rtc time
	rtcDataHandler_t rtcTime;
	status_t status = RTC_ReadTime(&rtcTime);
	wakeParams.rtcWakeTime = RTC_GetUnixTime(&rtcTime);
	
	// Update protect settings wake time
	protectSettings.effectiveWakeStart = SysTime_GetMs();
	
	return status;
}

static bool checkSleepSignal(void)
{
	// Start with true -- once one condition fails we can stop checks
	bool readyToSleep = true;
	// If time hasn't elapsed
	if (!SysTime_IsElapsed(wakeParams.sysWakeTime, wakeParams.duration)) {
		readyToSleep = false;
	}
	// If no motion hasn't elapsed
	if (readyToSleep && motionWakeEnabled) {
		if (wakeParams.motion || !SysTime_IsElapsed(wakeParams.lastMotionTime, 
				noMotionBeforeSleep - (ACC_MOTION_WINDOW * CONFIG_SEC_TIME_TO_SYS_TIME))) // this compensates for the IMU moving window
		{
			readyToSleep = false;
		}
	}
	// If last trigger was less than "no motion" seconds ago -- only applies to absolute trigger mode
	if (triggerEnabled && !ADC_GetTrigRelative() && ADC_GetTrigPassed()) {
		if (ADC_GetTrigActive() || 
				!SysTime_IsElapsed(ADC_GetLastTrigTime(), noMotionBeforeSleep)) 
		{
			readyToSleep = false;
		}
	}
	
	return readyToSleep;
}

static status_t setupProtectSignal(void)
{
	// Get protect mode
	configProtectMode_t protectMode = NULL_PROTECT_INIT;
	status_t status = Config_Ioctl(configIoctlGetProtectMode, (uint8_t *)&protectMode);
	if (StatusOk == status) {
		if (protectModeOff == protectMode) {
			// disable
			protectSettings.enabled = false;
		} else if (protectModeTrigger == protectMode) {
			// trigger
			protectSettings.enabled = true;
			protectSettings.trigger = true;
			
			// Trigger enabled should be true -- if not, ADC was not set up to have
			// an analog sensor on this channel.
			// Returning a bad status here will make the system remain in an invalid
			// study state, thus returning to idle and re-enabling the USB
			if (!ADC_GetTrigEnabled()) return StatusConfigSettings; 
		} else {
			// shakes
			protectSettings.enabled = true;
			protectSettings.trigger = false;
		}
	}
	
	// Get protect mode parameters
	if (protectSettings.enabled) {
		if (StatusOk == status) {
			status = Config_Ioctl(configIoctlGetWakeLimit, (uint8_t *)&protectSettings.wakeupLimit);
		}
		if (StatusOk == status) {
			status = Config_Ioctl(configIoctlGetWakeTick, (uint8_t *)&protectSettings.wakeupTickLimit);
			protectSettings.wakeupTickLimit *= CONFIG_SEC_TIME_TO_SYS_TIME;
		}
		if (StatusOk == status) {
			status = Config_Ioctl(configIoctlGetWakeReset, (uint8_t *)&protectSettings.wakeupResetInterval);
			protectSettings.wakeupResetInterval *= CONFIG_MIN_TIME_TO_RTC_TIME;
		}
		if (StatusOk == status) {
			status = Config_Ioctl(configIoctlGetSleepDur, (uint8_t *)&protectSettings.sleepDuration);
			protectSettings.sleepDuration *= CONFIG_MIN_TIME_TO_RTC_TIME;
		}
	}
	
	// Initialize state
	protectSettings.wakeupCount = 0;
	
	return status;
}

static bool checkProtectSignal(bool sleepSignal)
{
	// Exit if not enabled
	if (!protectSettings.enabled) return false;

	bool wakeupTickLimit = false;
	if (SysTime_IsElapsed(protectSettings.effectiveWakeStart, 
			protectSettings.wakeupTickLimit))
	{
		wakeupTickLimit = true;
		protectSettings.effectiveWakeStart += protectSettings.wakeupTickLimit;
	}
	
	// Check for trigger event
	if (protectSettings.trigger && ADC_GetTrigPassed()) {
		// Reset
		protectSettings.wakeupCount = 0;
		return false; // exit
		
	}
	// Check for counter increment
	if (sleepSignal || wakeupTickLimit) {
		// Set wakeup count start (used for timeout) if needed
		if (protectSettings.wakeupCount == 0) {
			// Update start time
			protectSettings.wakeupCountStart = wakeParams.rtcWakeTime;
		} else {
			// Check for reset
			rtcDataHandler_t currentTime;
			status_t status = RTC_ReadTime(&currentTime);
			if (StatusOk == status) { // In case of bad status, we won't restart the time.
				// Compare times
				uint32_t currentUnix = RTC_GetUnixTime(&currentTime);
				if ((currentUnix - protectSettings.wakeupCountStart) >= 
						protectSettings.wakeupResetInterval) {
					// Reset
					protectSettings.wakeupCountStart = wakeParams.rtcWakeTime;
					protectSettings.wakeupCount = 0;
					return false; // exit
				}
			}
		}
		// Increment count unless this is a sleep event and we've already incremented due to time..
		if (!(sleepSignal && (wakeParams.sysWakeTime != protectSettings.effectiveWakeStart))) {
			protectSettings.wakeupCount++;
		}
	}
	
	// Check for protect conditions..
	if (protectSettings.wakeupCount >= protectSettings.wakeupLimit) {
		return true;
	} else {
		return false;
	}
}

static status_t handleProtectStateTrigger(uint32_t timeoutSec)
{
	rtcDataHandler_t currentRtcTime;
	status_t status = RTC_ReadTime(&currentRtcTime);
	
	if (StatusOk == status) {
		status = ADC_SetupProtectModeTrigger();
	}
	
	if (StatusOk == status) {
		uint32_t startTime = RTC_GetUnixTime(&currentRtcTime);
		// until the trigger is passed or we time out, sleep for increments
		while (!ADC_GetProtectModeTriggerPassed()) {
			// Sleep
			status = Status_Preserve(status, Power_Sleep(PROTECT_CHECK_INTERVAL, 
					clockModeLowPower));
			
			// Check timeout
			status = Status_Preserve(status, RTC_ReadTime(&currentRtcTime));
			if ((RTC_GetUnixTime(&currentRtcTime) - startTime) >= timeoutSec) {
				break;
			}
		}
	}
	
	return status;
}

static publicState_t publicStateFromStudyState(studyState_t state)
{
	publicState_t ret = publicStateAwake;
	switch (state) {
		case studyStateInvalid:
		case studyStateWake:
			ret = publicStateAwake;
			break;
		case studyStateDeepSleep:
			ret = publicStateDeepSleep;
			break;
		case studyStateSleep:
			ret = publicStateSleep;
			break;
		case studyStateProtect:
			ret = publicStateProtected;
			break;
		default:
			break;
	}

	return ret;
}


// Public functions bodies ---------------------------------------------------
status_t SysState_Init(status_t initStatus)
{
    status_t status = StatusOk;
    
    // Store init status
    initOk = (StatusOk == initStatus) ? true : false;

    // Check for start-up actions
    systemState = systemStateInvalid; // this will get cleared if we enter a different state
    if (initOk) {
    	// Get op mode
    	opModeTypes_t opMode;
    	status = Config_Ioctl(configIoctlGetMode, (uint8_t *)&opMode);
    	if (StatusOk == status) {
    		if (operate == opMode) {
    			modeOperate = true;
    			
    			// Check for start study
    			startStudyTypes_t startStudy;
				status = Config_Ioctl(configIoctlGetStartStudyTrig, &startStudy);
				if (StatusOk == status) {
					if (startStudyPowerOn == startStudy) {
						status = systemStateTransition(systemStateStudyActive);
					} 
    			}
    		} else {
#ifndef SWO_PROFILE_BUILD
    			status = Power_SwitchClockMode(clockModeLowPower);
    			if (StatusOk == status) {
					// Perform the specified calibration
					if (calibrateLoadCell == opMode) {
						status = Status_Preserve(status, HX711_CalibrateMode());
					} else if (calibrateHall == opMode) {
						status = Status_Preserve(status, Hall_CalibrateMode());
					} else if (calibrateImu == opMode) {
						status = Status_Preserve(status, Bno055_CalibrateMode());
					}
    			}
    			status = Status_Preserve(status, Power_SwitchClockMode(clockModeNormal));
#endif // SWO_PROFILE_BUILD
    		}
    	}
    }
    
    // If system state has not been overwritten, go to idle state
    if (systemState == systemStateInvalid) {
    	status = systemStateTransition(systemStateIdle);
    	
    	// Notify of bad status
    	if ((StatusOk != status) || !initOk) {
			// Blink LED but don't overwrite bad status
			UserInterface_BlinkLedAsync(ledPatternDeviceStatus);
			initOk = false; // make sure init ok is false (it may be the case that something failed above)..
    	}
    }
    
	// Export commands if uart debug is enabled
    if (StatusOk == status) {
		configEnableState_t uartDebug;
		Config_Ioctl(configIoctlGetUart, &uartDebug);
		if(settingEnable == uartDebug) {
			status = Console_ExportCommandsToCli(&exportedReg, commandList);
		}
    }
	
    return status;
}

status_t SysState_HandleState(void)
{
    status_t status = StatusOk;
    
    switch (systemState) {
    	case systemStateIdle:
    		if (longButtonPress) {
    			if (initOk && modeOperate) {
					// Enter study
					status = systemStateTransition(systemStateStudyActive);
				} else {
					status = UserInterface_BlinkLedAsync(ledPatternDeviceStatus);
				}
    			longButtonPress = false;
    		}
    		break;
    	case systemStateStudyActive:
    		switch (studyState) {
    			case studyStateDeepSleep:
    				// This only gets called after we wake from deep sleep 
    				// Enter wake study state
					status = studyStateTransition(studyStateWake);
    				break;
    			case studyStateWake:
    				// Don't sleep if we're in usb serial mode
    				if (!usbSerialEnabled) {
						bool sleepSignal = checkSleepSignal();
						bool protectSignal = checkProtectSignal(sleepSignal);
						if (protectSignal) {
							status = studyStateTransition(studyStateProtect);
						} else if (sleepSignal) {
							status = studyStateTransition(studyStateSleep);
						}
    				}
    				break;
    			case studyStateSleep:
    				// This only gets called after we wake
    				status = studyStateTransition(studyStateWake);
    				break;
    			case studyStateProtect:
    				// This only gets called after we're done with protect mode
    				status = studyStateTransition(studyStateWake);
    				break;
    			default:
    				break;
    		}
    		// Exit study
    		if (longButtonPress || stopStudySignal || (studyStateInvalid == studyState)) {
    			status = systemStateTransition(systemStateIdle);
    			longButtonPress = false; // we're OK to clear this if stopStudySignal was the reason we stopped
    		}
    		break;
    	default:
    		break;
    }
    return status;
}

ledPattern_t SysState_GetCurrentStateBlinkPattern(void)
{
	ledPattern_t retVal = ledPatternDeviceStatus;
	
	switch (systemState) {
		case systemStateIdle:
			if (initOk) {
				retVal = ledPatternStudyReady;
			} else {
				retVal = ledPatternDeviceStatus;
			}
			break;
		case systemStateStudyActive:
			retVal = ledPatternStudyActive;
			break;
		default:
			break;
	}
	
	return retVal;
}

uint32_t SysState_GetWakeTime(void)
{
	return wakeParams.rtcWakeTime;
}

void SysState_NotifyLongButtonPress(void)
{
	longButtonPress = true;
}

void SysState_NotifyButtonInterrupt(GPIO_PinState pinState)
{
	wakeParams.lastWakeSource = wakeSourceButton;
}

void SysState_NotifyImuInterrupt(GPIO_PinState pinState)
{
	// Active high
	if (GPIO_PIN_SET == pinState) {
		wakeParams.motion = true;
	} else {
		wakeParams.motion = false;
		wakeParams.lastMotionTime = SysTime_GetMs();
	}
	
	wakeParams.lastWakeSource = wakeSourceMotion;
}

void SysState_NotifyWakeupTimerInterrupt(void)
{
	wakeParams.lastWakeSource = wakeSourceTime;
}

void SysState_NotifyFlashFull(void)
{
	stopStudySignal = true;
}

/// SAEC Kinetic Vision, Inc. ----------- END OF FILE
