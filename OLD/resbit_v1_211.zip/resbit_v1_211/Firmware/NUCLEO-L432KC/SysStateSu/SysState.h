/**
  @file       SysState.h

  @copyright  (C) 2020 Kinetic Vision, Cincinnati Ohio.
               This software is property of SAEC Kinetic Vision, Inc 
               and is considered confidential.

  @brief      SysState software unit "H" file.

  @author     aloebs

  @defgroup   SysStateSoftwareUnit

  Configuration History
  =====================

  Config Item    | Value
  -------------- | -----
  Config #       | NA
  Revision       | NA
  Revised, Date  | NA
  QA, Date       | NA
  Approved, Date | NA
  Released, Date | NA

  Significant Modification History (Most recent at top)
  =====================================================

  Date         | Initials | Details
  ------------ | -------- | -------
  May 16, 2020 | ASL      | Original

  Theory of Operation
  ===================
  Manages system state

  */

// Define to prevent recursive inclusion -------------------------------------
#ifndef __SYSSTATE_H_
#define __SYSSTATE_H_

#include "stm32l4xx_hal.h"

#include "../StatusSu/Status.h"
#include "../UserInterfaceSu/UserInterface.h"

// Exported macro ------------------------------------------------------------

// Exported types ------------------------------------------------------------
// Defined states used for sending to mcu peripherals (currently only bluebits)
// -- not used internally
typedef enum {
	publicStateAwake = 0,
	publicStateSleep,
	publicStateProtected,
	publicStateDeepSleep,
} publicState_t;

// Exported constants --------------------------------------------------------

// Exported objects ----------------------------------------------------------

// Exported functions --------------------------------------------------------

///  @brief Initializes the SysState software unit
///  @param args[in] initStatus - Result of system initialization
status_t SysState_Init(status_t initStatus);

///  @brief Updates extended state variables and handles state transitions
status_t SysState_HandleState(void);

///  @brief Returns user interface blink pattern associated with current state
ledPattern_t SysState_GetCurrentStateBlinkPattern(void);

///  @brief Returns the wake-up time of the current wake cycle
uint32_t SysState_GetWakeTime(void);

///  @brief Notifies the system state module of a long button press
void SysState_NotifyLongButtonPress(void);

///  @brief Notifies the system state module of a button interrupt
void SysState_NotifyButtonInterrupt(GPIO_PinState pinState);

///  @brief Notifies the system state module of an imu interrupt
void SysState_NotifyImuInterrupt(GPIO_PinState pinState);

///  @brief Notifies the system state module of a wakeup timer interrupt
void SysState_NotifyWakeupTimerInterrupt(void);

///  @brief Notifies the system state module that the flash chip is full
void SysState_NotifyFlashFull(void);

#endif // __SYSSTATE_H_

/// SAEC Kinetic Vision, Inc. ----------- END OF FILE
