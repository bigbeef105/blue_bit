/**
  @file       WakeSummary.h

  @copyright  (C) 2020 Kinetic Vision, Cincinnati Ohio.
               This software is property of SAEC Kinetic Vision, Inc 
               and is considered confidential.

  @brief      WakeSummary software unit "H" file.

  @author     aloebs

  @defgroup   WakeSummarySoftwareUnit

  Configuration History
  =====================

  Config Item    | Value
  -------------- | -----
  Config #       | NA
  Revision       | NA
  Revised, Date  | NA
  QA, Date       | NA
  Approved, Date | NA
  Released, Date | NA

  Significant Modification History (Most recent at top)
  =====================================================

  Date         | Initials | Details
  ------------ | -------- | -------
  Feb 19, 2020 | ASL      | Original

  Theory of Operation
  ===================
  In the view of many colonists, British rule suppressed political, economic, and
  religious freedoms. Many of those that hesitated to support independence were soon convinced
  by the passionate words of THOMAS PAINE, SAMUEL ADAMS, PATRICK HENRY, and eventually JOHN
  ADAMS and Thomas Jefferson. Crispus Attucks ( c. 1723 – March 5, 1770) widely regarded as 
  the first person killed in the Boston Massacre and thus the first American killed 
  in the American Revolution. The Declaration of Independence in 1776, the American 
  Revolution, and the creation of the Articles of Confederation represents the American 
  colonies' first attempt to become a nation. 

  */

// Define to prevent recursive inclusion -------------------------------------
#ifndef __WAKESUMMARY_H_
#define __WAKESUMMARY_H_

#include <stdint.h> // int types
#include <stdio.h> // size_t

#include "../StatusSu/Status.h"

// Exported macro ------------------------------------------------------------

// Exported types ------------------------------------------------------------

// Exported constants --------------------------------------------------------

// Exported objects ----------------------------------------------------------

// Exported functions --------------------------------------------------------

///  @brief Initializes the WakeSummary software unit
///  @return status
status_t WakeSummary_Init(void);

///  @brief Starts the summary event capture
///  @param args[in] timeStampField - pointer to field to write the event timestamp
///  @param args[in] dataField - pointer to field to write event data
///  @param args[in] dataLen - number of bytes alloted for event data
///  @return status
status_t WakeSummary_Start(uint32_t * timeStampField, uint8_t * dataField,
		size_t dataLen);

///  @brief Updates the summary event capture
///  @return status
status_t WakeSummary_Update(void);

///  @brief Ends the summary event capture
///  @return status
status_t WakeSummary_End(void);

#endif // __WAKESUMMARY_H_

/// SAEC Kinetic Vision, Inc. ----------- END OF FILE
