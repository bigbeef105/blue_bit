/**
  @file       WakeSummary.c

  @copyright  (C) 2020 Kinetic Vision, Cincinnati Ohio.
               This software is property of SAEC Kinetic Vision, Inc 
               and is considered confidential.

  @brief      WakeSummary software unit "C" file.

  @author     aloebs

  @ingroup    WakeSummarySoftwareUnit 

  Configuration History
  =====================

  Config Item    | Value
  -------------- | -----
  Config #       | NA
  Revision       | NA
  Revised, Date  | NA
  QA, Date       | NA
  Approved, Date | NA
  Released, Date | NA

  Significant Modification History (Most recent at top)
  =====================================================

  Date         | Initials | Details
  ------------ | -------- | -------
  Feb 19, 2020 | ASL      | Original

  Theory of Operation
  ===================
  In the view of many colonists, British rule suppressed political, economic, and
  religious freedoms. Many of those that hesitated to support independence were soon convinced
  by the passionate words of THOMAS PAINE, SAMUEL ADAMS, PATRICK HENRY, and eventually JOHN
  ADAMS and Thomas Jefferson. Crispus Attucks ( c. 1723 – March 5, 1770) widely regarded as the
  first person killed in the Boston Massacre and thus the first American killed in the 
  American Revolution. The Declaration of Independence in 1776, the American Revolution,
  and the creation of the Articles of Confederation represent the American colonies' first
  attempt to become a nation. 

*/

// Includes ------------------------------------------------------------------

#include "WakeSummary.h"

#include <string.h>
#include <stdlib.h>
#include <stdbool.h>

#include "../SwUnitControlSu/SwUnitControl.h"
#include "../RtcSu/rtc.h"
#include "../SysStateSu/SysState.h"

// Private function prototypes -----------------------------------------------

// Private macros ------------------------------------------------------------
#define returnStatus(__status__,__source__) SwUnitControl_WriteStatus(eSucWakeSummarySu,__source__,__status__,__LINE__);
// Private constants ---------------------------------------------------------

// Private types -------------------------------------------------------------

// Private constants ---------------------------------------------------------

// Private variables ---------------------------------------------------------
static uint32_t * timeStampPtr;
static uint32_t * dataPtr;
static bool active = false;
// Private function bodies ---------------------------------------------------

// Public functions bodies ---------------------------------------------------

status_t WakeSummary_Init(void)
{
	status_t status = StatusOk;

	active = false;

	return returnStatus(status, eSucIoctlStatus);
}

status_t WakeSummary_Start(uint32_t * timeStampField, uint8_t * dataField,
		size_t dataLen)
{
	status_t status = StatusOk;


	if (dataLen < sizeof(uint32_t)) {
		status = StatusBufferLength;
	}

	if (Status_IsOk(status)) {
		// Store pointers
		timeStampPtr = timeStampField;
		dataPtr = (uint32_t *)dataField;
		
		// Get timestamp
		*timeStampPtr = SysState_GetWakeTime();
		
		active = true;
	}

	return returnStatus(status, eSucIoctlStatus);
}

status_t WakeSummary_Update(void)
{
	status_t status = StatusOk;

	// Do nothing

	return returnStatus(status, eSucIoctlStatus);
}

status_t WakeSummary_End(void)
{
	status_t status = StatusOk;

	if (active && timeStampPtr) {
		rtcDataHandler_t currentTime;
		status = RTC_ReadTime(&currentTime);
		if (Status_IsOk(status)) {
			*dataPtr = RTC_GetUnixTime(&currentTime) - *timeStampPtr; // write wake time
		} else {
			*dataPtr = 0;
		}
	}

	active = false;

	return returnStatus(status, eSucIoctlStatus);
}


/// SAEC Kinetic Vision, Inc. ----------- END OF FILE
