/**
  @file       UsbSerial.c

  @copyright  (C) 2019 Kinetic Vision, Cincinnati Ohio.
               This software is property of SAEC Kinetic Vision, Inc
               and is considered confidential.

  @brief      USB Serial software unit "C" file.

  @author     Parker Kamer

  @ingroup    UsbSerialSu

  Configuration History
  =====================

  Config Item    | Value
  -------------- | -----
  Config #       | NA
  Revision       | NA
  Revised, Date  | NA
  QA, Date       | NA
  Approved, Date | NA
  Released, Date | NA

  Significant Modification History (Most recent at top)
  =====================================================

  Date         | Initials | Details
  ------------ | -------- | -------
  20 Nov 2019  | PK       | Original

  Theory of Operation
  ===================
  TBD

*/

// Includes ------------------------------------------------------------------

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <math.h>

#include "stm32l4xx_hal.h"
#include "usbd_cdc_if.h"
#include "../StatusSu/Status.h"
#include "../Bno055Su/bno055.h"
#include "../RtcSu/Rtc.h"
#include "../AdcSu/adc.h"
#include "../GpioSu/gpio.h"
#include "../DataAggregatorSu/DataAggregator.h"
#include "UsbSerial.h"
#include "../UtilitySu/Utility.h"

// Private function prototypes -----------------------------------------------

// Private macros ------------------------------------------------------------

// Private constants ---------------------------------------------------------

// Private types -------------------------------------------------------------

// Private constants ---------------------------------------------------------

// Private variables ---------------------------------------------------------
static char SerialBuff[500];

// Private function bodies ---------------------------------------------------

// Public functions bodies ---------------------------------------------------

status_t Serial_HandleInput(void)
{
	status_t status = StatusOk;



	return status;
}

status_t Serial_HandleOutput(rtcDataHandler_t * rtcData, imuDataHandler_t * imuData)
{
	status_t status = StatusOk;

	uint16_t stringSize;

	//Format Data
	stringSize = sprintf(SerialBuff, "Operational Mode: Setup\r\n");
	//while(USBD_BUSY == CDC_Transmit_FS(SerialBuff, stringSize));

	stringSize += sprintf(SerialBuff+stringSize, "Protected Sleep: 0\r\n");
	//while(USBD_BUSY == CDC_Transmit_FS(SerialBuff, stringSize));

	stringSize += sprintf(SerialBuff+stringSize, "Flash page: 0\r\n");
	//while(USBD_BUSY == CDC_Transmit_FS(SerialBuff, stringSize));

	stringSize += sprintf(SerialBuff+stringSize, "RTC: %02i/%02i/%02i %02i:%02i:%02i.%03lu\r\n",
			rtcData->rtcDateData.months, rtcData->rtcDateData.days, rtcData->rtcDateData.years,
			rtcData->rtcTimeData.hours, rtcData->rtcTimeData.minutes, rtcData->rtcTimeData.seconds,
			rtcData->rtcTimeData.milliseconds);
	//while(USBD_BUSY == CDC_Transmit_FS(SerialBuff, stringSize));

	stringSize += sprintf(SerialBuff+stringSize, "VAnalog_1 = 0.00000\r\n");
	//while(USBD_BUSY == CDC_Transmit_FS(SerialBuff, stringSize));
	stringSize += sprintf(SerialBuff+stringSize, "VAnalog_2 = 0.00000\r\n");
	//while(USBD_BUSY == CDC_Transmit_FS(SerialBuff, stringSize));
	stringSize += sprintf( SerialBuff+stringSize, "VAnalog_3 = 0.00000\r\n");
	//while(USBD_BUSY == CDC_Transmit_FS(SerialBuff, stringSize));
	stringSize += sprintf( SerialBuff+stringSize, "VAnalog_4 = 0.00000\r\n");
	//while(USBD_BUSY == CDC_Transmit_FS(SerialBuff, stringSize));

	//Handle Peripheral Data

	//Handle Imu Data
	//Temperature
	stringSize += sprintf(SerialBuff+stringSize, "Temp = 0.00 deg C\r\n");
	//while(USBD_BUSY == CDC_Transmit_FS(SerialBuff, stringSize));

	//Accel
	stringSize += sprintf(SerialBuff+stringSize, "ax = ");
	stringSize += Utility_FtoaBase10(imuData->accData[0], SerialBuff+stringSize, fPrecision_3);
	stringSize += sprintf( SerialBuff+stringSize, " ay = ");
	stringSize += Utility_FtoaBase10(imuData->accData[1], SerialBuff+stringSize, fPrecision_3);
	stringSize += sprintf( SerialBuff+stringSize, " az = ");
	stringSize += Utility_FtoaBase10(imuData->accData[2], SerialBuff+stringSize, fPrecision_3);
	stringSize += sprintf( SerialBuff+stringSize, " mg\r\n");
	//while(USBD_BUSY == CDC_Transmit_FS(SerialBuff, stringSize));

	//Gyro
	stringSize += sprintf( SerialBuff+stringSize, "gx = ");
	stringSize += Utility_FtoaBase10(imuData->gyrData[0], SerialBuff+stringSize, fPrecision_3);
	stringSize += sprintf( SerialBuff+stringSize, " gy = ");
	stringSize += Utility_FtoaBase10(imuData->gyrData[1], SerialBuff+stringSize, fPrecision_3);
	stringSize += sprintf( SerialBuff+stringSize, " gz = ");
	stringSize += Utility_FtoaBase10(imuData->gyrData[2], SerialBuff+stringSize, fPrecision_3);
	stringSize += sprintf( SerialBuff+stringSize, " deg/s\r\n");
	//while(USBD_BUSY == CDC_Transmit_FS(SerialBuff, stringSize));

	//Compass
	stringSize += sprintf( SerialBuff+stringSize, "mx = ");
	stringSize += Utility_FtoaBase10(imuData->magData[0], SerialBuff+stringSize, fPrecision_3);
	stringSize += sprintf( SerialBuff+stringSize, " my = ");
	stringSize += Utility_FtoaBase10(imuData->magData[1], SerialBuff+stringSize, fPrecision_3);
	stringSize += sprintf( SerialBuff+stringSize, " mz = ");
	stringSize += Utility_FtoaBase10(imuData->magData[2], SerialBuff+stringSize, fPrecision_3);
	stringSize += sprintf( SerialBuff+stringSize, " uT\r\n");
	//while(USBD_BUSY == CDC_Transmit_FS(SerialBuff, stringSize));

	//Quat
	stringSize += sprintf( SerialBuff+stringSize, "q0 = ");
	stringSize += Utility_FtoaBase10(imuData->quatData[0], SerialBuff+stringSize, fPrecision_3);
	stringSize += sprintf( SerialBuff+stringSize, " qx = ");
	stringSize += Utility_FtoaBase10(imuData->quatData[1], SerialBuff+stringSize, fPrecision_3);
	stringSize += sprintf( SerialBuff+stringSize, " qy = ");
	stringSize += Utility_FtoaBase10(imuData->quatData[2], SerialBuff+stringSize, fPrecision_3);
	stringSize += sprintf( SerialBuff+stringSize, " qz = ");
	stringSize += Utility_FtoaBase10(imuData->quatData[3], SerialBuff+stringSize, fPrecision_3);
	stringSize += sprintf( SerialBuff+stringSize, "\r\n");
	//while(USBD_BUSY == CDC_Transmit_FS(SerialBuff, stringSize));

	//Euler

	stringSize += sprintf( SerialBuff+stringSize, "Yaw, Pitch, Roll: ");
	stringSize += Utility_FtoaBase10(imuData->eulerData[0], SerialBuff+stringSize, fPrecision_3);
	SerialBuff[stringSize++] = 44;
	SerialBuff[stringSize++] = 32;
	stringSize += Utility_FtoaBase10(imuData->eulerData[2], SerialBuff+stringSize, fPrecision_3);
	SerialBuff[stringSize++] = 44;
	SerialBuff[stringSize++] = 32;
	stringSize += Utility_FtoaBase10(imuData->eulerData[1], SerialBuff+stringSize, fPrecision_3);
	stringSize += sprintf( SerialBuff+stringSize, "\r\n");
	//while(USBD_BUSY == CDC_Transmit_FS(SerialBuff, stringSize));

	//Fusion Rate
	stringSize += sprintf( SerialBuff+stringSize, "Fusion rate = 100 Hz\r\n");
	//while(USBD_BUSY == CDC_Transmit_FS(SerialBuff, stringSize));

	stringSize += sprintf( SerialBuff+stringSize, "\r\n");
	//while(USBD_BUSY == CDC_Transmit_FS(SerialBuff, stringSize));

	while(USBD_BUSY == CDC_Transmit_FS(SerialBuff, stringSize));

	return status;
}

/// SAEC Kinetic Vision, Inc. ----------- END OF FILE


