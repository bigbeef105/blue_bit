/**
  @file       UsbSerial.h

  @copyright  (C) 2019 Kinetic Vision, Cincinnati Ohio.
               This software is property of SAEC Kinetic Vision, Inc
               and is considered confidential.

  @brief      USB Serial software unit "H" file.

  @author     Parker Kamer

  @defgroup   UsbSerialSu Handles input/output data over the USB virtual com port

  Configuration History
  =====================

  Config Item    | Value
  -------------- | -----
  Config #       | NA
  Revision       | NA
  Revised, Date  | NA
  QA, Date       | NA
  Approved, Date | NA
  Released, Date | NA

  Significant Modification History (Most recent at top)
  =====================================================

  Date         | Initials | Details
  ------------ | -------- | -------
  20 Nov 2019  | PK       | Original

  Theory of Operation
  ===================
  This software unit handles all out going/incoming messages over
  the usb com port.

  */

// Define to prevent recursive inclusion -------------------------------------
#ifndef __SERIAL_H
#define __SERIAL_H

#include "../StatusSu/Status.h"
#include "../RtcSu/rtc.h"
#include "../Bno055Su/bno055.h"

// Exported macro ------------------------------------------------------------

// Exported types ------------------------------------------------------------

// Exported constants --------------------------------------------------------

// Exported objects ----------------------------------------------------------

// Exported functions --------------------------------------------------------
/// @brief Handles all incoming messages over the usb com port
/// @return StatusOk
status_t Serial_HandleInput(void);

/// @brief Handles all out going messages over the usb com port
/// @return StatusOk
status_t Serial_HandleOutput(rtcDataHandler_t * rtcData, imuDataHandler_t * imuData);

#endif // __SERIAL_H

/// SAEC Kinetic Vision, Inc. ----------- END OF FILE


