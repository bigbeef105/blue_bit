/**
 *****************************************************************************
 * @file     PwmHal.c
 * @brief    PWMHal
 * @author   Dominick Hatton
 * @defgroup PWMHal
 ******************************************************************************
 *
 * @copyright COPYRIGHT (c) 2019 SAEC Kinetic Vision, Inc.
 *            All Rights Reserved.
 *
 * This software is property of SAEC Kinetic Vision, Inc., Inc and is
 * confidential. Unauthorized use, publication, disclosure, possession,
 * or duplication exposes you to severe civil and/or criminal penalty.
 *
 ******************************************************************************
 *
 * Significant Modification History (Most Recent at top)
 *
 * Date        | Initials | Description
 * ----------- | -------- | -----------
 * 22 AUG 2019 | DLH      | Original
 *
 * Theory of Operation
 * -------------------
 * TBD
 *
 *
 *
 */

// Includes ------------------------------------------------------------------

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

#include "stm32l4xx_hal.h"
#include "../Middlewares/Third_Party/FatFs/src/ff.h"
#include "../StatusSu/Status.h"
#include "../ConsoleSu/Console.h"
#include "../GpioSu/Gpio.h"
#include "../TimerSu/timer.h"
#include "../PowerSu/power.h"
#include "../AdcSu/adc.h"
#include "../UserInterfaceSu/UserInterface.h"
#include "HX711.h"
#include "fatfs.h"

// Private constants ---------------------------------------------------------
#define DATA_SET 6
#define IGN_LOW_SAMPLE 1
#define IGN_HIGH_SAMPLE 1

#define DATA_READY_TIMEOUT_INIT     500
#define DATA_READY_TIMEOUT          0

#define CALLBACK_DELAY_US           100

// Private types -------------------------------------------------------------
typedef struct{
    GPIO_InitTypeDef sckPin;
    GPIO_TypeDef* sckPort;
    GPIO_InitTypeDef dOutPin;
    GPIO_TypeDef* dOutPort;
} hx711Pins_t;

typedef enum {
    HX711Gain_128,
    HX711Gain_64,
    HX711Gain_32,

    HX711Gain_Count
}HX711Gain_t;

typedef enum{
	loadCellConnector,
	loadCellWeight,
	loadCellOffset,
	loadCellScale,

	NUM_LOAD_CELL_SETTINGS
}loadCellSettings_t;

typedef struct{
	char* pValue;
	loadCellSettings_t mode;
}loadCellValues_t;

static loadCellValues_t LoadCellArray[NUM_LOAD_CELL_SETTINGS] = {
	{
		.pValue = "Connector",
		.mode = loadCellConnector
	},
	{
		.pValue = "Weight",
		.mode = loadCellWeight
	},
	{
		.pValue = "Offset",
		.mode = loadCellOffset
	},
	{
		.pValue = "Scale",
		.mode = loadCellScale
	},
};

// Private variables ---------------------------------------------------------
static uint8_t _Gain;
static int32_t _Offset[NUM_CONNECTORS] = {0,0,0};
static int32_t _WeightedValue[NUM_CONNECTORS] = {0,0,0};
static float _Scale[NUM_CONNECTORS] = {1,1,1};
static uint32_t _Weight[NUM_CONNECTORS] = {1,1,1};

static hx711Pins_t hx711Pins[NUM_CONNECTORS] = {
        { {0}, NULL },
        { {0}, NULL },
        { {0}, NULL },
};

int32_t dataSampleSet[NUM_CONNECTORS][DATA_SET] = { { 0 } };
uint8_t sampleIndex[NUM_CONNECTORS] = { 0 };

static bool initialized = false;

// Private function prototypes -----------------------------------------------
static status_t readWithTare(connectors_t connector, int32_t* output, int32_t timeout);
static status_t convertUnits(connectors_t connector, int32_t input, float* output);
static status_t setGain(connectors_t connector, HX711Gain_t gain);
static status_t tare(connectors_t connector, uint32_t sampleCount);
static status_t convertAdcData(connectors_t connector, int32_t* output, int32_t timeout);
static int32_t smoothData(connectors_t connector);

static status_t readCalibFile(void);
static status_t writeCalibFile(void);

// Private function bodies ---------------------------------------------------
static status_t readWithTare(connectors_t connector, int32_t* output, int32_t timeout)
{
    status_t status = StatusOk;

    if(NULL == output){
        status = StatusNullParameter;
    }

    if(StatusOk == status){
        int32_t adcValue;
        status = convertAdcData(connector, &adcValue, timeout);

        if (StatusOk == status) {
            dataSampleSet[connector][sampleIndex[connector]] = adcValue;
            sampleIndex[connector]++;
            if(sampleIndex[connector] >= DATA_SET){
                sampleIndex[connector] = 0;
            }
        }
    }


    // If reading unsuccessful, just output previous data set
    *output = smoothData(connector);
    *output -= _Offset[connector];

    return status;
}

static status_t convertUnits(connectors_t connector, int32_t input, float* output)
{
    status_t status = StatusOk;

    if(NULL == output){
        status = StatusNullParameter;
    }

    if(StatusOk == status){
        *output = (float)input / _Scale[connector];
    }

    return status;
}

static status_t setGain(connectors_t connector, HX711Gain_t gain) {
    status_t status = StatusOk;

    switch (gain) {
        case HX711Gain_128:
            _Gain = 1;
            break;
        case HX711Gain_64:
            _Gain = 3;
            break;
        case HX711Gain_32:
            _Gain = 2;
            break;
        default:
            status = StatusCommandNotFound;
            break;
    }

    if(StatusOk == status){
        int32_t adcValue;
        for(int i = 0; i < DATA_SET; i++){
            status = convertAdcData(connector, &adcValue, DATA_READY_TIMEOUT_INIT);
            dataSampleSet[connector][sampleIndex[connector]] = adcValue;
            sampleIndex[connector]++;
            if(sampleIndex[connector] >= DATA_SET){
                sampleIndex[connector] = 0;
            }
        }
    }

    return status;
}

static status_t tare(connectors_t connector, uint32_t sampleCount)
{
	status_t status = StatusOk;
	int32_t data = 0;
	int32_t sum = 0;

	if(StatusOk == status){
		for(int i = 0; i < sampleCount;i++){
			status = convertAdcData(connector, &data, DATA_READY_TIMEOUT_INIT);
			sum += data;
		}
	}

	if(StatusOk == status){
		_Offset[connector] = abs(sum) / sampleCount;

		//If sum is negative
		if(sum < 0){
			_Offset[connector] *= -1;
		}
	}

	return status;
}

//Timeout is in milliseconds (ms)
static status_t waitReady(connectors_t connector, uint32_t timeout) {
	uint8_t dPin = 1;
	uint32_t Tickstart = HAL_GetTick();
	
	if (timeout == 0) {
	    if (!HAL_GPIO_ReadPin(hx711Pins[connector].dOutPort, hx711Pins[connector].dOutPin.Pin)) {
	        return StatusOk;
	    } else {
	        return StatusHx711Timeout;
	    }
	}

	while(dPin) {
		dPin = HAL_GPIO_ReadPin(hx711Pins[connector].dOutPort, hx711Pins[connector].dOutPin.Pin);
		//Include Timeout
		 if (((HAL_GetTick() - Tickstart) > timeout) || (timeout == 0U)){
			 return StatusHx711Timeout;
		 }
	}
	
	return StatusOk;
}

static status_t convertAdcData(connectors_t connector, int32_t* output, int32_t timeout) {
	status_t status = StatusOk;

	if(NULL == output){
		status = StatusNullParameter;
	}


	uint32_t value = 0;
	int i;

	if(StatusOk == status){
		status = waitReady(connector, timeout);
	}

	if(StatusOk == status){
		//disable interrupts, other than sys tick (slow-down in the clock line makes the hx711 mad)
		__set_BASEPRI(1 << 4);

		for(i = 0; i < 24; i++) {//reads data
			HAL_GPIO_WritePin(hx711Pins[connector].sckPort, hx711Pins[connector].sckPin.Pin, GPIO_PIN_SET);//clk High

			//delay 1us
			Timer_MicroSecDelay(1);

			if(HAL_GPIO_ReadPin(hx711Pins[connector].dOutPort, hx711Pins[connector].dOutPin.Pin)) value++;// read Data pin
			value = value << 1;

			//delay 1us
			Timer_MicroSecDelay(1);

			HAL_GPIO_WritePin(hx711Pins[connector].sckPort, hx711Pins[connector].sckPin.Pin, GPIO_PIN_RESET);// clk low
		}

		for(i = 0; i < _Gain; i++) {//sets Gain for next reading
			HAL_GPIO_WritePin(hx711Pins[connector].sckPort, hx711Pins[connector].sckPin.Pin, GPIO_PIN_SET);

			//delay 1us
			Timer_MicroSecDelay(1);

			HAL_GPIO_WritePin(hx711Pins[connector].sckPort, hx711Pins[connector].sckPin.Pin, GPIO_PIN_RESET);
		}

		//Enable ints
		__set_BASEPRI(0);

		uint32_t temp = 0;
		if(value & 0x800000){
			temp = 0xFF000000;//checks if value is negative than converts signed 24bit value to signed 32 bit
		}

		*output = value | temp;
	}

	return status;
}

static int32_t smoothData(connectors_t connector){

	int32_t data = 0;
	int32_t L = dataSampleSet[connector][0];
	int32_t H = dataSampleSet[connector][0];

	for (uint8_t r = 0; r < DATA_SET; r++) {
		if (L > dataSampleSet[connector][r]){
			L = dataSampleSet[connector][r]; // find lowest value
		}
		if (H < dataSampleSet[connector][r]) {
			H = dataSampleSet[connector][r]; // find highest value
		}
		data += dataSampleSet[connector][r];
	}

	if(IGN_LOW_SAMPLE){
		data -= L; //remove lowest value
	}
	if(IGN_HIGH_SAMPLE){
		data -= H; //remove highest value
	}

	return data / (DATA_SET - IGN_LOW_SAMPLE - IGN_HIGH_SAMPLE);
}

static status_t readCalibFile(void)
{
	status_t status = StatusOk;
	char buff[50];
	uint8_t buffIndex=0;
	connectors_t connector;
	FRESULT res;
	static bool fileRead = false;
	FATFS* USBDISKFatFs;
	FIL* calibFile;

	USBDISKFatFs = FATFS_GetFileSystem();
	calibFile = FATFS_GetConfigFile();

	status = StatusOk;
	if(!fileRead){

		res = f_mount(USBDISKFatFs, "", 1);
		if(FR_OK != res){
			status = StatusFatFsMount;
		}

		if (StatusOk == status) {
			res = f_stat("loadcell.txt", NULL);
			if (FR_OK != res) {
				status = StatusFatFsOpen;
			}
		}

		if (StatusOk == status) {
			res = f_open(calibFile, "loadcell.txt", FA_OPEN_EXISTING | FA_READ);
			if (FR_OK != res) {
				status = StatusFatFsOpen;
			}
		}

		while(StatusOk == status){
			if( NULL != f_gets(buff ,sizeof(buff), calibFile))
			{
				for( int j = 0; j < NUM_LOAD_CELL_SETTINGS; j++)
				{
					if(0 == strncmp(buff, LoadCellArray[j].pValue, strlen( LoadCellArray[j].pValue)))
					{
						for(buffIndex = 0; buffIndex < sizeof(buff); buffIndex++){
							if( buff[buffIndex] == '='){
								buffIndex++;
								switch( LoadCellArray[j].mode){
									case loadCellConnector:
									    status = GPIO_GetConnectorFromName(buff + buffIndex, 
                                                    sizeof(buff) - buffIndex, &connector);
										break;
									case loadCellWeight:
										_Weight[connector] = atoi(buff+buffIndex);
										break;
									case loadCellOffset:
										_Offset[connector] = atoi(buff+buffIndex);
										break;
									case loadCellScale:
										_Scale[connector] = atoi(buff+buffIndex) / (float)_Weight[connector];
										break;
									default:
										break;
								}
								break;
							}
						}
						//break;
					}
				}
			}
			else{
				break;
			}
		}

		f_close(calibFile);
		f_mount(0, "", 1);
		fileRead = true;
	}

	return status;
}

static status_t writeCalibFile(void)
{
	status_t status = StatusOk;
	FRESULT res;
	char buff[50];
	FATFS* USBDISKFatFs;
	FIL* calibFile;

	USBDISKFatFs = FATFS_GetFileSystem();
	calibFile = FATFS_GetConfigFile();

	res = f_mount(USBDISKFatFs, "", 1);
	if(FR_OK != res){
		status = StatusFatFsMount;
	}

	if(StatusOk == status){
		//Remove the previous file
		//res = f_unlink("loadcell.txt");

		//Create a new file
		res = f_open(calibFile, "loadcell.txt", FA_OPEN_ALWAYS | FA_WRITE);
		if (FR_OK != res) {
			status = StatusFatFsOpen;
		}
		else {
			//for loop of load cells present on config file
			for (int i = 0; i < hbound1(hx711Pins); i++){
				if(hx711Pins[i].sckPort != NULL && hx711Pins[i].dOutPort != NULL)
				{
				    uint8_t connectorName[2];
				    GPIO_GetNameFromConnector((connectors_t)i, connectorName, sizeof(connectorName));
                    sprintf(buff,"Connector=%s \r\n",connectorName);

					int bytesWritten;
					bytesWritten = f_puts(buff, calibFile);

					if (bytesWritten > 0) {
						sprintf(buff,"Weight=%lu \r\n",_Weight[i]);
						bytesWritten  = f_puts(buff, calibFile);

						if (bytesWritten > 0) {
							sprintf(buff,"Offset=%li \r\n",_Offset[i]);
							bytesWritten = f_puts(buff, calibFile);

							if (bytesWritten > 0) {
								sprintf(buff,"Scale=%li \r\n",_WeightedValue[i]);//(uint32_t)_Scale[i]);
								bytesWritten  = f_puts(buff, calibFile);
							}
						}
					}
					if (bytesWritten <= 0) {
						status = StatusFatFsWrite;
						break;
					}
				}
			}
			// Unconditionally close the open file
			res = f_close(calibFile);
		}
	}

	res = f_mount(0, "", 1);
	if(FR_OK != res){
		status = StatusFatFsMount;
	}

	return status;
}

// Public functions bodies ---------------------------------------------------

///
/// Init the software unit
///
status_t HX711_Init(connectors_t connector) 
{
	status_t status = StatusOk;

	// Save pin configs, initialize pins
	hx711Pins[connector].dOutPin.Pin = GPIO_GetConnectorAnalogPin(connector);
	hx711Pins[connector].dOutPin.Mode = GPIO_MODE_INPUT;
	hx711Pins[connector].dOutPin.Pull = GPIO_NOPULL;
	hx711Pins[connector].dOutPin.Speed = GPIO_SPEED_FREQ_LOW;
	hx711Pins[connector].dOutPort = GPIO_GetConnectorAnalogPort(connector);
	HAL_GPIO_DeInit(hx711Pins[connector].dOutPort,hx711Pins[connector].dOutPin.Pin);
	HAL_GPIO_Init(hx711Pins[connector].dOutPort, &hx711Pins[connector].dOutPin);

	hx711Pins[connector].sckPin.Pin = GPIO_GetConnectorGPIOPin(connector);
	hx711Pins[connector].sckPin.Mode = GPIO_MODE_OUTPUT_PP;
	hx711Pins[connector].sckPin.Pull = GPIO_NOPULL;
	hx711Pins[connector].dOutPin.Speed = GPIO_SPEED_FREQ_LOW;
	hx711Pins[connector].sckPort = GPIO_GetConnectorGPIOPort(connector);
    HAL_GPIO_DeInit(hx711Pins[connector].sckPort,hx711Pins[connector].sckPin.Pin);
	HAL_GPIO_Init(hx711Pins[connector].sckPort, &hx711Pins[connector].sckPin);
	HAL_GPIO_WritePin(hx711Pins[connector].sckPort, hx711Pins[connector].sckPin.Pin, GPIO_PIN_RESET);

	status = setGain(connector, HX711Gain_64);
	if(StatusOk == status){
		if(!initialized)
		{
#ifndef SWO_PROFILE_BUILD
			readCalibFile();
#endif // SWO_PROFILE_BUILD
			initialized = true;
		}
	}

	return status;
}

status_t HX711_ReadData(connectors_t connector, connectorDataHandler_t * dataOut)
{
    float output = 0.0f;
    int32_t rawWithTare = 0;
    status_t status = readWithTare(connector, &rawWithTare, DATA_READY_TIMEOUT);
    if (StatusHx711Timeout == status) {
        status = StatusOk; // clear this status, as its expected due to sample rate mismatch
    }
    
    if (StatusOk == status) {
        status = convertUnits(connector, rawWithTare, &output);
    }
    dataOut->data[0].float32 = output;
    return status;
}

status_t HX711_PowerOff(connectors_t connector) {
	status_t status = StatusOk;

	if(StatusOk == status){
		HAL_GPIO_WritePin(hx711Pins[connector].sckPort, hx711Pins[connector].sckPin.Pin, GPIO_PIN_RESET);
		HAL_GPIO_WritePin(hx711Pins[connector].sckPort, hx711Pins[connector].sckPin.Pin, GPIO_PIN_SET);
		HAL_Delay(1);
	}

	return status;
}

status_t HX711_PowerOn(connectors_t connector) {
	status_t status = StatusOk;

	if(StatusOk == status){
		HAL_GPIO_WritePin(hx711Pins[connector].sckPort, hx711Pins[connector].sckPin.Pin, GPIO_PIN_RESET);
	}

	return status;
}

status_t HX711_CalibrateMode(void)
{
	status_t status = StatusOk;
	int32_t value = 0;

	if(initialized){
		for(int i = 0; i < 4; i++){
			if(hx711Pins[i].sckPort != NULL && hx711Pins[i].dOutPort != NULL)
			{
				// Wait for button
				UserInterface_WaitForButton();
				
				// Tare Load Cell
				status = tare(i, 10);
				if(StatusOk != status){
					break;
				}

				// Blink LED
				status = Status_Preserve(status, UserInterface_BlinkLed(ledPatternCalibrateStep));
				// Wait for button
				UserInterface_WaitForButton();

				// Calibrate Load Cell
				for(int j = 0; j < 10; j++){
					status = Status_Preserve(status, readWithTare(i, &value, DATA_READY_TIMEOUT_INIT));
					if(StatusOk != status){
						break;
					}
				}
				if(StatusOk != status){
					break;
				}

				_WeightedValue[i] = value;
				/*status = setScale(i, (float)value); //Todo: This value need to go into the calib file but is not the actual scale value
				if(StatusOk != status){
					break;
				}*/

				// Blink LED
				status = Status_Preserve(status, UserInterface_BlinkLed(ledPatternCalibrateStep));
			}
		}
		status = Status_Preserve(status, writeCalibFile());
	}
	
	return status;
}
/// SAEC Kinetic Vision, Inc  ----------- END OF FILE
