/**
  @file       HX711.h

  @copyright  (C) 2019 Kinetic Vision, Cincinnati Ohio.
               This software is property of SAEC Kinetic Vision, Inc
               and is considered confidential.

  @brief      HX711 software unit "H" file.

  @author     Dominick Hatton, Parker Kamer

  @defgroup   Hx711Su Analog to digital converter

  Configuration History
  =====================

  Config Item    | Value
  -------------- | -----
  Config #       | NA
  Revision       | NA
  Revised, Date  | NA
  QA, Date       | NA
  Approved, Date | NA
  Released, Date | NA

  Significant Modification History (Most recent at top)
  =====================================================

  Date         | Initials | Details
  ------------ | -------- | -------
  20 Sep 2019  | PK	  	  | Migrated to resbit
  22 Aug 2019  | DLH      | Original

  Theory of Operation
  ===================
  The hx711 will be used to gather analog data from a bridge sensor to calculate weight

  */

// Define to prevent recursive inclusion -------------------------------------
#ifndef __HX711_H_
#define __HX711_H_

#include "../GpioSu/gpio.h"
#include "../DataAggregatorSu/DataAggregator.h"

// Exported types ------------------------------------------------------------

// Exported constants --------------------------------------------------------

// Exported macro ------------------------------------------------------------

// Exported objects ----------------------------------------------------------

// Exported functions --------------------------------------------------------

/// @brief Initializes an hx711 device
/// @param args[in] connector - connector associated with the HX711
/// @returns StatusOk, StatusCommandNotFound, StatusParameter1, StatusNullParameter,
/// 		 StatusHx711Timeout, StatusFatFsMount, StatusFatFsOpen
status_t HX711_Init(connectors_t connector);

/// @brief Reads and scales data from the HX711, writes into dataOut
status_t HX711_ReadData(connectors_t connector, connectorDataHandler_t * dataOut);

/// @brief Turn on the hx711
/// @param args[in] connector - Id number of the connector
/// @return StatusOk
status_t HX711_PowerOn(connectors_t connector);

/// @brief Turn off the hx711
/// @param args[in] connector - Id number of the connector
/// @return StatusOk
status_t HX711_PowerOff(connectors_t connector);

/// @brief calibrate the hx711
status_t HX711_CalibrateMode(void);

#endif // __HX711_H_

/// SAEC Kinetic Vision, Inc  ----------- END OF FILE
