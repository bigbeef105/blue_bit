/**
  @file       Console.h

  @copyright  (C) 2019 Kinetic Vision, Cincinnati Ohio.
               This software is property of SAEC Kinetic Vision, Inc
               and is considered confidential.

  @brief      Template software unit "H" file.

  @author     John Hancock

  @defgroup   ConsoleSoftwareUnit Console software unit, handles CLI commands
                                  and console display. Operationally, this
                                  is a rather conventional command line interface.


  Configuration History
  =====================

  Config Item    | Value
  -------------- | -----
  Config #       | NA
  Revision       | NA
  Revised, Date  | NA
  QA, Date       | NA
  Approved, Date | NA
  Released, Date | NA

  Significant Modification History (Most recent at top)
  =====================================================

  Date        | Initials | Details
  ----------- | -------- | -------
  05 Jun 2019 | SRC      | Import

  Theory of Operation
  -------------------
  Operationally, this is a rather conventional command line interface.
  CLI commands are exported by client software units (to the CLI) using
  the "console_ExportCommands( )" function.

  After initialization the client must "open" a uart. If the client wishes
  to cease using a uart, or change usart assingments, the the uart must be
  first "closed".

  */


// Define to prevent recursive inclusion -------------------------------------
#ifndef __CONSOLE_H
#define __CONSOLE_H

#include <stdint.h>
#include <stdbool.h>
#include "../StatusSu/Status.h"

// Exported macro ------------------------------------------------------------

// Exported types ------------------------------------------------------------

typedef const struct {
    uint8_t *pCommand;
    uint8_t *pUsage;
    status_t (*pHandlerFn)(uint16_t argc, uint8_t **argv);
} consoleCommand_t;

typedef struct cliRegistration_s {
    consoleCommand_t const *pList;
    struct cliRegistration_s *pNext;
} consoleRegistration_t;

typedef enum {

	// The UART is not open
	eClosedUart = 0,

	// Valid UART(s)
	eCpuUart1,
	eCpuUart2,
	eCpuUart3,
	eCpuUart4,
    eUsbCdcUart,


	// Tracks number of possible values of "consoleUart_t"
	eNumberOfUarts

} consoleUart_t;


// Exported constants --------------------------------------------------------

// Exported objects ----------------------------------------------------------

// Exported functions --------------------------------------------------------

status_t Console_WriteString (void *string);
status_t Console_ExportCommandsToCli (consoleRegistration_t *pReg, consoleCommand_t *pCommandList);
status_t Console_Open (void);
status_t Console_Tick (void);
status_t Console_Close (void);
status_t Console_Init (void);
status_t Console_DeInit(void);
status_t Console_Enable(bool enable);

#endif // __CONSOLE_H

/// SAEC Kinetic Vision, Inc. ----------- END OF FILE

