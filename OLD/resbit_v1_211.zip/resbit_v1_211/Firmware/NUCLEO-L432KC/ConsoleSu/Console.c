/**
 ******************************************************************************
 * @file    Console.c
 * @brief   Console 
 * @author  Sherman Couch
 * @ingroup ConsoleSoftwareUnit
 ******************************************************************************
 *
 * @copyright COPYRIGHT (c) 2019 SAEC Kinetic Vision, Inc 
 *            All Rights Reserved
 *
 * This software is property of SAEC Kinetic Vision, Inc and is considered
 * confidential.
 *
 ******************************************************************************
 *
 * Significant Modification History (Most Recent at top)
 * -----------------------------------------------------
 *
 * Date        | Initials | Description
 * ----------- | -------- | -----------
 * 05 Jun 2019 | SC       | Import
 *
 * Theory of Operation
 * -------------------
 * The console thread is a thin layer above:
 *      - UART data operations, and
 *      - command processing.
 *
 *
 */

// Includes ------------------------------------------------------------------

#include <stddef.h>
#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>
#include <string.h>
#include <stdarg.h>

// HAL level includes
#include "stm32l4xx_hal.h"

// Software unit includes
#include "../StatusSu/Status.h"
#include "../UsartSu/usart.h"
#include "../SwUnitControlSu/SwUnitControl.h"
#include "Console.h"

// Private function prototypes -----------------------------------------------

// Private macros ------------------------------------------------------------

/// This macro feeds status information for tracking purposes to software unit control.
#define returnStatus(__status__,__source__) SwUnitControl_WriteStatus(eSucConsoleSu,__source__,__status__,__LINE__);

// This is a key define for the status handling
#define _status_tHIS_SU HmiSu_Console


#define MAX_ARGS 10
#define HBOUND(_array_) (sizeof(_array_)/sizeof(_array_[0]))

#define ASCII_CR '\r'
#define ASCII_LF '\n'
#define ASCII_TAB '\t'
#define ASCII_BS 8
#define ASCII_DEL 0x7f
#define ASCII_WHITE_SPACE(_c_) ((_c_==' ')||(_c_=='\t')||(_c_=='\r')||(_c_=='\n'))

#define ASCII_NEW_LINE_STR "\x0d\x0a"

// For use with osThreadFlagsXXX RTOS2 functions
#define RX_CHAR_FLAG 1

// Private constants ---------------------------------------------------------
static const char szPrompt[] = ASCII_NEW_LINE_STR "> ";


// Private types -------------------------------------------------------------

// Private function prototypes -----------------------------------------------
static status_t helpCommand(uint16_t argc, uint8_t **argv);
static status_t versionCommand(uint16_t argc, uint8_t **argv);
static status_t resetCommand(uint16_t argc, uint8_t **argv);
static status_t parseIntoArcArv(void);
static status_t executeCmdFromArgcArgv(int16_t argc, uint8_t *argv[]);

// Private constants ---------------------------------------------------------

static const consoleCommand_t commandList[] = {
    { "version", "usage: version", versionCommand },
    { "help", "usage: help partial-name", helpCommand },
	{ "reset", "usage: reset", resetCommand },
    { NULL, NULL, NULL },
};

// Private types -------------------------------------------------------------

// Private variables ---------------------------------------------------------

static volatile bool initialized = false;
static bool enabled = false;
static volatile consoleRegistration_t consoleRegistrationRoot = {
    (consoleCommand_t *) commandList, // .pList =
    NULL, // .pNext =
};
static volatile uint16_t RxBufferIdx = 0;
static volatile uint8_t RxBuffer[100];
static volatile uint8_t *argv[MAX_ARGS];
static volatile int16_t argc;

// Private function bodies ---------------------------------------------------


static status_t write (void *pString, uint16_t length)
{

	status_t status;

	status = Usart_Write(pString, length);

	return status;
}

static status_t writeString(void *pString)
{
	uint16_t length;
	status_t status;

	length = strlen(pString);

	status = write(pString, length);

	return status;
}

static status_t processRxInConsoleMode(void)
{
    uint16_t sizeRead;
    uint8_t c;
    
    status_t status;
    
    status = StatusOk;
    
    // Read from the console usart and buffer each byte one at a time.  Look
    // for ASCII <CR> while processing

    do {
        status = Usart_Read(&c, 1, &sizeRead);

        if (StatusOk != status) {
        	break;
        }

        if (0 == sizeRead) {
            break;
        }

        // Process carriage return
        if (ASCII_CR == c) {
            RxBuffer[RxBufferIdx] = 0;
            status = StatusCarriageReturn;
            break;
        }
        
        // Backspace?
        else if ( (ASCII_BS == c) || (ASCII_DEL == c) ) {
            
            if (RxBufferIdx) {
                writeString("\x08 \x08");
                RxBufferIdx--;
                RxBuffer[RxBufferIdx] = 0;
                RxBuffer[RxBufferIdx+1] = 0;
            }
        }

        // else, store RX character
        else if (RxBufferIdx+1 < sizeof(RxBuffer)) {
            
            // Echo to console
            write(&c, 1);
            
            // Store character, put null terminator after char
            RxBuffer[RxBufferIdx++] = c;
            RxBuffer[RxBufferIdx] = 0;
        }

    } while (sizeRead);
    
    return status;
    
} // processRxInConsoleMode


static status_t parseIntoArcArv(void)
{
    uint16_t i;

    // Default all "argv" parameters to be a null string
    for (i = 0; i < HBOUND(argv); i++) {
        argv[i] = 0;
    }

    // Parse RxBuffer
    argc = 0;
    for (i = 0; i < RxBufferIdx; i++) {

        // Remove leading white space
        if (ASCII_WHITE_SPACE(RxBuffer[i])) {
            continue;
        }

        // Protect array "pArg"
        if (argc >= HBOUND(argv)) {
            break;
        }

        // Prepare argument pointer
        argv[argc++] = &RxBuffer[i++];

        // Scan forward in "RxBuffer" looking for end of parameter
        for (; i < RxBufferIdx; i++) {

            // Keep processing this parameter until white space
            if (!ASCII_WHITE_SPACE(RxBuffer[i])) {
                continue;
            }

            // Null terminate this parameter by replacing the white space with a null terminator
            RxBuffer[i] = 0;

            // This parameter is setup, continue with the next one
            break;
        }
    }

    return StatusOk;

} // parseIntoArcArv

static status_t helpCommand(uint16_t argc, uint8_t **argv)
{
    status_t status;
    consoleRegistration_t *pReg;

	// Pass through the list of registered commands
    status = StatusOk;
	pReg = (void *) &consoleRegistrationRoot;
	while (pReg) {

		// Pass through the current command list
		consoleCommand_t *pList;
		pList = pReg->pList;

		while (pList && (pList->pUsage)) {

			// Print usage on console
			uint16_t partialCmdLength;
			partialCmdLength = strlen((char *) argv[1]);
			if ((argc <= 1) || (0 == strncmp((char *) pList->pCommand, (char *) argv[1], (size_t) partialCmdLength))) {

				status = writeString(pList->pCommand);
				if (StatusOk != status) {
					break;
				}

				writeString("\t");
				writeString(pList->pUsage);
				// writeString(ASCII_NEW_LINE_STR);
				writeString(ASCII_NEW_LINE_STR "===============================================" ASCII_NEW_LINE_STR);
			}

			// Continue with the next element in the command list
			pList++;

		} // while ...

		if (StatusOk != status) {
			break;
		}

		pReg = pReg->pNext;

	} // while...


    return status;

} // help

static status_t resetCommand(uint16_t argc, uint8_t **argv)
{
	// The adroit Cortex M engineer will recognize this as a CPU reset.
	while (1) {
		SCB->AIRCR = 0x05FA0004;
	}

	// We should never reach this point
	return StatusCodePath;

} // resetCommand



static status_t versionCommand(uint16_t argc, uint8_t **argv)
{
    status_t status;

	// Pass through the list of registered commands
    status = StatusOk;

	status = writeString("v0.12.17\r\n");

    return status;

} // versionCommand

static status_t executeCmdFromArgcArgv(int16_t argc, uint8_t *argv[])
{
    consoleCommand_t *pList;
    consoleRegistration_t *pReg;

    status_t status;

    // If a command was specified, this assumes the command has not been found.  Otherwise,
	// no command was specified, assume status will be OK.
	if (argc) {
		status = StatusCommandNotFound;

		// Start the external command handler on a new line
		Console_WriteString("\r\n");
	} else {
		status = StatusOk;
	}

    // Pass through the list of registered command list, looking to handle the
    // command indicated in argv[0]
    pReg = (void *) &consoleRegistrationRoot;
    while (pReg) {

        // Pass through the current command list, looking for the command in argv[0]
        // consoleCommand_t *pList;
        pList = pReg->pList;
        while (pList && (pList->pCommand)) {

            // Does the command in argv[0], match the current command in the list?
            if (0 == strcmp((char *) argv[0], (char *)pList->pCommand)) {

                // If there is an external handler function attached
                // to this external command string, then call that
                // external handler.
                if (NULL != pList->pHandlerFn) {

                    // status_t (*pHandlerFn)(uint16_t argc, uint8_t **argv);
                    // pHandlerFn = pList->p;

                    // Call the external command handler
                    status = (pList->pHandlerFn)(argc, argv);
                    
                    break;
                }
            }

            // Continue with the next element in the command list
            pList++;
        }
        pReg = pReg->pNext;

    }

    return status;

} // executeCmdFromArgcArgv

// Public functions bodies ---------------------------------------------------

status_t Console_ExportCommandsToCli (consoleRegistration_t *pExportedReg, consoleCommand_t *pCommandList)
{
    consoleRegistration_t *pReg;
    status_t status;

    // Initialize status return
    status = StatusOk;

    if (!initialized) {
        status = StatusNotInitialized;
    }

    // Pass through the list of registered commands, looking to insert
    if (StatusOk == status) {

		pReg = (void *) &consoleRegistrationRoot;
		while (pReg) {

			// Insert exported registration
			if (NULL == pReg->pNext) {
				pExportedReg->pList = pCommandList;
				pReg->pNext = pExportedReg;

				// Be sure the new next pointer is null
				pReg = pReg->pNext;
				pReg->pNext = NULL;

				// Note: "status" return is already initialized
				break;
			}

			// Exported registration already linked?
			if (pExportedReg == pReg->pNext) {
				status = StatusAlreadyLinked;
				break;
			}

			// Continue with next
			pReg = pReg->pNext;
		}
    }

    // We care about tracking this status, use macro to feed status to SW Unit control.
    return returnStatus(status, eSucReadStatus);

} // Console_ExportCommandsToCli


status_t Console_Tick(void)
{
	status_t status;

	status = StatusOk;

    if (StatusOk == status && initialized && enabled) {
		status = processRxInConsoleMode ();

		// Now execute command using argc / argv
		if (StatusCarriageReturn == status) {

			parseIntoArcArv();

			status = executeCmdFromArgcArgv(argc, (void *) argv);
			if (StatusOk != status) {
				char buff[80];
				sprintf(buff, "Status: %u", status);
				Console_WriteString(buff);
			}

			// Reset the callback variables
			RxBufferIdx = 0;

			// Show Console Prompt. Note remap of status variable.
			status = writeString((void *) szPrompt);
		}
    }

    // We care about tracking this status, use macro to feed status to SW Unit control.
    return returnStatus(status, eSucIoctlStatus);

} // Console_Tick

status_t Console_WriteString(void *pString)
{
	status_t status;

	status = StatusOk;
    if (!initialized) {
        status = StatusNotInitialized;
    }

    if ((StatusOk == status) && enabled) {
    	status = writeString(pString);
    }

    // We care about tracking this status, use macro to feed status to SW Unit control.
    return returnStatus(status, eSucWriteStatus);

} // Console_WriteString

status_t Console_Init(void)
{
    status_t status;
    status = StatusOk;

	// MX_USART1_UART_Init();

    if (initialized) {
        status = StatusAlreadyInitialized;
    }
    
    if (StatusOk == status) {
        consoleRegistrationRoot.pList = commandList;
        consoleRegistrationRoot.pNext = NULL;

        RxBufferIdx = 0;
    	initialized = true;
    	enabled = true; // enabled by default

        //Console_WriteString("(C) 2019 Procter and Gamble\r\n");

        uint8_t buff[80];
        sprintf((char *) buff, "Build: %s %s\r\n", __DATE__, __TIME__);
        //Console_WriteString(buff);

		//Console_WriteString((void *) szPrompt);
    }
  
    // We care about tracking this status, use macro to feed status to SW Unit control.
    return returnStatus(status, eSucInitStatus);

} // Console_Init

status_t Console_DeInit(void)
{
	initialized = false;
	
	return StatusOk;
}

status_t Console_Enable(bool enable)
{
	enabled = enable;
	
	return StatusOk;
}

/// SAEC Kinetic Vision, Inc  ----------- END OF FILE
