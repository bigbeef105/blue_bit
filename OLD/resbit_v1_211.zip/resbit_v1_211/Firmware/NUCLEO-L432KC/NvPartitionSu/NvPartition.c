#if 0
/**
  @file       NvPartition.c

  @copyright  (C) 2019 Kinetic Vision, Cincinnati Ohio.
               This software is property of SAEC Kinetic Vision, Inc
               and is considered confidential.

  @brief      Non Volatile Partition software unit "C" file.

  @author     Parker Kamer

  @ingroup    NvPartitionSu

  Configuration History
  =====================

  Config Item    | Value
  -------------- | -----
  Config #       | NA
  Revision       | NA
  Revised, Date  | NA
  QA, Date       | NA
  Approved, Date | NA
  Released, Date | NA

  Significant Modification History (Most recent at top)
  =====================================================

  Date         | Initials | Details
  ------------ | -------- | -------
  16 Aug 2019  | PK       | Original

  Theory of Operation
  ===================
  This software unit is a buffering layer between the config software unit and the
  memory block the will hold a copy of the config file:

						 |							      |
  	  ConfigSu <---------|         FatFS (Flash)          |<--- device.cfg
  	  	  ^				 |								  |
  	  	  |				 |								  |
  	  	  |				 |--------------------------------|
  	  	  v				 |								  |
  	  NvPartitionSu <--->| Non Volatile Partition (Flash) |
  	  	  	  	  	  	 |								  |

*/

// Includes ------------------------------------------------------------------

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

#include "stm32l4xx_hal.h"
#include "../StatusSu/Status.h"
#include "../ConsoleSu/Console.h"
#include "../SwUnitControlSu/SwUnitControl.h"
#include "../Tc58FlashUtilitiesSu/Tc58FlashUtilities.h"
#include "../Tc58FlashLogicalSu/Tc58FlashLogical.h"
#include "../Tc58FlashPhysicalSu/Tc58FlashPhysical.h"
#include "../Tc58FlashBufferSu/Tc58FlashBuffer.h"
#include "../Tc58FlashPhysicalSu/Tc58FlashIoControl.h"

#include "NvPartition.h"

// Private function prototypes -----------------------------------------------
static status_t cliNVPWriteCommand(uint16_t argc, uint8_t **argv);
static status_t cliNVPReadCommand(uint16_t argc, uint8_t **argv);

// Private macros ------------------------------------------------------------
/// This macro feeds status information for tracking purposes to software unit control.
#define returnStatus(__status__,__source__) SwUnitControl_WriteStatus(eSucNvPartitionSu,__source__,__status__,__LINE__);

// Private constants ---------------------------------------------------------
#define HEAD_ID 0xABCDEF
#define TAIL_ID	0xFEDCBA

// Private types -------------------------------------------------------------

// Private constants ---------------------------------------------------------

// Private variables ---------------------------------------------------------
static uint32_t lSectorsPerBlock;
static uint32_t lSectorsPerPage;

static const consoleCommand_t commandList[] = {
	{
		.pCommand = "nw",
		.pUsage = "usage: write a value to NVP",
		.pHandlerFn = cliNVPWriteCommand
	},
	{
		.pCommand = "nr",
		.pUsage = "usage: read a value from NVP",
		.pHandlerFn = cliNVPReadCommand
	},
	{
    	.pCommand = NULL,
		.pUsage = NULL,
		.pHandlerFn = NULL
    },
};

static consoleRegistration_t exportedReg;
static volatile bool initialized = false;

// Private function bodies ---------------------------------------------------
static status_t cliNVPWriteCommand(uint16_t argc, uint8_t **argv)
{
	status_t status = StatusOk;

	//Create settings
	nvConfigData_t configData={
		.headID = HEAD_ID,
		.opMode = 1,

		.imuEnable = 1,
		.adcEnable = 1,
		.gpioEnabled = 0,

		.frequency = 100,
		.wakeMode = 2,
		.sleepDelay = 10,
		.sleepDuration = 150,
		.tailID = TAIL_ID
	};

	//Write settings to NVP
	status = NvPartition_WriteNvp(&configData);

	return status;
}

static status_t cliNVPReadCommand(uint16_t argc, uint8_t **argv)
{
	status_t status = StatusOk;
    char buff[100];
	nvConfigData_t configData = {0};

	//Read settings from NVP
	status = NvPartition_ReadNvp(&configData);

	if(StatusOk == status){
		sprintf(buff, "opmode = %i \r\nimuEnable = %i \r\nadcEnable = %i \r\ngpioEnabled = %i \r\n",configData.opMode,configData.imuEnable,
																							   configData.adcEnable, configData.gpioEnabled);
		Console_WriteString(buff);
		sprintf(buff, "frequency = %i \r\nwakeMode = %i \r\nsleepDelay = %i \r\nsleepDuration = %i \r\n",configData.frequency,configData.wakeMode,
				   	   	   	   	   	   	   	   	   	   	   	   	   	   	   	   	   	   	   	   	   	  configData.sleepDelay, configData.sleepDuration);
		Console_WriteString(buff);
	}
	return status;
}

// Public functions bodies ---------------------------------------------------

status_t NvPartition_Init(void)
{
	status_t status = StatusOk;

	if (initialized) {
	    status = StatusAlreadyInitialized;
	}
	else{
		// Setup the sectors per block variable
		if (status == StatusOk) {
		   	status = Tc58Flash_DoIoControl(Tc58IoctlGetSectorsPerBlock, &lSectorsPerBlock);
		}

		// Setup the sectors per page variable
		if (status == StatusOk) {
		  	status = Tc58Flash_DoIoControl(Tc58IoctlGetSectorsPerPage, &lSectorsPerPage);
		}

	  	status = Console_ExportCommandsToCli (&exportedReg, commandList);
		initialized = true;
	}

	return returnStatus(status, eSucInitStatus);
}

status_t NvPartition_WriteNvp(nvConfigData_t* configData)
{
	status_t status = StatusOk;

	//verify the pointer is not NULL
	if(NULL == configData){
		status = StatusNullParameter;
	}

	//Check structure IDs
	if(StatusOk == status){
		if(HEAD_ID != configData->headID || TAIL_ID != configData->tailID){
			status = StatusConfigId;
		}
	}

	// Setup the address of the NV data
	Tc58RemapAddress_t nvPartitionAddr;
	if (StatusOk == status) {

		uint32_t nvBlockNumber;
		status = Tc58Flash_DoIoControl(Tc58IoctlGetNvPartitionBlock, &nvBlockNumber);
		if (StatusOk == status) {
			nvPartitionAddr.block = (uint16_t) nvBlockNumber;
			nvPartitionAddr.page = 0;
		}
	}

	// Write the data to the address of the NV data
	if (StatusOk == status) {
		uint8_t sectorBuff[512];

		// If there is enough buffer to write, then write data
		if (sizeof(*configData) <= sizeof(sectorBuff)) {
			memcpy(sectorBuff, configData, sizeof(*configData));
			status = Tc58Buffer_WriteOneSector(nvPartitionAddr, sectorBuff);
		} else {
			status = StatusBufferLength;
		}
	}

	return returnStatus(status, eSucWriteStatus);

} // NvPartition_WriteNvp

status_t NvPartition_ReadNvp(nvConfigData_t* configData)
{
	status_t status = StatusOk;

	//verify the pointer is not NULL
	if(NULL == configData){
		status = StatusNullParameter;
	}

	// Setup the address of the NV data
	Tc58RemapAddress_t nvPartitionAddr;
	if (StatusOk == status) {

		uint32_t nvBlockNumber;
		status = Tc58Flash_DoIoControl(Tc58IoctlGetNvPartitionBlock, &nvBlockNumber);
		if (StatusOk == status) {
			nvPartitionAddr.block = (uint16_t) nvBlockNumber;
			nvPartitionAddr.page = 0;
		}
	}

	// Read the data from the address of the NV data
	if (StatusOk == status) {

		uint8_t sectorBuff[512];
		if (sizeof(*configData) <= sizeof(sectorBuff)) {
			status = Tc58Buffer_ReadOneSector(nvPartitionAddr, sectorBuff);
		} else {
			status = StatusBufferLength;
		}

		if (StatusOk == status) {
			memcpy(configData, sectorBuff, sizeof(*configData));
		}
	}



	//Check structure IDs
	if(StatusOk == status){
		if(HEAD_ID != configData->headID || TAIL_ID != configData->tailID){
			status = StatusConfigId;
		}
	}

	return returnStatus(status, eSucReadStatus);
} // NvPartition_ReadNvp

/// SAEC Kinetic Vision, Inc. ----------- END OF FILE
#endif

