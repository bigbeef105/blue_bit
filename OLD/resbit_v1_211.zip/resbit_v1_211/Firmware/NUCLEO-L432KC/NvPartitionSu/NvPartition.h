/**
  @file       NvPartition.h

  @copyright  (C) 2019 Kinetic Vision, Cincinnati Ohio.
               This software is property of SAEC Kinetic Vision, Inc
               and is considered confidential.

  @brief      Non Volatile Partition software unit "H" file.

  @author     Parker Kamer

  @defgroup   NvPartitionSu Non volatile configuration storage

  Configuration History
  =====================

  Config Item    | Value
  -------------- | -----
  Config #       | NA
  Revision       | NA
  Revised, Date  | NA
  QA, Date       | NA
  Approved, Date | NA
  Released, Date | NA

  Significant Modification History (Most recent at top)
  =====================================================

  Date         | Initials | Details
  ------------ | -------- | -------
  17 Sep 2019  | SC       | Upgraded - NV partion API is now accessed as a linear array of storage, offset zero to length of NV.
  16 Aug 2019  | PK       | Original

  Theory of Operation
  ===================
  This software unit is a buffering layer between the config software unit and the
  memory block the will hold a copy of the config file:

						 |							      |
  	  ConfigSu <---------|         FatFS (Flash)          |<--- device.cfg
  	  	  ^				 |								  |
  	  	  |				 |								  |
  	  	  |				 |--------------------------------|
  	  	  v				 |								  |
  	  NvPartitionSu <--->| Non Volatile Partition (Flash) |
  	  	  	  	  	  	 |								  |
  */

// Define to prevent recursive inclusion -------------------------------------
#ifndef __NVPARTITION_SU_H
#define __NVPARTITION_SU_H

// Exported macro ------------------------------------------------------------

#define NV_BASE_ADDR_CONFIG_DATA 0x1000
#define NV_BASE_ADDR_BLOCK_REMAP_TABLE 0x2000

// Exported types ------------------------------------------------------------

//Todo: Structure will be flushed out when config file is approved
//Todo: Does this struct belong here or in the config su?
//Todo: Create enums for settings with multiple options
typedef struct{
	//Magic Number
	uint32_t headID;

	//Important user
	uint8_t opMode;

	//User
	bool imuEnable;
	bool adcEnable;
	bool gpioEnabled;

	//Pro user
	uint16_t frequency;
	uint8_t wakeMode;
	uint16_t sleepDelay;
	uint16_t sleepDuration;

	//Magic Number
	uint32_t tailID;
} nvConfigData_t;

// Exported constants --------------------------------------------------------

// Exported objects ----------------------------------------------------------

// Exported functions --------------------------------------------------------

///  @brief Initializes the NvPartition software unit
///  @return StatusOk, StatusAlreadyInitialized.
status_t NvPartition_Init(void);

///  @brief Write data to the non volatile partition
///  @param[in] baseAddressNv
///  @param[in] pBuffer
///  @param[in] numberBytesToWrite
///  @return StatusOk
status_t NvPartition_Write(uint32_t baseAddressNv, void *pBuffer, uint32_t numberBytesToWrite);

///  @brief Read data from the non volatile partition
///  @param[in] baseAddressNv
///  @param[in] pBuffer
///  @param[in] numberBytesToRead
///  @return StatusOk
status_t NvPartition_Read(uint32_t baseAddressNv, void *pBuffer, uint32_t numberBytesToRead);

#endif // __NVPARTITION_SU_H

/// SAEC Kinetic Vision, Inc. ----------- END OF FILE


