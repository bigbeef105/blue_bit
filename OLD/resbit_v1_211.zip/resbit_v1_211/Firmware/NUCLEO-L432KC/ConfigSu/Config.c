/**
  @file       Config.c

  @copyright  (C) 2019 Kinetic Vision, Cincinnati Ohio.
               This software is property of SAEC Kinetic Vision, Inc
               and is considered confidential.

  @brief      Configuration software unit "C" file.

  @author     Parker Kamer

  @ingroup    ConfigSu

  Configuration History
  =====================

  Config Item    | Value
  -------------- | -----
  Config #       | NA
  Revision       | NA
  Revised, Date  | NA
  QA, Date       | NA
  Approved, Date | NA
  Released, Date | NA

  Significant Modification History (Most recent at top)
  =====================================================

  Date         | Initials | Details
  ------------ | -------- | -------
  21 Aug 2019  | PK       | Original

  Theory of Operation
  ===================
  TBD

*/

// Includes ------------------------------------------------------------------

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

#include "stm32l4xx_hal.h"

#include "../Middlewares/Third_Party/FatFs/src/ff.h"
#include "../StatusSu/Status.h"
#include "../ConsoleSu/Console.h"
#include "../RtcSu/rtc.h"
#include "Config.h"

#include "fatfs.h"

// Private function prototypes -----------------------------------------------
static void findValueString(char* configString, char* valueString);
static void saveConfig( configSettings_t configNum, uint8_t* pConfigValues );
static status_t findConfigNum(char* nameTagString, configSettings_t *configNum);
static status_t processValueString(char* pString, configSettings_t configNum, uint8_t* pDataOut);

// Private macros ------------------------------------------------------------

// Private constants ---------------------------------------------------------

// Private types -------------------------------------------------------------
//Todo: Collapse all structs and enums into one struct and one enum ??? pjk 8/22/19
typedef struct{
	char* nameTag;
	configSettings_t configVariable;
} configNode_t;

typedef struct{
	char* pValue;
	connectors_t type;
} connectorValue_t;

typedef struct{
	char* pValue;
	thresholdTypes_t type;
} thresholdValue_t;

typedef struct{
	char* pValue;
	startStudyTypes_t type;
} startStudyValue_t;

typedef struct{
	char* pValue;
	extSensorTypes_t type;
} extSensorValue_t;

typedef struct{
	char* pValue;
	configEnableState_t state;
} enableStateValue_t;

typedef struct{
	char* pValue;
	frequencySettings_t freq;
} freqValue_t;

typedef struct{
	char* pValue;
	wakeTriggerTypes_t trigger;
} triggerValue_t;

typedef struct{
	char* pValue;
	opModeTypes_t mode;
} opModeValue_t;

typedef struct{
	char* pValue;
	orientationSettings_t orientation;
}orientationValue_t;

typedef struct{
	char* pValue;
	configProtectMode_t mode;
}protectModeValue_t;

typedef struct {
	char * pValue;
	clockSpeed_t clockSpeed;
} clockSpeedValue_t;

// Private constants ---------------------------------------------------------
#define ASCII_EQUALS_CHAR	'='
#define ASCII_FSLASH_CHAR	'/'
#define ASCII_SPACE_CHAR	' '
static const opModeValue_t OpModeArray[NUM_OP_MODES] = {
		{
			.pValue = "operate",
			.mode = operate
		},
		{
			.pValue = "tare IMU",
			.mode = calibrateImu
		},
		{
			.pValue = "calibrate hall",
			.mode = calibrateHall
		},
		{
			.pValue = "calibrate load cell",
			.mode = calibrateLoadCell
		}
};

static const triggerValue_t WakeTriggerArray[NUM_TRIGGER] = {
		{
			.pValue = "time",
			.trigger = triggerTime
		},
		{
			.pValue = "shake",
			.trigger = triggerShake
		},
		{
			.pValue = "both",
			.trigger = triggerBoth
		}
};

static const freqValue_t FreqArray[NUM_FREQ] = {
		{
			.pValue = "1",
			.freq = freq1hz
		},
		{
			.pValue = "10",
			.freq = freq10hz
		},
		{
			.pValue = "50",
			.freq = freq50hz
		},
		{
			.pValue = "100",
			.freq = freq100hz
		},
		{
			.pValue = "200",
			.freq = freq200hz
		},
		{
			.pValue = "300",
			.freq = freq300hz
		},
		{
			.pValue = "400",
			.freq = freq400hz
		}
};

static const enableStateValue_t EnableStateArray[NUM_ENABLE_STATES] = {
		{
			.pValue = "enable",
			.state = settingEnable
		},
		{
			.pValue = "disable",
			.state = settingDisable
		}
};

static const extSensorValue_t ExtSensorArray[NUM_SENSOR_TYPE] = {
		{
			.pValue = "null",
			.type = sensorNull
		},
		{
			.pValue = "analog",
			.type = sensorAnalog
		},
		{
			.pValue = "digital",
			.type = sensorDigital
		},
		{
			.pValue = "hall",
			.type = sensorHall
		},
		{
			.pValue = "long range hall",
			.type = sensorLongRangeHall
		},
		{
			.pValue = "pressure & temperature",
			.type = sensorPressureTemp
		},
		{
			.pValue = "pressure",
			.type = sensorPressure
		},
		{
			.pValue = "temperature",
			.type = sensorTemperature
		},
		{
            .pValue = "dual pressure & temperature",
            .type = sensorDualPressureTemp
        },
        {
            .pValue = "dual pressure",
            .type = sensorDualPressure
        },
        {
            .pValue = "dual temperature",
            .type = sensorDualTemp
        },
		{
			.pValue = "load cell",
			.type = sensorLoadCell
		},
		{
			.pValue = "etape",
			.type = sensorEtape
		},
		{
			.pValue = "lidar",
			.type = sensorLidar
		},
		{
			.pValue = "auxillary LED",
			.type = sensorAuxLED
		},
		{
			.pValue = "liquid level",
			.type = sensorLiquidLvl
		},
		{
			.pValue = "bluebit",
			.type = sensorBluebit
		}
};

static const connectorValue_t TrigSrcArray[NUM_CONNECTORS] = {
	{
		.pValue = "J1",
		.type = connectorJ1
	},
	{
		.pValue = "J2",
		.type = connectorJ2
	},
	{
		.pValue = "J4",
		.type = connectorJ4
	}
};

static const thresholdValue_t ThresholdTypeArray[NUM_THRES_SRC] = {
		{
			.pValue = "absolute",
			.type = thresholdAbsolute
		},
		{
			.pValue = "relative",
			.type = thresholdRelative
		}
	};

static const startStudyValue_t StartStudyArray[NUM_STUDY_TRIG] = {
	{
		.pValue = "power on",
		.type = startStudyPowerOn
	},
	{
		.pValue = "button",
		.type = startStudyButton
	},
};

static const clockSpeedValue_t ClockSpeedArray[NUM_CLOCKSPEEDS] = {
	{
		.pValue = "80MHz",
		.clockSpeed = clockSpeed80Mhz,
	},
	{
		.pValue = "60MHz",
		.clockSpeed = clockSpeed60Mhz,
	},
	{
		.pValue = "40MHz",
		.clockSpeed = clockSpeed40Mhz,
	},
	{
		.pValue = "26MHz",
		.clockSpeed = clockSpeed26Mhz,
	},
	{
		.pValue = "16MHz",
		.clockSpeed = clockSpeed16Mhz,
	},
	{
		.pValue = "8MHz",
		.clockSpeed = clockSpeed8Mhz,
	},
	{
		.pValue = "4MHz",
		.clockSpeed = clockSpeed4Mhz,
	},
};

static const configNode_t ConfigArray[NUM_CONFIG_SETTINGS] = {
		{
			.nameTag = "Mode",
			.configVariable = configMode
		},
		{
			.nameTag = "RTC",
			.configVariable = configRtc
		},
		{
			.nameTag = "Low Power Accel",
			.configVariable = configLpAcc
		},
		{
			.nameTag = "IMU",
			.configVariable = configImu
		},
		{
			.nameTag = "Accelerometer Data",
			.configVariable = configAcc
		},
		{
			.nameTag = "Gyroscope Data",
			.configVariable = configGyr
		},
		{
			.nameTag = "Magnetometer Data",
			.configVariable = configMag
		},
		{
			.nameTag = "Euler Angle Data",
			.configVariable = configEuler
		},
		{
			.nameTag = "Quaternion Data",
			.configVariable = configQuat
		},
		{
			.nameTag = "Board Orientation",
			.configVariable = configBoardOrientation
		},
		{
			.nameTag = "debug LED",
			.configVariable = configDebugLED
		},
		{
			.nameTag = "debug UART",
			.configVariable = configDebugUART
		},
		{
			.nameTag = "Frequency",
			.configVariable = configFrequency
		},
		{
			.nameTag = "Wake Trigger",
			.configVariable = configWakeTrigger
		},
		{
			.nameTag = "Start Study Trigger",
			.configVariable = configStartStudyTrigger
		},
		{
			.nameTag = "Protected Mode",
			.configVariable = configProtectedMode
		},
		{
			.nameTag = "Deep Sleep Mode",
			.configVariable = configDeepSleepMode
		},
		{
			.nameTag = "J1 Connector",
			.configVariable = configJ1Connector
		},
		{
			.nameTag = "J2 Connector",
			.configVariable = configJ2Connector
		},
		{
			.nameTag = "J3 Connector",
			.configVariable = configJ3Connector
		},
		{
			.nameTag = "J4 Connector",
			.configVariable = configJ4Connector
		},
		{
			.nameTag = "Analog Trigger",
			.configVariable = configAnalogTrigger
		},
		{
			.nameTag = "Trigger Threshold Value",
			.configVariable = configTriggerThreshold
		},
		{
			.nameTag = "Trigger Threshold Type",
			.configVariable = configThresholdType
		},
		{
			.nameTag = "Battery Output",
			.configVariable = configBatteryOutput
		},
		{
			.nameTag = "Temperature Output",
			.configVariable = configTemperatureOutput
		},
		{
			.nameTag = "Fixed Time Sleep",
			.configVariable = configFixedSleep
		},
		{
			.nameTag = "Fixed Time Wakeup Duration",
			.configVariable = configFixedWakeupDuration
		},
		{
			.nameTag = "Wake On Shake Awake Duration",
			.configVariable = configWakeOnShakeAwakeDuration
		},
		{
			.nameTag = "No Motion Before Sleep",
			.configVariable = configNoMotionBeforeSleep
		},
		{
			.nameTag = "Deep Sleep Time",
			.configVariable = configDeepSleepDuration
		},
		{
			.nameTag = "Bogus Wakeup Limit",
			.configVariable = configBogusWakeupLimit
		},
		{
			.nameTag = "Bogus Wakeup Tick Value",
			.configVariable = configBogusWakeupTick
		},
		{
			.nameTag = "Bogus Wakeup Reset",
			.configVariable = configBogusWakeupReset
		},
		{
			.nameTag = "Protected Sleep Duration",
			.configVariable = configProtectedSleepDuration
		},
		{
			.nameTag = "Data Sync Counter",
			.configVariable = configDataSyncCounter
		},
		{
			.nameTag = "Format File System",
			.configVariable = configFormatFileSystem
		},
		{
			.nameTag = "USB Serial Mode",
			.configVariable = configUsbSerialMode
		},
		{
			.nameTag = "Binary File Mode",
			.configVariable = configBinaryFileMode,
		},
		{
			.nameTag = "MCU Clock Speed",
			.configVariable = configClockSpeed,
		},
		{
			.nameTag = "Wake Time Summary",
			.configVariable = configWakeSummary
		},
		{
			.nameTag = "Trigger Count Summary",
			.configVariable = configTrigCountSummary
		},
		{
			.nameTag = "Study Power Down Voltage",
			.configVariable = configBatteryVoltage
		},
		{
			.nameTag = "File Allocation Size",
			.configVariable = configFileSize
		},
        {
            .nameTag = "BLE Advert On Time",
            .configVariable = configBleAdvertOnTime
        },
        {
            .nameTag = "BLE Advert Off Time Min",
            .configVariable = configBleAdvertOffTimeMin
        },
        {
            .nameTag = "BLE Advert Off Time Max",
            .configVariable = configBleAdvertOffTimeMax
        },
        {
            .nameTag = "BLE Always Advertise",
            .configVariable = configBleAlwaysAdvertise
        },
        {
            .nameTag = "BLE Advert Interval",
            .configVariable = configBleAdvertInterval
        }
};

static const orientationValue_t OrientationArray[NUM_ORIENTATION] = {
	{
		.pValue = "v",
		.orientation = orientVertical
	},
	{
		.pValue = "h",
		.orientation = orientHorizontal
	},
	{
		.pValue = "u",
		.orientation = orientUpward
	},
	{
		.pValue = "d",
		.orientation = orientDownward
	},
	{
		.pValue = "f",
		.orientation = orientForward
	},
	{
		.pValue = "b",
		.orientation = orientBackward
	},
	{
		.pValue = "r",
		.orientation = orientRight
	},
	{
		.pValue = "l",
		.orientation = orientLeft
	}
};

static const protectModeValue_t ProtectModeArray[NUM_PROTECT_MODES] = {
	{
		.pValue = "off",
		.mode = protectModeOff
	},
	{
		.pValue = "trigger",
		.mode = protectModeTrigger
	},
	{
		.pValue = "shakes",
		.mode = protectModeShakes
	}
};

// Private variables ---------------------------------------------------------
static configData_t ConfigSettings = {
		.opMode = operate,
		.rtcStartTime.rtcDateData.days = 1,
		.rtcStartTime.rtcDateData.months = 1,
		.rtcStartTime.rtcDateData.years = 0,
		.rtcStartTime.rtcTimeData.hours = 0,
		.rtcStartTime.rtcTimeData.minutes = 0,
		.rtcStartTime.rtcTimeData.seconds = 0,

		//User
		.lpAccEnable = settingDisable,
		.imuEnable = settingEnable,
		.accEnable = settingEnable,
		.gyrEnable = settingDisable,
		.magEnable = settingDisable,
		.eulerEnable = settingDisable,
		.quatEnable = settingEnable,
		.boardOrientation[0] = orientHorizontal,	//vertical/horizontal
		.boardOrientation[1] = orientForward,		//usb direction
		.boardOrientation[2] = orientUpward,		//board direction
		.debugLED = settingDisable,
		.debugUART = settingDisable,
		.frequency = freq100hz,
		.wakeTrigger = triggerTime,
		.startStudyTrigger = startStudyPowerOn,
		.protectedMode = protectModeOff,
		.deepSleepMode = settingDisable,

		.j1Connector = sensorNull,
		.j2Connector = sensorPressureTemp,
		.j3Connector = sensorNull,
		.j4Connector = sensorHall,
		.analogTrigger = connectorJ1,
		.thresholdType = thresholdAbsolute,
		.triggerThreshold = 0xFFFF,
		.batteryOutput = settingEnable,
		.temperatureOutput = settingEnable,

		.wakeSummary = settingDisable,
		.triggerCountSummary = settingDisable,

		//Pro user
		.fixedTimeSleep = 0xFFFF,
		.fixedTimeWakeupDuration = 0xFFFF,

		.wakeOnShakeAwakeDuration = 0xFFFF,
		.noMotionBeforeSleep = 0xFFFF,
		.bogusWakeupLimit = 0xFFFF,
		.bogusWakeupTick = 0xFFFF,
		.bogusWakeupReset = 0xFFFF,
		.protectedSleepDuration = 0xFFFF,

		.deepSleepDuration.rtcDateData.days = 1,
		.deepSleepDuration.rtcDateData.months = 1,
		.deepSleepDuration.rtcDateData.years = 0,
		.deepSleepDuration.rtcTimeData.hours = 0,
		.deepSleepDuration.rtcTimeData.minutes = 0,
		.deepSleepDuration.rtcTimeData.seconds = 0,

		.dataSyncCounter = 0,

		.formatFileSys = settingDisable,
		.usbSerialMode = settingDisable,
		.binaryFileMode = settingDisable,
		.clockSpeed = clockSpeed26Mhz,

		.batteryShutDownVoltage = 2.0,
		.fileSize = 0,
		
		.bleAdvertOnTime = 60,
		.bleAdvertOffTimeMin = 60,
		.bleAdvertOffTimeMax = 3600,
		.bleAlwaysAdvertise = settingDisable,
		.bleAdvertInterval = 1000,
};

static bool ConfigFileError = false;
static volatile bool initialized = false;

// Private function bodies ---------------------------------------------------
static void findValueString(char* configString, char* valueString)
{
	bool foundEquals = false;

	uint8_t valueStringSize = 0;
	uint8_t configStringSize = strlen(configString);
	uint8_t stringIndex = 0;

	//Find the assignment char '='
	while(1){
		//report error and break
		if(stringIndex >= configStringSize){
			break;
		}
		if(!foundEquals){
			//Is this char '='
			if(ASCII_EQUALS_CHAR == configString[stringIndex]){
				foundEquals = true;
			}
		}
		else{
			//Find a non space char
			if(ASCII_SPACE_CHAR != configString[stringIndex]){
				break;
			}
		}
		//Check the next char
		stringIndex++;
	}

	if(foundEquals){
		//Find the comment chars '//' or consecutive spaces
		for( int i = stringIndex; i < configStringSize; i++)
		{
			if((ASCII_FSLASH_CHAR == configString[i] && ASCII_FSLASH_CHAR == configString[i+1]) ||
					(ASCII_SPACE_CHAR == configString[i] && ASCII_SPACE_CHAR == configString[i+1]) ||
						'\t' == configString[i])
			{
				valueStringSize = (i-stringIndex);
				memcpy(valueString, configString+stringIndex, valueStringSize);
				valueString[valueStringSize] = '\0';
				break;
			}
		}
	}
}

static void rtcReadString(char* pStringIn, uint8_t* pDataOut)
{
	uint8_t stringIndex = 0;
	uint8_t tempStringIndex;
	uint8_t argCount = 0;
	char tempString[4];

	memset(tempString,0,4);
	tempStringIndex = 0;

	int intValue;

	//get the date '01/01/2000'
	while(1){
		//process string value
		if( '/' == pStringIn[stringIndex]){
			intValue = atoi(tempString);
			pDataOut[argCount++] = intValue;
			memset(tempString,0,4);
			tempStringIndex = 0;
		}
		else if(tempStringIndex >= 4){
			intValue= atoi(tempString+2);
			pDataOut[argCount++] = intValue;
			memset(tempString,0,4);
			tempStringIndex = 0;
		}
		else if(' ' != pStringIn[stringIndex]){
			tempString[tempStringIndex++] = pStringIn[stringIndex];
		}
		if(argCount >= 3){
			break;
		}

		stringIndex++;
	}
	//get the time '00:00:00'
	while(1){
		//process string value
		if( ':' == pStringIn[stringIndex] || tempStringIndex >= 2){
			intValue = atoi(tempString);
			pDataOut[argCount++] = intValue;
			memset(tempString,0,4);
			tempStringIndex = 0;
		}
		else if(' ' != pStringIn[stringIndex]){
			tempString[tempStringIndex++] = pStringIn[stringIndex];
		}

		if(argCount >= 6){
			break;
		}

		stringIndex++;
	}
}

//Needs additional parameter checking
static void saveConfig( configSettings_t configNum, uint8_t* pConfigValues )
{
	switch(configNum){
		case configMode:
			ConfigSettings.opMode = *pConfigValues;
			break;
		case configRtc:
			ConfigSettings.rtcStartTime.rtcDateData.months = pConfigValues[0];
			ConfigSettings.rtcStartTime.rtcDateData.days = pConfigValues[1];
			ConfigSettings.rtcStartTime.rtcDateData.years = pConfigValues[2];
			ConfigSettings.rtcStartTime.rtcTimeData.hours = pConfigValues[3];
			ConfigSettings.rtcStartTime.rtcTimeData.minutes = pConfigValues[4];
			ConfigSettings.rtcStartTime.rtcTimeData.seconds = pConfigValues[5];

			break;

//*************** USER DEFINITIONS *********************
		case configLpAcc:
			ConfigSettings.lpAccEnable = *pConfigValues;
			break;
		case configImu:
			ConfigSettings.imuEnable = *pConfigValues;
			break;
		case configAcc:
			ConfigSettings.accEnable = *pConfigValues;
			break;
		case configGyr:
			ConfigSettings.gyrEnable = *pConfigValues;
			break;
		case configMag:
			ConfigSettings.magEnable = *pConfigValues;
			break;
		case configEuler:
			ConfigSettings.eulerEnable = *pConfigValues;
			break;
		case configQuat:
			ConfigSettings.quatEnable = *pConfigValues;
			break;
		case configBoardOrientation:
			ConfigSettings.boardOrientation[0] = pConfigValues[0];
			ConfigSettings.boardOrientation[1] = pConfigValues[1];
			ConfigSettings.boardOrientation[2] = pConfigValues[2];
			break;
		case configDebugLED:
			ConfigSettings.debugLED = *pConfigValues;
			break;
		case configDebugUART:
			ConfigSettings.debugUART = *pConfigValues;
			break;
		case configFrequency:
			ConfigSettings.frequency  = *pConfigValues;
			break;
		case configWakeTrigger:
			ConfigSettings.wakeTrigger =  *pConfigValues;
			break;
		case configStartStudyTrigger:
			ConfigSettings.startStudyTrigger =  *pConfigValues;
			break;
		case configProtectedMode:
			ConfigSettings.protectedMode = *pConfigValues;
			break;
		case configDeepSleepMode:
			ConfigSettings.deepSleepMode = *pConfigValues;
			break;
		case configJ1Connector:
			ConfigSettings.j1Connector = *pConfigValues;
			break;
		case configJ2Connector:
			ConfigSettings.j2Connector = *pConfigValues;
			break;
		case configJ3Connector:
			ConfigSettings.j3Connector = *pConfigValues;
			break;
		case configJ4Connector:
			ConfigSettings.j4Connector = *pConfigValues;
			break;
		case configAnalogTrigger:
			ConfigSettings.analogTrigger = *pConfigValues;
			break;
		case configThresholdType:
			ConfigSettings.thresholdType = *pConfigValues;
			break;
		case configTriggerThreshold:
			ConfigSettings.triggerThreshold = (pConfigValues[1]<<8) | pConfigValues[0];
			break;
		case configBatteryOutput:
			ConfigSettings.batteryOutput = *pConfigValues;
			break;
		case configTemperatureOutput:
			ConfigSettings.temperatureOutput = *pConfigValues;
			break;
//*************** PRO USER *********************
		case configFixedSleep:
			ConfigSettings.fixedTimeSleep = (pConfigValues[1]<<8) | pConfigValues[0];
			break;
		case configFixedWakeupDuration:
			ConfigSettings.fixedTimeWakeupDuration = (pConfigValues[1]<<8) | pConfigValues[0];
			break;
		case configWakeOnShakeAwakeDuration:
			ConfigSettings.wakeOnShakeAwakeDuration = (pConfigValues[1]<<8) | pConfigValues[0];
			break;
		case configNoMotionBeforeSleep:
			ConfigSettings.noMotionBeforeSleep = (pConfigValues[1]<<8) | pConfigValues[0];
			break;
		case configDeepSleepDuration:
			ConfigSettings.deepSleepDuration.rtcDateData.months = pConfigValues[0];
			ConfigSettings.deepSleepDuration.rtcDateData.days = pConfigValues[1];
			ConfigSettings.deepSleepDuration.rtcDateData.years = pConfigValues[2];
			ConfigSettings.deepSleepDuration.rtcTimeData.hours = pConfigValues[3];
			ConfigSettings.deepSleepDuration.rtcTimeData.minutes = pConfigValues[4];
			ConfigSettings.deepSleepDuration.rtcTimeData.seconds = pConfigValues[5];
			break;
		case configBogusWakeupLimit:
			ConfigSettings.bogusWakeupLimit = (pConfigValues[1]<<8) | pConfigValues[0];
			break;
		case configBogusWakeupTick:
			ConfigSettings.bogusWakeupTick = (pConfigValues[1]<<8) | pConfigValues[0];
			break;
		case configBogusWakeupReset:
			ConfigSettings.bogusWakeupReset = (pConfigValues[1]<<8) | pConfigValues[0];
			break;
		case configProtectedSleepDuration:
			ConfigSettings.protectedSleepDuration = (pConfigValues[1]<<8) | pConfigValues[0];
			break;
		case configDataSyncCounter:
			ConfigSettings.dataSyncCounter = (pConfigValues[1]<<8) | pConfigValues[0];
			break;
		case configFormatFileSystem:
			ConfigSettings.formatFileSys = *pConfigValues;
			break;
		case configUsbSerialMode:
			ConfigSettings.usbSerialMode = *pConfigValues;
			break;
		case configBinaryFileMode:
			ConfigSettings.binaryFileMode = *pConfigValues;
			break;
		case configClockSpeed:
			memcpy(&ConfigSettings.clockSpeed, pConfigValues, sizeof(ConfigSettings.clockSpeed));
			break;
		case configWakeSummary:
			ConfigSettings.wakeSummary = *pConfigValues;
			break;
		case configTrigCountSummary:
			ConfigSettings.triggerCountSummary = *pConfigValues;
			break;
		case configBatteryVoltage:
			memcpy(&ConfigSettings.batteryShutDownVoltage, pConfigValues,sizeof(ConfigSettings.batteryShutDownVoltage));
			//ConfigSettings.batteryShutDownVoltage = *pConfigValues;
			break;
		case configFileSize:
			memcpy(&ConfigSettings.fileSize, pConfigValues,sizeof(ConfigSettings.fileSize));
			break;
		case configBleAdvertOnTime:
		    ConfigSettings.bleAdvertOnTime = (pConfigValues[1]<<8) | pConfigValues[0];
		    break;
        case configBleAdvertOffTimeMin:
            ConfigSettings.bleAdvertOffTimeMin = (pConfigValues[1]<<8) | pConfigValues[0];
            break;
        case configBleAdvertOffTimeMax:
            ConfigSettings.bleAdvertOffTimeMax = (pConfigValues[1]<<8) | pConfigValues[0];
            break;
        case configBleAlwaysAdvertise:
            ConfigSettings.bleAlwaysAdvertise = *pConfigValues;
            break;
        case configBleAdvertInterval:
            ConfigSettings.bleAdvertInterval = (pConfigValues[1]<<8) | pConfigValues[0];
            break;
		default:
			break;
	}
}

static status_t findConfigNum(char* nameTagString, configSettings_t *configNum)
{
	status_t status = StatusOk;

	*configNum = NULL_CONFIG_INIT;

	for (int i = 0; i < NUM_CONFIG_SETTINGS; i++)
	{
		if(0 == strncmp(nameTagString, ConfigArray[i].nameTag, strlen( ConfigArray[i].nameTag)))
		{
			*configNum = ConfigArray[i].configVariable;
			break;
		}
	}

	if(NULL_CONFIG_INIT == *configNum)
	{
		status = StatusConfigSettings;
	}
	return status;
}

static status_t processValueString(char* pString, configSettings_t configNum, uint8_t* pDataOut)
{
	status_t status = StatusOk;
	int proUserValue = 0;
	float proUserFloat = 0.0;

	switch(configNum){
		case configMode:
			*pDataOut = NULL_OP_INIT;
			for(int i = 0; i < NUM_OP_MODES; i++)
			{
				if(0 == strncmp(pString, OpModeArray[i].pValue, strlen( OpModeArray[i].pValue))){
					*pDataOut = OpModeArray[i].mode;
					break;
				}
			}
			if(NULL_OP_INIT == *pDataOut){
				status = StatusConfigStringValue;
			}
			break;
		case configRtc:
			rtcReadString(pString, pDataOut);
			break;

//*************** USER DEFINITIONS *********************
		case configLpAcc:
		case configImu:
		case configAcc:
		case configGyr:
		case configMag:
		case configEuler:
		case configQuat:
		case configDebugLED:
		case configDebugUART:
		case configDeepSleepMode:
		case configFormatFileSystem:
		case configUsbSerialMode:
		case configBinaryFileMode:
		case configWakeSummary:
		case configTrigCountSummary:
		case configBatteryOutput:
		case configTemperatureOutput:
		case configBleAlwaysAdvertise:
			*pDataOut = NULL_ENABLE_INIT;
			for(int i = 0; i < NUM_ENABLE_STATES; i++)
			{
				if(0 == strncmp(pString, EnableStateArray[i].pValue, strlen( EnableStateArray[i].pValue))){
					*pDataOut = EnableStateArray[i].state;
					break;
				}
			}
			if(NULL_ENABLE_INIT == *pDataOut){
				status = StatusConfigStringValue;
			}
			break;
		case configProtectedMode:
			*pDataOut = NULL_PROTECT_INIT;
			for(int i = 0; i < NUM_PROTECT_MODES; i++)
			{
				if(0 == strncmp(pString, ProtectModeArray[i].pValue, strlen( ProtectModeArray[i].pValue))){
					*pDataOut = ProtectModeArray[i].mode;
					break;
				}
			}
			if(NULL_PROTECT_INIT == *pDataOut){
				status = StatusConfigStringValue;
			}
			break;
		case configBoardOrientation:
			for(int i = 0; i < 3; i++){
				char setting = pString[i*2];
				pDataOut[i] = NULL_ORIENTATION_INIT;
				for(int j = 0; j < NUM_ORIENTATION; j++)
				{
					if(0 == strncmp(&setting, OrientationArray[j].pValue, strlen( OrientationArray[j].pValue))){
						pDataOut[i] = OrientationArray[j].orientation;
						break;
					}
				}
				if(NULL_ORIENTATION_INIT == pDataOut[i]){
					status = StatusConfigStringValue;
				}
			}

			break;
		case configFrequency:
			*pDataOut = NULL_FREQ_INIT;
			for(int i = 0; i < NUM_FREQ; i++)
			{
				if(0 == strncmp(pString, FreqArray[i].pValue, strlen( pString))){
					*pDataOut = FreqArray[i].freq;
					break;
				}
			}
			if(NULL_FREQ_INIT == *pDataOut){
				status = StatusConfigStringValue;
			}
			break;
		case configWakeTrigger:
			*pDataOut = NULL_TRIGGER_INIT;
			for(int i = 0; i < NUM_TRIGGER; i++)
			{
				if(0 == strncmp(pString, WakeTriggerArray[i].pValue, strlen( WakeTriggerArray[i].pValue))){
					*pDataOut = WakeTriggerArray[i].trigger;
					break;
				}
			}
			if(NULL_TRIGGER_INIT == *pDataOut){
				status = StatusConfigStringValue;
			}
			break;
		case configStartStudyTrigger:
			*pDataOut = NULL_STUDY_TRIG;
			for(int i = 0; i < NUM_STUDY_TRIG; i++)
			{
				if(0 == strncmp(pString, StartStudyArray[i].pValue, strlen( StartStudyArray[i].pValue))){
					*pDataOut = StartStudyArray[i].type;
					break;
				}
			}
			if(NULL_STUDY_TRIG == *pDataOut){
				status = StatusConfigStringValue;
			}
			break;
		case configJ1Connector:
		case configJ2Connector:
		case configJ3Connector:
		case configJ4Connector:
			*pDataOut = NULL_SENSOR_INIT;
			for(int i = 0; i < NUM_SENSOR_TYPE; i++)
			{
				if(0 == strncmp(pString, ExtSensorArray[i].pValue, strlen( ExtSensorArray[i].pValue))){
					*pDataOut = ExtSensorArray[i].type;
					break;
				}
			}
			if(NULL_SENSOR_INIT == *pDataOut){
				status = StatusConfigStringValue;
			}
			break;
		case configAnalogTrigger:
			*pDataOut = NULL_SENSOR_INIT;
			for(int i = 0; i < NUM_CONNECTORS; i++)
			{
				if(0 == strncmp(pString, TrigSrcArray[i].pValue, strlen( TrigSrcArray[i].pValue))){
					*pDataOut = TrigSrcArray[i].type;
					break;
				}
			}
			if(NULL_SENSOR_INIT == *pDataOut){
				status = StatusConfigStringValue;
			}
			break;
		case configThresholdType:
			*pDataOut = NULL_THRES_SRC;
			for(int i = 0; i < NUM_THRES_SRC; i++)
			{
				if(0 == strncmp(pString, ThresholdTypeArray[i].pValue, strlen( ThresholdTypeArray[i].pValue))){
					*pDataOut = ThresholdTypeArray[i].type;
					break;
				}
			}
			if(NULL_THRES_SRC == *pDataOut){
				status = StatusConfigStringValue;
			}
			break;
		case configClockSpeed:
			*pDataOut = NULL_CLOCKSPEED_INIT;
			for(int i = 0; i < NUM_CLOCKSPEEDS; i++)
			{
				if(0 == strncmp(pString, ClockSpeedArray[i].pValue, strlen( pString))){
					*pDataOut = ClockSpeedArray[i].clockSpeed;
					break;
				}
			}
			if(NULL_CLOCKSPEED_INIT == *pDataOut){
				status = StatusConfigStringValue;
			}
			break;
//*************** PRO USER *********************
		case configFixedSleep:
		case configFixedWakeupDuration:
		case configWakeOnShakeAwakeDuration:
		case configNoMotionBeforeSleep:
		case configTriggerThreshold:
		case configBogusWakeupLimit:
		case configBogusWakeupTick:
		case configBogusWakeupReset:
		case configProtectedSleepDuration:
		case configDataSyncCounter:
		case configFileSize:
		case configBleAdvertOnTime:
		case configBleAdvertOffTimeMin:
		case configBleAdvertOffTimeMax:
		case configBleAdvertInterval:
			proUserValue = atoi(pString);
			if((0 == proUserValue) && ('0' != *pString)){
				status = StatusConfigStringValue;
			}
			if(StatusOk == status){
				memcpy(pDataOut, &proUserValue, sizeof(int));
			}
			break;
		case configBatteryVoltage:
			proUserFloat = atof(pString);
			if((0 == proUserFloat) && ('0' != *pString)){
				status = StatusConfigStringValue;
			}
			if(StatusOk == status){
				memcpy(pDataOut, &proUserFloat, sizeof(float));
			}
			break;
		case configDeepSleepDuration:
			rtcReadString(pString, pDataOut);
			break;

		default:
			break;
	}

	return status;
}

// Public functions bodies ---------------------------------------------------

status_t Config_Init(void)
{
	status_t status = StatusOk;

	if (initialized) {
	    status = StatusAlreadyInitialized;
	}
	else{
#ifndef SWO_PROFILE_BUILD
		status = Config_ReadFile();
#endif // SWO_PROFILE_BUILD
		if(StatusOk == status){
			initialized = true;
		}
	}

	return status;
}

status_t Config_ReadFile(void)
{
	configSettings_t configNum;
	uint8_t configValues[10];
	uint8_t configCounter = 0;
	char stringBuff[50];
	char valueString[30];
	FATFS* USBDISKFatFs;
	FIL* configFile;

	USBDISKFatFs = FATFS_GetFileSystem();
	configFile = FATFS_GetConfigFile();

	status_t status = StatusOk;
	FRESULT res;

	// ===== Open File =====
	res = f_mount(USBDISKFatFs, "", 1);
	if(FR_OK == res){
		//Does the config file exist?
		res = f_stat("device.cfg", NULL);
		if(FR_OK == res){
			res = f_open(configFile, "device.cfg", FA_OPEN_EXISTING | FA_READ);
		}
		//If no file exists/can't open the file then report status
		if(FR_OK != res){
			status = StatusFatFsOpen;
		}
	}
	else{
		status = StatusFatFsMount;
	}

	// ===== Parse File =====
	if (StatusOk == status){
		while(1){
			//read line
			if( NULL != f_gets(stringBuff, sizeof(stringBuff),configFile))
			{
				for( int j = 0; j < NUM_CONFIG_SETTINGS; j++)
				{
					//If the Name Tag is valid, get the enum value and then process the value string
					if(0 == strncmp(stringBuff, ConfigArray[j].nameTag, strlen( ConfigArray[j].nameTag)))
					{
						//Clear Arrays
						memset(configValues, 0, 10);
						memset(valueString, 0, 30);

						//Valid Setting
						status = findConfigNum(ConfigArray[j].nameTag, &configNum);
						//Valid Value
						if(StatusOk == status){
							findValueString(stringBuff, valueString);
							status = processValueString(valueString, configNum, configValues);
						}
						//Commit Setting
						if(StatusOk == status){
							saveConfig( configNum, configValues );
							configCounter++;
						}
						break;
					}
				}
				if(StatusOk != status){
					break;
				}
			}
			else{
				break;
			}
		}
		//handle errors
		if(NUM_CONFIG_SETTINGS != configCounter){
			status = StatusConfigSettings;
		}

	}

	// ===== Close File =====
	if(StatusOk == status){
		f_close(configFile);
		f_mount(0, "", 1);
		ConfigFileError = false;
	}
	else{
		ConfigFileError = true;
	}

	return status;
}

status_t Config_Ioctl(configIoctl_t ioctlCode, uint8_t* outValue)
{
	status_t status = StatusOk;

	switch(ioctlCode){
	case configIoctlGetMode:
		*outValue = ConfigSettings.opMode;
		break;
	case configIoctlGetRtc:
		memcpy(outValue, &ConfigSettings.rtcStartTime, sizeof(rtcDataHandler_t));
		break;

	case configIoctlGetLpAcc:
		*outValue = ConfigSettings.lpAccEnable;
		break;
	case configIoctlGetImu:
		*outValue = ConfigSettings.imuEnable;
		break;
	case configIoctlGetAcc:
		*outValue = ConfigSettings.accEnable;
		break;
	case configIoctlGetGyr:
		*outValue = ConfigSettings.gyrEnable;
		break;
	case configIoctlGetMag:
		*outValue = ConfigSettings.magEnable;
		break;
	case configIoctlGetEuler:
		*outValue = ConfigSettings.eulerEnable;
		break;
	case configIoctlGetQuat:
		*outValue = ConfigSettings.quatEnable;
		break;
	case configIoctlGetOrientation:
		memcpy(outValue,ConfigSettings.boardOrientation,3);
		break;
	case configIoctlGetLed:
		*outValue = ConfigSettings.debugLED;
		break;
	case configIoctlGetUart:
		*outValue = ConfigSettings.debugUART;
		break;
	case configIoctlGetFreq:
		*outValue = ConfigSettings.frequency;
		break;
	case configIoctlGetWakeTrig:
		*outValue = ConfigSettings.wakeTrigger;
		break;
	case configIoctlGetStartStudyTrig:
		*outValue = ConfigSettings.startStudyTrigger;
		break;
	case configIoctlGetProtectMode:
		*outValue = ConfigSettings.protectedMode;
		break;
	case configIoctlGetDeepSleepMode:
		*outValue = ConfigSettings.deepSleepMode;
		break;
	case configIoctlGetJ1:
		*outValue = ConfigSettings.j1Connector;
		break;
	case configIoctlGetJ2:
		*outValue = ConfigSettings.j2Connector;
		break;
	case configIoctlGetJ3:
		*outValue = ConfigSettings.j3Connector;
		break;
	case configIoctlGetJ4:
		*outValue = ConfigSettings.j4Connector;
		break;
	case configIoctlGetAnalogTrig:
		*outValue = ConfigSettings.analogTrigger;
		break;
	case configIoctlGetThresholdType:
		*outValue = ConfigSettings.thresholdType;
		break;
	case configIoctlGetTrigThreshold:
		memcpy(outValue,&ConfigSettings.triggerThreshold,sizeof(uint16_t));
		break;
	case configIoctlGetBatteryOutput:
		*outValue = ConfigSettings.batteryOutput;
		break;
	case configIoctlGetTemperatureOutput:
		*outValue = ConfigSettings.temperatureOutput;
		break;

	//memcpy?
	case configIoctlGetFixedSleep:
		memcpy(outValue,&ConfigSettings.fixedTimeSleep,sizeof(uint16_t));
		break;
	case configIoctlGetFixedWakeupDuration:
		memcpy(outValue,&ConfigSettings.fixedTimeWakeupDuration,sizeof(uint16_t));
		break;
	case configIoctlGetWakeDur:
		memcpy(outValue,&ConfigSettings.wakeOnShakeAwakeDuration,sizeof(uint16_t));
		break;
	case configIoctlGetNmSleep:
		memcpy(outValue,&ConfigSettings.noMotionBeforeSleep,sizeof(uint16_t));
		break;
	case configIoctlGetWakeLimit:
		memcpy(outValue,&ConfigSettings.bogusWakeupLimit,sizeof(uint16_t));
		break;
	case configIoctlGetWakeTick:
		memcpy(outValue,&ConfigSettings.bogusWakeupTick,sizeof(uint16_t));
		break;
	case configIoctlGetWakeReset:
		memcpy(outValue,&ConfigSettings.bogusWakeupReset,sizeof(uint16_t));
		break;
	case configIoctlGetSleepDur:
		memcpy(outValue,&ConfigSettings.protectedSleepDuration,sizeof(uint16_t));
		break;

	case configIoctlGetDeepSleepDur:
		memcpy(outValue, &ConfigSettings.deepSleepDuration, sizeof(rtcDataHandler_t));
		break;

	case configIoctlGetDataSyncCounter:
		memcpy(outValue,&ConfigSettings.dataSyncCounter,sizeof(configEnableState_t));
		break;

	case configIoctlGetFormatFileSys:
		memcpy(outValue,&ConfigSettings.formatFileSys,sizeof(configEnableState_t));
		break;

	case configIoctlGetUsbSerialMode:
		memcpy(outValue,&ConfigSettings.usbSerialMode,sizeof(configEnableState_t));
		break;

	case configIoctlGetBinaryFileMode:
		memcpy(outValue,&ConfigSettings.binaryFileMode,sizeof(configEnableState_t));
		break;
		
	case configIoctlGetClockSpeed:
		memcpy(outValue,&ConfigSettings.clockSpeed,sizeof(clockSpeed_t));
		break;

	case configIoctlGetBluebitEnabled:
		;configEnableState_t enabled = settingDisable;
		// Start false, flip to true if found
		enabled = (ConfigSettings.j1Connector == sensorBluebit) ?
				settingEnable : enabled;
		enabled = (ConfigSettings.j2Connector == sensorBluebit) ?
				settingEnable : enabled;
		enabled = (ConfigSettings.j3Connector == sensorBluebit) ?
				settingEnable : enabled;
		enabled = (ConfigSettings.j4Connector == sensorBluebit) ?
				settingEnable : enabled;
		memcpy(outValue, &enabled, sizeof(configEnableState_t));
		break;

	case configIoctlGetWakeSummaryEnabled:
		memcpy(outValue,&ConfigSettings.wakeSummary,sizeof(configEnableState_t));
		break;

	case configIoctlGetTrigCountEnabled:
		memcpy(outValue,&ConfigSettings.triggerCountSummary,sizeof(configEnableState_t));
		break;

	case configIoctlGetBatteryVoltage:
		memcpy(outValue,&ConfigSettings.batteryShutDownVoltage,sizeof(float));
		break;

	case configIoctlGetFileSize:
		memcpy(outValue,&ConfigSettings.fileSize,sizeof(uint32_t));
		break;
		
	case configIoctlGetBleAdvertOnTime:
        memcpy(outValue,&ConfigSettings.bleAdvertOnTime,sizeof(uint16_t));
        break;
        
    case configIoctlGetBleAdvertOffTimeMin:
        memcpy(outValue,&ConfigSettings.bleAdvertOffTimeMin,sizeof(uint16_t));
        break;
        
    case configIoctlGetBleAdvertOffTimeMax:
        memcpy(outValue,&ConfigSettings.bleAdvertOffTimeMax,sizeof(uint16_t));
        break;
        
    case configIoctlGetBleAlwaysAdvertise:
        memcpy(outValue,&ConfigSettings.bleAlwaysAdvertise,sizeof(configEnableState_t));
        break;
        
    case configIoctlGetBleAdvertInterval:
        memcpy(outValue,&ConfigSettings.bleAdvertInterval,sizeof(uint16_t));
        break;

	case configIoctlGetConfigError:
		*outValue = ConfigFileError;
		break;

	default:
		break;
	}

	return status;
}

//TODO: Some of this remapping is strange, Need to understand it better
//TODO: Rewrite to remove nested switch case statements
status_t Config_RemapBoardAxis(orientationSettings_t *pBuffer, uint8_t* outBuff)
{
	status_t status = StatusOk;
	uint8_t axisDirection = 0;
	uint8_t axisSign = 0;

	orientationSettings_t boardPos = pBuffer[0];	//v=vertical, h=horizontal
	orientationSettings_t usbPos = pBuffer[1];		//u=up, d=down, f=forward, b=backward, l=left, r=right
	orientationSettings_t topPos = pBuffer[2];		//u=up, d=down, f=forward, b=backward, l=left, r=right

	switch(boardPos){
		case orientVertical:
			if(orientUpward == usbPos){
				switch(topPos){
					case orientForward://---------------------------------------
						axisDirection |= yAxisId << X_AXIS_REG_POS;
						axisSign |= 1 << Y_SIGN_REG_POS;
						axisDirection |= xAxisId << Z_AXIS_REG_POS;
						axisDirection |= zAxisId << Y_AXIS_REG_POS;
						axisSign |= 1 << Z_SIGN_REG_POS;
						break;//-------------------------------------------------
					case orientBackward://---------------------------------------
						axisDirection |= yAxisId << X_AXIS_REG_POS;
						axisDirection |= xAxisId << Z_AXIS_REG_POS;
						axisSign |= 1 << X_SIGN_REG_POS;
						axisDirection |= zAxisId << Y_AXIS_REG_POS;
						axisSign |= 1 << Z_SIGN_REG_POS;
						break;//-------------------------------------------------
					case orientLeft:
						axisDirection |= zAxisId << X_AXIS_REG_POS;
						axisSign |= 1 << Z_SIGN_REG_POS;

						axisDirection |= xAxisId << Z_AXIS_REG_POS;

						axisDirection |= yAxisId << Y_AXIS_REG_POS;
						break;
					case orientRight:
						axisDirection |= zAxisId << X_AXIS_REG_POS;
						axisSign |= 1 << Z_SIGN_REG_POS;

						axisDirection |= xAxisId << Z_AXIS_REG_POS;
						axisSign |= 1 << X_SIGN_REG_POS;

						axisDirection |= yAxisId << Y_AXIS_REG_POS;
						axisSign |= 1 << Y_SIGN_REG_POS;
						break;
					default:
						status = StatusImuAxisRemap;
						break;
				}
			}
			else if(orientDownward == usbPos){
				switch(topPos){
					case orientForward://----------------------------
						axisDirection |= yAxisId << X_AXIS_REG_POS;
						axisSign |= 1 << Y_SIGN_REG_POS;

						axisDirection |= xAxisId << Z_AXIS_REG_POS;
						axisSign |= 1 << X_SIGN_REG_POS;

						axisDirection |= zAxisId << Y_AXIS_REG_POS;
						break;//-------------------------------------
					case orientBackward://---------------------------
						axisDirection |= yAxisId << X_AXIS_REG_POS;

						axisDirection |= xAxisId << Z_AXIS_REG_POS;

						axisDirection |= zAxisId << Y_AXIS_REG_POS;
						break;//-------------------------------------
					case orientLeft:
						axisDirection |= zAxisId << X_AXIS_REG_POS;

						axisDirection |= xAxisId << Z_AXIS_REG_POS;

						axisDirection |= yAxisId << Y_AXIS_REG_POS;
						axisSign |= 1 << Y_SIGN_REG_POS;
						break;
					case orientRight:
						axisDirection |= zAxisId << X_AXIS_REG_POS;

						axisDirection |= xAxisId << Z_AXIS_REG_POS;
						axisSign |= 1 << X_SIGN_REG_POS;

						axisDirection |= yAxisId << Y_AXIS_REG_POS;
						break;
					default:
						status = StatusImuAxisRemap;
						break;
				}
			}
			else if(orientForward == usbPos){
				if(orientLeft ==  topPos){//------------------------
					axisDirection |= zAxisId << X_AXIS_REG_POS;
					axisSign |= 1 << Z_SIGN_REG_POS;

					axisDirection |= yAxisId << Z_AXIS_REG_POS;
					axisSign |= 1 << Y_SIGN_REG_POS;

					axisDirection |= xAxisId << Y_AXIS_REG_POS;

				}//-------------------------------------------------
				else if(orientRight ==  topPos){//------------------
					axisDirection |= zAxisId << X_AXIS_REG_POS;

					axisDirection |= yAxisId << Z_AXIS_REG_POS;
					axisSign |= 1 << Y_SIGN_REG_POS;

					axisDirection |= xAxisId << Y_AXIS_REG_POS;
					axisSign |= 1 << X_SIGN_REG_POS;
				}//-------------------------------------------------
				else{
					status = StatusImuAxisRemap;
				}
			}
			else if(orientBackward == usbPos){
				if(orientLeft ==  topPos){//------------------------
					axisDirection |= zAxisId << X_AXIS_REG_POS;

					axisDirection |= yAxisId << Z_AXIS_REG_POS;

					axisDirection |= xAxisId << Y_AXIS_REG_POS;
				}//-------------------------------------------------
				else if(orientRight ==  topPos){//------------------
					axisDirection |= zAxisId << X_AXIS_REG_POS;
					axisSign |= 1 << Z_SIGN_REG_POS;

					axisDirection |= yAxisId << Z_AXIS_REG_POS;

					axisDirection |= xAxisId << Y_AXIS_REG_POS;
					axisSign |= 1 << X_SIGN_REG_POS;
				}//-------------------------------------------------
				else{
					status = StatusImuAxisRemap;
				}
			}
			else if(orientLeft == usbPos){
				axisDirection |= xAxisId << X_AXIS_REG_POS;

				if(orientForward ==  topPos){
					axisDirection |= yAxisId << Z_AXIS_REG_POS;
					axisSign |= 1 << Y_SIGN_REG_POS;

					axisDirection |= zAxisId << Y_AXIS_REG_POS;
				}
				else if(orientBackward ==  topPos){
					axisDirection |= yAxisId << Z_AXIS_REG_POS;

					axisDirection |= zAxisId << Y_AXIS_REG_POS;
					axisSign |= 1 << Z_SIGN_REG_POS;
				}
				else{
					status = StatusImuAxisRemap;
				}
			}
			else if(orientRight == usbPos){
				axisDirection |= xAxisId << X_AXIS_REG_POS;
				axisSign |= 1 << X_SIGN_REG_POS;

				if(orientForward ==  topPos){
					axisDirection |= yAxisId << Z_AXIS_REG_POS;
					axisSign |= 1 << Y_SIGN_REG_POS;

					axisDirection |= zAxisId << Y_AXIS_REG_POS;
					axisSign |= 1 << Z_SIGN_REG_POS;
				}
				else if(orientBackward ==  topPos){
					axisDirection |= yAxisId << Z_AXIS_REG_POS;

					axisDirection |= zAxisId << Y_AXIS_REG_POS;
				}
				else{
					status = StatusImuAxisRemap;
				}
			}
			else{
				status = StatusImuAxisRemap;
			}
			break;
		case orientHorizontal:
			if(orientUpward == topPos){
				axisDirection |= zAxisId << Z_AXIS_REG_POS;
				axisSign |= 1 << Z_SIGN_REG_POS;

				switch(usbPos){
					case orientForward:
						axisDirection |= yAxisId << X_AXIS_REG_POS;
						axisSign |= 1 << Y_SIGN_REG_POS;

						axisDirection |= xAxisId << Y_AXIS_REG_POS;
						axisSign |= 1 << X_SIGN_REG_POS;
						break;
					case orientBackward:
						axisDirection |= yAxisId << X_AXIS_REG_POS;

						axisDirection |= xAxisId << Y_AXIS_REG_POS;
						break;
					case orientLeft:
						axisDirection |= xAxisId << X_AXIS_REG_POS;

						axisDirection |= yAxisId << Y_AXIS_REG_POS;
						axisSign |= 1 << Y_SIGN_REG_POS;
						break;
					case orientRight:
						axisDirection |= xAxisId << X_AXIS_REG_POS;
						axisSign |= 1 << X_SIGN_REG_POS;

						axisDirection |= yAxisId << Y_AXIS_REG_POS;
						break;
					default:
						status = StatusImuAxisRemap;
						break;
				}
			}
			else if(orientDownward == topPos){
				axisDirection |= zAxisId << Z_AXIS_REG_POS;

				switch(usbPos){
					case orientForward:
						axisDirection |= yAxisId << X_AXIS_REG_POS;
						axisSign |= 1 << Y_SIGN_REG_POS;

						axisDirection |= xAxisId << Y_AXIS_REG_POS;
						break;
					case orientBackward:
						axisDirection |= yAxisId << X_AXIS_REG_POS;

						axisDirection |= xAxisId << Y_AXIS_REG_POS;
						axisSign |= 1 << X_SIGN_REG_POS;
						break;
					case orientLeft:
						axisDirection |= xAxisId << X_AXIS_REG_POS;

						axisDirection |= yAxisId << Y_AXIS_REG_POS;
						break;
					case orientRight:
						axisDirection |= xAxisId << X_AXIS_REG_POS;
						axisSign |= 1 << X_SIGN_REG_POS;

						axisDirection |= yAxisId << Y_AXIS_REG_POS;
						axisSign |= 1 << Y_SIGN_REG_POS;
						break;
					default:
						status = StatusImuAxisRemap;
						break;
				}
			}
			else{
				status = StatusImuAxisRemap;
			}
			break;
		default:
			status = StatusImuAxisRemap;
			break;
	}

	outBuff[0] = axisDirection;
	outBuff[1] = axisSign;

	if(StatusOk != status){
		ConfigFileError = true;
	}

	return status;
}

/// SAEC Kinetic Vision, Inc. ----------- END OF FILE


