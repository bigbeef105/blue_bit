/**
  @file       Config.h

  @copyright  (C) 2019 Kinetic Vision, Cincinnati Ohio.
               This software is property of SAEC Kinetic Vision, Inc
               and is considered confidential.

  @brief      Configuration File software unit "H" file.

  @author     Parker Kamer

  @defgroup   ConfigSu Configuration file handling

  Configuration History
  =====================

  Config Item    | Value
  -------------- | -----
  Config #       | NA
  Revision       | NA
  Revised, Date  | NA
  QA, Date       | NA
  Approved, Date | NA
  Released, Date | NA

  Significant Modification History (Most recent at top)
  =====================================================

  Date         | Initials | Details
  ------------ | -------- | -------
  21 Aug 2019  | PK       | Original

  Theory of Operation
  ===================
  TBD

  */

// Define to prevent recursive inclusion -------------------------------------
#ifndef __CONFIG_SU_H
#define __CONFIG_SU_H

#include "../RtcSu/rtc.h"
#include "../StatusSu/Status.h"
#include "../GpioSu/gpio.h"

// Exported macro ------------------------------------------------------------
//#define HARDWARE_QA_BUILD

//#define PROFILE_READS
//#define PROFILE_WRITES
//#define NO_SENSOR_READS
//#define NO_FLASH_WRITES

//#define HARDWARE_QA_BUILD
//#define SWO_PROFILE_BUILD

//#define LSI_BUILD

// Exported types ------------------------------------------------------------
typedef enum {
	configMode,
	configRtc,
	configLpAcc,
	configImu,
	configAcc,
	configGyr,
	configMag,
	configEuler,
	configQuat,
	configBoardOrientation,
	configDebugLED,
	configDebugUART,
	configFrequency,
	configWakeTrigger,
	configStartStudyTrigger,
	configProtectedMode,
	configDeepSleepMode,
	configJ1Connector,
	configJ2Connector,
	configJ3Connector,
	configJ4Connector,
	configAnalogTrigger,
	configThresholdType,
	configTriggerThreshold,
	configBatteryOutput,
	configTemperatureOutput,
	configFixedSleep,
	configFixedWakeupDuration,
	configWakeOnShakeAwakeDuration,
	configNoMotionBeforeSleep,
	configDeepSleepDuration,
	configBogusWakeupLimit,
	configBogusWakeupTick,
	configBogusWakeupReset,
	configProtectedSleepDuration,
	configDataSyncCounter,
	configFormatFileSystem,
	configUsbSerialMode,
	configBinaryFileMode,
	configClockSpeed,
	configWakeSummary,
	configTrigCountSummary,
	configBatteryVoltage,
	configFileSize,
	configBleAdvertOnTime,
	configBleAdvertOffTimeMin,
	configBleAdvertOffTimeMax,
	configBleAlwaysAdvertise,
	configBleAdvertInterval,

	NUM_CONFIG_SETTINGS,
	NULL_CONFIG_INIT
}configSettings_t;

typedef enum {
	operate,
	calibrateImu,
	calibrateHall,
	calibrateLoadCell,

	NUM_OP_MODES,
	NULL_OP_INIT
}opModeTypes_t;

typedef enum{
	freq1hz,
	freq10hz,
	freq50hz,
	freq100hz,
	freq200hz,
	freq300hz,
	freq400hz,

	NUM_FREQ,
	NULL_FREQ_INIT
}frequencySettings_t;

typedef enum {
	triggerTime,
	triggerShake,
	triggerBoth,

	NUM_TRIGGER,
	NULL_TRIGGER_INIT
}wakeTriggerTypes_t;

typedef enum {
	sensorNull,
	sensorAnalog,
	sensorDigital,
	sensorHall,
	sensorLongRangeHall,
	sensorPressure,
	sensorTemperature,
	sensorPressureTemp,
	sensorDualPressure,
	sensorDualTemp,
	sensorDualPressureTemp,
	sensorLoadCell,
	sensorEtape,
	sensorLidar,
	sensorAuxLED,
	sensorLiquidLvl,
	sensorBluebit, // TODO: Rename this struct to peripheral types?

	NUM_SENSOR_TYPE,
	NULL_SENSOR_INIT
}extSensorTypes_t;

typedef enum {
	thresholdAbsolute,
	thresholdRelative,

	NUM_THRES_SRC,
	NULL_THRES_SRC
}thresholdTypes_t;

typedef enum {
	startStudyPowerOn,
	startStudyButton,

	NUM_STUDY_TRIG,
	NULL_STUDY_TRIG
}startStudyTypes_t;

typedef enum{
	settingDisable,
	settingEnable,

	NUM_ENABLE_STATES,
	NULL_ENABLE_INIT
}configEnableState_t;

typedef enum{
	protectModeOff,
	protectModeTrigger,
	protectModeShakes,

	NUM_PROTECT_MODES,
	NULL_PROTECT_INIT
}configProtectMode_t;

typedef enum{
	orientVertical,
	orientHorizontal,
	orientUpward,
	orientDownward,
	orientForward,
	orientBackward,
	orientLeft,
	orientRight,

	NUM_ORIENTATION,
	NULL_ORIENTATION_INIT
}orientationSettings_t;

typedef enum{
	xAxisId,
	yAxisId,
	zAxisId
}axisRemapId_t;

typedef enum{
	axisPositive,
	axisNegative
}axisRemapSign_t;

typedef enum {
	clockSpeed80Mhz,
	clockSpeed60Mhz,
	clockSpeed40Mhz,
	clockSpeed26Mhz,
	clockSpeed16Mhz,
	clockSpeed8Mhz,
	clockSpeed4Mhz,
	
	NUM_CLOCKSPEEDS,
	NULL_CLOCKSPEED_INIT,
} clockSpeed_t;

typedef enum {
	configIoctlGetMode,
	configIoctlGetRtc,

	configIoctlGetLpAcc,
	configIoctlGetImu,
	configIoctlGetAcc,
	configIoctlGetGyr,
	configIoctlGetMag,
	configIoctlGetEuler,
	configIoctlGetQuat,
	configIoctlGetOrientation,
	configIoctlGetLed,
	configIoctlGetUart,
	configIoctlGetFreq,
	configIoctlGetWakeTrig,
	configIoctlGetStartStudyTrig,
	configIoctlGetProtectMode,
	configIoctlGetDeepSleepMode,
	configIoctlGetJ1,
	configIoctlGetJ2,
	configIoctlGetJ3,
	configIoctlGetJ4,
	configIoctlGetAnalogTrig,
	configIoctlGetThresholdType,
	configIoctlGetTrigThreshold,
	configIoctlGetBatteryOutput,
	configIoctlGetTemperatureOutput,

	configIoctlGetFixedSleep,
	configIoctlGetFixedWakeupDuration,
	configIoctlGetWakeDur,
	configIoctlGetNmSleep,
	configIoctlGetDeepSleepDur,
	configIoctlGetWakeLimit,
	configIoctlGetWakeTick,
	configIoctlGetWakeReset,
	configIoctlGetSleepDur,
	configIoctlGetDataSyncCounter,
	configIoctlGetFormatFileSys,
	configIoctlGetUsbSerialMode,
	configIoctlGetBinaryFileMode,
	configIoctlGetClockSpeed,
	configIoctlGetBluebitEnabled,

	configIoctlGetWakeSummaryEnabled,
	configIoctlGetTrigCountEnabled,
	
	configIoctlGetBatteryVoltage,
	configIoctlGetFileSize,

	configIoctlGetBleAdvertOnTime,
	configIoctlGetBleAdvertOffTimeMin,
	configIoctlGetBleAdvertOffTimeMax,
	configIoctlGetBleAlwaysAdvertise,
	configIoctlGetBleAdvertInterval,
	
	configIoctlGetConfigError,
	//==========================

	NUM_CONFIG_IOCTL
} configIoctl_t;

typedef struct{
	//Magic Number
	uint32_t headID;

	//Important user
	opModeTypes_t opMode;
	rtcDataHandler_t rtcStartTime;

	//User
	configEnableState_t lpAccEnable;
	configEnableState_t imuEnable;
	configEnableState_t accEnable;
	configEnableState_t gyrEnable;
	configEnableState_t magEnable;
	configEnableState_t eulerEnable;
	configEnableState_t quatEnable;
	orientationSettings_t boardOrientation[3];
	configEnableState_t debugLED;
	configEnableState_t debugUART;
	frequencySettings_t frequency;
	wakeTriggerTypes_t wakeTrigger;
	startStudyTypes_t startStudyTrigger;
	configProtectMode_t protectedMode;
	configEnableState_t deepSleepMode;

	extSensorTypes_t j1Connector;
	extSensorTypes_t j2Connector;
	extSensorTypes_t j3Connector;
	extSensorTypes_t j4Connector;
	connectors_t analogTrigger;
	thresholdTypes_t thresholdType;
	uint16_t triggerThreshold;
	configEnableState_t batteryOutput;
	configEnableState_t temperatureOutput;

	configEnableState_t wakeSummary;
	configEnableState_t triggerCountSummary;

	//Pro user
	uint16_t fixedTimeSleep;
	uint16_t fixedTimeWakeupDuration;

	uint16_t wakeOnShakeAwakeDuration;
	uint16_t noMotionBeforeSleep;
	uint16_t bogusWakeupLimit;
	uint16_t bogusWakeupTick;
	uint16_t bogusWakeupReset;
	uint16_t protectedSleepDuration;

	rtcDataHandler_t deepSleepDuration;

	uint16_t dataSyncCounter;
	configEnableState_t formatFileSys;
	configEnableState_t usbSerialMode;
	configEnableState_t binaryFileMode;
	clockSpeed_t clockSpeed;

	float batteryShutDownVoltage;
	uint32_t fileSize;
	
	uint16_t bleAdvertOnTime;
	uint16_t bleAdvertOffTimeMin;
	uint16_t bleAdvertOffTimeMax;
	configEnableState_t bleAlwaysAdvertise;
	uint16_t bleAdvertInterval;

	//Magic Number
	uint32_t tailID;
} configData_t;

// Exported constants --------------------------------------------------------
#define X_AXIS_REG_POS 0
#define Y_AXIS_REG_POS 2
#define Z_AXIS_REG_POS 4
#define X_SIGN_REG_POS 2
#define Y_SIGN_REG_POS 1
#define Z_SIGN_REG_POS 0
// Exported objects ----------------------------------------------------------

// Exported functions --------------------------------------------------------

///  @brief Initializes the Configuration software unit
///  @details The Config init will attempt to read the config file located in
/// 		  the file system.
///  @return StatusOk
status_t Config_Init(void);

///  @brief Read the configuration data from the Config file
///  @return StatusOk
status_t Config_ReadFile(void);

///  @brief Handle Config ioctl commands
///  @param [in] ioctlCode - Command Id for io function
///  @param [out] outValue - Pointer to a variable that will hold return data from io command
///  @return StatusOk
status_t Config_Ioctl(configIoctl_t ioctlCode, uint8_t* outValue);

///  @brief Remap the bno055 axis based on data from the config file
///  @param [in] pBuffer -Input buffer containing the board orientation
///  @param [out] outBuff - Output buffer containing orientation values
///  @return StatusOk
status_t Config_RemapBoardAxis(orientationSettings_t *pBuffer, uint8_t* outBuff);

#endif // __CONFIG_SU_H

/// SAEC Kinetic Vision, Inc. ----------- END OF FILE


