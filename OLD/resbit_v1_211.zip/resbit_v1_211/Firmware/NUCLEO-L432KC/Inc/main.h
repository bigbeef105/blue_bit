/**
  @file       main.h

  @copyright  (C) 2019 Kinetic Vision, Cincinnati Ohio.
               This software is property of SAEC Kinetic Vision, Inc
               and is considered confidential.

  @brief      main software unit "H" file.

  @author     Sherman Couch

  @defgroup   mainName Traditional C program, entry point and root system halt handling.

  Configuration History
  =====================

  Config Item    | Value
  -------------- | -----
  Config #       | NA
  Revision       | NA
  Revised, Date  | NA
  QA, Date       | NA
  Approved, Date | NA
  Released, Date | NA

  Significant Modification History (Most recent at top)
  =====================================================

  Date         | Initials | Details
  ------------ | -------- | -------
  22 Jul 2019  | SC       | Using original, brought into standard template.

  Theory of Operation
  ===================
  TBD

  */

// Define to prevent recursive inclusion -------------------------------------
#ifndef __MAIN_H
#define __MAIN_H

// Exported macro ------------------------------------------------------------

///  @brief   Interface macro to the (single and only) last chance halt loop.
///  @details Clients will use this macro as though it were a function. However,
///           "under the covers" it is actually a stackless implementation.  The
///           intent is to be able to use this function to also "catch" stack faults.
///  @return  This interface never returns control.
#if 0
///  @brief This label is used by the "Main_Halt() macro".
Main_HaltLoop label;
#define Main_Halt(__STATUS__) asm volatile (
             "mov r0, __STATUS__ \n\t"\
             "B Main_HaltLoop\n\t");
#endif

// Exported types ------------------------------------------------------------

// Exported constants --------------------------------------------------------

// Exported objects ----------------------------------------------------------

// Exported functions --------------------------------------------------------
///  @brief  Handles a system halt (unable to continue).
///  @return This function does not return.
void Main_Halt(void);

///  @brief  Handles a system Error.
///  @return This function does not return.
void Error_Handler(void);

#endif // __MAIN_H

/// SAEC Kinetic Vision, Inc. ----------- END OF FILE

