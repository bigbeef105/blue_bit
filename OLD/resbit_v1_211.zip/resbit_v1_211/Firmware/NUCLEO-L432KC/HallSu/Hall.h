/**
  @file       Hall.h

  @copyright  (C) 2019 Kinetic Vision, Cincinnati Ohio.
               This software is property of SAEC Kinetic Vision, Inc
               and is considered confidential.

  @brief      Template software unit "H" file.

  @author     Parker Kamer

  @defgroup   HallSu

  Configuration History
  =====================

  Config Item    | Value
  -------------- | -----
  Config #       | NA
  Revision       | NA
  Revised, Date  | NA
  QA, Date       | NA
  Approved, Date | NA
  Released, Date | NA

  Significant Modification History (Most recent at top)
  =====================================================

  Date         | Initials | Details
  ------------ | -------- | -------
  13 Dec 2019  | PK       | Original

  Theory of Operation
  ===================
  Used to read an analog signal supplied by a hall effect sensor.

  */

// Define to prevent recursive inclusion -------------------------------------
#ifndef __HALL_H
#define __HALL_H

// Exported macro ------------------------------------------------------------

// Exported types ------------------------------------------------------------
typedef struct {
	float actualState1;
	float actualState2;
	float scaledState1;
	float scaledState2;
} hallCalibration_t;

// Exported constants --------------------------------------------------------

// Exported objects ----------------------------------------------------------

// Exported functions --------------------------------------------------------

/// @brief Initialize a hall sensor
/// @param args[in] connector - Id number of the connector
/// @param args[in] longRange - true if this is a long range hall sensor
/// @return StatusOk
status_t Hall_Init(connectors_t connector, bool longRange);

/// @brief Wakes hall sensor from sleep (if applicable)
status_t Hall_EnableRead(connectors_t connector);

/// @brief Returns hall sensor to sleep (if applicable)
status_t Hall_DisableRead(connectors_t connector);

/// @brief Apply a user defined scale to remap the output data
/// @param args[in] connector - Id number of the connector
/// @param args[in] input - raw analog data
/// @param args[out] output - scaled output data
/// @return StatusOk
status_t Hall_ScaleData(connectors_t connector, uint16_t input, float* output);

/// @brief Get the calibration data for a specific hall sensor
/// @param args[in] connector - Id number of the connector
/// @param args[out] data - Calibration data for the hall sensor
/// @return StatusOk
status_t Hall_GetCalib(connectors_t connector, hallCalibration_t* data);

/// @brief Calibrate the hall sensor
/// @return StatusOk
status_t Hall_CalibrateMode(void);

#endif // __HALL_H

/// SAEC Kinetic Vision, Inc. ----------- END OF FILE


