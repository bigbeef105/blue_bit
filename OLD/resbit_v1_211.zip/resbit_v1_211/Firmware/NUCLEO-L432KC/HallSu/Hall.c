/**
  @file       Hall.c

  @copyright  (C) 2019 Kinetic Vision, Cincinnati Ohio.
               This software is property of SAEC Kinetic Vision, Inc
               and is considered confidential.

  @brief      Hall sensor software unit "C" file.

  @author     Parker Kamer

  @ingroup    HallSu

  Configuration History
  =====================

  Config Item    | Value
  -------------- | -----
  Config #       | NA
  Revision       | NA
  Revised, Date  | NA
  QA, Date       | NA
  Approved, Date | NA
  Released, Date | NA

  Significant Modification History (Most recent at top)
  =====================================================

  Date         | Initials | Details
  ------------ | -------- | -------
  13 Dec 2019  | PK       | Original

  Theory of Operation
  ===================
  TBD

*/

// Includes ------------------------------------------------------------------

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <math.h>

#include "stm32l4xx_hal.h"
#include "../Middlewares/Third_Party/FatFs/src/ff.h"
#include "../StatusSu/Status.h"
#include "../RtcSu/rtc.h"
#include "../ConfigSu/Config.h"
#include "../AdcSu/adc.h"
#include "../PowerSu/power.h"
#include "../GpioSu/Gpio.h"
#include "../UserInterfaceSu/UserInterface.h"
#include "Hall.h"
#include "fatfs.h"
#include "../UtilitySu/Utility.h"

// Private macros ------------------------------------------------------------

// Private constants ---------------------------------------------------------

// Private types -------------------------------------------------------------
typedef enum {
    hallSensorNone,
    hallSensorNormal,
    hallSensorLongRange,
} hallSensorTypes_t;

typedef enum{
	hallSensorConnector,
	hallSensorActualMin,
	hallSensorActualMax,
	hallSensorScaledMin,
	hallSensorScaledMax,

	NUM_HALL_SENSOR_SETTINGS
}hallSensorSettings_t;

typedef struct{
	char* pValue;
	hallSensorSettings_t mode;
}hallSensorValues_t;

// Private constants ---------------------------------------------------------
static const hallSensorValues_t HallSensorArray[NUM_HALL_SENSOR_SETTINGS] = {
    {
        .pValue = "Connector",
        .mode = hallSensorConnector
    },
    {
        .pValue = "Actual Min",
        .mode = hallSensorActualMin
    },
    {
        .pValue = "Actual Max",
        .mode = hallSensorActualMax
    },
    {
        .pValue = "Scaled Min",
        .mode = hallSensorScaledMin
    },
    {
        .pValue = "Scaled Max",
        .mode = hallSensorScaledMax
    },
};


// Private variables ---------------------------------------------------------
static bool CalibFileRead = false;
static hallSensorTypes_t ActiveHallArray[NUM_CONNECTORS] = { hallSensorNone };
static hallCalibration_t HallCalibration[NUM_CONNECTORS];

static bool initialized;

// Private function prototypes -----------------------------------------------
static status_t writeCalibFile(void);
static status_t readCalibFile(void);

// Private function bodies ---------------------------------------------------
static status_t writeCalibFile(void)
{
	status_t status = StatusOk;
	FATFS* USBDISKFatFs;
	FIL* calibFile;
	FRESULT res;
	char buff[50];
	UINT stringSize = 0;
	UINT bw = 0;
	char floatString[10];

	USBDISKFatFs = FATFS_GetFileSystem();
	calibFile = FATFS_GetConfigFile();

	res = f_mount(USBDISKFatFs, "", 1);
	if( FR_OK != res){
		status = StatusFatFsMount;
	}
	//Remove the previous file
	//res = f_unlink("hall.txt");

	//Create a new file
	if (StatusOk == status) {
		res = f_open(calibFile, "hall.txt", FA_CREATE_ALWAYS | FA_WRITE);
		if (FR_OK != res) {
			status = StatusFatFsOpen;
		}

		for(int i = 0; i < NUM_CONNECTORS; i++){
			if(ActiveHallArray[i])
			{
				memset(buff,0x00,50);
				uint8_t connectorName[2];
				GPIO_GetNameFromConnector((connectors_t)i, connectorName, sizeof(connectorName));
				stringSize = sprintf(buff,"Connector=%s \r\n",connectorName);
				res = f_write(calibFile, buff,stringSize,&bw); //res = f_puts(buff,&calibFile);

				memset(buff,0x00,50);
				memset(floatString,0x00,10);
				Utility_FtoaBase10(HallCalibration[i].actualState1, floatString, fPrecision_1);
				stringSize = sprintf(buff,"Actual Min=%s \r\n",floatString);
				res = f_write(calibFile, buff,stringSize,&bw); //res = f_puts(buff,&calibFile);

				memset(buff,0x00,50);
				memset(floatString,0x00,10);
				Utility_FtoaBase10(HallCalibration[i].actualState2, floatString, fPrecision_1);
				stringSize = sprintf(buff,"Actual Max=%s \r\n",floatString);
				res = f_write(calibFile, buff,stringSize,&bw); //res = f_puts(buff,&calibFile);

				memset(buff,0x00,50);
				memset(floatString,0x00,10);
				Utility_FtoaBase10(HallCalibration[i].scaledState1, floatString, fPrecision_1);
				stringSize = sprintf(buff,"Scaled Min=%s \r\n",floatString);
				res = f_write(calibFile, buff,stringSize,&bw); //res = f_puts(buff,&calibFile);

				memset(buff,0x00,50);
				memset(floatString,0x00,10);
				Utility_FtoaBase10(HallCalibration[i].scaledState2, floatString, fPrecision_1);
				stringSize = sprintf(buff,"Scaled Max=%s \r\n",floatString);
				res = f_write(calibFile, buff,stringSize,&bw); //res = f_puts(buff,&calibFile);
			}
		}

		res = f_close(calibFile);
		res = f_mount(0, "", 1);
	}

	return status;
}

static status_t readCalibFile(void)
{
	status_t status = StatusOk;

	FATFS* USBDISKFatFs;
	FIL* calibFile;
	char buff[50];
	uint8_t buffIndex=0;
	connectors_t connector;
	static bool fileRead = false;

	USBDISKFatFs = FATFS_GetFileSystem();
	calibFile = FATFS_GetConfigFile();

	if(!fileRead){
		f_mount(USBDISKFatFs, "", 1);

		if(FR_OK == f_stat("hall.txt", NULL)){
			f_open(calibFile, "hall.txt", FA_OPEN_EXISTING | FA_READ);
			while(1){
				if( NULL != f_gets(buff ,sizeof(buff), calibFile))
				{
					for( int j = 0; j < NUM_HALL_SENSOR_SETTINGS; j++)
					{
						if(0 == strncmp(buff, HallSensorArray[j].pValue, strlen( HallSensorArray[j].pValue)))
						{
							for(buffIndex = 0; buffIndex < sizeof(buff); buffIndex++){
								if( buff[buffIndex] == '='){
									buffIndex++;
									switch( HallSensorArray[j].mode){
										case hallSensorConnector:
										    status = GPIO_GetConnectorFromName(buff + buffIndex, 
										            sizeof(buff) - buffIndex, &connector);
											break;
										case hallSensorActualMin:
											HallCalibration[connector].actualState1 = atof(buff+buffIndex);
											break;
										case hallSensorActualMax:
											HallCalibration[connector].actualState2 = atof(buff+buffIndex);
											break;
										case hallSensorScaledMin:
											HallCalibration[connector].scaledState1 = atof(buff+buffIndex);
											break;
										case hallSensorScaledMax:
											HallCalibration[connector].scaledState2 = atof(buff+buffIndex);
											break;
										default:
											break;
									}
									break;
								}
							}
							break;
						}
					}
				}
				else{
					break;
				}
			}

			f_close(calibFile);

		}
		else{
			status = StatusFatFsOpen;
		}
		f_mount(0, "", 1);
		fileRead = true;
	}

	return status;
}

// Public functions bodies ---------------------------------------------------
status_t Hall_Init(connectors_t connector, bool longRange) {
	status_t status = StatusOk;

	GPIO_InitTypeDef gpioInit = { GPIO_GetConnectorGPIOPin(connector), GPIO_MODE_OUTPUT_PP, GPIO_NOPULL };
	GPIO_InitTypeDef analogInit = { GPIO_GetConnectorAnalogPin(connector), GPIO_MODE_ANALOG_ADC_CONTROL, GPIO_NOPULL };
	if (longRange) {
	    HAL_GPIO_Init(GPIO_GetConnectorGPIOPort(connector), &gpioInit);
        HAL_GPIO_Init(GPIO_GetConnectorAnalogPort(connector), &analogInit);
	    ActiveHallArray[connector] = hallSensorLongRange;
	} else {
	    HAL_GPIO_Init(GPIO_GetConnectorGPIOPort(connector), &gpioInit);
        HAL_GPIO_Init(GPIO_GetConnectorAnalogPort(connector), &analogInit);
	    ActiveHallArray[connector] = hallSensorNormal;
	}
	
	status = Hall_DisableRead(connector); // make sure sensor is powered off
#ifndef SWO_PROFILE_BUILD
	if (!CalibFileRead) {
	    if (StatusOk == readCalibFile()) {
	        CalibFileRead = true;
	    }
	}
#endif // SWO_PROFILE_BUILD

	initialized = true;

	return status;
}

status_t Hall_EnableRead(connectors_t connector)
{
	HAL_GPIO_WritePin(GPIO_GetConnectorGPIOPort(connector), 
			GPIO_GetConnectorGPIOPin(connector), GPIO_PIN_SET);
    
    return StatusOk;
}

status_t Hall_DisableRead(connectors_t connector)
{
	HAL_GPIO_WritePin(GPIO_GetConnectorGPIOPort(connector), 
			GPIO_GetConnectorGPIOPin(connector), GPIO_PIN_RESET);
    
    return StatusOk;
}

status_t Hall_ScaleData(connectors_t connector, uint16_t input, float* output){
	status_t status = StatusOk;
	float percent = 0.0;
	float rawAnalog = input;

	//Apply offset to raw analog value
	if (HallCalibration[connector].actualState2 > HallCalibration[connector].actualState1)
	{
		if (rawAnalog < HallCalibration[connector].actualState1){
			rawAnalog = HallCalibration[connector].actualState1;
		}
		else if (rawAnalog > HallCalibration[connector].actualState2){
			rawAnalog = HallCalibration[connector].actualState2;
		}

		rawAnalog = rawAnalog - HallCalibration[connector].actualState1;

		percent = rawAnalog / (HallCalibration[connector].actualState2 - HallCalibration[connector].actualState1);
	}
	else
	{
		if (rawAnalog < HallCalibration[connector].actualState2){
			rawAnalog = HallCalibration[connector].actualState2;
		}
		else if (rawAnalog > HallCalibration[connector].actualState1){
			rawAnalog = HallCalibration[connector].actualState1;
		}

		rawAnalog = HallCalibration[connector].actualState1 - rawAnalog;

		percent = rawAnalog / (HallCalibration[connector].actualState1 - HallCalibration[connector].actualState2);
	}

	rawAnalog = (HallCalibration[connector].scaledState2 - HallCalibration[connector].scaledState1) * percent;
	rawAnalog += HallCalibration[connector].scaledState1;

	*output = rawAnalog;

	return status;
}

status_t Hall_GetCalib(connectors_t connector, hallCalibration_t* data)
{
	status_t status = StatusOk;

	*data = HallCalibration[connector];

	return status;
}

status_t Hall_CalibrateMode(void)
{
	status_t status = StatusOk;
	memBlock32_t sample;

	//Run a for loop of hall sensors present on config file
	if(initialized){
		for(int i = 0; i < NUM_CONNECTORS; i++){
			if(hallSensorNone != ActiveHallArray[i])
			{
				// Wait for button
				UserInterface_WaitForButton();

				// Calibrate position 1
				status = Status_Preserve(status, 
						ADC_ReadConnectorBlocking((connectors_t)i, false, 10, 1000, &sample));
				HallCalibration[i].actualState1 = (float)sample.uint32; // this value is stores as an int -- do not deref as float!

				// Blink LED
				status = Status_Preserve(status, UserInterface_BlinkLed(ledPatternCalibrateStep));

				// Wait for button
				UserInterface_WaitForButton();

				// Calibrate position 2
				status = Status_Preserve(status, 
						ADC_ReadConnectorBlocking((connectors_t)i, false, 10, 1000, &sample));
				HallCalibration[i].actualState2 = (float)sample.uint32; // this value is stores as an int -- do not deref as float!
				
				// Write scaled states
				HallCalibration[i].scaledState1 = 0.0f;
				HallCalibration[i].scaledState2 = 1.0f;
				
				// Blink LED
				status = Status_Preserve(status, UserInterface_BlinkLed(ledPatternCalibrateStep));
			}
		}
		
		writeCalibFile();
	}

	return status;
} //Hall_CalibrateMode
/// SAEC Kinetic Vision, Inc. ----------- END OF FILE


