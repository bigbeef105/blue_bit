/**
  @file       ProtocolHandler.c

  @copyright  (C) 2020 Kinetic Vision, Cincinnati Ohio.
               This software is property of SAEC Kinetic Vision, Inc
               and is considered confidential.

  @brief      ProtocolHandler software unit "C" file.

  @author     Andrew Loebs

  @ingroup    ProtocolHandlerSoftwareUnit

  Configuration History
  =====================

  Config Item    | Value
  -------------- | -----
  Config #       | NA
  Revision       | NA
  Revised, Date  | NA
  QA, Date       | NA
  Approved, Date | NA
  Released, Date | NA

  Significant Modification History (Most recent at top)
  =====================================================

  Date         | Initials | Details
  ------------ | -------- | -------
  27 Jan 2020  | ASL      | Original

  Theory of Operation
  ===================
  Handles Resbit/Bluebits coms logic

*/

// Includes ------------------------------------------------------------------
#include "ProtocolHandler.h"

#include <string.h> // memcpy

#include "../SwUnitControlSu/SwUnitControl.h" // SwUnitControl_WriteStatus()
#include "../PacketSu/Packet.h" // Packet_* functions, packet_t, PACKET_HEADER_LEN
#include "../MessagerSu/Messager.h" // Messager_* functions
#include "../SysTimeSu/SysTime.h" // SysTime_* functions
#include "../ProtocolHalSu/ProtocolHal.h" // ProtocolHal_* functions

// Private macros ------------------------------------------------------------
#define returnStatus(__status__,__source__) SwUnitControl_WriteStatus(eSucProtocolHandlerSu,__source__,__status__,__LINE__);

// Private constants ---------------------------------------------------------

// Private types -------------------------------------------------------------
typedef enum {
    ProtocolStateIdle = 0,
    ProtocolStateReceive,
    ProtocolStateRespond,
    ProtocolStateSend,
    ProtocolStateGetResponse,
} protocolState_t;

typedef struct {
    uint8_t contents[MESSAGE_MAX_LEN];
    int tailIndex;
    int lastTailIndex;
    int numPackets;
    int currentPacketNum;
} messageData_t;

// Private constants ---------------------------------------------------------

// Private function prototypes -----------------------------------------------
static status_t handleIdleTick();
static status_t handleReceiveTick();
static status_t handleRespondTick();
static status_t handleSendTick();
static status_t handleGetResponseTick();

static status_t handlePacketReceive();
static status_t handleResponseReceive();

static status_t generatePacket(messageData_t * message, packet_t * packet);

static void resetMessageData(messageData_t * message);
static bool checkTimeout();
static void resetAndReturnToIdle();
static bool checkMessageDelay();
static void clearMessageDelay();
static void setMessageDelay(uint32_t delayMs);

// Private variables ---------------------------------------------------------
static bool initialized = false;
static protocolState_t state = ProtocolStateIdle;

static messageData_t receiveBuffer;
static messageData_t sendBuffer;
static packet_t receivePacket;
static packet_t sendPacket;
static bool sendInProgress = false;

static uint8_t responseCode = 0;
static bool responseCodeSet = false;
static response_t response;

static uint32_t timeoutStart = 0;
static uint32_t messageDelayStart = 0;
static uint32_t messageDelayDuration = 0;
static int writeRetryCount = 0;

// Private function bodies ---------------------------------------------------
static status_t handleIdleTick()
{
    status_t status = StatusOk;

    if (checkMessageDelay()) {
        if (ProtocolHal_HasPacket()) {
            resetMessageData(&receiveBuffer);
            state = ProtocolStateReceive;

            timeoutStart = SysTime_GetMs();
        } else if (sendInProgress) {
            status = ProtocolHal_WritePacket(&sendPacket);

            state = ProtocolStateSend;
            timeoutStart = SysTime_GetMs();
        }
    }

    return status;
}

static status_t handleReceiveTick()
{
    status_t status = StatusOk;

    // Wait for full packet
    if (ProtocolHal_HasPacket()) {
        status = handlePacketReceive();

        responseCode = Packet_GetResponseCode(status);
        responseCodeSet = true;

        state = ProtocolStateRespond;
        timeoutStart = SysTime_GetMs();

    } else if (checkTimeout()) {
        resetAndReturnToIdle();
        status = StatusComsReceiveTimeout;
    }

    return status;
}

static status_t handleRespondTick()
{
    status_t status = StatusOk;

    if (responseCodeSet) {
        status = Packet_GenerateResponse(&response, responseCode);

        if (Status_IsOk(status)) {
            status = ProtocolHal_WriteResponse(&response);
        }
        responseCodeSet = false;
    } else if (ProtocolHal_IsWriteDone()) {
        // Respond finished
        if (receiveBuffer.numPackets == (receiveBuffer.currentPacketNum + 1)) {
            // Message done
            state = ProtocolStateIdle;
            status = Messager_HandleMessage(&receiveBuffer.contents[0],
                                           receiveBuffer.tailIndex);
            setMessageDelay(COMS_MESSAGE_INTERVAL);
        } else {
            state = ProtocolStateReceive;
            timeoutStart = SysTime_GetMs();
        }
    } else if (checkTimeout()) {
        resetAndReturnToIdle();
        status = StatusComsReceiveTimeout;
    }

    return status;
}

static status_t handleSendTick()
{
    status_t status = StatusOk;

    if (ProtocolHal_IsWriteDone()) {
        timeoutStart = SysTime_GetMs();
        state = ProtocolStateGetResponse;
    } else if (checkTimeout()) {
        // TODO: Message done callback
        resetAndReturnToIdle();
        status = StatusComsSendTimeout;
    }

    return status;
}

static status_t handleGetResponseTick()
{
    status_t status = StatusOk;

    if (ProtocolHal_HasResponse()) {
        status = handleResponseReceive();
        if (Status_IsOk(status)) {
            if (sendBuffer.numPackets > (sendBuffer.currentPacketNum + 1)) {
                status = generatePacket(&sendBuffer, &sendPacket);
                if (Status_IsOk(status)) {
                    ProtocolHal_WritePacket(&sendPacket);

                    timeoutStart = SysTime_GetMs();
                    state = ProtocolStateSend;
                } else {
                    resetAndReturnToIdle();
                    setMessageDelay(COMS_TIMEOUT_MS);
                }
            } else {
                resetAndReturnToIdle();
                setMessageDelay(COMS_MESSAGE_INTERVAL);
            }
        } else if (StatusComsResponseError == status) {
            resetAndReturnToIdle();
            setMessageDelay(COMS_TIMEOUT_MS);
        } else {
            // check retry
            if (writeRetryCount == COMS_RETRY_LIMIT) {
                resetAndReturnToIdle();
                setMessageDelay(COMS_TIMEOUT_MS);
            } else {
                ProtocolHal_WritePacket(&sendPacket);
                writeRetryCount++;

                timeoutStart = SysTime_GetMs();
                state = ProtocolStateSend;
            }
        }
    } else if (checkTimeout()) {
        resetAndReturnToIdle();
        status = StatusComsSendTimeout;
    }

    return status;
}

static status_t handlePacketReceive()
{
    status_t status = StatusOk;

    size_t packetLen = 0;
    status = ProtocolHal_GetPacket(&receivePacket, &packetLen);

    // Get packet header info
    int lastPacketNum = receiveBuffer.currentPacketNum;
    if (Status_IsOk(status)) {
        status = Packet_ParseHeader(&receivePacket, packetLen);
    }
    if (Status_IsOk(status)) {
        // Copy packet info to message data
        receiveBuffer.numPackets = receivePacket.numPackets;
        receiveBuffer.currentPacketNum = receivePacket.packetNum;
        // Validate packet order
        if (lastPacketNum == receiveBuffer.currentPacketNum) {
            receiveBuffer.tailIndex = receiveBuffer.lastTailIndex;
        } else if ((lastPacketNum + 1) != receiveBuffer.currentPacketNum) {
            status = StatusComsPacketOrder;
        }
    }
    // Get packet body
    if (Status_IsOk(status)) {
        status = Packet_ParseBody(&receiveBuffer.contents[receiveBuffer.tailIndex],
                                  MESSAGE_MAX_LEN - receiveBuffer.tailIndex,
                                  &receivePacket);
    }
    // Update message info
    if (Status_IsOk(status)) {
        receiveBuffer.tailIndex += receivePacket.dataLen;
    }

    return status;
}

static status_t handleResponseReceive()
{
    status_t status = StatusOk;

    status = ProtocolHal_GetResponse(&response);
    if (Status_IsOk(status)) {
        status = Packet_ParseResponse(&response);
    }

    return status;
}

static status_t generatePacket(messageData_t * message, packet_t * packet)
{
    status_t status = StatusOk;

    size_t packetLen = message->tailIndex - message->lastTailIndex;
    packetLen = (packetLen > PACKET_MAX_DATA_LEN) ?
            PACKET_MAX_DATA_LEN : packetLen;

    message->currentPacketNum++;
    status = Packet_Pack(packet,
                               &message->contents[message->lastTailIndex],
                               packetLen,
                               message->numPackets,
                               message->currentPacketNum);
    message->lastTailIndex += packetLen; // update tail

    return status;
}

static void resetMessageData(messageData_t * message)
{
    message->currentPacketNum = -1;
    message->tailIndex = 0;
    message->lastTailIndex = 0;
}

static bool checkTimeout()
{
    return SysTime_IsElapsed(timeoutStart, COMS_TIMEOUT_MS);
}

static void resetAndReturnToIdle()
{
    ProtocolHal_Reset();
    clearMessageDelay();

    state = ProtocolStateIdle;
    sendInProgress = false;
}

static bool checkMessageDelay()
{
    return SysTime_IsElapsed(messageDelayStart, messageDelayDuration);
}

static void clearMessageDelay()
{
    messageDelayStart = 0;
    messageDelayDuration = 0;
}

static void setMessageDelay(uint32_t delayMs)
{
    messageDelayStart = SysTime_GetMs();
    messageDelayDuration = delayMs;
}

// Public functions bodies ---------------------------------------------------
status_t ProtocolHandler_Init()
{
    status_t status = StatusOk;
    if (initialized) {
        status = StatusAlreadyInitialized;
    }
    if (Status_IsOk(status)) {
        clearMessageDelay();
        state = ProtocolStateIdle;
        initialized = true;
    }

    return returnStatus(status, eSucInitStatus);
}

status_t ProtocolHandler_Tick()
{
    status_t status = StatusOk;

    switch (state) {
        case ProtocolStateIdle:
            status = handleIdleTick();
            break;
        case ProtocolStateReceive:
            status = handleReceiveTick();
            break;
        case ProtocolStateRespond:
            status = handleRespondTick();
            break;
        case ProtocolStateSend:
            status = handleSendTick();
            break;
        case ProtocolStateGetResponse:
            status = handleGetResponseTick();
            break;
        default:
            status = StatusCodePath;
            break;
    }

    return returnStatus(status, eSucIoctlStatus);
}

status_t ProtocolHandler_SendMessage(const uint8_t * buff, size_t len)
{
    status_t status = StatusOk;

    // Input validation
    if (buff == NULL)
        status = StatusNullParameter;
    else if ((len < 1) || (len > MESSAGE_MAX_LEN))
        status = StatusBufferLength;

    if (Status_IsOk(status)) {
        // Setup message data
        resetMessageData(&sendBuffer);
        sendBuffer.numPackets = (len / PACKET_MAX_DATA_LEN) + 1;
        sendBuffer.tailIndex = len; // for send data, this will just be used to mark the end of the data
        memcpy(sendBuffer.contents, buff, len);

        status = generatePacket(&sendBuffer, &sendPacket);
    }
    if (Status_IsOk(status)) {
        sendInProgress = true;
        writeRetryCount = 0;
    }

    return returnStatus(status, eSucWriteStatus);
}

bool ProtocolHandler_IsSendReady()
{
    return !sendInProgress;
}

/// SAEC Kinetic Vision, Inc. ----------- END OF FILE
