/**
  @file       ProtocolHandler.h

  @copyright  (C) 2020 Kinetic Vision, Cincinnati Ohio.
               This software is property of SAEC Kinetic Vision, Inc
               and is considered confidential.

  @brief      ProtocolHandler software unit "H" file.

  @author     Andrew Loebs

  @defgroup   ProtocolHandlerSoftwareUnit Handles Resbit/Bluebits coms logic

  Configuration History
  =====================

  Config Item    | Value
  -------------- | -----
  Config #       | NA
  Revision       | NA
  Revised, Date  | NA
  QA, Date       | NA
  Approved, Date | NA
  Released, Date | NA

  Significant Modification History (Most recent at top)
  =====================================================

  Date         | Initials | Details
  ------------ | -------- | -------
  10 Feb 2020  | ASL      | Original

  Theory of Operation
  ===================
  Handles Resbit/Bluebits coms logic

  */

// Define to prevent recursive inclusion -------------------------------------
#ifndef __PROTOCOL_HANDLER_H
#define __PROTOCOL_HANDLER_H

#include <stdbool.h> // bool
#include <stdint.h> // int types
#include <stdio.h> // size_t

#include "../StatusSu/Status.h" // status_t

// Exported macro ------------------------------------------------------------

// Exported types ------------------------------------------------------------

// Exported constants --------------------------------------------------------
#define MESSAGE_MAX_LEN             512

// Exported objects ----------------------------------------------------------

// Exported functions --------------------------------------------------------

///  @brief Initializes the ProtocolHandler software unit
///  @return StatusOk, StatusAlreadyInitialized.
status_t ProtocolHandler_Init();

///  @brief Foreground tick method
///  @return StatusOk
status_t ProtocolHandler_Tick();

///  @brief Sends message over coms interface
///  @param args[in] buff - buffer containing message data
///  @param args[in] len - length of message data
///  @return StatusOk, StatusNullPointer, StatusInvalidSize
status_t ProtocolHandler_SendMessage(const uint8_t * buff, size_t len);

///  @brief Returns true if coms interface is ready to send message
bool ProtocolHandler_IsSendReady();


#endif // __PROTOCOL_HANDLER_H

/// SAEC Kinetic Vision, Inc. ----------- END OF FILE


