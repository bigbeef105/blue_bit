/**
 @file       Base64.c

 @copyright  (C) 2020 Kinetic Vision, Cincinnati Ohio.
 This software is property of SAEC Kinetic Vision, Inc 
 and is considered confidential.

 @brief      Base64 software unit "C" file.

 @author     aloebs

 @ingroup    Base64SoftwareUnit 

 Configuration History
 =====================

 Config Item    | Value
 -------------- | -----
 Config #       | NA
 Revision       | NA
 Revised, Date  | NA
 QA, Date       | NA
 Approved, Date | NA
 Released, Date | NA

 Significant Modification History (Most recent at top)
 =====================================================

 Date         | Initials | Details
 ------------ | -------- | -------
 Jul 8, 2020 | XX       | Original

 Theory of Operation
 ===================
 Stateful base64 encoder to allow for encoding data in chunks.

 */

// Includes ------------------------------------------------------------------
#include "Base64.h"

#include "../SwUnitControlSu/SwUnitControl.h"

// Private macros ------------------------------------------------------------
#define returnStatus(__status__,__source__) SwUnitControl_WriteStatus(eSucBase64Su,__source__,__status__,__LINE__);
// Private constants ---------------------------------------------------------
#define MIN_DEST_LEN			4
#define ENCODING_TABLE_LEN		64
#define ENCODING_INDEX_MAX		(ENCODING_TABLE_LEN - 1)

#define PADDING_BYTE			'='

// Private types -------------------------------------------------------------

// Private function prototypes -----------------------------------------------

// Private constants ---------------------------------------------------------
static const uint8_t encodingTable[ENCODING_TABLE_LEN] = { 'A', 'B', 'C', 'D',
		'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R',
		'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', 'a', 'b', 'c', 'd', 'e', 'f',
		'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't',
		'u', 'v', 'w', 'x', 'y', 'z', '0', '1', '2', '3', '4', '5', '6', '7',
		'8', '9', '+', '/' };

// Private variables ---------------------------------------------------------

// Private function bodies ---------------------------------------------------

// Public functions bodies ---------------------------------------------------
status_t Base64_EncoderStart(base64Encoder_t * encoder, uint8_t * dest,
		uint16_t destLen)
{
	status_t status = StatusOk;
	// Validate input
	if (!encoder || !dest)
		status = StatusNullParameter;
	else if (destLen < MIN_DEST_LEN)
		status = StatusBufferLength;

	// Initialize encoder
	if (StatusOk == status) {
		encoder->_dest = dest;
		encoder->_destLen = destLen;
		encoder->_index = 0;
		encoder->_incomplete = 0;
	}

	return returnStatus(status, eSucInitStatus);
}

status_t Base64_EncoderAddChunk(base64Encoder_t * encoder, uint8_t * src,
		uint16_t len)
{
	status_t status = StatusOk;
	// Validate input
	if (!encoder || !src)
		status = StatusNullParameter;
	else if (len < 1)
		status = StatusBufferLength;

	if (StatusOk == status) {
		int srcIndex = 0;
		int destIndex = (encoder->_index / 3) * 4;
		uint32_t triple = encoder->_incomplete;
		while ((srcIndex < len) && (StatusOk == status)) {
			switch (encoder->_index % 3) {
				case 0:
					triple |= (src[srcIndex++] << 16) & 0xFF0000;
					break;
				case 1:
					triple |= (src[srcIndex++] << 8) & 0x00FF00;
					break;
				case 2:
					// Update & write the triple
					// If dest index is out of room, write bad status which will exit
					if ((destIndex + 4) >= encoder->_destLen) {
						status = StatusBufferLength;
					} else {
						// Finish the 24-bit number
						triple |= src[srcIndex++];
						// Write 4 bytes to dest
						encoder->_dest[destIndex++] = encodingTable[(triple >> 18) & ENCODING_INDEX_MAX];
						encoder->_dest[destIndex++] = encodingTable[(triple >> 12) & ENCODING_INDEX_MAX];
						encoder->_dest[destIndex++] = encodingTable[(triple >> 6) & ENCODING_INDEX_MAX];
						encoder->_dest[destIndex++] = encodingTable[triple & ENCODING_INDEX_MAX];
						// Zero out triple (this is necessary if we stop here, since we write this to _incomplete)
						triple = 0;
					}
					break;
			}
			// Increment our pseudo-source-index every byte
			encoder->_index++;
		}
		// Update incomplete
		encoder->_incomplete = triple;
	}

	return returnStatus(status, eSucIoctlStatus);
}

status_t Base64_EncoderEnd(base64Encoder_t * encoder, uint16_t * bytesWritten)
{
	status_t status = StatusOk;
	// Validate input
	if (!encoder || !bytesWritten)
		status = StatusNullParameter;
	
	if (StatusOk == status) {
		// Calculate the current destination array index
		int destIndex = (encoder->_index / 3) * 4;
		// We need to write a number of bytes from the triple
		// and a number of padding bytes based on the final modulus (if not 0)
		if ((encoder->_index % 3) != 0) {
			// Make sure there's room
			if ((destIndex + 4) >= encoder->_destLen) {
				status = StatusBufferLength;
			} else {
				// In the case of modulus 1, write 2 bytes and pad 2
				if ((encoder->_index % 3) == 1) {
					encoder->_dest[destIndex++] = encodingTable[(encoder->_incomplete >> 18) & ENCODING_INDEX_MAX];
					encoder->_dest[destIndex++] = encodingTable[(encoder->_incomplete >> 12) & ENCODING_INDEX_MAX];
					encoder->_dest[destIndex++] = PADDING_BYTE;
					encoder->_dest[destIndex++] = PADDING_BYTE;
				}
				// In the case of modulus 2, write 3 bytes and pad 1
				else {
					encoder->_dest[destIndex++] = encodingTable[(encoder->_incomplete >> 18) & ENCODING_INDEX_MAX];
					encoder->_dest[destIndex++] = encodingTable[(encoder->_incomplete >> 12) & ENCODING_INDEX_MAX];
					encoder->_dest[destIndex++] = encodingTable[(encoder->_incomplete >> 6) & ENCODING_INDEX_MAX];
					encoder->_dest[destIndex++] = PADDING_BYTE;
				}
			}
		}
		// Write out the final bytes written
		*bytesWritten = destIndex;
	}
	
	return returnStatus(status, eSucIoctlStatus);
}


/// SAEC Kinetic Vision, Inc. ----------- END OF FILE
