/**
  @file       Base64.h

  @copyright  (C) 2020 Kinetic Vision, Cincinnati Ohio.
               This software is property of SAEC Kinetic Vision, Inc 
               and is considered confidential.

  @brief      Base64 software unit "H" file.

  @author     aloebs

  @defgroup   Base64SoftwareUnit

  Configuration History
  =====================

  Config Item    | Value
  -------------- | -----
  Config #       | NA
  Revision       | NA
  Revised, Date  | NA
  QA, Date       | NA
  Approved, Date | NA
  Released, Date | NA

  Significant Modification History (Most recent at top)
  =====================================================

  Date         | Initials | Details
  ------------ | -------- | -------
  Jul 7, 2020 | XX       | Original

  Theory of Operation
  ===================
  Stateful base64 encoder to allow for encoding data in chunks.

  */

// Define to prevent recursive inclusion -------------------------------------
#ifndef __BASE64_H_
#define __BASE64_H_

#include <stdint.h>

#include "../StatusSu/Status.h"

// Exported macro ------------------------------------------------------------

// Exported types ------------------------------------------------------------
typedef struct {
	uint8_t * _dest;
	uint16_t _destLen;
	uint16_t _index;
	uint32_t _incomplete;
} base64Encoder_t;
// Exported constants --------------------------------------------------------

// Exported objects ----------------------------------------------------------

// Exported functions --------------------------------------------------------

///  @brief Initializes the base64 encoder
///  @param encoder - encoder to initialize (must be allocated prior to function call)
///  @param dest - array to write encoded data to
///  @param destLen - length of dest (in bytes)
status_t Base64_EncoderStart(base64Encoder_t * encoder, uint8_t * dest, uint16_t destLen);

///  @brief Encodes a chunk into the base64 encoder's destination array
///  @note encoder must have been initialized with Base64_EncoderStart
///  @note in case of bad status return, encoder state is invalid and should not be used further
///  @param encoder - encoder to add data to
///  @param src - raw data to be encoded and added to encoder's destination array
///  @param len - length of the source array (in bytes)
status_t Base64_EncoderAddChunk(base64Encoder_t * encoder, uint8_t * src, uint16_t len);

///  @brief Adds padding bytes as needed to encoder's destination array, reports bytes written
///  @param encoder - encoder to end
///  @param bytesWritten - number of bytes written to the destination array
status_t Base64_EncoderEnd(base64Encoder_t * encoder, uint16_t * bytesWritten);

#endif // __BASE64_H_

/// SAEC Kinetic Vision, Inc. ----------- END OF FILE
