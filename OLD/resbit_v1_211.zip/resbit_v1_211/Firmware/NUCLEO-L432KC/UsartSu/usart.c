/**
  @file       usart.c

  @copyright  (C) 2019 Kinetic Vision, Cincinnati Ohio.
               This software is property of SAEC Kinetic Vision, Inc
               and is considered confidential.

  @brief      USART software unit "C" file.

  @author     Sherman Couch

  @ingroup    UsartSu

  Configuration History
  =====================

  Config Item    | Value
  -------------- | -----
  Config #       | NA
  Revision       | NA
  Revised, Date  | NA
  QA, Date       | NA
  Approved, Date | NA
  Released, Date | NA

  Significant Modification History (Most recent at top)
  =====================================================

  Date         | Initials | Details
  ------------ | -------- | -------
  22 Jul 2019  | SC       | Original

  Theory of Operation
  ===================
  Usart communication will be needed for handling console commands and responses.

*/

// Includes ------------------------------------------------------------------

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

#include "stm32l4xx_hal.h"
#include "../StatusSu/Status.h"
#include "../SwUnitControlSu/SwUnitControl.h"
#include "usart.h"

// Private function prototypes -----------------------------------------------

// Private macros ------------------------------------------------------------

// Private constants ---------------------------------------------------------

// Private types -------------------------------------------------------------

// Private constants ---------------------------------------------------------

// This macro feeds status information for tracking purposes to software unit control.
#define returnStatus(__status__,__source__) SwUnitControl_WriteStatus(eSucUsartSu,__source__,__status__,__LINE__);

// Private variables ---------------------------------------------------------
UART_HandleTypeDef huart1;
static bool initialized = false;

// Private function bodies ---------------------------------------------------

// Public functions bodies ---------------------------------------------------

void HAL_UART_MspInit(UART_HandleTypeDef* uartHandle)
{

  GPIO_InitTypeDef GPIO_InitStruct = {0};
  if(uartHandle->Instance==USART1)
  {
    __HAL_RCC_USART1_CLK_ENABLE();

    /**USART1 GPIO Configuration    
    PB6     ------> USART1_TX
    PB7     ------> USART1_RX 
    */
    GPIO_InitStruct.Pin = GPIO_PIN_6|GPIO_PIN_7;
    GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
    GPIO_InitStruct.Alternate = GPIO_AF7_USART1;
    HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);
  }
}

void HAL_UART_MspDeInit(UART_HandleTypeDef* uartHandle)
{
	if(uartHandle->Instance==USART1)
	{
	  __HAL_RCC_USART1_CLK_DISABLE();

	  /**USART1 GPIO Configuration
	  PB6     ------> USART1_TX
	  PB7     ------> USART1_RX
	  */
	  HAL_GPIO_DeInit(GPIOB, GPIO_PIN_6|GPIO_PIN_7);
	}
}

status_t Usart_Write(uint8_t *pBuffer, uint16_t length)
{
	status_t status;

	status = StatusOk;

	uint32_t retryCount;

	retryCount = 0;

	while (1) {
		if (HAL_OK == HAL_UART_Transmit(&huart1, pBuffer, length, 1000)) {
			break;
		}

		if (retryCount++ > 10000) {
			status = StatusHal;
			break;
		}
	}

	return returnStatus(status, eSucWriteStatus);
}

status_t Usart_Read(uint8_t *pBuffer, uint16_t length, uint16_t *pBytesRead)
{
	HAL_StatusTypeDef halStatus;

	status_t status;

	halStatus = HAL_UART_Receive(&huart1, pBuffer, length, 0);

	// Has some data (perhaps) been received?
	if ((HAL_TIMEOUT == halStatus) || (HAL_OK == halStatus))
	{
		*pBytesRead = huart1.RxXferSize - huart1.RxXferCount;
		status = StatusOk;
	} else {
		status = StatusHal;
	}

	return returnStatus(status, eSucReadStatus);
}

status_t Usart_Init (void)
{
	status_t status;

	status = StatusOk;

	if (initialized) {
		status = StatusAlreadyInitialized;
	}

	if (StatusOk == status) {
		huart1.Instance = USART1;
		huart1.Init.BaudRate = 115200;
		huart1.Init.WordLength = UART_WORDLENGTH_8B;
		huart1.Init.StopBits = UART_STOPBITS_1;
		huart1.Init.Parity = UART_PARITY_NONE;
		huart1.Init.Mode = UART_MODE_TX_RX;
		huart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
		huart1.Init.OverSampling = UART_OVERSAMPLING_16;
		huart1.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
		huart1.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
		if (HAL_UART_Init(&huart1) != HAL_OK)
		{
			status = StatusHal;
		}
	}

	if (StatusOk == status) {
		initialized = true;
	}
	return returnStatus(status, eSucInitStatus);
}

status_t Usart_DeInit (void)
{
	status_t status = StatusOk;

	if(initialized){
		HAL_StatusTypeDef halStatus = HAL_UART_DeInit(&huart1);
		if(HAL_OK != halStatus){
			status = StatusHal;
		}
		else{
			initialized = false;
		}
	}

	return status;
}


/// SAEC Kinetic Vision, Inc. ----------- END OF FILE
