/**
  @file       DeviceInfo.h

  @copyright  (C) 2020 Kinetic Vision, Cincinnati Ohio.
               This software is property of SAEC Kinetic Vision, Inc 
               and is considered confidential.

  @brief      DeviceInfo software unit "H" file.

  @author     aloebs

  @defgroup   DeviceInfoSoftwareUnit

  Configuration History
  =====================

  Config Item    | Value
  -------------- | -----
  Config #       | NA
  Revision       | NA
  Revised, Date  | NA
  QA, Date       | NA
  Approved, Date | NA
  Released, Date | NA

  Significant Modification History (Most recent at top)
  =====================================================

  Date         | Initials | Details
  ------------ | -------- | -------
  Mar 05, 2020 | ASL      | Original

  Theory of Operation
  ===================
  Provides device info for other software units

  */

// Define to prevent recursive inclusion -------------------------------------
#ifndef __DEVICEINFO_H_
#define __DEVICEINFO_H_

#include <stdint.h>

#include "../StatusSu/Status.h"

// Exported macro ------------------------------------------------------------
#define SERIAL_NUM_SIZE			sizeof(serialNum_t)
#define SERIAL_NUM_WORDS		3

// Exported types ------------------------------------------------------------
typedef union {
  uint32_t whole;
  struct {
    uint8_t build;
    uint8_t revision;
    uint8_t minor;
    uint8_t major;
  };
} version_t;

typedef union {
	uint8_t bytes[SERIAL_NUM_WORDS * sizeof(uint32_t)];
	uint32_t words[SERIAL_NUM_WORDS];
} serialNum_t;

// Exported constants --------------------------------------------------------

// Exported objects ----------------------------------------------------------

// Exported functions --------------------------------------------------------

/// Initializes device info
status_t DeviceInfo_Init(void);

/// Returns pointer to numeric hardware version
/// @param args[out] version - version_t to write to
status_t DeviceInfo_GetHardwareVersion(version_t *version);

/// Returns pointer to numeric firmware version
/// @param args[out] version - version_t to write to
status_t DeviceInfo_GetFirmwareVersion(version_t *version);

/// Returns pointer to uuid
/// @param args[out] serialNum - serialNum_t to write to
status_t DeviceInfo_GetSerialNum(serialNum_t *serialNum);

/// Returns pointer to hardware version string
/// @param args[out] str - pointer to write address of version string
status_t DeviceInfo_GetHardwareVersionStr(char **str);

/// Returns pointer to firmware version string
/// @param args[out] str - pointer to write address of version string
status_t DeviceInfo_GetFirmwareVersionStr(char **str);


#endif // __DEVICEINFO_H_

/// SAEC Kinetic Vision, Inc. ----------- END OF FILE
