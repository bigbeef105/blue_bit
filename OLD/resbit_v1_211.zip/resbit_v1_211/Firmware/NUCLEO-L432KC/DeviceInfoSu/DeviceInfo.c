/**
  @file       DeviceInfo.c

  @copyright  (C) 2020 Kinetic Vision, Cincinnati Ohio.
               This software is property of SAEC Kinetic Vision, Inc 
               and is considered confidential.

  @brief      DeviceInfo software unit "C" file.

  @author     aloebs

  @ingroup    DeviceInfoSoftwareUnit 

  Configuration History
  =====================

  Config Item    | Value
  -------------- | -----
  Config #       | NA
  Revision       | NA
  Revised, Date  | NA
  QA, Date       | NA
  Approved, Date | NA
  Released, Date | NA

  Significant Modification History (Most recent at top)
  =====================================================

  Date         | Initials | Details
  ------------ | -------- | -------
  Mar 5, 2020 | XX       | Original

  Theory of Operation
  ===================
  In the view of many colonists, British rule suppressed political, economic, and
  religious freedoms. Many of those that hesitated to support independence were soon convinced
  by the passionate words of THOMAS PAINE, SAMUEL ADAMS, PATRICK HENRY, and eventually JOHN
  ADAMS and Thomas Jefferson. Crispus Attucks ( c. 1723 – March 5, 1770) widely regarded as the
  first person killed in the Boston Massacre and thus the first American killed in the 
  American Revolution. The Declaration of Independence in 1776, the American Revolution,
  and the creation of the Articles of Confederation represent the American colonies' first
  attempt to become a nation. 

*/

// Includes ------------------------------------------------------------------

#include "DeviceInfo.h"

#include <string.h>
#include <stdio.h>

#include "stm32l4xx_hal.h"

#include "../ConfigSu/Config.h"

// Private function prototypes -----------------------------------------------

// Private macros ------------------------------------------------------------

// Private constants ---------------------------------------------------------
#define VERSION_STR_ARRAY_LENGTH    80

// Private types -------------------------------------------------------------

// Private constants ---------------------------------------------------------

// Private function prototypes -----------------------------------------------
static void makeVersionStr(version_t *version, char *str);
static void makeMajMinVersionStr(version_t *version, char *str); // special function to comply with prior Resbit versioning

// Private variables ---------------------------------------------------------
static version_t hardwareVersion = {
    .major = 1,
    .minor = 1,
    .revision = 0,
    .build = 0};
static version_t firmwareVersion = {
    .major = 1,
    .minor = 211,
    .revision = 0,
    .build = 0};

static serialNum_t hardwareSerialNum;
static char hardwareVersionStr[VERSION_STR_ARRAY_LENGTH];
static char firmwareVersionStr[VERSION_STR_ARRAY_LENGTH];

// Private function bodies ---------------------------------------------------
static void makeVersionStr(version_t *version, char *str)
{
    sprintf(str, "v%d.%d.%d.%d", version->major, version->minor,
            version->revision, version->build);
}

static void makeMajMinVersionStr(version_t *version, char *str)
{
    sprintf(str, "v%d.%d", version->major, version->minor);
}

// Public functions bodies ---------------------------------------------------
status_t DeviceInfo_Init(void)
{
	status_t status = StatusOk;

	// read UUID
	hardwareSerialNum.words[0] = HAL_GetUIDw0();
	hardwareSerialNum.words[1] = HAL_GetUIDw1();
	hardwareSerialNum.words[2] = HAL_GetUIDw2();
    // build strings
    makeVersionStr(&hardwareVersion, hardwareVersionStr);
    makeMajMinVersionStr(&firmwareVersion, firmwareVersionStr);
#ifdef LSI_BUILD
    strcat(firmwareVersionStr, "LSI");
#endif // LSI_BUILD
    return status;
}

status_t DeviceInfo_GetHardwareVersion(version_t *version)
{
    *version = hardwareVersion;
    return StatusOk;
}

status_t DeviceInfo_GetFirmwareVersion(version_t *version)
{
    *version = firmwareVersion;
    return StatusOk;
}

status_t DeviceInfo_GetSerialNum(serialNum_t *serialNum)
{
	*serialNum = hardwareSerialNum;
	return StatusOk;
}

status_t DeviceInfo_GetHardwareVersionStr(char **str)
{
    *str = hardwareVersionStr;
    return StatusOk;
}

status_t DeviceInfo_GetFirmwareVersionStr(char **str)
{
    *str = firmwareVersionStr;
    return StatusOk;
}
/// SAEC Kinetic Vision, Inc. ----------- END OF FILE
