/**
  @file       lis2de12.h

  @copyright  (C) 2019 Kinetic Vision, Cincinnati Ohio.
               This software is property of SAEC Kinetic Vision, Inc
               and is considered confidential.

  @brief      Lis2de12 motion detecting imu software unit "H" file.

  @author     Parker Kamer

  @defgroup   Lis2de12Su

  Configuration History
  =====================

  Config Item    | Value
  -------------- | -----
  Config #       | NA
  Revision       | NA
  Revised, Date  | NA
  QA, Date       | NA
  Approved, Date | NA
  Released, Date | NA

  Significant Modification History (Most recent at top)
  =====================================================

  Date         | Initials | Details
  ------------ | -------- | -------
  20 Sep 2019  | PK       | Original

  Theory of Operation
  ===================
  The Lisde12 accelerometer wwill supply the device with a motion based interrupt.
  When the device detects motion it will wake the device from its sleep state. If the
  device detects no motion for a configured amount of time, the device will enter a
  low power state.

  */

// Define to prevent recursive inclusion -------------------------------------
#ifndef __LIS2DE12_H
#define __LIS2DE12_H

#include <stdbool.h>

#include "../StatusSu/Status.h"

// Exported macro ------------------------------------------------------------
#define ACC_MOTION_WINDOW				1 // sec

// Exported types ------------------------------------------------------------
typedef enum {
	accIndexX = 0,
	accIndexY,
	accIndexZ,
	
	NUM_ACCEL_INDEXES,
} accIndexes_t;

typedef struct {
	float accData[NUM_ACCEL_INDEXES];
} accDataHandler_t;

// Exported functions --------------------------------------------------------
///  @brief Initialize the lis2de12 accelerometer
///  @return StatusOk, StatusAlreadyInitialized
status_t Lis2de12_Init(void);

///  @brief Enables data read ability
status_t Lis2de12_EnableRead(void);

///  @brief Disables data read ability
status_t Lis2de12_DisableRead(void);

///  @brief Enables/disables motion interrupt
///  @param args[in] enable - enables motion interrupt when true, disables when false
status_t Lis2de12_EnableMotionInterrupt(bool enable);

/// @brief Reads data from the device asynchronously, writes result into dataOut, 
///         calls callback when done
status_t Lis2de12_ReadData(accDataHandler_t * dataOut, void (*callback)(void));

#endif // __LIS2DE12_H

/// SAEC Kinetic Vision, Inc. ----------- END OF FILE




