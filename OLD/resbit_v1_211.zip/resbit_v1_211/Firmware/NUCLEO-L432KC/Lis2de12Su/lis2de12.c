/**
  @file       lis2de12.c

  @copyright  (C) 2019 Kinetic Vision, Cincinnati Ohio.
               This software is property of SAEC Kinetic Vision, Inc
               and is considered confidential.

  @brief      Lis2de12 motion detecting imu software unit "C" file.

  @author     Parker Kamer

  @ingroup    Lis2de12Su

  Configuration History
  =====================

  Config Item    | Value
  -------------- | -----
  Config #       | NA
  Revision       | NA
  Revised, Date  | NA
  QA, Date       | NA
  Approved, Date | NA
  Released, Date | NA

  Significant Modification History (Most recent at top)
  =====================================================

  Date         | Initials | Details
  ------------ | -------- | -------
  20 Sep 2019  | PK       | Original

  Theory of Operation
  ===================
  TBD

*/

// Includes ------------------------------------------------------------------
#include "lis2de12.h"

#include <string.h>
#include <stdio.h>
#include <stdlib.h>

#include "stm32l4xx_hal.h"

#include "../StatusSu/Status.h"
#include "../ConsoleSu/Console.h"
#include "../SwUnitControlSu/SwUnitControl.h"
#include "../GpioSu/Gpio.h"
#include "../I2cSu/i2c.h"
#include "../RtcSu/rtc.h"
#include "../ConfigSu/Config.h"
#include "../SysTimeSu/SysTime.h"
#include "../Bno055Su/bno055.h"

// Private macros ------------------------------------------------------------
/// This macro feeds status information for tracking purposes to software unit control.
#define returnStatus(__status__,__source__) SwUnitControl_WriteStatus(eSucLis2de12Su,__source__,__status__,__LINE__);

// Private constants ---------------------------------------------------------
#define LIS2DE12_I2C_ADDRESS 				0x32
#define LIS2DE12_CHIP_ID_VAL 				0x33
#define LIS2DE12_I2C_TIMEOUT_VAL			20 // ms
#define LIS2DE12_STARTUP_TIME				6 // ms

#define CTRL_REG0_RESET_VAL					0x10

#define CTRL_REG1_ODR_POWERDOWN				0x00
#define CTRL_REG1_ODR_10HZ					0x20
#define CTRL_REG1_LPEN						0x08
#define CTRL_REG1_ZEN						0x04
#define CTRL_REG1_YEN						0x02
#define CTRL_REG1_XEN						0x01

#define CTRL_REG5_LIR_INT2					0x02

#define CTRL_REG6_I2_ACT_ENABLE				0x08
#define CTRL_REG6_I2_ACT_DISABLE			0x00
#define CTRL_REG6_INT_POLARITY_ACTLOW		0x02

#define ACC_MOTION_THRESHOLD				112 // mg
#define ACC_LSB_TO_MG						16 // 16 mg / LSB @ +/-2g FS
#define ACT_THS_VALUE						ACC_MOTION_THRESHOLD / ACC_LSB_TO_MG

#define ODR_SAMPLE_RATE						10 // Hz
#define ACT_DUR_VALUE						((ACC_MOTION_WINDOW * ODR_SAMPLE_RATE) - 1) / 8

#define ADDRESS_AUTO_INCR					0x80

#define REGISTER_ADDRESS_LEN				1
#define READ_LEN							6

#define WRITE_BUFFER_SIZE					1
#define READ_BUFFER_SIZE					6 // keep this separate from read len in case we use this buffer for something else in future

#define RAW_ACC_INDEX_X						1
#define RAW_ACC_INDEX_Y						3
#define RAW_ACC_INDEX_Z						5

// Private types -------------------------------------------------------------
typedef enum
{
	whoAmI = 0x0F,
	ctrlReg0 = 0x1E,
	ctrlReg1 = 0x20,
	ctrlReg2,
	ctrlReg3,
	ctrlReg4,
	ctrlReg5,
	ctrlReg6,
	fifoReadStart = 0x28,
	outX,
	reserved1,
	outY,
	reserved2,
	outZ,
	fifoCtrlReg,
	int2Cfg = 0x34,
	int2Src,
	int2Ths,
	int2Duration,
	actThs = 0x3E,
	actDur

} lsi2de12RegMap_t;

typedef struct {
	accIndexes_t srcIndex;
	bool flipSign;
} axisRemap_t;

// Private function prototypes -----------------------------------------------
static status_t writeRegister(uint8_t reg, uint8_t data);
static status_t setupAxisRemap(void);
static accIndexes_t bnoRemapRegIndexToAccIndex(bno055AxisMapValues_t bno055Axis);
static void overlappedCallback(status_t status);
static status_t processData(accDataHandler_t * dataOut,
		uint8_t * rawBuffer, size_t len);

// Private constants ---------------------------------------------------------

// Private variables ---------------------------------------------------------
static i2cHandle_t i2cHandle;
static bool intEnabled = false;
static bool readEnabled = false;

static axisRemap_t axisRemapData[NUM_ACCEL_INDEXES];

static uint8_t i2cWriteBuffer[WRITE_BUFFER_SIZE];
static uint8_t i2cReadBuffer[READ_BUFFER_SIZE];
static volatile overlapped_t i2cOverlapped;

static accDataHandler_t * dataHandlerOut = NULL;
static void (*readCallback)(void) = NULL;

// Private function bodies ---------------------------------------------------
static status_t writeRegister(uint8_t reg, uint8_t data)
{
	uint8_t returnData;

	uint8_t registerInfo[2] = { reg, data };

	// Setup retry timeout
	uint32_t startTime = SysTime_GetMs();
	status_t status = StatusHal;
	while ((StatusOk != status)
			&& !SysTime_IsElapsed(startTime, LIS2DE12_I2C_TIMEOUT_VAL)) 
	{
		status = I2C_Write(i2cHandle, registerInfo, sizeof(registerInfo),
				LIS2DE12_I2C_TIMEOUT_VAL);
	}

	if (status == StatusOk) {
		// Confirm correct settings
		status = I2C_MemRead(i2cHandle, reg, REGISTER_ADDRESS_LEN, &returnData,
				sizeof(returnData),
				LIS2DE12_I2C_TIMEOUT_VAL);
		if (StatusOk == status) {
			if (returnData != data) {
				status = StatusHal;
			}
		}
	}

	return returnStatus(status, eSucWriteStatus);
}

static status_t setupAxisRemap(void)
{
	// Get orientation from config file
	orientationSettings_t configBoardOrientation[3];
	status_t status = Config_Ioctl(configIoctlGetOrientation, configBoardOrientation);
	
	// Zero out destination remap struct
	bno055AxisMapSignConfig_t remap;
	remap.bytes[0] = 0;
	remap.bytes[1] = 0;
	
	// Transform orientation to remap
	if (StatusOk == status) {
		status = Config_RemapBoardAxis(configBoardOrientation, (uint8_t *)&remap);
	}
	
	if (StatusOk == status) {		
		// Get index that X is remapping from
		axisRemapData[accIndexX].srcIndex = bnoRemapRegIndexToAccIndex((bno055AxisMapValues_t)remap.bits.mapX);
		// Write sign
		axisRemapData[accIndexX].flipSign = (bno055AxisSignValueNeg == remap.bits.signX);
		
		// Get index that Y is remapping from
		axisRemapData[accIndexY].srcIndex = bnoRemapRegIndexToAccIndex((bno055AxisMapValues_t)remap.bits.mapY);
		// Write sign
		axisRemapData[accIndexY].flipSign = (bno055AxisSignValueNeg == remap.bits.signY);
		
		// Get index that Z is remapping from
		axisRemapData[accIndexZ].srcIndex = bnoRemapRegIndexToAccIndex((bno055AxisMapValues_t)remap.bits.mapZ);
		// Write sign
		axisRemapData[accIndexZ].flipSign = (bno055AxisSignValueNeg == remap.bits.signZ);
	}
	
	return status;
}

static accIndexes_t bnoRemapRegIndexToAccIndex(bno055AxisMapValues_t bno055Axis)
{
	accIndexes_t retVal = -1; // initialize to invalid value
	switch (bno055Axis) {
		case bno055AxisMapValueX:
			retVal = accIndexX;
			break;
		case bno055AxisMapValueY:
			retVal = accIndexY;
			break;
		case bno055AxisMapValueZ:
			retVal = accIndexZ;
			break;
	}
	
	return retVal;
}

static void overlappedCallback(status_t status)
{
	if (dataHandlerOut)
		processData(dataHandlerOut, i2cReadBuffer, READ_LEN);
	if (readCallback)
		readCallback();
}

static status_t processData(accDataHandler_t * dataOut,
		uint8_t * rawBuffer, size_t len)
{
	status_t status = StatusOk;
	if (len <= RAW_ACC_INDEX_Z)
		status = StatusBufferLength;
	
	// Lis -> Bno transform (flip Y & Z)
	accDataHandler_t bnoFrame = {{
			((int8_t) rawBuffer[RAW_ACC_INDEX_X]) * ACC_LSB_TO_MG,
			((int8_t) rawBuffer[RAW_ACC_INDEX_Y]) * ACC_LSB_TO_MG * -1.0f,
			((int8_t) rawBuffer[RAW_ACC_INDEX_Z]) * ACC_LSB_TO_MG * -1.0f,
	}};
	
	if (StatusOk == status) {
		// Transform based on values from bno remap reg
		for (int i = 0; i < NUM_ACCEL_INDEXES; i++) {
			// Get data from remapped axis
			dataOut->accData[i] = bnoFrame.accData[axisRemapData[i].srcIndex];
			// Flip sign if needed
			if (axisRemapData[i].flipSign) {
				dataOut->accData[i] *= -1.0f;
			}
		}
	}
	
	return returnStatus(status, eSucIoctlStatus); // report here as this doesn't report at the public interface
}

// Public functions bodies ---------------------------------------------------
status_t Lis2de12_Init(void)
{
	status_t status = StatusOk;

	// Delay for startup time
	HAL_Delay(LIS2DE12_STARTUP_TIME);

	// Create i2c instance
	status = I2C_CreateHandle(&i2cHandle, LIS2DE12_I2C_ADDRESS);

	// Verify Chip ID
	if (StatusOk == status) {
		uint8_t i2cReturnData;
		status = I2C_MemRead(i2cHandle, whoAmI, 1, &i2cReturnData, 1,
		LIS2DE12_I2C_TIMEOUT_VAL);

		if ((i2cReturnData != LIS2DE12_CHIP_ID_VAL) || (status != StatusOk)) {
			status = StatusImuChipId;
		}
	}

	// Configure registers
	if (StatusOk == status) {
		// Set bit 4 (required), clear SA0 pull-up enable
		status = writeRegister(ctrlReg0, CTRL_REG0_RESET_VAL);
		HAL_Delay(5);
	}
	if (StatusOk == status) {
		// Default to power-down mode, set LPEN (required), enable all axes
		status = writeRegister(ctrlReg1,
		CTRL_REG1_ODR_POWERDOWN | CTRL_REG1_LPEN |
		CTRL_REG1_ZEN | CTRL_REG1_YEN | CTRL_REG1_XEN);
	}
	if (StatusOk == status) {
		// Latch interrupt request on int2
		status = writeRegister(ctrlReg5, CTRL_REG5_LIR_INT2);
	}
	if (StatusOk == status) {
		// Disable activity interrupt on int2
		status = writeRegister(ctrlReg6,
		CTRL_REG6_I2_ACT_DISABLE | CTRL_REG6_INT_POLARITY_ACTLOW);
	}
	if (StatusOk == status) {
		// Set motion threshold
		status = writeRegister(actThs, ACT_THS_VALUE);
	}
	if (StatusOk == status) {
		// Set interrupt duration (effectively the moving window for the motion interrupt)
		status = writeRegister(actDur, ACT_DUR_VALUE);
	}
	
	// Setup axis remap
	if (StatusOk == status) {
		status = setupAxisRemap();
	}

	// Initialize state information
	intEnabled = false;
	readEnabled = false;

	return returnStatus(status, eSucInitStatus);
}

status_t Lis2de12_EnableRead(void)
{
	status_t status = StatusOk;
	// If interrupt or read are already enabled, the ODR is already set correctly
	if (!intEnabled && !readEnabled) {
		status = writeRegister(ctrlReg1,
		CTRL_REG1_ODR_10HZ | CTRL_REG1_LPEN |
		CTRL_REG1_ZEN | CTRL_REG1_YEN | CTRL_REG1_XEN);
	}

	if (StatusOk == status)
		readEnabled = true;

	return status;
}

status_t Lis2de12_DisableRead(void)
{
	status_t status = StatusOk;
	// If interrupt is enabled, we don't want to disable ODR
	if (!intEnabled) {
		status = writeRegister(ctrlReg1,
		CTRL_REG1_ODR_POWERDOWN | CTRL_REG1_LPEN |
		CTRL_REG1_ZEN | CTRL_REG1_YEN | CTRL_REG1_XEN);
	}

	if (StatusOk == status)
		readEnabled = false;

	return status;
}

status_t Lis2de12_EnableMotionInterrupt(bool enable)
{
	status_t status = StatusOk;
	// Enable the interrupt if not already enabled
	if (enable && !intEnabled) {
		// Set ODR if read is not already enabled
		if (!readEnabled) {
			status = writeRegister(ctrlReg1,
			CTRL_REG1_ODR_10HZ | CTRL_REG1_LPEN |
			CTRL_REG1_ZEN | CTRL_REG1_YEN | CTRL_REG1_XEN);
		}
		// Enable interrupt
		if (StatusOk == status) {
			// Enable activity interrupt on int2
			status = writeRegister(ctrlReg6,
			CTRL_REG6_I2_ACT_ENABLE | CTRL_REG6_INT_POLARITY_ACTLOW);
		}
		// Update state
		if (StatusOk == status) {
			intEnabled = true;
		}
	}
	// Disable the interrupt if not already disabled
	else if (intEnabled) {
		// Set ODR to off if read is not enabled
		if (!readEnabled) {
			status = writeRegister(ctrlReg1,
			CTRL_REG1_ODR_POWERDOWN | CTRL_REG1_LPEN |
			CTRL_REG1_ZEN | CTRL_REG1_YEN | CTRL_REG1_XEN);
		}
		// Disable interrupt
		if (StatusOk == status) {
			// Disable activity interrupt on int2
			status = writeRegister(ctrlReg6,
			CTRL_REG6_I2_ACT_DISABLE | CTRL_REG6_INT_POLARITY_ACTLOW);
		}
		// Update state
		if (StatusOk == status) {
			intEnabled = false;
		}
	}

	return status;
}

status_t Lis2de12_ReadData(accDataHandler_t * dataOut,
		void (*callback)(void))
{
	status_t status = StatusOk;
	// Validate input
	if (!dataOut || !callback)
		status = StatusNullParameter;
	else if (!readEnabled)
		status = StatusInvalidState;

	if (StatusOk == status) {
		// Store pointers
		dataHandlerOut = dataOut;
		readCallback = callback;

		// Initiate read
		i2cWriteBuffer[0] = (ADDRESS_AUTO_INCR | fifoReadStart);

		i2cOverlapped.callback = overlappedCallback;
		i2cOverlapped.timeout = LIS2DE12_I2C_TIMEOUT_VAL;
		i2cOverlapped.outBuffer = i2cWriteBuffer;
		i2cOverlapped.outBufferSize = REGISTER_ADDRESS_LEN;
		i2cOverlapped.inBuffer = i2cReadBuffer;
		i2cOverlapped.inBufferSize = READ_LEN;

		status = I2C_MemReadAsync(i2cHandle, &i2cOverlapped);
	}

	return returnStatus(status, eSucReadStatus);
}
