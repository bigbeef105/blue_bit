#include "unity.h"

#include <stdint.h>
#include <stdbool.h>
#include <string.h>

#include "Utility.h"
#include "Status.h"

#define TEST_BUFFER_LEN     32

void setUp(void)
{
}

void tearDown(void)
{
}

void itoaTestAgainstExpected(int32_t testVal, uint8_t * expectedStr, uint8_t minDigits)
{
    uint8_t testBuffer[TEST_BUFFER_LEN];
    memset(testBuffer, 0, sizeof(testBuffer));

    TEST_ASSERT_EQUAL(strlen((char *)expectedStr), Utility_ItoaBase10(testVal, testBuffer, minDigits));
    TEST_ASSERT_EQUAL_STRING(expectedStr, testBuffer);
}

void ftoaTestAgainstExpected(float testVal, uint8_t * expectedStr, fPrecision_t precision)
{
    uint8_t testBuffer[TEST_BUFFER_LEN];
    memset(testBuffer, 0, sizeof(testBuffer));

    TEST_ASSERT_EQUAL(strlen((char *)expectedStr), Utility_FtoaBase10(testVal, testBuffer, precision));
    TEST_ASSERT_EQUAL_STRING(expectedStr, testBuffer);
}

void test_Utility_ItoaBase10(void)
{
    // Test with 0
    itoaTestAgainstExpected(0, "0", 1);
    itoaTestAgainstExpected(0, "000", 3);
    itoaTestAgainstExpected(0, "000000", 6);

    // Test with negative
    itoaTestAgainstExpected(-427, "-427", 1);
    itoaTestAgainstExpected(-427, "-427", 3);
    itoaTestAgainstExpected(-427, "-000427", 6);

    // Test with positive
    itoaTestAgainstExpected(57, "57", 1);
    itoaTestAgainstExpected(57, "057", 3);
    itoaTestAgainstExpected(57, "000057", 6);

    // Test with edge case -- this doesn't support INT_MIN as the function flips negative numbers
    uint8_t edgeCaseStr[TEST_BUFFER_LEN];
    sprintf(edgeCaseStr, "%d", INT32_MIN + 1);
    itoaTestAgainstExpected(INT32_MIN + 1, edgeCaseStr, 1);
    sprintf(edgeCaseStr, "%d", INT32_MAX);
    itoaTestAgainstExpected(INT32_MAX, edgeCaseStr, 1);
}

void test_Utility_FtoaBase10(void)
{
    // Test with 0
    ftoaTestAgainstExpected(0, "0", fPrecision_0);
    ftoaTestAgainstExpected(0, "0.0", fPrecision_1);
    ftoaTestAgainstExpected(0, "0.00", fPrecision_2);
    ftoaTestAgainstExpected(0, "0.000", fPrecision_3);

    // Test with negative
    ftoaTestAgainstExpected(-4789.3385, "-4789", fPrecision_0);
    ftoaTestAgainstExpected(-4789.3385, "-4789.3", fPrecision_1);
    ftoaTestAgainstExpected(-4789.3385, "-4789.33", fPrecision_2);
    ftoaTestAgainstExpected(-4789.3385, "-4789.338", fPrecision_3);

    // Test with positive
    ftoaTestAgainstExpected(523908.9, "523908", fPrecision_0);
    ftoaTestAgainstExpected(523908.9, "523908.9", fPrecision_1);
    ftoaTestAgainstExpected(523908.9, "523908.90", fPrecision_2);
    ftoaTestAgainstExpected(523908.9, "523908.906", fPrecision_3); // trailing six is due to single precision float errors
}