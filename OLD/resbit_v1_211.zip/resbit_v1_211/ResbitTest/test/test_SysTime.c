#include "unity.h"

#include <stdint.h>
#include <stdbool.h>

#include "SysTime.h"
#include "Status.h"
#include "mock_Console.h"
#include "mock_stm32l4xx_hal.h"

// Force linkage
TEST_FILE("SwUnitControl.c");

void setUp(void)
{
}

void tearDown(void)
{
}

void test_SysTime_GetElapsedNormal(void)
{
    HAL_GetTick_ExpectAndReturn(11000);
    TEST_ASSERT_EQUAL(1000, SysTime_GetElapsed(10000));
}

void test_SysTime_GetElapsedWrap(void)
{
    HAL_GetTick_ExpectAndReturn(50);
    TEST_ASSERT_EQUAL(100, SysTime_GetElapsed(UINT32_MAX - 49));
}

void test_SysTime_GetElapsedEdge(void)
{
    // both zero
    HAL_GetTick_ExpectAndReturn(0);
    TEST_ASSERT_EQUAL(0, SysTime_GetElapsed(0));
    // both at max
    HAL_GetTick_ExpectAndReturn(UINT32_MAX);
    TEST_ASSERT_EQUAL(0, SysTime_GetElapsed(UINT32_MAX));
    // measuring from max
    HAL_GetTick_ExpectAndReturn(9);
    TEST_ASSERT_EQUAL(10, SysTime_GetElapsed(UINT32_MAX));
    // largest possible return
    HAL_GetTick_ExpectAndReturn(99);
    TEST_ASSERT_EQUAL(UINT32_MAX, SysTime_GetElapsed(100));
}

void test_SysTime_IsElapsedNormal(void)
{
    // one off
    HAL_GetTick_ExpectAndReturn(10099);
    TEST_ASSERT_FALSE(SysTime_IsElapsed(10000, 1000));
    // exactly elapsed
    HAL_GetTick_ExpectAndReturn(22000);
    TEST_ASSERT_TRUE(SysTime_IsElapsed(20000, 2000));
    // one greater
    HAL_GetTick_ExpectAndReturn(33001);
    TEST_ASSERT_TRUE(SysTime_IsElapsed(30000, 3000));
}

void test_SysTime_IsElapsedWrap(void)
{
    // one off
    HAL_GetTick_ExpectAndReturn(49);
    TEST_ASSERT_FALSE(SysTime_IsElapsed(UINT32_MAX - 49, 100));
    // exactly elapsed
    HAL_GetTick_ExpectAndReturn(500);
    TEST_ASSERT_TRUE(SysTime_IsElapsed(UINT32_MAX - 499, 1000));
    // one greater
    HAL_GetTick_ExpectAndReturn(5001);
    TEST_ASSERT_TRUE(SysTime_IsElapsed(UINT32_MAX - 4999, 10000));
}

void test_SysTime_IsElapsedEdge(void)
{
    // zero time
    HAL_GetTick_ExpectAndReturn(0);
    TEST_ASSERT_TRUE(SysTime_IsElapsed(0, 0));
    // max time
    HAL_GetTick_ExpectAndReturn(UINT32_MAX);
    TEST_ASSERT_TRUE(SysTime_IsElapsed(UINT32_MAX, 0));
}
