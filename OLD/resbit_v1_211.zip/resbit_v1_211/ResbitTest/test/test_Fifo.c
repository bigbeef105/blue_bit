#include "unity.h"

#include <stdbool.h>
#include <string.h> // memset

#include "Fifo.h"
#include "Status.h"
#include "mock_Console.h"

#define FIFO_LEN                10000 // this is private within Fifo.c so we need to redefine it here
#define MULTI_READ_WRITE_COUNT  1000

// Force linkage
TEST_FILE("SwUnitControl.c");

// Private variables
static bool initialized = false;

// Private function prototypes
static void generateBytes(uint8_t startVal, uint8_t step, uint8_t *buffer, size_t len);
static void checkBytes(uint8_t startVal, uint8_t step, uint8_t *buffer, size_t len);
static void checkCountAndAvailable(uint16_t expectedCount, uint16_t totalLen);

// Private function definitions
static void generateBytes(uint8_t startVal, uint8_t step, uint8_t *buffer, size_t len)
{
    uint8_t val = startVal;
    for (int i = 0; i < len; i++) {
        buffer[i] = val;
        val += step;
    }
}

static void checkBytes(uint8_t startVal, uint8_t step, uint8_t *buffer, size_t len)
{
    uint8_t val = startVal;
    for (int i = 0; i < len; i++) {
        TEST_ASSERT_EQUAL(val, buffer[i]);
        val += step;
    }
}

static void checkCountAndAvailable(uint16_t expectedCount, uint16_t totalLen)
{
    uint16_t count, available;
    status_t status = Fifo_GetCount(&count);
    TEST_ASSERT_EQUAL(StatusOk, status);
    TEST_ASSERT_EQUAL(expectedCount, count);
    status = Fifo_GetAvailable(&available);
    TEST_ASSERT_EQUAL(StatusOk, status);
    TEST_ASSERT_EQUAL((totalLen - 1) - expectedCount, available);
}

// Test functions
void setUp(void)
{
    // We only want to do this once..
    if (!initialized) {
        Console_ExportCommandsToCli_IgnoreAndReturn(StatusOk);
        Fifo_Init();
        initialized = true;
    } else {
        Fifo_Reset();
    }
}

void tearDown(void)
{
}

void test_Fifo_InitState(void)
{
    checkCountAndAvailable(0, FIFO_LEN);
}

void test_Fifo_BasicReadWrite(void)
{
    size_t bufferLen = 100;
    uint8_t buffer[bufferLen];
    uint8_t startVal = 10;
    uint8_t step = 37;
    generateBytes(startVal, step, buffer, bufferLen);

    // Write chunk
    status_t status = Fifo_Write(buffer, bufferLen);
    TEST_ASSERT_EQUAL(StatusOk, status);
    checkCountAndAvailable(bufferLen, FIFO_LEN);    

    // Read chunk
    memset(buffer, 0, bufferLen);
    status = Fifo_Read(buffer, bufferLen);
    TEST_ASSERT_EQUAL(StatusOk, status);
    checkCountAndAvailable(0, FIFO_LEN); 

    // Check read data
    checkBytes(startVal, step, buffer, bufferLen);
}

void test_Fifo_FullCapacity(void)
{
    size_t bufferLen = FIFO_LEN - 1;
    uint8_t buffer[bufferLen];
    uint8_t startVal = 3;
    uint8_t step = 2;
    generateBytes(startVal, step, buffer, bufferLen);

    // Write chunk
    status_t status = Fifo_Write(buffer, bufferLen);
    TEST_ASSERT_EQUAL(StatusOk, status);
    checkCountAndAvailable(bufferLen, FIFO_LEN);    

    // Read chunk
    memset(buffer, 0, bufferLen);
    status = Fifo_Read(buffer, bufferLen);
    TEST_ASSERT_EQUAL(StatusOk, status);
    checkCountAndAvailable(0, FIFO_LEN); 

    // Check read data
    checkBytes(startVal, step, buffer, bufferLen);
}

void test_Fifo_BadStatusWhenWriteTooLarge(void)
{
    size_t secondWriteLen = 273;
    size_t bufferLen = FIFO_LEN - secondWriteLen;
    uint8_t buffer[bufferLen];
    uint8_t startVal = 3;
    uint8_t step = 2;
    generateBytes(startVal, step, buffer, bufferLen);

    // Write chunk
    status_t status = Fifo_Write(buffer, bufferLen);
    TEST_ASSERT_EQUAL(StatusOk, status);
    checkCountAndAvailable(bufferLen, FIFO_LEN);

    // Attempt to write second chunk
    status = Fifo_Write(buffer, secondWriteLen);
    TEST_ASSERT_EQUAL(StatusSpaceAvailable, status);

    // Attempt to write longer chunk
    status = Fifo_Write(buffer, secondWriteLen + 1);
    TEST_ASSERT_EQUAL(StatusSpaceAvailable, status);

    // Attempt write of exact length
    status = Fifo_Write(buffer, secondWriteLen - 1);
    TEST_ASSERT_EQUAL(StatusOk, status);
    checkCountAndAvailable(FIFO_LEN - 1, FIFO_LEN);
}

void test_Fifo_BadStatusWhenReadTooLarge(void)
{
    size_t bufferLen = 500;
    uint8_t buffer[bufferLen];
    uint8_t startVal = 3;
    uint8_t step = 2;

    // Make sure it doesn't work on empty buffer
    status_t status = Fifo_Read(buffer, 1);
    TEST_ASSERT_EQUAL(StatusSpaceAvailable, status);

    // Write chunk
    status = Fifo_Write(buffer, bufferLen - 1);
    TEST_ASSERT_EQUAL(StatusOk, status);
    checkCountAndAvailable(bufferLen - 1, FIFO_LEN);

    // Test too long by 1
    status = Fifo_Read(buffer, bufferLen);
    TEST_ASSERT_EQUAL(StatusSpaceAvailable, status);

    // No need to text exact read -- we did this in test basic read/write
}

void test_Fifo_MultiReadWrite(void)
{
    // These need to total to less than
    uint16_t writeSizes[] = {13, 57, 99, 1000, 2701, 3388};
    uint16_t numWriteSizes = sizeof(writeSizes) / sizeof(*writeSizes);

    size_t bufferLen = 3771; // equal to largest write size
    uint8_t startVal = 230;
    uint8_t step = 13;

    uint8_t writeBuffer[bufferLen];
    generateBytes(startVal, step, writeBuffer, bufferLen);

    uint16_t writeSizeIndex = 0;
    uint16_t readSizeIndex = 0;
    
    uint16_t expectedCount = 0;
    status_t status = StatusOk;

    // Have writes lead reads
    for (writeSizeIndex = 0; writeSizeIndex < 4; writeSizeIndex++) {
        status = Fifo_Write(writeBuffer, writeSizes[writeSizeIndex]);
        expectedCount += writeSizes[writeSizeIndex];

        TEST_ASSERT_EQUAL(StatusOk, status);
        checkCountAndAvailable(expectedCount, FIFO_LEN);
    }
    
    // Check reads/writes
    uint8_t readBuffer[bufferLen];
    for (int i = 0; i < MULTI_READ_WRITE_COUNT; i++) {
        // Write
        status = Fifo_Write(writeBuffer, writeSizes[writeSizeIndex]);
        expectedCount += writeSizes[writeSizeIndex];

        TEST_ASSERT_EQUAL(StatusOk, status);
        checkCountAndAvailable(expectedCount, FIFO_LEN);

        // Read
        memset(readBuffer, 0, writeSizes[readSizeIndex]);
        status = Fifo_Read(readBuffer, writeSizes[readSizeIndex]);
        expectedCount -= writeSizes[readSizeIndex];

        TEST_ASSERT_EQUAL(StatusOk, status);
        checkCountAndAvailable(expectedCount, FIFO_LEN);
        checkBytes(startVal, step, readBuffer, writeSizes[readSizeIndex]);

        // Increment indices
        writeSizeIndex++;
        if (writeSizeIndex >= numWriteSizes) writeSizeIndex -= numWriteSizes;
        readSizeIndex++;
        if (readSizeIndex >= numWriteSizes) readSizeIndex -= numWriteSizes;
    }
}

