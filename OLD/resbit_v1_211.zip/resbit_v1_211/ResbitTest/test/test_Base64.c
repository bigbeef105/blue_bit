#include "unity.h"

#include <string.h>

#include "Base64.h"
#include "Status.h"
#include "mock_Console.h"

// Force linkage
TEST_FILE("SwUnitControl.c");

// Private variables

// Private function prototypes
static void encodeInChunks(base64Encoder_t * encoder, uint8_t * src, uint16_t len, uint16_t chunkSize);

// Private function definitions
static void encodeInChunks(base64Encoder_t * encoder, uint8_t * src, uint16_t len, uint16_t chunkSize)
{
    uint16_t remaining = len;
    while (remaining > 0) {
        uint16_t actualChunkSize = (remaining < chunkSize) ? remaining : chunkSize;
        TEST_ASSERT_EQUAL(StatusOk, Base64_EncoderAddChunk(encoder, &src[len - remaining], actualChunkSize));
        remaining -= actualChunkSize;
    }
}

// Test functions
void setUp(void)
{
}

void tearDown(void)
{
}

void test_Base64_TwoPadBytes(void)
{
    uint8_t src[] = "a";
    uint8_t expected[] = "YQ==";
    uint8_t dest[sizeof(expected)];

    // Start encoder
    base64Encoder_t encoder;
    TEST_ASSERT_EQUAL(StatusOk, Base64_EncoderStart(&encoder, dest, sizeof(dest)));
    // Add data
    TEST_ASSERT_EQUAL(StatusOk, Base64_EncoderAddChunk(&encoder, src, strlen(src)));
    // End encoder
    uint16_t bytesWritten = 0;
    TEST_ASSERT_EQUAL(StatusOk, Base64_EncoderEnd(&encoder, &bytesWritten));
    // Check bytesWritten
    TEST_ASSERT_EQUAL(strlen(expected), bytesWritten);
    // Check result
    TEST_ASSERT_EQUAL_STRING_LEN(expected, dest, strlen(expected));
}

void test_Base64_OnePadByte(void)
{
    uint8_t src[] = "ab";
    uint8_t expected[] = "YWI=";
    uint8_t dest[sizeof(expected)];

    // Start encoder
    base64Encoder_t encoder;
    TEST_ASSERT_EQUAL(StatusOk, Base64_EncoderStart(&encoder, dest, sizeof(dest)));
    // Add data
    TEST_ASSERT_EQUAL(StatusOk, Base64_EncoderAddChunk(&encoder, src, strlen(src)));
    // End encoder
    uint16_t bytesWritten = 0;
    TEST_ASSERT_EQUAL(StatusOk, Base64_EncoderEnd(&encoder, &bytesWritten));
    // Check bytesWritten
    TEST_ASSERT_EQUAL(strlen(expected), bytesWritten);
    // Check result
    TEST_ASSERT_EQUAL_STRING_LEN(expected, dest, strlen(expected));
}

void test_Base64_NoPadByte(void)
{
    uint8_t src[] = "abc";
    uint8_t expected[] = "YWJj";
    uint8_t dest[sizeof(expected)];

    // Start encoder
    base64Encoder_t encoder;
    TEST_ASSERT_EQUAL(StatusOk, Base64_EncoderStart(&encoder, dest, sizeof(dest)));
    // Add data
    TEST_ASSERT_EQUAL(StatusOk, Base64_EncoderAddChunk(&encoder, src, strlen(src)));
    // End encoder
    uint16_t bytesWritten = 0;
    TEST_ASSERT_EQUAL(StatusOk, Base64_EncoderEnd(&encoder, &bytesWritten));
    // Check bytesWritten
    TEST_ASSERT_EQUAL(strlen(expected), bytesWritten);
    // Check result
    TEST_ASSERT_EQUAL_STRING_LEN(expected, dest, strlen(expected));
}

void test_Base64_EncodingInOnes(void)
{
    uint8_t src[] = "The light that burns twice as bright burns half as long, and you have burned so very very brightly Roy.";
    uint8_t expected[] = "VGhlIGxpZ2h0IHRoYXQgYnVybnMgdHdpY2UgYXMgYnJpZ2h0IGJ1cm5zIGhhbGYgYXMgbG9uZywgYW5kIHlvdSBoYXZlIGJ1cm5lZCBzbyB2ZXJ5IHZlcnkgYnJpZ2h0bHkgUm95Lg==";
    uint8_t dest[sizeof(expected)];

    // Start encoder
    base64Encoder_t encoder;
    TEST_ASSERT_EQUAL(StatusOk, Base64_EncoderStart(&encoder, dest, sizeof(dest)));
    // Add data
    encodeInChunks(&encoder, src, strlen(src), 1);
    // End encoder
    uint16_t bytesWritten = 0;
    TEST_ASSERT_EQUAL(StatusOk, Base64_EncoderEnd(&encoder, &bytesWritten));
    // Check bytesWritten
    TEST_ASSERT_EQUAL(strlen(expected), bytesWritten);
    // Check result
    TEST_ASSERT_EQUAL_STRING_LEN(expected, dest, strlen(expected));
}

void test_Base64_EncodingInThrees(void)
{
    uint8_t src[] = "Replicants are like any other machine, are either a benefit or a hazard. If they're a benefit it's not my problem.";
    uint8_t expected[] = "UmVwbGljYW50cyBhcmUgbGlrZSBhbnkgb3RoZXIgbWFjaGluZSwgYXJlIGVpdGhlciBhIGJlbmVmaXQgb3IgYSBoYXphcmQuIElmIHRoZXkncmUgYSBiZW5lZml0IGl0J3Mgbm90IG15IHByb2JsZW0u";
    uint8_t dest[sizeof(expected)];

    // Start encoder
    base64Encoder_t encoder;
    TEST_ASSERT_EQUAL(StatusOk, Base64_EncoderStart(&encoder, dest, sizeof(dest)));
    // Add data
    encodeInChunks(&encoder, src, strlen(src), 3);
    // End encoder
    uint16_t bytesWritten = 0;
    TEST_ASSERT_EQUAL(StatusOk, Base64_EncoderEnd(&encoder, &bytesWritten));
    // Check bytesWritten
    TEST_ASSERT_EQUAL(strlen(expected), bytesWritten);
    // Check result
    TEST_ASSERT_EQUAL_STRING_LEN(expected, dest, strlen(expected));
}

void test_Base64_EncodingInTens(void)
{
    uint8_t src[] = "Not very sporting to fire on an unarmed opponent. I thought you were supposed to be good. Aren't you the \"good\" man? C'mon, Deckard. Show me what you're made of.";
    uint8_t expected[] = "Tm90IHZlcnkgc3BvcnRpbmcgdG8gZmlyZSBvbiBhbiB1bmFybWVkIG9wcG9uZW50LiBJIHRob3VnaHQgeW91IHdlcmUgc3VwcG9zZWQgdG8gYmUgZ29vZC4gQXJlbid0IHlvdSB0aGUgImdvb2QiIG1hbj8gQydtb24sIERlY2thcmQuIFNob3cgbWUgd2hhdCB5b3UncmUgbWFkZSBvZi4=";
    uint8_t dest[sizeof(expected)];

    // Start encoder
    base64Encoder_t encoder;
    TEST_ASSERT_EQUAL(StatusOk, Base64_EncoderStart(&encoder, dest, sizeof(dest)));
    // Add data
    encodeInChunks(&encoder, src, strlen(src), 10);
    // End encoder
    uint16_t bytesWritten = 0;
    TEST_ASSERT_EQUAL(StatusOk, Base64_EncoderEnd(&encoder, &bytesWritten));
    // Check bytesWritten
    TEST_ASSERT_EQUAL(strlen(expected), bytesWritten);
    // Check result
    TEST_ASSERT_EQUAL_STRING_LEN(expected, dest, strlen(expected));
}

void test_Base64_DestTooSmallOnEncode(void)
{
    uint8_t src[] = "More human than human is our motto.";
    uint8_t expected[] = "TW9yZSBodW1hbiB0aGFuIGh1bWFuIGlzIG91ciBtb3R0by4=";
    uint8_t dest[sizeof(expected)] = { 0 };

    // Start encoder -- feed it a fake length
    base64Encoder_t encoder;
    TEST_ASSERT_EQUAL(StatusOk, Base64_EncoderStart(&encoder, dest, sizeof(dest) - 6));
    // Add data -- this should hit an error
    TEST_ASSERT_EQUAL(StatusBufferLength, Base64_EncoderAddChunk(&encoder, src, strlen(src)));
    // Make sure it didn't overwrite
    TEST_ASSERT_EQUAL(0, dest[sizeof(dest) - 6]);
}

void test_Base64_DestTooSmallOnEnd(void)
{
    uint8_t src[] = "Nothing is worse than having an itch you can never scratch!";
    uint8_t expected[] = "Tm90aGluZyBpcyB3b3JzZSB0aGFuIGhhdmluZyBhbiBpdGNoIHlvdSBjYW4gbmV2ZXIgc2NyYXRjaCE=";
    uint8_t dest[sizeof(expected)] = { 0 };

    // Start encoder -- feed it a fake length
    base64Encoder_t encoder;
    TEST_ASSERT_EQUAL(StatusOk, Base64_EncoderStart(&encoder, dest, sizeof(dest) - 2));
    // Add data
    TEST_ASSERT_EQUAL(StatusOk, Base64_EncoderAddChunk(&encoder, src, strlen(src)));
    // End encoder -- this should hit an error
    uint16_t bytesWritten = 0;
    TEST_ASSERT_EQUAL(StatusBufferLength, Base64_EncoderEnd(&encoder, &bytesWritten));
    // Make sure it didn't overwrite
    TEST_ASSERT_EQUAL(0, dest[sizeof(dest) - 2]);
}
