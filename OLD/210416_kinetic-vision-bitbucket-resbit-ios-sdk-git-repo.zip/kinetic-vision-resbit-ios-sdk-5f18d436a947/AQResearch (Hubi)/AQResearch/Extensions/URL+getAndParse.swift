//
//  URL+getAndParse.swift
//  AQResearch
//
//  Created by Aaron on 2/3/20.
//  Copyright © 2020 Procter & Gamble. All rights reserved.
//

import Foundation

extension URL {
    
    /// Performs a GET action with the given URL, and then parses the result to the given type
    /// - Parameters:
    ///   - type: The type to parse the result to
    ///   - headers: Headers to include in the HTTP request
    ///   - completion: Called when the request completes, passing in the parsed result or an error
    func getAndParse<T: Decodable>(for type: T.Type, headers: [String: String] = [:], completion: @escaping (Result<T, Error>) -> Void) {

        var request = URLRequest(url: self)

        for key in headers.keys {
            request.setValue(headers[key] ?? "", forHTTPHeaderField: key)
        }
        
        URLSession.shared.dataTask(with: request) { data, response, error in
            
            if let error = error {
                DispatchQueue.main.async {
                    completion(.failure(error))
                }
            } else {
                if let data = data {
                    do {
                        let result = try JSONDecoder().decode(T.self, from: data)
                        completion(.success(result))
                    } catch let error {
                        completion(.failure(error))
                    }
                }
            }
        }.resume()
    }
}
