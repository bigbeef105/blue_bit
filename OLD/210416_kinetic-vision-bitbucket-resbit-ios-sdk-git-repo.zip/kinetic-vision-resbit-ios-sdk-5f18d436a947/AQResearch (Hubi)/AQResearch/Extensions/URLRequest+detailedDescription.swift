//
//  URLRequest+detailedDescription.swift
//  AQResearch
//
//  Created by Aaron on 1/24/20.
//  Copyright © 2020 Procter & Gamble. All rights reserved.
//

import Foundation

extension URLRequest {
    
    /// Gets a description of the URLRequest suitable for logging
    var detailedDescription: String {
        
        var str = "URL: \(self.url?.absoluteString ?? "<nil>")"
        
        if let headers = allHTTPHeaderFields {
            str += "\nHeaders: "
            for key in headers.keys {
                str += "\n\t\(key): \(headers[key] ?? "<nil>")"
            }
        }
        
        if let body = self.httpBody {
            str += "\nBody: "
            str += "\n\t\(String(bytes: body, encoding: .utf8)!)"
        }
        
        return str
        
    }
    
}
