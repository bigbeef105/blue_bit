//
//  UIImage+withTintColor.swift
//  AQResearch
//
//  Created by Aaron on 12/2/19.
//  Copyright © 2019 Procter & Gamble. All rights reserved.
//

import Foundation
import UIKit

extension UIImage {
    
    /// Applies tint to image
    /// - Parameter color: Color to tint with
    func tintWith(color: UIColor) -> UIImage {
        UIGraphicsBeginImageContextWithOptions(self.size, false, self.scale)
        color.setFill()

        let context = UIGraphicsGetCurrentContext()
        context?.translateBy(x: 0, y: self.size.height)
        context?.scaleBy(x: 1.0, y: -1.0)
        context?.setBlendMode(CGBlendMode.normal)

        let rect = CGRect(origin: .zero, size: CGSize(width: self.size.width, height: self.size.height))
        context?.clip(to: rect, mask: self.cgImage!)
        context?.fill(rect)

        let newImage = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()

        return newImage!
    }

    /// Resize to given width/height
    /// - Parameters:
    ///   - width: Target width
    ///   - height: Target height. If nil, calculated based on width and starting aspect ratio
    func sizedTo(width: CGFloat, height: CGFloat? = nil) -> UIImage {
        let xScale = width / self.size.width

        let yScale = height != nil ? height! / self.size.width : xScale     //If height is not provided, calc based on width scale
        let newHeight = height != nil ? height! : self.size.height * yScale

        UIGraphicsBeginImageContext(CGSize(width: width, height: newHeight))

        self.draw(in: CGRect(x: 0, y: 0, width: width, height: newHeight))

        let newImage = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()

        return newImage!
    }
}
