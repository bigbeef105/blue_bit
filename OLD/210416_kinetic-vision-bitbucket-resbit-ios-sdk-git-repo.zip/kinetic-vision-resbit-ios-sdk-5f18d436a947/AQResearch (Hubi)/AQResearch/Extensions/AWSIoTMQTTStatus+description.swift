//
//  AWSIotMqttStatus+description.swift
//  AQResearch
//
//  Created by Aaron on 1/9/20.
//  Copyright © 2020 Procter & Gamble. All rights reserved.
//

import Foundation
import AWSIoT

extension AWSIoTMQTTStatus {
    var description: String {
        switch self {
        case .unknown:
            return "Unknown"
        case .connecting:
            return "Connecting"
        case .connected:
            return "Connected"
        case .disconnected:
            return "Disconnected"
        case .connectionRefused:
            return "ConnectionRefused"
        case .connectionError:
            return "ConnectionError"
        case .protocolError:
            return "ProtocolError"
        default:
            return "Other/Unknown"
        }
    }
}
