//
//  Logger.swift
//  AQWritePOC
//
//  Created by Aaron on 11/11/19.
//  Copyright © 2019 Alchemy. All rights reserved.
//

import Foundation

/// The LoggerLevel to be used by the Logger
///
///
///
enum LoggerLevel: Int {
    case Off = 0
    case Fatal = 100
    case Error = 200
    case Warn = 300
    case Info = 400
    case Debug = 500
    case Trace = 600
}

/// Defines methods that Loggers should contain
///
/// # Properties
///
/// A Logger Message consists of the **message**, a **LoggerLevel**, a **Channel**, and a **datetime**.
///
/// - **message:** The message to be logged
/// - **level:** The LoggerLevel for this message. The Logger will write the logged message only if the logger's `level` property is less than or equal to the message's provided **LoggerLevel**
/// - **channel:** A logged message will be written to a **channel** of the logger. This allows a single Logger to separate multiple data streams if needed. The **channel** should always be optional.
/// - **datetime** The DateTime when the logged message is written. This allows for messages sent to a web service or other asynchronous log to order the messages correctly in the log
///
/// # Extension
///
///  Logger includes an extension that provides a default implementation of most functions, providing the following default values for all properties:
///  - **message:** `""` / Empty string
/// - **level:** `.Trace`
/// - **channel:** `""` / None
/// - **datetime** Current DateTime with seconds to 3 decimal places
///
protocol Logger {

    
    /// The Logger should respond to all LoggerLevels less than or equal to this LoggerLevel
    var level: LoggerLevel { get set }
    
    /// Writes the text to the Logger for the current DateTime, at the default LoggerLevel, and on the default Channel. Messages will be written to the log if the default LoggerLevel is less than or equal to the Logger's `level`.
    /// - Parameter text: Text to write. `nil` defaults to an empty string
    func write(_ text: String?)
    
    /// Writes to the Logger with the given parameters at the current DateTime at the default LoggerLevel. Messages will be written to the log if the default LoggerLevel is less than or equal to the Logger's `level`.
    /// - Parameters:
    ///   - text: Text to write to the log. If nil, will write an empty string.
    ///   - channel: The channel on which to log the message
    func write(_ text: String?, channel: String)

    /// Writes to the Logger with the given parameters on the default channel and at the default LoggerLevel. Messages will be written to the log if the default LoggerLevel is less than or equal to the Logger's `level`.
    /// - Parameters:
    ///   - text: Text to write to the log. If nil, will write an empty string.
    ///   - datetime: The DateTime the message was logged
    func write(_ text: String?, datetime: Date)
    
    /// Writes to the Logger with the given parameters at the default LoggerLevel. Messages will be written to the log if the default LoggerLevel is less than or equal to the Logger's `level`.
    /// - Parameters:
    ///   - text: Text to write to the log. If nil, will write an empty string.
    ///   - datetime: The DateTime the message was logged
    ///   - channel: The channel on which to log the message
    func write(_ text: String?, datetime: Date, channel: String)

    func write(_ text: String?, level: LoggerLevel)
    /// Writes to the Logger with the given parameters on the default channel and at the current dateTime.
    /// - Parameters:
    ///   - text: Text to write to the log. If nil, will write an empty string.
    ///   - datetime: The DateTime the message was logged
    ///   - level: The LoggerLevel to log the message to. Messages will be written to a log in the provided LoggerLevel is less than or equal to the Logger's `level`.
    
    func write(_ text: String?, channel: String, level: LoggerLevel)

    /// Writes to the Logger with the given parameters on the default channel.
    /// - Parameters:
    ///   - text: Text to write to the log. If nil, will write an empty string.
    ///   - datetime: The DateTime the message was logged
    ///   - level: The LoggerLevel to log the message to. Messages will be written to a log in the provided LoggerLevel is less than or equal to the Logger's `level`.
    func write(_ text: String?, datetime: Date, level: LoggerLevel)
    
    /// Writes to the Logger with the given parameters
    /// - Parameters:
    ///   - text: Text to write to the log. If nil, will write an empty string.
    ///   - datetime: The DateTime the message was logged
    ///   - channel: The channel on which to log the message
    ///   - level: The LoggerLevel to log the message to. Messages will be written to a log if the provided LoggerLevel is less than or equal to the Logger's `level`.
    func write(_ text: String?, datetime: Date, channel: String, level: LoggerLevel)
}

extension Logger {
     func write(_ text: String?) {
         write("\(text ?? "")", datetime: Date(), channel: "", level: .Trace)
     }
     
     func write(_ text: String?, datetime: Date) {
         write("\(text ?? "")", datetime: datetime, channel: "", level: .Trace)
     }
    
     func write(_ text: String?, channel: String) {
         write("\(text ?? "")", datetime: Date(), channel: channel, level: .Trace)
     }

     func write(_ text: String?, datetime: Date = Date(), channel: String) {
         write("\(text ?? "")", datetime: datetime, channel: channel, level: .Trace)
    }
    
    func write(_ text: String?, level: LoggerLevel) {
        write("\(text ?? "")", datetime: Date(), channel: "", level: level)
    }

    func write(_ text: String?, channel: String, level: LoggerLevel) {
        write("\(text ?? "")", datetime: Date(), channel: channel, level: level)
    }

    func write(_ text: String?, datetime: Date, level: LoggerLevel) {
        write("\(text ?? "")", datetime: datetime, channel: "", level: level)
    }

}

struct LoggerParameters {
    var identifier: String
    var logger: Logger
}

/// A Logger that will write to multiple Loggers. This is a singleton, that should be configured using `func configure(level: LoggerLevel)`
class MultiLogger: Logger {

    /// The shared MultiLogger
    static let shared = MultiLogger(level: .Fatal)

    /// The default LoggerLevel for any loggers that have not defined their own level
    var level: LoggerLevel
    
    /// A dictionary of loggers keyed by the logger identifier
    var loggerList: [String: LoggerParameters] = [:]
    
    /// Retrieves all loggers
    var loggers: [Logger] { loggerList.keys.compactMap { loggerList[$0]!.logger } }
    
    private init(level: LoggerLevel) {
        self.level = level
    }
    
    /// Configures the MultiLogger's LoggerLevel. If `configure` is not called, the default level will be `.Fatal`
    /// - Parameter level: The MultiLogger's default logger level
    func configure(level: LoggerLevel) {
        self.level = level
    }
    
    /// Adds a logger to the `loggerList`
    /// - Parameters:
    ///   - params: A `LoggerParameters` struct that defines the logger
    ///   - clearAll: If `true`, all loggers will be cleared before adding the new logger
    func addLogger(withParameters params: LoggerParameters, clearAll: Bool = false) {
        addLoggers(withParameterList: [params], clearAll: clearAll)
    }
    
    /// Adds a logger to the `loggerList`
    /// - Parameters:
    ///   - logger: the `Logger` to add
    ///   - identifier: A string to identify the Logger.
    ///   - clearAll: If `true`, all loggers will be cleared before adding the new logger
    func addLogger(logger: Logger, identifier: String, clearAll: Bool = false) {
        let params = LoggerParameters(identifier: identifier, logger: logger)
        addLogger(withParameters: params, clearAll: clearAll)
    }

    /// Adds a set of loggers to the `loggerList`
    /// - Parameters:
    ///   - loggers: A dictionary defining the loggers, keyed off of the logger's identifier
    ///   - clearAll: If `true`, all loggers will be cleared before adding the new logger
    func addLoggers(loggers: [String: Logger], clearAll: Bool = false) {
        var paramList: [LoggerParameters] = []
        for key in loggers.keys {
            let params = LoggerParameters(identifier: key, logger: loggers[key]!)
            paramList.append(params)
        }
        addLoggers(withParameterList: paramList, clearAll: clearAll)
    }
    
    /// Adds a set of loggers to the `loggerList`
    /// - Parameters:
    ///   - params: A collection of `LoggerParameters` structs that define the loggers to add
    ///   - clearAll: If `true`, all loggers will be cleared before adding the new logger
    func addLoggers(withParameterList loggers: [LoggerParameters], clearAll: Bool = false) {
        print("Adding Loggers.  clearAll: \(clearAll)")
        if clearAll {
            loggerList.removeAll(keepingCapacity: false)
        }
        
        loggers.forEach { logger in
            self.loggerList[logger.identifier] = logger
        }
    }
    
    /// Returns `true` if a logger with the given identifier exists in the MultiLogger's logger list
    /// - Parameter identifier: The identifier to look for in the MultiLogger's logger list
    func hasLogger(identifier: String) -> Bool {
        return loggerList.keys.contains(identifier)
    }
    
    /// Write message to all Loggers with the provided parameters
    /// - Parameters:
    ///   - text: Text to write to the log. If nil, will write an empty string.
    ///   - datetime: The DateTime the message was logged
    ///   - channel: The channel on which to log the message
    ///   - level: The LoggerLevel to log the message to. Messages will be written to a log if the provided LoggerLevel is less than or equal to the Logger's `level`.
    func write(_ text: String?, datetime: Date = Date(), channel: String, level: LoggerLevel) {
        for logger in loggers {
            logger.write(text, datetime: datetime, channel: channel, level: level)
        }
    }
}


/// A Logger that logs messages to the Xcode console
class ConsoleLogger: Logger {
    
    var level: LoggerLevel

    init(level: LoggerLevel) {
        self.level = level
    }
    
    func write(_ text: String?, datetime: Date = Date(), channel: String, level: LoggerLevel) {
        if level.rawValue <= self.level.rawValue {

            var logstr = "[\(datetime)]"

            if channel != "" {
                logstr += " [\(channel)]"
            }

            print("\(logstr): \(text ?? "")")
        }
    }
}


/// A logger that logs messages to a WebLogger.
///
/// # Server
/// Server code available here: https://github.com/awtyler/loggerapi
///
class WebLogger: Logger {
    var level: LoggerLevel
    
    struct LogEntry {
        let date: Date
        let text: String
        
        func toJsonString() -> String {
            
            let formatter = DateFormatter()
            formatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss.SSSSS"
            let dateString = formatter.string(from: date)
            
            return """
            {
                "date": "\(dateString)",
                "text": "\(text.replacingOccurrences(of: "\"", with: "\\\""))"
            }
            """
        }
    }
    
    fileprivate let url: URL
    fileprivate let logName: String

    func write(_ text: String?, datetime: Date, channel: String, level: LoggerLevel) {
        if level.rawValue <= self.level.rawValue {
            let postLogName = "\(logName)\(channel != "" ? "-\(channel)" : "")"
            let url = URL(string: "\(self.url.absoluteString)\(postLogName)")
            
            let entry = LogEntry(date: datetime, text: text ?? "")
            let payload = entry.toJsonString()
            
            url?.postAndForget(withBody: payload)
        }
    }

  

    init(logName: String? = nil, url: URL, level: LoggerLevel = .Fatal) {
        self.level = level
        self.logName = logName ?? "default"
        self.url = url
    }
}
