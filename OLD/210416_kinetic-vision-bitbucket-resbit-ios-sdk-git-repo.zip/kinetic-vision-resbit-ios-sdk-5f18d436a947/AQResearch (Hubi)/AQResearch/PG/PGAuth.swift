//
//  CognitoAbstraction.swift
//  AQWritePOC
//
//  Created by Aaron on 11/6/19.
//  Copyright © 2019 Alchemy. All rights reserved.
//

import Foundation
import AWSMobileClient
import AWSAuthUI

/// Delegate to inform when a user's login status changes
protocol PGAuthDelegate: class {
    func loginStatusChanged(newUserState: UserState?, info: [String: String]?)
}

/// Overloaded function for `PGAuthDelegate`
extension PGAuthDelegate {
    func loginStatusChanged(newUserState: UserState?) {
        loginStatusChanged(newUserState: newUserState, info: nil)
    }
}

/// Errors for PGAuth
enum PGAuthError: Error {
    case ProvisioningError(message: String)
    case FormatError(message: String)
    case NotLoggedInError
    case UnknownError
    
    var localizedDescription: String {
        switch self {
        case let .ProvisioningError(message): return "ProvisioningError: \(message)"
        case let .FormatError(message): return "FormatError: \(message)"
        case .NotLoggedInError: return "NotLoggedInError: User is not logged in"
        case .UnknownError: return "Unknown Error"
        }
    }
}

/// A singleton class to handle authentication and user-related tasks and information requests. Abstracts AWS Cognito calls.
///
/// Accessed via the `shared` property
///
public class PGAuth {
    
    /// The URL used to provision a user's account
    fileprivate static let ProvisionUrl = Constants.PGAuth.provisionUrl
    
    /// The shared instance
    static var shared: PGAuth = PGAuth()
    
    /// The AWS Mobile Client
    fileprivate var mobileClient: AWSMobileClient!
    /// Flag that ensures certain portions of the `.configure` method are only executed once
    fileprivate var isConfigured: Bool = false
    /// Stores the AWS user tokens
    fileprivate var tokens: Tokens?
    
    /// Allows UI to be updated on login status changes
    weak var delegate: PGAuthDelegate?
    
    /// Exposes the AWSMobileClient object.
    ///
    /// This is required to be exposed for PGWrite, which works in tandem with PGAuth, but developers are discouraged from using it.
    var awsMobileClient: AWSMobileClient {
        return mobileClient
    }
    
    /// The logger to be used
    var logger: Logger?
    
    /// Returns the current User Authorization State
    var authState: UserState {
        return mobileClient.currentUserState
    }
    
    /// Initializes the PGAuth shared instance with a `nil` logger
    private init() {
        configure()
    }
    
    /// Gets the AWS Username
    var username: String? {
        return mobileClient.username
    }
    
    /// Sets tho logger to us
    /// - Parameter logger: The logger to use
    func setLogger(logger: Logger) {
        self.logger = logger
    }
    
    /// Initializes the AWS Mobile Client and sets the logger.
    ///
    /// While this method can be called multiple times, only the logger will be set after the first call. This is controlled by the `fileprivate var isConfigured: Bool` variable.
    ///
    /// - Parameter logger: The logger to use
    func configure(logger: Logger? = nil) {
        
        //Configure logger if it's passed in, but don't remove it if nil is passed
        if let logger = logger {
            self.logger = logger
        }
        
        //Configuration should only be called once
        guard isConfigured == false else {
            return
        }
        
        mobileClient = AWSMobileClient.default()
        
        self.logger?.write("Configuring PGAuth...")
        
        //self.logger?.write login state changes to the console
        //TODO: Remove this, or alter to re-authenticate when needed
        mobileClient.addUserStateListener(self) { (userState, info) in
            
            self.delegate?.loginStatusChanged(newUserState: userState, info: info)
            
            switch (userState) {
            case .guest:
                self.logger?.write("***** user is in guest mode.")
            case .signedOut:
                self.logger?.write("***** user signed out")
            case .signedIn:
                self.logger?.write("***** user is signed in.")
            case .signedOutUserPoolsTokenInvalid:
                self.logger?.write("***** need to login again.")
            case .signedOutFederatedTokensInvalid:
                self.logger?.write("***** user logged in via federation, but currently needs new tokens")
            default:
                self.logger?.write("***** unsupported")
            }
            
            self.mobileClient.getTokens { (tokens, error) in
                self.tokens = tokens
                self.logger?.write("Tokens: \(String(describing: tokens))")
                self.logger?.write("Error: \(String(describing: error))")
            }
        }
        
        mobileClient.initialize { (userState, error) in
            if let userState = userState {
                switch(userState){
                case .signedIn:
                    self.logger?.write("***** Logged In")
                case .signedOut:
                    self.logger?.write("***** Not Signed In")
                default:
                    self.mobileClient.signOut()
                }
            } else if let error = error {
                self.logger?.write(error.localizedDescription)
            }
        }
        
        isConfigured = true
    }
    
    /// Logs a user into AWS
    /// - Parameters:
    ///   - username: The user's username. Should be an email address
    ///   - password: The user's password
    ///   - completion: Called after attempting to log in
    func signIn(username: String, password: String, completion: @escaping ((SignInResult?, Error?) -> Void) = {(a, b) in}) {
        Event.Account.login.log()
        mobileClient.signIn(username: username, password: password) { result, error in
            
            if let error = error as? AWSMobileClientError {
                completion(result, error)
                Event.AWS.loginFailure.log()
                return
            }
            
            Event.AWS.loginSuccess.log()
            //If successful, try to provision. Otherwise, just call the completion
            if let result = result, result.signInState == .signedIn {
                self.provisionUser { provResult in
                    switch provResult {
                    case .success():
                        Event.AWS.provisionSuccess.log()
                        completion(result, error)
                    case .failure(let provError):
                        Event.AWS.provisionFailure.log()
                        completion(result, provError)
                    }
                }
            } else {
                completion(result, error)
            }
            
        }
    }
    
    /// Creates a new AWS Cognito account for a user
    /// - Parameters:
    ///   - emailAddress: The new user's email address
    ///   - password: The new user's password
    ///   - phoneNumber: The new user's phone number
    ///   - studyId: The new user's Study ID
    ///   - participantCode: The new user's Participant Code
    ///   - completion: Called after attempting to create the user
    func signUp(emailAddress: String, password: String, phoneNumber: String, studyId: String, participantCode: String, completion: @escaping((SignUpResult?, Error?) -> Void) = { signUpResult, error in }) {
        Event.Account.signUp.log()
        mobileClient.signUp(username: emailAddress,
                            password: password,
                            userAttributes: ["phone_number": "+1\(phoneNumber)",
                                "email": emailAddress,
                                "custom:study-id": studyId,
                                "custom:participant-id": participantCode
            ],
                            completionHandler: completion)
    }
    
    /// Confirms a user's email address through the AWS Cognito service
    /// - Parameters:
    ///   - username: The user's username - should be an email address
    ///   - confirmationCode: The confirmation code entered by the user.
    ///   - completion: Called after attempting to confirm the account
    func confirmAccount(username: String, confirmationCode: String, completion: @escaping ((SignUpResult?, Error?) -> Void) = { signUpResult, error in }) {
        Event.Account.confirmAccount.log()
        mobileClient.confirmSignUp(username: username, confirmationCode: confirmationCode, completionHandler: completion)
    }
    
    /// Emails a new AWS Cognito confirmation code to a user.
    /// - Parameters:
    ///   - username: The user's username - should be an email address
    ///   - completion: Called after attempting to send the confirmation code
    func resendConfirmationCode(username: String, completion: @escaping ((SignUpResult?, Error?) -> Void) = { signupResult, error in }) {
        Event.Account.resendConfirmationCode.log()
        mobileClient.resendSignUpCode(username: username, completionHandler: completion)
    }
    
    /// Logs a user out of the AWS Cognito service
    /// - Parameter completion: Called after attempting to log out
    func signOut(completion: ((Error?) -> Void)? = nil) {
        Event.Account.logout.log()
        mobileClient.signOut() { error in
            if error != nil {
                Event.AWS.logoutFailure.log()
            } else {
                Event.AWS.logoutSuccess.log()
            }
            self.delegate?.loginStatusChanged(newUserState: self.authState)
            completion?(error)
        }
    }
    
    /// Gets the user's authentication tokens from the AWS Cognito service
    /// - Parameter completion: Called after attempting to get the authentication tokens
    private func getTokens(completion: @escaping (Tokens?) -> Void) {
        self.logger?.write("Called getTokens(completion:)")
        if self.authState == .signedIn && tokens != nil {
            self.logger?.write("Tokens exist. Passing them to completion.")
            completion(self.tokens)
            return
        }
        
        self.logger?.write("Tokens don't exist yet.  Getting them.")
        
        mobileClient.getTokens { (tokens, error) in
            if let error = error {
                self.logger?.write("Error retrieving tokens: \(error)")
                self.tokens = nil
                completion(self.tokens)
            } else {
                self.logger?.write("Tokens retrieved: \(String(describing: tokens))")
                self.tokens = tokens
                completion(self.tokens)
            }
        }
    }
    
    /// Gets Device IDs associated with a user
    /// - Parameter completion: Called after the IDs are retrieved
    func getAssociatedDeviceIds(completion: @escaping (Result<[String], Error>) -> Void) {
        
        getUserAttributes { (result) in
            
            switch result {
            case let .failure(error):
                self.logger?.write("Error getting associated IDs: \(error.localizedDescription)")
            case let .success(attribs):
                if let studyId = attribs.studyId,
                    let participantId = attribs.participantId {
                    
                    if let url = Constants.PGAuth.associatedIdsUrl(studyId: studyId, participantId: participantId) {
                        
                        self.getTokens() { tokens in
                            
                            if let token = tokens?.accessToken?.tokenString {
                                
                                self.logger?.write("Found token: \(token)")
                                
                                let headers: [String: String] = [
                                    "Authorization": "Bearer \(token)"
                                ]
                                
                                url.getAndParse(for: [String].self, headers: headers) { (result) in
                                    switch result {
                                    case let .success(items):
                                        self.logger?.write("Got associated IDs: \(items)")

                                        var devices: [String] = []
                                        items.forEach {
                                            devices.append($0)
                                        }

                                        completion(.success(devices))

                                    case let .failure(error):
                                        self.logger?.write("Error getting associated IDs: \(error)")
                                        completion(.failure(error))
                                    }
                                }
                            }
                        }
                    }
                    
                } else {
                    self.logger?.write("Error getting associated IDs: Study ID or Participant ID is nil.")
                }
                
            }
        }
    }
    
    /// Requests user attributes from AWS Cognito, and passes them to the completion as a UserAttributes struct
    /// - Parameter completion: Called after attempting to get attributes from AWS Cognito
    func getUserAttributes(completion: @escaping (Result<UserAttributes, Error>) -> Void) {
        self.mobileClient.getUserAttributes { (attributes, error) in
            
            if let error = error {
                completion(.failure(error))
            } else if let attributes = attributes {
                completion(.success(UserAttributes(attributes: attributes)))
            } else {
                completion(.failure(PGAuthError.UnknownError))
            }
        }
    }
    
    /// Writes current user attributes to the Logger
    func logUserAttributes() {
        
        self.getUserAttributes { (result) in
            switch result {
            case let .success(attributes):
                self.logger?.write(attributes.debugDescription)
            case let .failure(error):
                self.logger?.write("Error! \(error.localizedDescription)")
            }
        }
    }
    
    /// Provisions a user to use the IoT services in AWS
    /// - Parameter completion: Called after attempting to provision the user
    func provisionUser(completion: @escaping (Result<Void, Error>) -> Void = { result in }) {
        
        self.mobileClient.getIdentityId().continueWith(block: { (task) -> AnyObject? in
            if let error = task.error {
                self.logger?.write("Error: " + error.localizedDescription)
                completion(.failure(PGAuthError.ProvisioningError(message: "Unable to get Identity ID, with error: \(error.localizedDescription)")))
            } else {
                // the task result will contain the identity id
                var cognitoId = task.result! as String
                
                guard let colonIndex = cognitoId.firstIndex(of: ":") else {
                    self.logger?.write("Error: cognitoId in incorrect format: \(cognitoId)")
                    completion(.failure(PGAuthError.FormatError(message: "cognitoId in incorrect format. Colon expected after region: \(cognitoId)")))
                    return task
                }
                
                let nextIndex = cognitoId.index(after: colonIndex)
                cognitoId = String(cognitoId.suffix(from: nextIndex))
                
                self.logger?.write("Cognito id: \(cognitoId)")
                
                self.logger?.write("Provisioning User...")
                self.getTokens { tokens in
                    
                    if let token = tokens?.accessToken?.tokenString {
                        
                        self.logger?.write("Found token: \(token)")
                        
                        let url = PGAuth.ProvisionUrl
                        var request = URLRequest(url: url)
                        
                        request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
                        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
                        request.httpMethod = "POST"
                        
                        request.httpBody = #"{ "identityId": "\#(cognitoId)" }"#.data(using: .utf8)
                        
                        self.logger?.write("Request Description: \n\(request.detailedDescription)")
                        
                        let task = URLSession.shared.dataTask(with: request) { data, response, error in
                            guard let data = data,
                                let response = response as? HTTPURLResponse,
                                error == nil else {                                              // check for fundamental networking error
                                    self.logger?.write("error: \(error.debugDescription)")
                                    completion(.failure(PGAuthError.ProvisioningError(message: error.debugDescription)))
                                    return
                            }
                            
                            guard (200 ... 299) ~= response.statusCode else {                    // check for http errors
                                self.logger?.write("statusCode should be 2xx, but is \(response.statusCode)")
                                self.logger?.write("response = \(response)")
                                if let responseString = String(data: data, encoding: .utf8) {
                                    self.logger?.write("responseString = \(responseString)")
                                }
                                completion(.failure(PGAuthError.ProvisioningError(message: "Expected 2xx Response Code, but got \(response.statusCode)")))
                                return
                            }
                            
                            if let responseString = String(data: data, encoding: .utf8) {
                                self.logger?.write("responseString = \(responseString)")
                            } else {
                                self.logger?.write("No body returned.")
                            }
                            
                            completion(.success(()))
                        }
                        
                        task.resume()
                    } else {
                        //No Token.  Need to login again
                        completion(.failure(PGWriteError.NotLoggedInError))
                    }
                }
            }
            return task;
        })
        
    }    
}
