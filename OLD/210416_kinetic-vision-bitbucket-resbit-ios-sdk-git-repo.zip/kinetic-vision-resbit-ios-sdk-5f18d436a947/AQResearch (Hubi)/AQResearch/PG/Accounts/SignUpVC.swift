//
//  SignUpVC.swift
//  AQResearch
//
//  Created by Aaron on 1/16/20.
//  Copyright © 2020 Procter & Gamble. All rights reserved.
//

import UIKit
import Validator
import SVProgressHUD
import AWSMobileClient

class SignUpVC: UIViewController {
    
    enum SignUpValidationError: String, ValidationError {
        case emailInvalid = "Email address is invalid"
        
        case passwordMinLength = "Password must have at least 8 characters"
        case passwordNumber = "Password must have at least one number"
        case passwordSpecialCharacter = "Password must have at least one special character"
        case passwordUppercase = "Password must have at least one uppercase character"
        case passwordLowercase = "Password must have at least one lowercase character"
        
        case confirmPasswordMatch = "Password and Confirm Password must match"
        
        case phoneInvalid = "Phone Number should contain 10 digits"
        case phoneStartNumInvalid = "Phone Number's first digit should be between 2 and 9"
        
        case studyIdLength = "Study ID should be 8 characters in length"
        case participantCodeLength = "Participant Code should be 8 characters in length"
        
        case required = "Field is required"
        
        var message: String { return self.rawValue }
    }
    
    let validations = Dictionary<UITextField, ValidationResult>()
    
    let logger = Constants.logger
    
    @IBOutlet weak var scrollView: UIScrollView!
    
    @IBOutlet weak var emailAddress: UITextField!
    @IBOutlet weak var password: UITextField!
    @IBOutlet weak var confirmPassword: UITextField!
    @IBOutlet weak var phoneNumber: UITextField!
    @IBOutlet weak var studyId: UITextField!
    @IBOutlet weak var participantCode: UITextField!
    
    @IBOutlet weak var emailError: UILabel!
    @IBOutlet weak var passwordError: UILabel!
    @IBOutlet weak var confirmPasswordError: UILabel!
    @IBOutlet weak var phoneNumberError: UILabel!
    @IBOutlet weak var studyIdError: UILabel!
    @IBOutlet weak var participantCodeError: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        clearAllValidation()
        
        registerKeyboardNotifications()
        
//        #warning("Remove test data")
//        emailAddress.text = "aaron+pgtest\(Int.random(in: 1000...9999))@atomicrobot.com"
//        password.text = "Asdf123#"
//        confirmPassword.text = "Asdf123#"
//        phoneNumber.text = "\(Int.random(in: 2000000000...9999999999))"
//        studyId.text = "ABCD\(Int.random(in: 1000...9999))"
//        participantCode.text = "WXYZ\(Int.random(in: 1000...9999))"
    }
    
    func getErrorLabel(for textField: UITextField) -> UILabel {
        switch textField {
        case emailAddress:
            return emailError
        case password:
            return passwordError
        case confirmPassword:
            return confirmPasswordError
        case phoneNumber:
            return phoneNumberError
        case studyId:
            return studyIdError
        case participantCode:
            return participantCodeError
        default:
            return emailError
        }
    }
    
    func updateValidation(for field: UITextField, validResult: ValidationResult) {
        
        field.layer.borderWidth = 1
        field.layer.cornerRadius = 5
        
        switch validResult {
        case .valid:
            field.layer.borderColor = Constants.Colors.success.cgColor
            field.backgroundColor = Constants.Colors.success.withAlphaComponent(0.15)
            getErrorLabel(for: field).isHidden = true
        case .invalid(let errors):
            field.layer.borderColor = Constants.Colors.danger.cgColor
            field.backgroundColor = Constants.Colors.danger.withAlphaComponent(0.15)
            
            let errorLabel = getErrorLabel(for: field)
            errorLabel.isHidden = false
            errors.forEach({ error in
                errorLabel.text = "\(errorLabel.text ?? "")\(error.message)\n"
            })
        }
    }
    
    func clearAllValidation() {
        clearValidation(for: emailAddress, clearMessages: true)
        clearValidation(for: password, clearMessages: true)
        clearValidation(for: confirmPassword, clearMessages: true)
        clearValidation(for: phoneNumber, clearMessages: true)
        clearValidation(for: studyId, clearMessages: true)
        clearValidation(for: participantCode, clearMessages: true)
    }
    
    func clearValidation(for field: UITextField, clearMessages: Bool) {
        field.layer.borderWidth = 0
        field.backgroundColor = nil
        
        if clearMessages {
            let errorLabel = getErrorLabel(for: field)
            errorLabel.isHidden = true
            errorLabel.text = ""
        }
    }
    
    @IBAction func editingStarted(_ sender: UITextField) {
        logger?.write("Editing Started: \(sender.placeholder!)")
        clearValidation(for: sender, clearMessages: false)
    }
    
    @IBAction func enterPressed(_ sender: UITextField) {
        
        //Only go process "Next"/"Done" if field is valid
        if validate(textField: sender, validateRequired: true)!.isValid {
            
            switch sender {
            case emailAddress:
                password.becomeFirstResponder()
            case password:
                confirmPassword.becomeFirstResponder()
            case confirmPassword:
                phoneNumber.becomeFirstResponder()
            case phoneNumber:
                studyId.becomeFirstResponder()
            case studyId:
                participantCode.becomeFirstResponder()
            case participantCode:
                createAccount(sender)
            default:
                ()  //Shouldn't be possible, but required for switch
            }
            
        }
    }
    
    @IBAction func textEdited(_ sender: UITextField) {
        //        clearValidation(for: sender)
    }
    
    
    @IBAction func validateText(_ sender: UITextField) {
        validate(textField: sender, validateRequired: false)
    }
    
    func validateAll() -> Bool {
        
        guard let participantCodeResult = validate(textField: participantCode, validateRequired: true),
            let studyIdResult = validate(textField: studyId, validateRequired: true),
            let phoneNumberResult = validate(textField: phoneNumber, validateRequired: true),
            let confirmPasswordResult = validate(textField: confirmPassword, validateRequired: true),
            let passwordResult = validate(textField: password, validateRequired: true),
            let emailAddressResult = validate(textField: emailAddress, validateRequired: true)
            else {
                return false
        }
        
        return emailAddressResult.isValid
            && passwordResult.isValid
            && confirmPasswordResult.isValid
            && phoneNumberResult.isValid
            && studyIdResult.isValid
            && participantCodeResult.isValid
    }
    
    @discardableResult
    func validate(textField: UITextField, validateRequired: Bool) -> ValidationResult? {
        var validationText = textField.text ?? ""
        var rules = ValidationRuleSet<String>()
        
        let requiredRule = ValidationRulePattern(pattern: "^.{1,}$", error: SignUpValidationError.required)
        
        if validateRequired {
            rules.add(rule: requiredRule)
        }
        
        //Clear current validation markings:
        clearValidation(for: textField, clearMessages: true)
        
        //Only validate if validating required, field has a value, or validate confirmPassword if password has a value
        if validateRequired
            || validationText != ""
            || (textField == confirmPassword
                && password.text ?? "" != "") {
            
            switch textField {
            case emailAddress:
                let emailRule = ValidationRulePattern(pattern: EmailValidationPattern.standard, error: SignUpValidationError.emailInvalid)
                rules.add(rule: emailRule)
                
            case password:
                let minLengthRule = ValidationRuleLength(min: 8, error: SignUpValidationError.passwordMinLength)
                let numRule = ValidationRulePattern(pattern: ContainsNumberValidationPattern(), error: SignUpValidationError.passwordNumber)
                
                let specialCharacterRule = ValidationRulePattern(pattern: "^.*[^a-zA-Z0-9]+.*$", error: SignUpValidationError.passwordSpecialCharacter)
                let uppercaseCharacterRule = ValidationRulePattern(pattern: "^.*[A-Z]+.*$", error: SignUpValidationError.passwordUppercase)
                let lowercaseCharacterRule = ValidationRulePattern(pattern: "^.*[a-z]+.*$", error: SignUpValidationError.passwordLowercase)
                
                rules.add(rule: minLengthRule)
                rules.add(rule: numRule)
                rules.add(rule: specialCharacterRule)
                rules.add(rule: uppercaseCharacterRule)
                rules.add(rule: lowercaseCharacterRule)
                
            case confirmPassword:
                let matchRule = ValidationRuleEquality(target: password.text ?? "", error: SignUpValidationError.confirmPasswordMatch)
                rules.add(rule: matchRule)
                
            case phoneNumber:
                let phonePattern = "^\\d{10}$"
                let phoneRule = ValidationRulePattern(pattern: phonePattern, error: SignUpValidationError.phoneInvalid)
                validationText = validationText.filter("0123456789".contains)
                
                let phoneStartRule = ValidationRulePattern(pattern: "^[2-9]{1}.*$", error: SignUpValidationError.phoneStartNumInvalid)
                
                rules.add(rule: phoneRule)
                rules.add(rule: phoneStartRule)
                
            case studyId:
                let lengthRule = ValidationRuleLength(min: 8, max: 8, lengthType: .characters, error: SignUpValidationError.studyIdLength)
                rules.add(rule: lengthRule)
                
            case participantCode:
                let lengthRule = ValidationRuleLength(min: 8, max: 8, lengthType: .characters, error: SignUpValidationError.participantCodeLength)
                rules.add(rule: lengthRule)
                
            default:
                ()  //No validation, nothing to do
            }
            
            let validationResult = validationText.validate(rules: rules)
            updateValidation(for: textField, validResult: validationResult)
            
            //            if !validationResult.isValid {
            //                textField.becomeFirstResponder()
            //            }
            
            return validationResult
        }
        return nil
    }
    
    @IBAction func createAccount(_ sender: Any) {

        logger?.write("Creating Account...")
        guard validateAll() else { return }
        
        SVProgressHUD.show(withStatus: "Creating account...")
        
        if let email = emailAddress.text,
            let pwd = password.text,
            let pn = phoneNumber.text,
            let sid = studyId.text,
            let pc = participantCode.text {

            PGAuth.shared.signUp(emailAddress: email, password: pwd, phoneNumber: pn, studyId: sid, participantCode: pc) { signUpResult, error in
                
                DispatchQueue.main.async {
                    
                    if let error = error {
                        
                        if let error = error as? AWSMobileClientError {
                            self.logger?.write("error: \(error); message: \(error.localizedDescription)")
                        } else {
                            self.logger?.write("SignUp Process error: \(error.localizedDescription)")
                        }
                        
                        SVProgressHUD.showErrorAndDismiss(withStatus: "Error creating account! Please try again.")
                        return
                    }
                    
                    if let signUpResult = signUpResult {
                        switch signUpResult.signUpConfirmationState {
                        case .confirmed:
                            self.logger?.write("User is signed up and confirmed.")
                            SVProgressHUD.dismiss()
                            self.navigationController?.popViewController(animated: true)
                        case .unconfirmed:
                            self.logger?.write("User is not confirmed and needs verification via \(signUpResult.codeDeliveryDetails!.deliveryMedium) sent at \(signUpResult.codeDeliveryDetails!.destination!)")
                            self.performSegue(withIdentifier: "confirmAccountSegue", sender: nil)
                            SVProgressHUD.dismiss()
                        case .unknown:
                            self.logger?.write("Unexpected case")
                            SVProgressHUD.showErrorAndDismiss(withStatus: "Error creating account. Please try again.")
                        }
                        
                    } else {
                        self.logger?.write("Error signing up user. signUpResult is nil.")
                        SVProgressHUD.showErrorAndDismiss(withStatus: "Error creating account. Please try again.")
                    }
                }
            }
        } else {
            //This should never be called, but since UITextField.text is optional, I don't want to force-unwrap it.
            SVProgressHUD.showErrorAndDismiss(withStatus: "Error creating account. Please try again.")

        }
    }
    
    //MARK: - Segue
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "confirmAccountSegue" {
            let dest = segue.destination as! ConfirmAccountVC
            
            guard let username = emailAddress.text, username != "",
                let password = password.text, password != "" else {
                logger?.write("Error loading ConfirmAccountVC: Email Address is empty")
                return
            }
            
            dest.username = username
            dest.password = password
        }
    }
    
    //MARK: - Keyboard Interactions
    func registerKeyboardNotifications() {
        let notificationCenter = NotificationCenter.default
        notificationCenter.addObserver(self, selector: #selector(keyboardWillHide), name: UIResponder.keyboardWillHideNotification, object: nil)
        notificationCenter.addObserver(self, selector: #selector(keyboardWillShow), name: UIResponder.keyboardWillChangeFrameNotification, object: nil)    }
    
    @objc func keyboardWillShow(notification:NSNotification){
        let userInfo = notification.userInfo!
        var keyboardFrame:CGRect = (userInfo[UIResponder.keyboardFrameBeginUserInfoKey] as! NSValue).cgRectValue
        keyboardFrame = self.view.convert(keyboardFrame, from: nil)
        
        var contentInset:UIEdgeInsets = self.scrollView.contentInset
        contentInset.bottom = keyboardFrame.size.height
        scrollView.contentInset = contentInset
    }
    
    @objc func keyboardWillHide(notification:NSNotification){
        
        let contentInset:UIEdgeInsets = UIEdgeInsets.zero
        scrollView.contentInset = contentInset
    }
    
}
