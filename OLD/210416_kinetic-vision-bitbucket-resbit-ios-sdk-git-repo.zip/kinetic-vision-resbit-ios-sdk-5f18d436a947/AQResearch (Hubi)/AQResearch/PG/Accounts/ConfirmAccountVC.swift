//
//  ConfirmAccountVCViewController.swift
//  AQResearch
//
//  Created by Aaron on 1/23/20.
//  Copyright © 2020 Procter & Gamble. All rights reserved.
//

import UIKit
import SVProgressHUD
import AWSMobileClient

class ConfirmAccountVC: UIViewController {
    
    
    @IBOutlet weak var scrollView: UIScrollView!
    @IBOutlet weak var confirmationCode: UITextField!
    @IBOutlet weak var confirmationCodeError: UILabel!
    @IBOutlet weak var confirmButton: UIButton!
    
    var logger: Logger?
    
    var username: String!
    var password: String!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        logger = Constants.logger
        
        logger?.write("Ready to confirm account with username: \(username ?? "nil")")
        
        registerKeyboardNotifications()
    }
    
    @IBAction func enterPressed(_ sender: UITextField) {
        confirmAccount(nil)
    }
    
    @IBAction func resendCode(_ sender: Any) {
        
        SVProgressHUD.show(withStatus: "Resending confirmation code...")
        
        PGAuth.shared.resendConfirmationCode(username: username) { signUpResult, error in
            DispatchQueue.main.async {
                SVProgressHUD.dismiss()
            }
        }
        
    }
    
    @IBAction func confirmAccount(_ sender: UIButton?) {
        
        SVProgressHUD.show(withStatus: "Confirming Account...")
        
        PGAuth.shared.confirmAccount(username: username, confirmationCode: confirmationCode.text ?? "") { signUpResult, error in
            DispatchQueue.main.async {
                
                if let error = error {
                    self.confirmationCode.text = ""
                    if let error = error as? AWSMobileClientError {
                        self.logger?.write("Error confirming account: \(error.localizedDescription)")
                    } else {
                        self.logger?.write("Error confirming account: \(error.localizedDescription)")
                    }
                    SVProgressHUD.showErrorAndDismiss(withStatus: "Error confirming account! Please try again.")
                    return
                }
                
                if let result = signUpResult {
                    self.logger?.write("Confirmed call complete with result: \(signUpResult.debugDescription)")
                    switch result.signUpConfirmationState {
                    case .confirmed:
                        //Account provisioned. Log into it.
                        SVProgressHUD.show(withStatus: "Logging you in...")
                        PGAuth.shared.signIn(username: self.username, password: self.password) { signInResult, error in
                            DispatchQueue.main.async {
                                if let error = error {
                                    if let error = error as? AWSMobileClientError {
                                        self.logger?.write("Error logging in: \(error.localizedDescription)")
                                    } else {
                                        self.logger?.write("Error logging in: \(error.localizedDescription)")
                                    }
                                    SVProgressHUD.showErrorAndDismiss(withStatus: "Account created, but there was an error logging in! Please try again.", delay: 4)
                                    self.navigationController?.popToLastViewController(with: LogInVC.self, animated: true)
                                    return
                                }
                                
                                if let result = signInResult {
                                    switch result.signInState {
                                    case .signedIn:
                                        SVProgressHUD.dismiss()
                                        self.navigationController?.popToLastViewController(with: SensorListTVC.self, animated: true)
                                    default:
                                        SVProgressHUD.showErrorAndDismiss(withStatus: "Account created, but there was an error logging in! Please try again.", delay: 4)
                                        self.navigationController?.popToLastViewController(with: LogInVC.self, animated: true)
                                    }
                                } else {
                                    //Shouldn't get here, because either `error` or `signInResult` should have a value
                                    SVProgressHUD.showErrorAndDismiss(withStatus: "Account created, but there was an error logging in! Please try again.", delay: 4)
                                    self.navigationController?.popToLastViewController(with: LogInVC.self, animated: true)
                                }
                            }
                        }
                        
                    case .unconfirmed:
                        self.confirmationCode.text = ""
                        SVProgressHUD.showErrorAndDismiss(withStatus: "Error confirming account! Please try again.")
                        return
                    case .unknown:
                        self.confirmationCode.text = ""
                        SVProgressHUD.showErrorAndDismiss(withStatus: "Error confirming account! Please try again.")
                        return
                    }
                }
                
            }
        }
    }
    
    //MARK: - Keyboard Interactions
    func registerKeyboardNotifications() {
        let notificationCenter = NotificationCenter.default
        notificationCenter.addObserver(self, selector: #selector(keyboardWillHide), name: UIResponder.keyboardWillHideNotification, object: nil)
        notificationCenter.addObserver(self, selector: #selector(keyboardWillShow), name: UIResponder.keyboardWillChangeFrameNotification, object: nil)    }
    
    @objc func keyboardWillShow(notification:NSNotification){
        let userInfo = notification.userInfo!
        var keyboardFrame:CGRect = (userInfo[UIResponder.keyboardFrameBeginUserInfoKey] as! NSValue).cgRectValue
        keyboardFrame = self.view.convert(keyboardFrame, from: nil)
        
        var contentInset:UIEdgeInsets = self.scrollView.contentInset
        contentInset.bottom = keyboardFrame.size.height
        scrollView.contentInset = contentInset
    }
    
    @objc func keyboardWillHide(notification:NSNotification){
        
        let contentInset:UIEdgeInsets = UIEdgeInsets.zero
        scrollView.contentInset = contentInset
    }
    
}
