//
//  LogInVC.swift
//  AQResearch
//
//  Created by Aaron on 1/16/20.
//  Copyright © 2020 Procter & Gamble. All rights reserved.
//

import UIKit
import AWSMobileClient
import SVProgressHUD

class LogInVC: UIViewController {
    
    @IBOutlet weak var emailAddress: UITextField!
    @IBOutlet weak var password: UITextField!
    @IBOutlet weak var logInButton: UIButton!
    @IBOutlet weak var signUpButton: UIButton!
    @IBOutlet weak var scrollView: UIScrollView!
    
    var logger: Logger? = Constants.logger
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        emailAddress.isEnabled = true
        emailAddress.isUserInteractionEnabled = true
     
        signUpButton.isHidden = true
        
        registerKeyboardNotifications()
    }
    
    @IBAction func enterPressed(_ sender: UITextField) {
        
        switch sender {
        case emailAddress:
            password.becomeFirstResponder()
        case password:
            logIn(nil)
        default:
            ()  //Can only be email or password, but required for switch
        }
        
    }
    
    @IBAction func logIn(_ sender: Any?) {
        
        logger?.write("Logging in...")
        
        guard let username = emailAddress.text,
            let password = password.text else {
                logger?.write("Username or Password text is nil")
                return
        }
        
        SVProgressHUD.show(withStatus: "Logging in...")
        PGAuth.shared.signIn(username: username, password: password) { signInResult, error in
            DispatchQueue.main.async {
                if let error = error {
                    if let error = error as? AWSMobileClientError {
                        switch error {
                        case .userNotConfirmed:
                            SVProgressHUD.dismiss()
                            self.performSegue(withIdentifier: "confirmAccountFromLoginSegue", sender: nil)
                        default:
                            self.logger?.write("Error logging in: \(error.localizedDescription)")
                            SVProgressHUD.showErrorAndDismiss(withStatus: "Error logging in! Please try again.")
                        }
                    } else {
                        self.logger?.write("Error logging in: \(error.localizedDescription)")
                        SVProgressHUD.showErrorAndDismiss(withStatus: "Error logging in! Please try again.")
                    }
                    return
                }
                
                guard let signInResult = signInResult else {
                    self.logger?.write("Error logging in: signInResult is nil")
                    SVProgressHUD.showErrorAndDismiss(withStatus: "Error logging in! Please try again.")
                    return
                }
                
                switch signInResult.signInState {
                case .signedIn:
                    SVProgressHUD.dismiss()
                    self.navigationController?.popViewController(animated: true)
                default:
                    //FIXME: Handle other cases here
                    SVProgressHUD.showErrorAndDismiss(withStatus: "Error logging in user: \(signInResult.signInState.rawValue)")
                }
            }
        }
        
    }
    
    @IBAction func signUp(_ sender: Any) {
        performSegue(withIdentifier: "signUpSegue", sender: self)
    }
    
    //MARK: - Segues
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "confirmAccountFromLoginSegue" {
            let dest = segue.destination as! ConfirmAccountVC
            dest.username = emailAddress.text ?? ""
            dest.password = password.text ?? ""
        }
    }
    
    //MARK: - Keyboard Interactions
    func registerKeyboardNotifications() {
        let notificationCenter = NotificationCenter.default
        notificationCenter.addObserver(self, selector: #selector(keyboardWillHide), name: UIResponder.keyboardWillHideNotification, object: nil)
        notificationCenter.addObserver(self, selector: #selector(keyboardWillShow), name: UIResponder.keyboardWillChangeFrameNotification, object: nil)    }
    
    @objc func keyboardWillShow(notification:NSNotification){
        let userInfo = notification.userInfo!
        var keyboardFrame:CGRect = (userInfo[UIResponder.keyboardFrameBeginUserInfoKey] as! NSValue).cgRectValue
        keyboardFrame = self.view.convert(keyboardFrame, from: nil)
        
        var contentInset:UIEdgeInsets = self.scrollView.contentInset
        contentInset.bottom = keyboardFrame.size.height
        scrollView.contentInset = contentInset
    }
    
    @objc func keyboardWillHide(notification:NSNotification){
        
        let contentInset:UIEdgeInsets = UIEdgeInsets.zero
        scrollView.contentInset = contentInset
    }

    
}
