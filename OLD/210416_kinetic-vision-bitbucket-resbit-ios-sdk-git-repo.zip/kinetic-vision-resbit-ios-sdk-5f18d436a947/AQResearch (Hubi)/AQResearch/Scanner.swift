//
//  Scanner.swift
//  BeaconBleTest
//
//  Created by Aaron on 12/16/19.
//  Copyright © 2019 Atomic Robot. All rights reserved.
//

import Foundation
import CoreBluetooth
import CoreLocation
import ResearchBit
import UIKit

/// Errors created by the Scanner class
enum ScannerError: Error {
    /// An error passed back from scanning via ResearchBit
    case ScanError(message: String)
    /// An error passed back froum connecting to BLE via ResearchBit
    case ConnectError(message: String)
    
    /// Description of the error
    var localizedDescription: String {
        switch self {
        case let .ScanError(message): return "ScanError: \(message)"
        case let .ConnectError(message): return "ConnectError: \(message)"
        }
    }
}

/// A singleton that does all the heavy lifting of dealing with the ResearchBit SDK
/// Access via the `.shared` property
///
/// - Manages the BLE device list
/// - Starts & Stops Monitoring for known beacons
///
class Scanner {
    
    /// A list of the sensors that have been found and saved for this user. Stored in UserDefaults
    @Storage(key: Constants.Keys.UserDefaults.sensorList, defaultValue: [])
    var sensors: [Sensor]
    
    /// The CLLocationManager used by the Beacons
    var locationManager: CLLocationManager!
    /// UI ViewDelegate to update when sensors change
    var uiDelegate: AQResearchViewDelegate?
    /// The queue to used when connecting to devices, so only one connection can happen at a time
    var connectQueue: OperationQueue
    /// The ResearchBit SDK
    var researchBit: ResearchBit!
    /// The Logger to write status messages to
    var logger: Logger?
    
    /// The shared instance
    static var shared: Scanner = Scanner()
    
    var devicesToAdd: [BLEDevice] = []
    
    /// Initialize the Scanner. Defaults the `connectQueue.maxConcurrentOperationCount` to `1`
    private init() {
        connectQueue = OperationQueue()
        connectQueue.maxConcurrentOperationCount = 1
    }
    
    /// Configures the scanner instance
    /// - Parameters:
    ///   - researchBit: The ResearchBit instance
    ///   - locationManager: The LocationManager instance
    ///   - locationManagerDelegate: The LocationManagerDelegate
    ///   - logger: The Logger
    func configure(researchBit: ResearchBit,
                   locationManager: CLLocationManager,
                   locationManagerDelegate: CLLocationManagerDelegate,
                   logger: Logger?) {
        self.logger = logger
        logger?.write("Configuring Scanner...")
        self.locationManager = locationManager
        self.locationManager.delegate = locationManagerDelegate
        self.locationManager.requestAlwaysAuthorization()
        self.researchBit = researchBit
        logger?.write("Logger configured.")
    }
    
    /// Returns whether the app is currently monitoring for the given Beacon
    /// - Parameter params: The `BeaconParameters` of the beacon to check for
    func isMonitoringForBeacon(with params: BeaconParameters) -> Bool {
        self.logStatus()
        logger?.write("Checking whether monitoring region: \(params.description)")
        for region in locationManager.monitoredRegions {
            if let bregion = region as? CLBeaconRegion {
                if params.matches(region: bregion) {
                    return true
                }
            }
        }
        return false
    }
    
    /// Updates the properties of the given sensor, matching on the sensor's `uuid` field
    /// - Parameter sensor: The sensor to update
    func update(sensor: Sensor) {
        if let index = sensors.firstIndex(where: { $0.uuid == sensor.uuid }) {
            sensors[index] = sensor
        } else {
            sensors.append(sensor)
        }
        uiDelegate?.sensorsUpdated()
    }
    
    /// Starts monitoring for beacons in the `sensors` list
    func startScanning() {
        
        logger?.write("Starting to monitor for beacons. Currently Status: ")
        logStatus()
        
        let status = CLLocationManager.authorizationStatus()
        Event.Beacon.authorizationStatus(status: status).log()
        
        if status == .authorizedAlways || status == .authorizedWhenInUse {
            logger?.write("Monitor for beacons authorized with status: \(status.description)")
            for sensor in sensors {
                if let params = sensor.beaconParams {
                    startScanning(forBeacon: params)
                }
            }
        } else {
            logger?.write("Not authorized to range/monitor for beacons, with status: \(status.description)")
            Event.Beacon.monitoringFailed.log()
        }
    }
    
    /// Stops monitoring for all beacons currently being monitored
    func stopScanning() {
        logger?.write("Monitoring stopping...")
        Event.Beacon.stoppedMonitoring.log()
        for region in locationManager.monitoredRegions {
            logger?.write("   Stopping monitor for region: \(region.identifier)")
            locationManager.stopMonitoring(for: region)
        }
        
        logger?.write("Monitoring stopped.")
    }
    
    /// Starts scanning for a single beacon
    /// - Parameter beacon: The `BeaconParameters` of the beacon to start scanning for
    func startScanning(forBeacon beacon: BeaconParameters) {
        let beaconRegion = CLBeaconRegion(proximityUUID: beacon.uuid, major: beacon.major, minor: beacon.minor, identifier: beacon.identifier ?? beacon.description)
        beaconRegion.notifyEntryStateOnDisplay = true
        
        if CLLocationManager.isMonitoringAvailable(for: CLBeaconRegion.self) {
            Constants.logger?.write("Monitoring for beacon: {uuid: \(beacon.uuid.uuidString.prefix(8)), major: \(beacon.major), minor: \(beacon.minor), identifier: \(beacon.identifier ?? "nil")}")
            locationManager.startMonitoring(for: beaconRegion)
        } else {
            Constants.logger?.write("Monitoring for beacons not available.")
        }
    }

    
    // //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    // //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    // //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

   var connectTask: UIBackgroundTaskIdentifier? = nil
   var completionSemaphore: DispatchSemaphore? = DispatchSemaphore(value: 1)
   var connectSemaphore: DispatchSemaphore? = DispatchSemaphore(value: 1)
   var completionQueue: DispatchQueue? = DispatchQueue(label: "completionQueue", qos: .background)
//    var sensorQueue: DispatchQueue?
   var sensorQueue: DispatchQueue? = DispatchQueue(label: "sensorQueue", qos: .background)
   var queueCount = 0

   /// Attempts to connect to all sensors in the `sensors` list, one at a time, then calls the completion
   /// - Parameter completion: Called after all connections have either succeeded or failed.
   func connectToKnownSensorsAndPostSummaryData(completion: @escaping () -> Void = {}) {

       logger?.write("RESTARTING \(#function)")

       let logger = self.logger

       logger?.write("Attempting to connect to known sensors...")
       DispatchQueue.global(qos: .background).async {

           logger?.write("Starting background task...")
           var connectTask = UIApplication.shared.beginBackgroundTask(withName: #function, expirationHandler: nil)

//            self.completionQueue = DispatchQueue(label: "completionQueue", qos: .background, autoreleaseFrequency: .workItem, target: nil)
//            self.completionSemaphore = DispatchSemaphore(value: 1)
//            self.connectSemaphore = DispatchSemaphore(value: 1)
           logger?.write("queueCount 1 CREATE (cs start): \(self.queueCount)"); self.queueCount += 1

           if self.sensors.count > 0 {

               self.completionQueue?.async {
                   logger?.write("queueCount 2 WAIT(x) (cs mid): \(self.queueCount)"); self.queueCount += 1
                   self.completionSemaphore?.wait()
                   PGWrite.shared.connect { (status, error) in
                       switch status {
                       case .connected:
                           logger?.write("Connected")
                           logger?.write("Saved Sensors (\(self.sensors.count)): ")

//                            self.sensorQueue = DispatchQueue(label: "sensorQueue", qos: .background, autoreleaseFrequency: .workItem, target: nil)
                           
                           logger?.write("queueCount 2 CREATE(x) (sem start): \(self.queueCount)"); self.queueCount += 1

                           for sensor in self.sensors {
                               self.sensorQueue?.async {
                                   logger?.write("Waiting for sensor queue...")
                                   logger?.write("queueCount 3 WAIT (sem mid): \(self.queueCount)"); self.queueCount += 1
                                   self.connectSemaphore?.wait()
                                   logger?.write("Connecting to sensor...")
                                   logger?.write("   \(sensor.uuid)")
                                   self.connectAndPostSummaryData(toSensor: sensor) { result in
                                       logger?.write("Processing sensor...")
                                       logger?.write("queueCount 6 SIGNAL (sem mid): \(self.queueCount)"); self.queueCount += 1
                                       self.connectSemaphore?.signal()
                                   }
                               }
                           }

                           self.sensorQueue?.async {
                               logger?.write("Waiting for sensor queue (end)...")
                               logger?.write("queueCount 4 WAIT (sem end): \(self.queueCount)"); self.queueCount += 1
                               self.connectSemaphore?.wait()
                               logger?.write("queueCount 7 SIGNAL (cs mid): \(self.queueCount)"); self.queueCount += 1
                               self.completionSemaphore?.signal()
                               self.connectSemaphore?.signal()
                               logger?.write("Sensor Connections complete.")
                           }
                           return
                       case .connectionError:
                           logger?.write("Error connecting 1: \(error?.localizedDescription ?? "nil")")
                       case .connectionRefused:
                           logger?.write("Error connecting 2: \(error?.localizedDescription ?? "nil")")
                       case .protocolError:
                           logger?.write("Error connecting 3: \(error?.localizedDescription ?? "nil")")
                       case .unknown:
                           logger?.write("Error connecting 4: status is \"Unknown\"")
                       default:
                           logger?.write("Connecting...")
                           ()  //Do nothing - Only try to do something if connected
                           
                       }
                   }
               }
           } else {
               logger?.write("No devices saved")
           }

           self.completionQueue?.async {
               logger?.write("queueCount 5 WAIT (cs end): \(self.queueCount)"); self.queueCount += 1
               let semaphoreResult = self.completionSemaphore?.wait(timeout: .now() + 20) //Force timeout after 9 minutes so .endBackgroundTask always gets executed
               logger?.write("queueCount 8 WAIT (cs done): \(self.queueCount)"); self.queueCount += 1
               logger?.write("Semaphore result: \(String(describing: semaphoreResult))")
               completion()
               logger?.write("Background task complete.")
               if let task = self.connectTask {
                   UIApplication.shared.endBackgroundTask(task)
               }
               self.connectTask = .invalid

               logger?.write("queueCount 9 FINISHED (cs): \(self.queueCount)"); self.queueCount += 1
               self.completionSemaphore?.signal()   //Need to signal semaphore so it can be replaced
           }
       }
   }

    
    // //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    // //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    // //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    
    // 240FAA08-2498-4B36-BC0C-EDCCC32D0635
    // 47-00-1C-00-11-50-4B-33-43-39-35-20
    
    
    /// Attempts to connect to a `BLEDevice` with the given UUID
    /// - Parameters:
    ///   - uuid: The UUID of the `BLEDevice` to connect to
    ///   - completion: Called after attempting to connect
    func connectToPeripheral(withUuid uuid: UUID, completion: @escaping (Result<[SummaryData], Error>) -> Void) {
        
        self.logger?.write("Attempting to connect to device \(String(uuid.uuidString.prefix(8)))")
        self.researchBit.getBLEDeviceSummaryData(peripheralUUID: uuid) { result in
            
            switch result {
            case let .failure(error):
                self.logger?.write("    Error connecting to device \(String(uuid.uuidString.prefix(8))): \(error.localizedDescription)")
                Event.BluetoothDevice.connectFailure.log()
                completion(.failure(ScannerError.ConnectError(message: error.localizedDescription)))
            case let .success(summaryData):
                Event.BluetoothDevice.connectSuccess.log()
                completion(.success(summaryData))
            }
        }
    }
    
    /// Attempts to connect to a `BLEDevice` for the given `Sensor`
    /// - Parameters:
    ///   - sensor: The `Sensor` to connect to`
    ///   - completion: Called after attempting to connect
    func connect(toSensor sensor: Sensor, completion: @escaping (Result<[SummaryData], Error>) -> Void) {
        let uuid = sensor.uuid
        connectToPeripheral(withUuid: uuid, completion: completion)
    }

    var postAttemptCount: Int = 0
    /// Attempts to connect to a `BLEDevice` and posts the result to AWS via MQTT
    /// - Parameters:
    ///   - sensor: The sensor to connect to
    ///   - completion: Called after attempting to connect
    func connectAndPostSummaryData(toSensor sensor: Sensor, completion: @escaping (Result<Void, Error>) -> Void = { _ in } ) {
        postAttemptCount += 1
        logger?.write("\(#function) Count: \(postAttemptCount)")
        let uuid = sensor.uuid
        logger?.write("Queuing connect to device: \(String(uuid.uuidString.prefix(8)))")
        
        var currentSensor = sensors.first(where: { $0.uuid == sensor.uuid })
        
        let logger = self.logger
        
        self.logger?.write("Attempting to connect to device \(String(uuid.uuidString.prefix(8)))")
        self.researchBit.getBLEDeviceSummaryData(peripheralUUID: uuid) { (result) in
            
            switch result {
            case let .failure(error):
                self.logger?.write("    Error connecting to device \(String(uuid.uuidString.prefix(8))): \(error.localizedDescription)")
                completion(.failure(error))
                return
            case let .success(summaryData):
                if summaryData.count > 0 {
                    PGWrite.shared.writeSummaryData(summaryData: summaryData, sensor: sensor) { result in
                        switch result {
                        case .success:
                            Event.AWS.writeMQTTSuccess.log()
                            logger?.write("   Found data [\(String(uuid.uuidString.prefix(8)))]: \(summaryData.count)", channel: "ble-connection")
                            let advertisement = SensorAdvertisement(uuid: sensor.uuid.uuidString, summaryStatus: "Complete", timestamp: Date(), summaryData: summaryData)
                            
                            logger?.write("Updating sensor: \(currentSensor?.debugDescription ?? "nil")")
                            
                            if currentSensor != nil {
                                currentSensor!.lastAdvertisement = advertisement
                                self.update(sensor: currentSensor!)
                            }
                            
                            logger?.write("   **** Updated sensor time: \(currentSensor?.lastAdvertisement?.timestamp.shortTimeAgoSinceNow ?? "None")")
                            
                            self.uiDelegate?.sensorsUpdated()
                        case .failure(let error):
                            Event.AWS.writeMQTTFailure.log()
                            logger?.write("   Error writing summary data: \(error)")
                        }
                    }
                    
                } else {
                    logger?.write("   No data found")
                    Event.BluetoothDevice.noData.log()
                }
                completion(.success(()))
            }
        }
    }
    
    //Try to repeat the scan once if BT state != .poweredOn
    /// `doScan(scanTime:for:completion)` sometimes fails with a "Bluetooth not powered on" error, even though BT is actually powered on and enabled. This flag allows a second attempt.
    var shouldRepeatScanOnFail: Bool = true
    var scanSemaphore: DispatchSemaphore? = DispatchSemaphore(value: 1)
    
    private func doScan(scanTime: Int, for deviceIds: [String], completion: @escaping (Result<[BLEDevice], Error>) -> Void = {_ in } ) {
        
        devicesToAdd = []
        
        let logger = self.logger
        researchBit.scanForBLEDevices(scanTime: scanTime) { result in
            
            Event.BluetoothDevice.scan.log()
            
            switch result {
            case let .success(peripherals):
                logger?.write("Found \(String(describing: (peripherals).count)) devices.")
                
                if peripherals.count > 0 {
                    
                    //Create a semaphore to ensure that all peripherals are connected to in sequence, and we wait until all are complete before calling the completion
                    let queue = DispatchQueue(label: "bleDeviceQueue", qos: .background)
//                    self.scanSemaphore = DispatchSemaphore(value: 1)
                    
                    for peripheral in peripherals {
                        queue.async {
                            
                            //Wait for semaphore
                            logger?.write("Waiting for semaphore...")
                            self.scanSemaphore?.wait()
                            
                            logger?.write("   Found device: \(String(describing: peripheral.name)): \(peripheral.identifier)")
                            
                            self.researchBit.getBLEDevice(peripheral: peripheral) { (result) in
                                switch result {
                                case let .failure(error):
                                    logger?.write("Error getting BLE device for peripheral \(peripheral.identifier.uuidString.prefix(8)): \(error)")
                                case let .success(device):
                                    //Connect to the device and see if it belongs to the user's account.
                                    
                                    // Setting this to `true` will ignore devices retrieved from Cognito
                                    let CONNECT_TO_ANY = false

                                    logger?.write("Checking Device SerialID (\(device.serialID)) against deviceIds: \(deviceIds)")

                                    var shouldConnect = false
                                    for id in deviceIds {
                                        if device.serialID.contains(id) {
                                            logger?.write(" - Can add device \(id) (\(device.serialID))")
                                            shouldConnect = true;
                                        } else {
                                            logger?.write(" - Cannot add device \(id) (\(device.serialID))")
                                        }
                                    }

                                    if CONNECT_TO_ANY || shouldConnect {
                                        
                                        if CONNECT_TO_ANY {
                                            logger?.write("Ignoring user-assigned IDs and connecting to any device found.")
                                        }
                                        
                                        logger?.write("Comparing \(device.peripheral.identifier)")
                                        
                                        logger?.write("      Adding Device: \(device.deviceName ?? "nil"): \(device.serialID.prefix(8))")
                                        Event.BluetoothDevice.addedDevice.log()
                                        self.devicesToAdd.append(device)
                                    } else {
                                        logger?.write("      Not adding!")
                                    }
                                }
                                
                                //Release the semaphore for the next device
                                self.scanSemaphore?.signal()
                            }
                        }
                    }
                    
                    queue.async {
                        self.scanSemaphore?.wait()
                        logger?.write("Devices to Add: \(self.devicesToAdd)")
                        completion(.success(self.devicesToAdd))
                        self.scanSemaphore?.signal()
                    }
                    
                } else {
                    logger?.write("   No devices found.")
                    completion(.success([]))
                }
            case let .failure(error):
                logger?.write("BT Scan Error: \(error.localizedDescription)")
                completion(.failure(ScannerError.ScanError(message: "BT Scan Error: \(error.localizedDescription)")))
            }
        }
    }
    
    /// Scans for new `BLEDevice`s
    /// - Parameters:
    ///   - scanTime: Number of seconds to scan
    ///   - deviceUuids: BLEDevice Serial IDs to search for
    ///   - completion: Called after the scan completes
    func scan(scanTime: TimeInterval? = nil, for deviceIds: [String], completion: @escaping (Result<[BLEDevice], Error>) -> Void = {_ in } ) {
        var intScanTime = 3
        if let scanTime = scanTime {
            intScanTime = Int(scanTime)
        }
        
        let state = RBBTManager.shared.btState
        
        switch state {
        case .poweredOn:
            logger?.write("Bluetooth is powered on with state: \(state.description)")
            logger?.write("Scanning for new devices for \(intScanTime) seconds.")
            
            shouldRepeatScanOnFail = true
            
            doScan(scanTime: intScanTime, for: deviceIds, completion: completion)
            
        default:
            logger?.write("Bluetooth not powered on with state: \(state.description)")
            
            if shouldRepeatScanOnFail {
                logger?.write("Trying again after 1 second...")
                shouldRepeatScanOnFail = false
                
                //Retry has to be on background thread; it seems the BT state is locked for the execution of the function
                DispatchQueue.global(qos: .background).asyncAfter(deadline: .now() + 1) {
                    self.logger?.write("Trying again now.")
                    self.doScan(scanTime: intScanTime, for: deviceIds, completion: completion)
                }
            } else {
                shouldRepeatScanOnFail = true
                
                let error = NSError(domain: "Error", code: 1, userInfo: [ NSLocalizedDescriptionKey: "Bluetooth is not powered on."])
                Event.BluetoothDevice.managerState(state: state).log()
                
                completion(.failure(ScannerError.ScanError(message: error.localizedDescription)))
            }
        }
    }
    
    /// Writes the current status of sensors and beacons to the `logger`
    /// # Includes:
    /// - List of sensors that are saved for the user
    /// - List of beacons the app is currently monitoring for
    func logStatus() {
        logger?.write("Found Sensors:")
        for sensor in sensors {
            logger?.write("   \(sensor.uuid) / \(sensor.beaconParams?.shortDescription ?? "No beacon")")
        }
        
        logger?.write("Currently Monitoring: ")
        for region in locationManager.monitoredRegions {
            logger?.write("   \(region.identifier)")
        }
    }
    
}
