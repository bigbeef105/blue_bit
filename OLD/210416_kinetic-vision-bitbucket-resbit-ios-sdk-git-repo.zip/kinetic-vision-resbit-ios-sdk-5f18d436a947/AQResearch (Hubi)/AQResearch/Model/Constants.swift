//
//  Constants.swift
//  AQResearch
//
//  Created by Aaron on 11/26/19.
//  Copyright © 2019 Procter & Gamble. All rights reserved.
//

import Foundation
import UIKit


/// Constants for use in this implementation of the app.
struct Constants {
    
    /// URL where an HTML file of the EULA is available. Accessible via the web and displayed in a WKWebView.
    static var eulaUrl = URL(string: "https://aq-research-ios-assets.s3.amazonaws.com/eula.html")!

    /// Keys for for dictionaries
    struct Keys {
        /// Defines keys used in UserDefaults
        struct UserDefaults {
            /// The key for storing the UUIDs of discovered Sensors
            static let sensorList = "AQKEY_SensorList"
        }

        /// Defines keys used by AWS Cognito User Attributes
        struct UserAttributes {
            static let phoneNumberVerified = "phone_number_verified"
            static let participantId = "custom:participant-id"
            static let studyId = "custom:study-id"
            static let emailVerified = "email_verified"
            static let email = "email"
            static let sub = "sub"
            static let phoneNumber = "phone_number"
        }
    }
    
    /// Cell Identifiers
    struct CellIdentifiers {
        /// The status cell
        static let statusCell = "statusCell"
    }

    /// Images
    struct Images {
        
        /// Images used in the Login/SignUp screens and to show Login status
        struct Login {
            static let loggedIn  = UIImage(named: "user_login")!
            static let loggedOut = UIImage(named: "user_login")!
            static let appLogo    = UIImage(named: "logo")!

            static let emailVerified = UIImage(named: "email_verified")!
            static let emailUnverified = UIImage(named: "email_unverified")!

            /// Login Images that are tinted with default colors
            struct Colored {
                static let loggedIn  = Login.loggedIn.tintWith(color: Colors.success)
                static let loggedOut = Login.loggedIn.tintWith(color: Colors.inactive)
                static let emailVerified = Login.emailVerified.tintWith(color: Colors.success)
                static let emailUnverified = Login.emailUnverified.tintWith(color: Colors.danger)
            }
        }
        
        /// Images used in the onboarding process
        struct Onboarding {
            /// Image of the Air Effects can with label to be scanned/entered in the app
            static let bottleWithLabel = UIImage(named: "bottle_with_label")!
        }
        
    }

    /// Constants used in the PGWrite class
    struct PGWrite {
        
        /// Endpoint where MQTT messages will be sent when retrieved from the BLE devices
        static let iotEndpoint = "wss://a1z2xigbhrq71i-ats.iot.us-east-1.amazonaws.com/mqtt"
        /// Data Manager Key used by the AWSIoTDataManager.
        static let dataManagerKey = "MyAWSIoTDataManager"
        /// AWS App Client Id, defined in AWS Console -> Cognito -> [User Pool] -> General Settings -> App Clients
        static let appClientId = "7l6327mincc632o91d3qr493an"
        /// AWS Identity Pool ID, defined in AWS Console -> Cognito -> [Identity Pool] -> Identity Pool ID
        static let identityPoolId = "us-east-1:cae961ca-cc4c-4156-b29f-6c261118ad01"
    }

    /// Constants used in the PGAuth class
    struct PGAuth {
        /// The URL that provisions a user
        static let provisionUrl = URL(string: "https://yzcsmh6wr1.execute-api.us-east-1.amazonaws.com/api/v1/provision")!
        
        /// Gets the URL that retrieves the device IDs associated with a user
        /// - Parameters:
        ///   - studyId: User's Study ID
        ///   - participantId: User's Participant ID
        static func associatedIdsUrl(studyId: String, participantId: String) -> URL? {
            return URL(string: "https://yzcsmh6wr1.execute-api.us-east-1.amazonaws.com/api/v1/devices/?studyID=\(studyId)&participantID=\(participantId)")
        }
    }
    
    /// Standard colors used throughout the app
    struct Colors {
        /// Color indicates success, positive outcome, or positive status
        static let success  = UIColor(named: "AQ_success")!
        /// Color indicates an inactive or disabled element
        static let inactive = UIColor(named: "AQ_inactive")!
        /// Color indicates failure or error
        static let danger   = UIColor(named: "AQ_danger")!
        /// Color indicates a warning, partial failure, partial success, unknown outcome, or unknown status
        static let warning  = UIColor(named: "AQ_warning")!
    }

    /// Static text used throughout the app
    struct Text {
        /// Displayed when a user's email address has been verified
        static let verifiedMessage = "Your email address has been verified!"
        /// Displayed when a user's email is not verified
        static let unverifiedMessage = "Your email address is unverified. Please check your email to verify your email address."
        /// Displayed when a user is not logged in
        static let logInCellText = "Please log in to start the study"
        /// Displayed when products would be shown, but no products are available to show
        static let noSensorsCellText = "No known products"
        
        /// Text used on the Troubleshooting page
        struct Troubleshooting {
            /// Title of the Troubleshooting page
            static let title = "Administration"
            /// Password needed to enter the Administration page
            static let secretCode = "admin"
            /// Discription displayed on the Troubleshooting page
            static let description = """
            This page allows the study administrator to troubleshoot and manage the user's application.
            """
        }
        
        /// Text used in the onboarding process
        struct Onboarding {
            /// Instructions for the user when their device can use the camera to capture the device code
            static let cameraInstructions = "Place the code/id from the product into the camera window above. When the code appears in the text field, tap the \"Continue\" button. If the code does not automatically populate the text field, enter the code manually and tap Continue."
            /// Instructions for the user when entering a device ID manually
            static let manualEntryInstructions =  "\nEnter the code from the product into the text field below and tap the \"Continue\" button."
        }
        
        
    }
    
    /// Logger to be used throughout the app
    ///
    /// Includes a MultiLogger that contains:
    /// - **ConsoleLogger** Logs to the Console
    ///
    static var logger: Logger? {
        get {
            if MultiLogger.shared.loggerList.count == 0 {
                
                let cLog = ConsoleLogger(level: .Trace)
                let cLogPref = LoggerParameters(identifier: "console", logger: cLog)
                MultiLogger.shared.addLoggers(withParameterList: [cLogPref], clearAll: true)

//                #warning("Remove Web Logger before moving to production")
//                let uuid = UIDevice.current.identifierForVendor?.uuidString
//                let wLog = WebLogger(logName: uuid != nil ? "AQR:\(uuid!.prefix(8))" : "AQR", url: URL(string: LoggerConfig.webLoggerUrl)!, level: .Trace)
//                let wLogPref = LoggerParameters(identifier: "web", logger: wLog)
//                MultiLogger.shared.addLoggers(withParameterList: [wLogPref], clearAll: false)
            }

            return MultiLogger.shared
        }
    }
    
    /// Web Logger configuration parameters
    struct LoggerConfig {
        /// Base URL of the WebLogger
        static let webLoggerUrl = ""
    }
}
