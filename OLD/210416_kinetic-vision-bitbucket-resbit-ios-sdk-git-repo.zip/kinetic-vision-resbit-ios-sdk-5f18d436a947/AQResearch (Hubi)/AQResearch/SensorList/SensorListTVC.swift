//
//  SensorListTableViewController.swift
//  AQResearch
//
//  Created by Aaron on 11/26/19.
//  Copyright © 2019 Procter & Gamble. All rights reserved.
//

import UIKit
import AWSMobileClient
import CoreLocation
import SVProgressHUD

protocol AQResearchViewDelegate {
    func sensorsUpdated() -> Void
}

class SensorListTVC: UITableViewController {
    var dataSource: UITableViewDataSource!
    let logger: Logger? = Constants.logger
    
    @IBOutlet weak var loginButton: UIBarButtonItem!
    @IBOutlet weak var scanButton: UIBarButtonItem!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        PGAuth.shared.configure(logger: Constants.logger)
        PGAuth.shared.delegate = self
        
        Scanner.shared.uiDelegate = self
     
        SVProgressHUD.setContainerView(self.navigationController?.view)
        
        if traitCollection.userInterfaceStyle == .dark {
            SVProgressHUD.setDefaultStyle(.light)
        } else {
            SVProgressHUD.setDefaultStyle(.dark)
        }
        
        SVProgressHUD.setAnimationsEnabled(true)

        configureTable()
        configureView(userState: PGAuth.shared.authState)

        self.refreshControl?.addTarget(self, action: #selector(refresh), for: UIControl.Event.valueChanged)

        if PGAuth.shared.authState != .signedIn {
            performSegue(withIdentifier: "loginSegue", sender: self)
        } else {
            PGAuth.shared.logUserAttributes()
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.tableView.reloadData()
    }

    //Pull-To-Refresh will update list of sensors.
    @objc func refresh(sender:AnyObject)
    {
        DispatchQueue.main.async {
            self.tableView.reloadData()
            self.refreshControl?.endRefreshing()
        }
    }

    func configureTable() {
        DispatchQueue.main.async {
            self.dataSource = SensorListTVDataSource(tableView: self.tableView)
            self.tableView.dataSource = self.dataSource
            self.tableView.register(UINib(nibName: "StatusCell", bundle: nil), forCellReuseIdentifier: Constants.CellIdentifiers.statusCell)
        }
    }

    func configureView(userState: UserState?) {
        self.title = "Product List"
        setNavigationButtons(userState: userState)
    }
    
    func setNavigationButtons(userState: UserState?) {
        switch userState {
        case .signedIn:
            loginButton.image = Constants.Images.Login.loggedIn.sizedTo(width: 25)
            loginButton.tintColor = Constants.Colors.success

            scanButton.isEnabled = true
            
        default:
            loginButton.image = nil
            loginButton.tintColor = nil
            loginButton.title = "Log In"

            scanButton.isEnabled = false

        }
    }

    @IBAction func logIn(_ sender: Any) {
        logger?.write("Log In tapped")
        switch PGAuth.shared.authState {
        case .signedIn:
            performSegue(withIdentifier: "userDetailsSegue", sender: self)
        default:
            performSegue(withIdentifier: "loginSegue", sender: self)
        }
    }
}

extension SensorListTVC: PGAuthDelegate {
    func loginStatusChanged(newUserState: UserState?, info: [String: String]?) {
        DispatchQueue.main.async {
            self.setNavigationButtons(userState: newUserState)
        }
    }
}

extension SensorListTVC: AQResearchViewDelegate {
    func sensorsUpdated() {
        DispatchQueue.main.async {
            self.tableView.reloadData()
        }
    }
}
