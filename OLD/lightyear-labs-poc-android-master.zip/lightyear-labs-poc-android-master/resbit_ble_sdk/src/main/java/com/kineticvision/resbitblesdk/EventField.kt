package com.kineticvision.resbitblesdk

class EventField<T:Any>(val name: String, val value: T) {

}
