package com.kv.androidhubi.customClasses

import android.content.Context
import android.util.Log
import androidx.lifecycle.viewModelScope
import codes.alchemy.awskit.iot.IotAuthState
import com.amazonaws.mobile.client.*
import com.amazonaws.mobile.client.results.SignInResult
import com.amazonaws.mobile.client.results.SignInState
import com.amazonaws.mobile.client.results.Tokens
import java.io.*
import java.lang.Exception
import java.net.HttpURLConnection
import java.net.URL
import java.nio.charset.StandardCharsets
import codes.alchemy.lightyearlabs.LightyearLabs
import com.kv.androidhubi.BuildConfig
import com.kv.androidhubi.BuildConfig.CLIENT_ID
import com.kv.androidhubi.BuildConfig.CLIENT_SECRET
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import java.util.*


class PGAuth(var context: Context) : UserStateListener {
    lateinit var mobileClient: AWSMobileClient
    lateinit var tokens: Tokens
    var ProvisionUrl = URL("https://yzcsmh6wr1.execute-api.us-east-1.amazonaws.com/api/v1/provision")
    var lightYearLabs : LightyearLabs? = null


    public fun getAuthState() : UserState {
        return mobileClient.currentUserState().userState
    }

//    public fun configure(completion: Callback<Error>) {
//        mobileClient = AWSMobileClient.getInstance()
//
//        mobileClient.addUserStateListener(this)
//
//        mobileClient.initialize(context, object: Callback<UserStateDetails> {
//            override fun onResult(result: UserStateDetails?) {
//                when (result?.userState) {
//                    UserState.SIGNED_IN -> Log.i(TAG, "***** user signed in")
//                    UserState.SIGNED_OUT -> Log.i(TAG, "***** user is signed out.")
//                    else -> {
//                        mobileClient.signOut()
//                    }
//                }
//
//                completion.onResult(null)
//            }
//
//            override fun onError(e: Exception?) {
//                Log.i(TAG, e?.localizedMessage!!)
//                completion.onError(e)
//            }
//        })
//    }

    // entry point for every app open. LightyearLabs must be initialized for every Application.onCreate()
//    fun loadLightyear(context: Context, completion: Callback<Error>): codes.alchemy.lightyearlabs.LightyearLabs {
//
//    }

    public fun signIn(lightyear: codes.alchemy.lightyearlabs.LightyearLabs, username: String, password: String, completion: Callback<Error>) {
        runBlocking {
            val result  = lightyear.login(username, password)
            if(result.isSuccess) {
                Log.i(TAG, "We logged in yo")
                completion.onResult(null)
            } else {
                Log.i(TAG, "Failed to log in")
                completion.onError(null)
            }

        }

        Log.i(TAG, "So did it hit this?")

//        mobileClient.signIn(username, password, null, object: Callback<SignInResult> {
//            override fun onResult(result: SignInResult?) {
//                Log.i(TAG, "ADFAESFDASFADSFADSF")
//                if(result?.signInState == SignInState.DONE) {
//
//                    provisionUser(object: Callback<Error> {
//                        override fun onResult(error: Error?) {
//                            completion.onResult(result)
//                        }
//
//                        override fun onError(e: Exception?) {
//                            completion.onError(e)
//                        }
//                    })
//                }
//            }
//
//            override fun onError(e: Exception?) {
//                Log.i(TAG, "EERRRRORRR")
//                if (e != null) {
//                    Log.i(TAG, e.localizedMessage)
//                    completion.onError(e)
//                    return
//                }
//            }
//
//        })
    }

    fun provisionUser(completion: Callback<Error>) {
        var identityID = mobileClient.identityId
        if(identityID != null || identityID != "") {
            var colonIndex = identityID.indexOfFirst { identityID == ":" }
            if(colonIndex != -1) {
                val e = error("cognitoId in incorrect format: ${identityID}")
                completion.onError(e)
            } else {
                identityID = identityID.substringAfter(":")
                Log.i(TAG, "Cognito id: " + identityID)
                Log.i(TAG, "Provisioning User...")
                this.getTokens(object: Callback<Tokens> {
                    override fun onResult(result: Tokens?) {
                        var token = result?.accessToken?.tokenString
                        if(token != null || token != "") {
                            Log.i(TAG, "Found token: $token")
                            var url = ProvisionUrl
                            var connection = url.openConnection() as HttpURLConnection

                            connection.requestMethod = "POST"
                            connection.setRequestProperty("Authorization", "Bearer " + token)
                            connection.setRequestProperty("Content-Type", "application/json")

                            val messageBody = "{ \"identityId\": \"$identityID\" }"
                            val postData: ByteArray = messageBody.toByteArray(StandardCharsets.UTF_8)
//
                            connection.setRequestProperty("Content-length", postData.size.toString())

                            try {
                                val outputStream: DataOutputStream = DataOutputStream(connection.outputStream)
                                outputStream.write(postData)
                                outputStream.flush()
                            } catch (exception: Exception) {

                            }

                            if (connection.responseCode != HttpURLConnection.HTTP_OK && connection.responseCode != HttpURLConnection.HTTP_CREATED) {
                                try {
                                    val inputStream: DataInputStream = DataInputStream(connection.inputStream)
                                    val reader: BufferedReader = BufferedReader(InputStreamReader(inputStream))
                                    val output: String = reader.readLine()

                                    val e = error("There was error while connecting the chat $output")
                                    System.exit(0)
                                    completion.onError(e)
                                } catch (exception: Exception) {
                                    throw Exception("Exception while push the notification  $exception.message")
                                    val e = error("Exception while push the notification: " + exception.message)
                                    completion.onError(e)
                                }
                            } else {
                                Log.i(TAG, connection.responseMessage)
                                completion.onResult(null)
                            }
                        }
                    }

                    override fun onError(e: Exception?) {
                        val e = error("Unable to get Identity ID")
                        completion.onError(e)
                    }

                })
            }
        } else {
            val e = error("Unable to get Identity ID")
            completion.onError(e)
        }
    }
//
//                            request.httpBody = #"{ "identityId": "\#(cognitoId)" }"#.data(using: .utf8)
//
//                            self.logger?.write("Request Description: \n\(request.detailedDescription)")
//
//                            let task = URLSession.shared.dataTask(with: request) { data, response, error in
//                            guard let data = data,
//                            let response = response as? HTTPURLResponse,
//                            error == nil else {                                              // check for fundamental networking error
//                                self.logger?.write("error: \(error.debugDescription)")
//                                completion(.failure(PGAuthError.ProvisioningError(message: error.debugDescription)))
//                                return
//                            }
//
//                            guard (200 ... 299) ~= response.statusCode else {                    // check for http errors
//                                self.logger?.write("statusCode should be 2xx, but is \(response.statusCode)")
//                                self.logger?.write("response = \(response)")
//                                if let responseString = String(data: data, encoding: .utf8) {
//                                    self.logger?.write("responseString = \(responseString)")
//                                }
//                                completion(.failure(PGAuthError.ProvisioningError(message: "Expected 2xx Response Code, but got \(response.statusCode)")))
//                                return
//                            }
//
//                            if let responseString = String(data: data, encoding: .utf8) {
//                                self.logger?.write("responseString = \(responseString)")
//                            } else {
//                                self.logger?.write("No body returned.")
//                            }
//
//                            completion(.success(()))
//                        }
//
//                            task.resume()
//                        } else {
//                            //No Token.  Need to login again
//                            completion(.failure(PGWriteError.NotLoggedInError))
//                        }
//                }
//            }
//            return task;
//        })
//    }

    private fun getTokens(completion: Callback<Tokens>) {
        if(getAuthState() == UserState.SIGNED_IN && this.tokens != null) {
            Log.i(TAG, "Tokens exist. Passing them to completion.")
            completion.onResult(this.tokens)
            return
        }

        Log.i(TAG, "Tokens don't exist yet.  Getting them.")

        mobileClient.getTokens(object: Callback<Tokens> {
            override fun onResult(result: Tokens?) {
                if (result != null) {
                    tokens = result
                    Log.i(TAG, "Tokens retrieved: $tokens")
                    completion.onResult(tokens)
                }
            }

            override fun onError(e: Exception?) {
                Log.i(TAG, "Error getting tokens")
                completion.onError(e)
            }
        })
    }

    override fun onUserStateChanged(details: UserStateDetails?) {
        when (details?.userState) {
            UserState.GUEST -> Log.i(TAG, "***** user is in guest mode.")
            UserState.SIGNED_IN -> Log.i(TAG, "***** user signed in")
            UserState.SIGNED_OUT -> Log.i(TAG, "***** user is signed out.")
            UserState.SIGNED_OUT_FEDERATED_TOKENS_INVALID -> Log.i(TAG, "***** self.logger?.write(\")\n")
            UserState.SIGNED_OUT_USER_POOLS_TOKENS_INVALID -> Log.i(TAG, "***** user logged in via federation, but currently needs new tokens")
            else -> { // Note the block
                Log.i(TAG, "***** unsupported")
            }
        }

        mobileClient.getTokens(object: Callback<Tokens> {
            override fun onResult(result: Tokens?) {
                if (result != null) {
                    tokens = result
                }
            }

            override fun onError(e: Exception?) {
                Log.i(TAG, e?.localizedMessage!!)
            }
        })
    }

    companion object {
        private const val TAG = "PGAuth"
        private const val REQUEST_ENABLE_BT = 1
    }
}