package com.kv.androidhubi

import android.Manifest
import android.app.AlertDialog
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.util.Log
import androidx.annotation.RequiresApi
import androidx.appcompat.app.ActionBar
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import codes.alchemy.awskit.iot.IotAuthState
import codes.alchemy.lightyearlabs.LightyearLabs
import com.amazonaws.mobile.client.Callback
import com.kv.androidhubi.customClasses.*
import org.altbeacon.beacon.BeaconManager
import timber.log.Timber


class MainActivity : AppCompatActivity() {
    public  val appNavigator: AppNavigator = AppNavigator()
    public lateinit var userPrefHandler: UserPrefHandler
    public lateinit var userAccountInfo: UserAccountInfo
    public lateinit var lightYearHubHandler: LightYearHubHandler

    private val PERMISSION_REQUEST_FINE_LOCATION = 1
    private val PERMISSION_REQUEST_BACKGROUND_LOCATION = 2

    @RequiresApi(Build.VERSION_CODES.O)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        supportActionBar?.setDisplayOptions(ActionBar.DISPLAY_SHOW_CUSTOM)
        supportActionBar?.setCustomView(R.layout.layout_menu)
        val action = supportActionBar
        val menuView = action!!.customView
        val toolbar: Toolbar = menuView.parent as Toolbar
        toolbar.setContentInsetsAbsolute(0, 0)
        toolbar.contentInsetEnd
        toolbar.setPadding(0, 0, 0, 0)
        supportActionBar?.hide()

        Log.i(MainActivity.TAG, "Started Main Activity")

        val application: BeaconRegionBootstrap = this.applicationContext as BeaconRegionBootstrap
        application.setMonitoringActivity(this)
        userPrefHandler = application.userPrefHandler
        userAccountInfo = application.userAccountInfo
        lightYearHubHandler = application.lightYearHubHandler

//        initLightyear()
        verifyBluetooth()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                if (checkSelfPermission(Manifest.permission.ACCESS_BACKGROUND_LOCATION)
                    != PackageManager.PERMISSION_GRANTED
                ) {
                    if (shouldShowRequestPermissionRationale(Manifest.permission.ACCESS_BACKGROUND_LOCATION)) {
                        val builder =
                            AlertDialog.Builder(this)
                        builder.setTitle("This app needs background location access")
                        builder.setMessage("Please grant location access so this app can detect beacons in the background.")
                        builder.setPositiveButton(android.R.string.ok, null)
                        builder.setOnDismissListener {
                            requestPermissions(
                                arrayOf(Manifest.permission.ACCESS_BACKGROUND_LOCATION),
                                PERMISSION_REQUEST_BACKGROUND_LOCATION
                            )
                        }
                        builder.show()
                    } else {
                        val builder =
                            AlertDialog.Builder(this)
                        builder.setTitle("Functionality limited")
                        builder.setMessage("Since background location access has not been granted, this app will not be able to discover beacons in the background.  Please go to Settings -> Applications -> Permissions and grant background location access to this app.")
                        builder.setPositiveButton(android.R.string.ok, null)
                        builder.setOnDismissListener { }
                        builder.show()
                    }
                }
            }
        }
    }

    override fun onBackPressed() {
        if(appNavigator.currentPageState == AppNavigator.AppPageState.PRODUCTLIST || appNavigator.currentPageState == AppNavigator.AppPageState.LOGIN) {
            moveTaskToBack(true)
        } else {
            appNavigator.handleBackButtonPress()
        }

//        moveTaskToBack(true)
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)

        when (requestCode) {
            PERMISSION_REQUEST_FINE_LOCATION -> {
                if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    // Fine location granted
                } else {
                    val builder =
                        AlertDialog.Builder(this)
                    builder.setTitle("Functionality limited")
                    builder.setMessage("Since location access has not been granted, this app will not be able to discover beacons.")
                    builder.setPositiveButton(android.R.string.ok, null)
                    builder.setOnDismissListener { }
                    builder.show()
                }
                return
            }
            PERMISSION_REQUEST_BACKGROUND_LOCATION -> {
                if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    // background permission granted
                } else {
                    val builder =
                        AlertDialog.Builder(this)
                    builder.setTitle("Functionality limited")
                    builder.setMessage("Since background location access has not been granted, this app will not be able to discover beacons when in the background.")
                    builder.setPositiveButton(android.R.string.ok, null)
                    builder.setOnDismissListener { }
                    builder.show()
                }
                return
            }
        }
    }

    fun getActualActionBar(): ActionBar? {
        return this.supportActionBar
    }

    public fun attemptLogin(username: String, password: String) {
        var dialog = HubiAlertDialog(this)
        dialog.show()
        dialog.loggingIn()

        lightYearHubHandler.loadLightyear(
            this,
            object : codes.alchemy.lightyearlabs.LightyearLabsCallback {
                override fun onResult(authState: IotAuthState, lightyear: LightyearLabs) {
//                lightYearHubHandler.deviceType = "STAND"//Constants.getDeviceName().toString()
                    Log.i(MainActivity.TAG, "Loaded Lightyear")

                    if (authState != IotAuthState.SignedIn) {
                        Log.i(MainActivity.TAG, "Auth state is not signed in")
                        lightYearHubHandler.loginUser(username, password, object : Callback<Error> {
                            override fun onResult(result: Error?) {
                                Log.i(MainActivity.TAG, "Signed In")

                                // login successful, let's link this device to the lightyear account if we haven't already
                                lightYearHubHandler.getDevice(object : Callback<Error> {
                                    override fun onResult(result: Error?) {
                                        var myRunnable = Runnable {
                                            if (userAccountInfo.getStudyID() == "") {
                                                dialog.enterStudyID(this@MainActivity)
                                            } else {
                                                dialog.hide()
                                            }

                                            if (!userAccountInfo.userIsSignedIn()) {
                                                userAccountInfo.setUsername(username)
                                                userAccountInfo.setPassword(password)
                                                userAccountInfo.setLightyearConsumerID(
                                                    lightYearHubHandler.device!!.consumerId!!
                                                )
                                            }

                                            lightYearHubHandler.setupMqttClient()
                                            appNavigator.SetState(
                                                AppNavigator.AppPageState.PRODUCTLIST,
                                                true
                                            )
                                        }

                                        runOnUiThread(myRunnable)
                                    }

                                    override fun onError(e: java.lang.Exception?) {
                                        Log.i(MainActivity.TAG, "Failed getting device")
                                        var myRunnable = Runnable {
                                            dialog.loginFailure()
                                        }

                                        runOnUiThread(myRunnable)
                                    }
                                })
                            }

                            override fun onError(e: java.lang.Exception?) {
                                Log.i(MainActivity.TAG, "Failed")
                                var myRunnable = Runnable {
                                    dialog.loginFailure()
                                }

                                runOnUiThread(myRunnable)
                            }
                        })
                    } else {
                        Log.i(MainActivity.TAG, "Signed in")
                        lightYearHubHandler.getDevice(object : Callback<Error> {
                            override fun onResult(result: Error?) {
                                var myRunnable = Runnable {
                                    if (userAccountInfo.getStudyID() == "") {
                                        dialog.enterStudyID(this@MainActivity)
                                    } else {
                                        dialog.hide()
                                    }

                                    if (!userAccountInfo.userIsSignedIn()) {
                                        userAccountInfo.setUsername(username)
                                        userAccountInfo.setPassword(password)
                                        userAccountInfo.setLightyearConsumerID(lightYearHubHandler.device!!.consumerId!!)
                                    }

                                    lightYearHubHandler.setupMqttClient()
                                    appNavigator.SetState(
                                        AppNavigator.AppPageState.PRODUCTLIST,
                                        true
                                    )
                                }

                                runOnUiThread(myRunnable)
                            }

                            override fun onError(e: java.lang.Exception?) {
                                Log.i(MainActivity.TAG, "Failed getting device")
                                var myRunnable = Runnable {
                                    dialog.loginFailure()
                                }

                                runOnUiThread(myRunnable)
                            }
                        })
                    }
                }

                override fun onError(e: Throwable) {
                    // braodcast error
                    e.printStackTrace()
                    Log.i(MainActivity.TAG, "Failed")
                    Timber.e("LightyearLabs AuthERROR: %s", e.localizedMessage)
                    var myRunnable = Runnable {
                        dialog.loginFailure()
                    }

                    runOnUiThread(myRunnable)
                }
            })
    }

//    private fun initLightyear() {
//        runBlocking {
//            // clientId for the LightyearLabs environment, this is contained in app:build.gradle
//            val clientId = BuildConfig.CLIENT_ID
//            // clientSecret for the LightyearLabs environment, this is contained in app:build.gradle
//            val clientSecret = BuildConfig.CLIENT_SECRET
//            // locale from which the connection is being made
//            val locale = Locale.US
//            LightyearLabs.initialize(
//                this@MainActivity,
//                clientId,
//                clientSecret,
//                locale,
//                object : LightyearLabsCallback {
//                    override fun onResult(authState: IotAuthState, lightyearInit: LightyearLabs) {
//                        iotAuthState = authState
//                        // when successfully loaded, broadcast the results
//                        Log.i("LoginFragment", "Initialized LightYear")
//                        lightyear = lightyearInit
//                    }
//
//                    override fun onError(e: Throwable) {
//                        Log.i("LoginFragment", e.localizedMessage)
//                    }
//                }
//            )
//        }
//    }

    override fun onDestroy() {
        super.onDestroy()
    }

//    override fun onResume() {
//        super.onResume()
//        val application: BeaconRegionBootstrap =
//            this.applicationContext as BeaconRegionBootstrap
//    }
//
//    override fun onPause() {
//        super.onPause()
//        (this.applicationContext as BeaconRegionBootstrap).setMonitoringActivity(null)
//    }

    private fun verifyBluetooth() {
        try {
            if (!BeaconManager.getInstanceForApplication(this).checkAvailability()) {
                val builder = AlertDialog.Builder(this)
                builder.setTitle("Bluetooth not enabled")
                builder.setMessage("Please enable bluetooth in settings and restart this application.")
                builder.setPositiveButton(android.R.string.ok, null)
                builder.setOnDismissListener {
                    //finish();
                    //System.exit(0);
                }
                builder.show()
            }
        } catch (e: RuntimeException) {
            val builder = AlertDialog.Builder(this)
            builder.setTitle("Bluetooth LE not available")
            builder.setMessage("Sorry, this device does not support Bluetooth LE.")
            builder.setPositiveButton(android.R.string.ok, null)
            builder.setOnDismissListener {
                //finish();
                //System.exit(0);
            }
            builder.show()
        }
    }

    companion object {
        private const val TAG = "MainActivity"
        private const val REQUEST_ENABLE_BT = 1
    }
}
