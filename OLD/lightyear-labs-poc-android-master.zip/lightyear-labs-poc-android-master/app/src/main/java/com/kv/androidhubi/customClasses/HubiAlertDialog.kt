package com.kv.androidhubi.customClasses

import android.app.Dialog
import android.content.Context
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.*
import android.widget.Button
import android.widget.TextView
import com.google.android.material.textfield.TextInputLayout
import com.kv.androidhubi.MainActivity
import com.kv.androidhubi.R
import com.kv.androidhubi.fragments.DebuggerFragment
import kotlinx.android.synthetic.main.fragment_login.view.*
import org.w3c.dom.Text

class HubiAlertDialog(context: Context) : Dialog(context) {

    private var layoutView : View? = null

    init {
        setCancelable(false)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
//        requestWindowFeature(Window.FEATURE_NO_TITLE)
        setContentView(R.layout.dialog_loading)
    }

    public fun noPeripheralsFoundInScan() {
        setContentView(R.layout.dialog_text_and_button)
        (this.findViewById(R.id.txt) as TextView).text = "No peripherals matching the ID you entered were found nearby."
        (this.findViewById(R.id.btnOkay) as Button).setOnClickListener {
            this.hide()
        }
    }

    public fun noPeripheralsFoundAttachedtoAccount() {
        setContentView(R.layout.dialog_text_and_button)
        (this.findViewById(R.id.txt) as TextView).text = "Your account has no deviceID matching the one you entered."
        (this.findViewById(R.id.btnOkay) as Button).setOnClickListener {
            this.hide()
        }
    }

    public fun dataSendingSuccess() {
        setContentView(R.layout.dialog_text_and_button)
        (this.findViewById(R.id.txt) as TextView).text = "Data sent successfully"
        (this.findViewById(R.id.btnOkay) as Button).setOnClickListener {
            this.hide()
        }
    }

    public fun dataSendingFail() {
        setContentView(R.layout.dialog_text_and_button)
        (this.findViewById(R.id.txt) as TextView).text = "Data failed to send."
        (this.findViewById(R.id.btnOkay) as Button).setOnClickListener {
            this.hide()
        }
    }

    public fun connectionSuccessful(mainActivity: MainActivity) {
        setContentView(R.layout.dialog_text_and_button)
        (this.findViewById(R.id.txt) as TextView).text = "Connection Successful."
        (this.findViewById(R.id.btnOkay) as Button).setOnClickListener {
            mainActivity.appNavigator.handleBackButtonPress()
            this.hide()
        }
    }

    public fun errorDuringScan() {
        setContentView(R.layout.dialog_text_and_button)
        (this.findViewById(R.id.txt) as TextView).text = "Error while performing scan."
        (this.findViewById(R.id.btnOkay) as Button).setOnClickListener {
            this.hide()
        }
    }

    public fun loggingIn() {
        setContentView(R.layout.dialog_loading)
        (this.findViewById(R.id.textLoading) as TextView).text = "Logging In..."
    }

    public fun loginFailure() {
        setContentView(R.layout.dialog_text_and_button)
        (this.findViewById(R.id.txt) as TextView).text = "Login Failed"
        (this.findViewById(R.id.btnOkay) as Button).setOnClickListener {
            this.hide()
        }
    }

    public fun deviceAlreadyAdded(mainActivity: MainActivity) {
        setContentView(R.layout.dialog_text_and_button)
        (this.findViewById(R.id.txt) as TextView).text = "This device has already been registered."
        (this.findViewById(R.id.btnOkay) as Button).setOnClickListener {
            mainActivity.appNavigator.handleBackButtonPress()
            this.hide()
        }
    }

    public fun enterStudyID(mainActivity: MainActivity) {
        setContentView(R.layout.dialog_text_and_input)
        var studyID = ""
        (this.findViewById(R.id.inputBoxStudyID) as TextInputLayout).editText?.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {

            }

            override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {

            }

            override fun afterTextChanged(p0: Editable?) {
                studyID = p0.toString()
            }
        })
        (this.findViewById(R.id.btnOkay) as Button).setOnClickListener {
            mainActivity.userAccountInfo.setStudyID(studyID)
            this.hide()
        }
    }

    public fun enterAdminPassword(mainActivity: MainActivity) {
        setContentView(R.layout.dialog_text_and_input_password)
        var password = ""
        (this.findViewById(R.id.txt) as TextView).text = "Enter Administrative Code"
        (this.findViewById(R.id.inputBoxStudyID) as TextInputLayout).hint = "Admin Code"
        (this.findViewById(R.id.inputBoxStudyID) as TextInputLayout)
        (this.findViewById(R.id.inputBoxStudyID) as TextInputLayout).editText?.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {

            }

            override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {

            }

            override fun afterTextChanged(p0: Editable?) {
                password = p0.toString()
            }
        })
        (this.findViewById(R.id.btnOkay) as Button).setOnClickListener {
            if(password.toLowerCase() == Constants.adminPassword.toLowerCase()) {
                mainActivity.appNavigator.SetState(AppNavigator.AppPageState.ADMIN, true)
                this.hide()
            } else {
                invalidAdminPassword()
            }
        }
    }

    public fun invalidAdminPassword() {
        setContentView(R.layout.dialog_text_and_button)
        (this.findViewById(R.id.txt) as TextView).text = "Invalid Code"
        (this.findViewById(R.id.btnOkay) as Button).setOnClickListener {
            this.hide()
        }
    }

    public fun clearedDevices() {
        setContentView(R.layout.dialog_text_and_button)
        (this.findViewById(R.id.txt) as TextView).text = "All products have been removed from your account"
        (this.findViewById(R.id.btnOkay) as Button).setOnClickListener {
            this.hide()
        }
    }

    public fun resetMonitoring() {
        setContentView(R.layout.dialog_text_and_button)
        (this.findViewById(R.id.txt) as TextView).text = "Monitored regions have been reset"
        (this.findViewById(R.id.btnOkay) as Button).setOnClickListener {
            this.hide()
        }
    }

    public fun debugScanBySerialID(debugger: DebuggerFragment) {
        setContentView(R.layout.dialog_text_and_input)
        var serialID = ""
        (this.findViewById(R.id.inputBoxStudyID) as TextInputLayout).editText?.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {

            }

            override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {

            }

            override fun afterTextChanged(p0: Editable?) {
                serialID = p0.toString()
            }
        })

        (this.findViewById(R.id.btnOkay) as Button).setOnClickListener {
            debugger.performScanByID(serialID.toLowerCase())
            this.hide()
        }
    }

//    override fun onCreate(savedInstanceState: Bundle?) {
//        super.onCreate(savedInstanceState)
//        setCancelable(false)
//
////        layoutView = getView(this.ownerActivity)
////        this.setView(layoutView)
//
//        val window: Window? = this.window
//        if (window != null) {
//            val layoutParams = WindowManager.LayoutParams()
//            layoutParams.copyFrom(this!!.window?.attributes)
//            layoutParams.width = LinearLayout.LayoutParams.WRAP_CONTENT
//            layoutParams.height = LinearLayout.LayoutParams.WRAP_CONTENT
//            this.window!!.attributes = layoutParams
//        }
//    }

//    private fun getView(activity: Activity?) : View {
//        val llPadding = 30
//        val ll = LinearLayout(activity)
//        ll.orientation = LinearLayout.HORIZONTAL
//        ll.setPadding(llPadding, llPadding, llPadding, llPadding)
//        ll.gravity = Gravity.CENTER
//        var llParam = LinearLayout.LayoutParams(
//            LinearLayout.LayoutParams.WRAP_CONTENT,
//            LinearLayout.LayoutParams.WRAP_CONTENT
//        )
//        llParam.gravity = Gravity.CENTER
//        ll.layoutParams = llParam
//        val progressBar = ProgressBar(activity)
//        progressBar.isIndeterminate = true
//        progressBar.setPadding(0, 0, llPadding, 0)
//        progressBar.layoutParams = llParam
//        llParam = LinearLayout.LayoutParams(
//            ViewGroup.LayoutParams.WRAP_CONTENT,
//            ViewGroup.LayoutParams.WRAP_CONTENT
//        )
//        llParam.gravity = Gravity.CENTER
//        val tvText = TextView(activity)
//        tvText.text = "Loading ..."
//        tvText.setTextColor(Color.parseColor("#000000"))
//        tvText.textSize = 20f
//        tvText.layoutParams = llParam
//        ll.addView(progressBar)
//        ll.addView(tvText)
//
//        return ll
//    }
}