package com.kv.androidhubi.customClasses

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.util.Log
import codes.alchemy.lemonadeplatform.model.LightyearLabsDevice
import com.google.gson.Gson
import com.kineticvision.resbitblesdk.BLEDevice
import com.kineticvision.resbitblesdk.SummaryData
import com.kv.androidhubi.BeaconRegionBootstrap
import com.kv.androidhubi.fragments.ReceiveProductFragment
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*

class UserAccountInfo(var userPrefHandler: UserPrefHandler) {

    public fun userIsSignedIn() : Boolean {
        return getUsername() != "" && getPassword() != ""
    }

    public fun getUsername() : String? {
        return userPrefHandler.userPrefGetString(Constants.userPrefKeyUsername)
    }

    public fun setUsername(username: String) {
        userPrefHandler.userPrefSetString(Constants.userPrefKeyUsername, username)
    }

    public fun getPassword() : String? {
        return userPrefHandler.userPrefGetString(Constants.userPrefKeyPassword)
    }

    public fun setPassword(password: String) {
        userPrefHandler.userPrefSetString(Constants.userPrefKeyPassword, password)
    }

    public fun getLightyearConsumerID() : String? {
        return userPrefHandler.userPrefGetString(Constants.userPrefKeyLightyearConsumerID)
    }

    public fun setLightyearConsumerID(deviceID: String) {
        userPrefHandler.userPrefSetString(Constants.userPrefKeyLightyearConsumerID, deviceID)
    }

    public fun getStudyID() : String? {
        return userPrefHandler.userPrefGetString(Constants.userPrefKeyStudyID)
    }

    public fun setStudyID(studyID: String) {
        userPrefHandler.userPrefSetString(Constants.userPrefKeyStudyID, studyID)
    }

    public fun setIgnoreDeviceIDs(ignoreDeviceIDs: Boolean) {
        if(ignoreDeviceIDs) {
            userPrefHandler.userPrefSetString(Constants.userPrefKeyIgnoreDeviceIDs, "true")
        } else {
            userPrefHandler.userPrefSetString(Constants.userPrefKeyIgnoreDeviceIDs, "false")
        }
    }

    public fun getIgnoreDeviceIDs() : Boolean {
        val ignoreDeviceIDs = userPrefHandler.userPrefGetString(Constants.userPrefKeyIgnoreDeviceIDs)

        if(ignoreDeviceIDs == "false") {
            return false
        }

        return true
    }

    public fun getRegisteredBLEDeviceIDs() : java.util.ArrayList<String> {
        var deviceIDs = java.util.ArrayList<String>()
        if(userPrefHandler.preferences!!.contains(Constants.userPrefKeyTotalBLEDeviceCount)) {
            for (i in 0 until getTotalRegisteredBLEDeviceCount()) {
                val keyBLEDeviceID : String = Constants.userPrefKeyBLEDeviceID + i.toString()
                val keyBLEDeviceLastSyncTime : String = Constants.userPrefKeyBLEDeviceLastSyncTime + i.toString()
                if(userPrefHandler.preferences!!.contains(keyBLEDeviceID) && userPrefHandler.preferences!!.contains(keyBLEDeviceLastSyncTime)) {
                    // This is a known device, grab its ID
                    var device : BLEDevice = Gson().fromJson(userPrefHandler.userPrefGetString(keyBLEDeviceID)!!, BLEDevice::class.java)
                    deviceIDs.add(device.serialID!!)
                    Log.i("UserAccountInfo", "Found device in user defaults: " + device.serialID!!)
                }
            }
        }
        return deviceIDs
    }

    public fun getRegisteredDevices() : java.util.ArrayList<BLEDevice> {
        var devices = java.util.ArrayList<BLEDevice>()
        if(userPrefHandler.preferences!!.contains(Constants.userPrefKeyTotalBLEDeviceCount)) {
            for (i in 0 until getTotalRegisteredBLEDeviceCount()) {
                val keyBLEDeviceID : String = Constants.userPrefKeyBLEDeviceID + i.toString()
                val keyBLEDeviceLastSyncTime : String = Constants.userPrefKeyBLEDeviceLastSyncTime + i.toString()
                if(userPrefHandler.preferences!!.contains(keyBLEDeviceID) && userPrefHandler.preferences!!.contains(keyBLEDeviceLastSyncTime)) {
                    // This is a known device, grab its ID
                    var device : BLEDevice = Gson().fromJson(userPrefHandler.userPrefGetString(keyBLEDeviceID)!!, BLEDevice::class.java)
                    devices.add(device)
                    Log.i("UserAccountInfo", "Found device in user defaults: " + device.serialID)
                }
            }
        }
        return devices
    }

    public fun getTotalRegisteredBLEDeviceCount() : Int {
        if(userPrefHandler.preferences!!.contains(Constants.userPrefKeyTotalBLEDeviceCount)) {
            return userPrefHandler.userPrefGetInt(Constants.userPrefKeyTotalBLEDeviceCount)
        } else {
            return 0
        }
    }

    public fun addNewDevice(device: BLEDevice) {
        val calendar = Calendar.getInstance()
        calendar.timeInMillis = device.lastSyncTime
        val sdf = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'")

        var deviceAsJSON = Gson().toJson(device)
        val keyBLEDeviceID : String = Constants.userPrefKeyBLEDeviceID + getTotalRegisteredBLEDeviceCount().toString()
        val keyBLEDeviceLastSyncTime : String = Constants.userPrefKeyBLEDeviceLastSyncTime + getTotalRegisteredBLEDeviceCount().toString()

        userPrefHandler.userPrefSetString(keyBLEDeviceID, deviceAsJSON)
        userPrefHandler.userPrefSetString(keyBLEDeviceLastSyncTime, sdf.format(calendar.time))

        var currentTotaRegisteredBLEDeviceCount = userPrefHandler.userPrefGetInt(
            Constants.userPrefKeyTotalBLEDeviceCount)

        currentTotaRegisteredBLEDeviceCount += 1

        userPrefHandler.userPrefSetInt(Constants.userPrefKeyTotalBLEDeviceCount, currentTotaRegisteredBLEDeviceCount)
    }

    // Updates device in userPref.
    // Returns false if device was already added
    // Returns true if this was a new device
    public fun userPrefUpdateBLEDevice(device: BLEDevice) : Boolean {
        val calendar = Calendar.getInstance()
        calendar.timeInMillis = device.lastSyncTime
        val sdf = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'")
        Log.d(TAG, getTotalRegisteredBLEDeviceCount()!!.toString())

        for (i in 0 until getTotalRegisteredBLEDeviceCount()) {
            val keyBLEDeviceID : String = Constants.userPrefKeyBLEDeviceID + i.toString()
            if(userPrefHandler.preferences!!.contains(keyBLEDeviceID)) {
                var knownDevice : BLEDevice = Gson().fromJson(userPrefHandler.userPrefGetString(keyBLEDeviceID)!!, BLEDevice::class.java)
                if(device.serialID == knownDevice.serialID) {
                    // This is a known device, update its sync time
                    var deviceAsJSON = Gson().toJson(device)
                    userPrefHandler.userPrefSetString(keyBLEDeviceID, deviceAsJSON)
                    return false
                }
            }
        }

        // If we reach here, then the device did not exist in user preferences, add it
        addNewDevice(device)
        return true
    }

    // Adds unsent data to user preferences and returns the index for the key where they are stored
    public fun addUnsentSummaryData(summaries: List<SummaryData>, device: BLEDevice) : Int {
        var jsonPayload = buildJSONPayloadFromSummaryData(summaries, device)
        var currentUnsentDataCount = getUnsentSummaryDataCount()
        Log.d(TAG, "unsent summary data count: " + currentUnsentDataCount.toString())
        var keyNewUnsentData = Constants.userPrefKeyUnsentSummaryData + currentUnsentDataCount.toString()
        userPrefHandler.userPrefSetString(keyNewUnsentData, jsonPayload)

        return currentUnsentDataCount
    }

    public fun getUnsentSummaryDataAsJSON(index: Int) :  String? {
        return userPrefHandler.userPrefGetString((Constants.userPrefKeyUnsentSummaryData + index.toString()))
    }

    public fun clearUnsentSummaryDataAtIndex(index: Int) {
        var keyUnsentData = Constants.userPrefKeyUnsentSummaryDataCount + index.toString()
        userPrefHandler.userPrefClearData(keyUnsentData)
        var currentUnsentDataCount = getUnsentSummaryDataCount()
        if(currentUnsentDataCount != 0) {
            currentUnsentDataCount -= 1
        }

        userPrefHandler.userPrefSetInt(Constants.userPrefKeyUnsentSummaryDataCount, currentUnsentDataCount)
    }

    public fun getUnsentSummaryDataCount() : Int {
        if(userPrefHandler.preferences!!.contains(Constants.userPrefKeyUnsentSummaryDataCount)) {
            return userPrefHandler.userPrefGetInt(Constants.userPrefKeyUnsentSummaryDataCount)
        } else {
            return 0
        }
    }

    public fun deleteAllDevices() {
        for(device in getRegisteredDevices()) {
            deleteDevice(device)
        }
    }

    public fun deleteDevice(device: BLEDevice) {
        for (i in 0 until getTotalRegisteredBLEDeviceCount()) {
            val keyBLEDeviceID : String = Constants.userPrefKeyBLEDeviceID + i.toString()
            if(userPrefHandler.preferences!!.contains(keyBLEDeviceID)) {
                var knownDevice : BLEDevice = Gson().fromJson(userPrefHandler.userPrefGetString(keyBLEDeviceID)!!, BLEDevice::class.java)
                if(device.serialID == knownDevice.serialID) {
                    userPrefHandler.userPrefRemoveString(keyBLEDeviceID)
                    userPrefHandler.userPrefSetInt(Constants.userPrefKeyTotalBLEDeviceCount, userPrefHandler.userPrefGetInt(Constants.userPrefKeyTotalBLEDeviceCount) - 1)
                }
            }
        }
    }

    public fun clearAllData() {
        userPrefHandler.userPrefClearAllData()
    }

    private fun buildJSONPayloadFromSummaryData(summaries: List<SummaryData>, device: BLEDevice) : String {

        val jsonEventArray = JSONArray()

        for(summary in summaries) {
            val jsonEventFields = JSONArray()

            for(eventField in summary.eventFields) {
                val jsonEventField = JSONObject()
                jsonEventField.put("name", eventField.name)
                jsonEventField.put("value", eventField.value)
                jsonEventFields.put(jsonEventField)
            }


            val jsonEvent = JSONObject()
            jsonEvent.put("eventUUID", summary.eventUUID)
            jsonEvent.put("eventFields", jsonEventFields)

            jsonEventArray.put(jsonEvent)
        }

        val jsonPayload = JSONObject()
        jsonPayload.put("studyId", getStudyID()) // user entered right now...
        jsonPayload.put("participantId", getUsername()) // this doesn't appear to exist right now?? Let's use usernaME
        jsonPayload.put("deviceId", device.serialID!!)
        jsonPayload.put("data", jsonEventArray)

        val jsonMessage = JSONObject()
        val dateFormat = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssXXX")
        val now : String = dateFormat.format(Date(System.currentTimeMillis()))
        val id = UUID.randomUUID().toString()
        jsonMessage.put("consumerId", getLightyearConsumerID()) // This is lightyear labs CONSUMER ID
        jsonMessage.put("sessionId", id)
        jsonMessage.put("sessionStartTime", now)
        jsonMessage.put("message", jsonPayload)

        val jsonString = jsonMessage.toString()
//        val jsonReadableString = jsonMessage.toString(3)

        return jsonString
    }

    companion object {
        private const val TAG = "UserAccountInfo"
    }
}
