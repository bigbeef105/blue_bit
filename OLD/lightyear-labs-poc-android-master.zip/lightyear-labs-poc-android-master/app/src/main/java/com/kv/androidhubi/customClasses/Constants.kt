package com.kv.androidhubi.customClasses

import android.os.Build

public final class Constants {
    companion object {
        const val userPrefKeyUsername = "username"
        const val userPrefKeyPassword = "password"

        const val userPrefKeyStudyID = "studyID"
        const val userPrefKeyLightyearConsumerID = "lightyearDeviceID"

        const val userPrefKeyIgnoreDeviceIDs = "ignoreDeviceIDs"

        const val userPrefKeyBLEDeviceID = "BLEDeviceID"
        const val userPrefKeyBLEDeviceiBeaconID = "BLEDeviceiBeaconID"
        const val userPrefKeyBLEDeviceiBeaconMajor = "BLEDeviceiBeaconMajor"
        const val userPrefKeyBLEDeviceiBeaconMinor = "BLEDeviceiBeaconMinor"
        const val userPrefKeyBLEDeviceLastSyncTime = "BLEDeviceLastSyncTime"
        const val userPrefKeyTotalBLEDeviceCount = "TotalBLEDeviceCount"

        const val userPrefKeyUnsentSummaryData = "UnsentSummaryData"
        const val userPrefKeyUnsentSummaryDataCount = "UnsentSummaryDataCount"

        const val eulaUrlString = "https://aq-research-ios-assets.s3.amazonaws.com/eula.html"

        const val adminPassword = "Admin"

        fun getDeviceName(): String? {
            val manufacturer: String = Build.MANUFACTURER
            val model: String = Build.MODEL
            return if (model.toLowerCase().startsWith(manufacturer.toLowerCase())) {
                capitalize(model)
            } else {
                capitalize(manufacturer) + " " + model
            }
        }


        private fun capitalize(s: String?): String {
            if (s == null || s.length == 0) {
                return ""
            }
            val first = s[0]
            return if (Character.isUpperCase(first)) {
                s
            } else {
                Character.toUpperCase(first).toString() + s.substring(1)
            }
        }
    }
}
