package com.kv.androidhubi.customClasses

import androidx.fragment.app.Fragment
import com.kv.androidhubi.BeaconRegionBootstrap
import com.kv.androidhubi.MainActivity

open class HubiFragmentExtender : Fragment() {
    public fun getMainActivity() : MainActivity {
        return activity as MainActivity
    }

    public fun getAppNavigator() : AppNavigator {
        return getMainActivity().appNavigator
    }

    public fun getRegionBootstrapApplication() : BeaconRegionBootstrap {
        return getMainActivity().application as BeaconRegionBootstrap
    }

    companion object {
        private const val TAG = "HUBI FRAGMENT"
        private const val REQUEST_ENABLE_BT = 1
    }
}