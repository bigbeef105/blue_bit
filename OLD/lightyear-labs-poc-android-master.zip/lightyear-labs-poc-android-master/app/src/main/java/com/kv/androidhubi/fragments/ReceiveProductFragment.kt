package com.kv.androidhubi.fragments

import android.app.AlertDialog
import android.bluetooth.BluetoothAdapter
import android.content.Intent
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.*
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import codes.alchemy.lemonadeplatform.model.LightyearLabsDevice
import codes.alchemy.lightyearlabs.LightyearLabs
import codes.alchemy.lightyearlabs.LightyearLabs.createDevice
import com.kv.androidhubi.customClasses.HubiFragmentExtender
import com.kv.androidhubi.R
import com.kv.androidhubi.customClasses.HubiAlertDialog
import kotlinx.android.synthetic.main.fragment_receive_product.view.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import org.altbeacon.beacon.BeaconManager
import timber.log.Timber

class ReceiveProductFragment : HubiFragmentExtender() {

    var beaconManager: BeaconManager? = null
    var deviceID: String = ""

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        var view = inflater.inflate(R.layout.fragment_receive_product, container, false)
        view.buttonPerformScan!!.setOnClickListener() {
            getDevicesThenScan()
        }

        view.textInputDeviceID.editText?.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {

            }

            override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {

            }

            override fun afterTextChanged(p0: Editable?) {
                deviceID = p0.toString()
            }
        })

        // Inflate the layout for this fragment
        return view
    }

    private fun getDevicesThenScan() {
        var dialog = HubiAlertDialog(this.getMainActivity())
        dialog.show()

        if(deviceID.length != 8) {
            var myRunnable = Runnable {
                dialog?.noPeripheralsFoundInScan()
            }

            getMainActivity().runOnUiThread(myRunnable)
        }

        var deviceAlreadyAdded = false

        // Check if this device has already been added or not. If it has, then don't bother to scan/re-add it.
        for(userPrefDeviceID in getMainActivity().userAccountInfo.getRegisteredBLEDeviceIDs()) {
            if(userPrefDeviceID.toLowerCase().startsWith(deviceID.toLowerCase())) {
                Log.i("ProductList", "already added")
                deviceAlreadyAdded = true
            }
        }

        if(!deviceAlreadyAdded) {
            getRegionBootstrapApplication().scanForNewDevice(deviceID.toLowerCase(), dialog)
        } else {
            var myRunnable = Runnable {
                dialog?.deviceAlreadyAdded(getMainActivity())
            }

            getMainActivity().runOnUiThread(myRunnable)
        }

        // Use Lightyear to pull all deviceIDs associated with the users account from the server
//        CoroutineScope(Dispatchers.IO).launch {
//            Log.i("ProductList", "@@@@@@@@@@@@@@@@@@@@@@@@")
//            val result = LightyearLabs.getDevices()
//            try {
//                val devices = result.getOrThrow()
//                if(devices.count() > 0) {
//                    // Loop through devices on this account and see if the user-entered ID matches any of them
//                    var deviceIDMatchesDeviceOnAccount = false
//                    for(device in devices) {
//                        Log.i("ProductList", "Found device ID: " + device.deviceId)
//                        if(device.deviceId.toLowerCase().startsWith(deviceID.toLowerCase()) && deviceID != "") {
//                            // This device ID matches one on the users account
//                            deviceIDMatchesDeviceOnAccount = true
//                            var deviceAlreadyAdded = false
//
//                            // Now check if this device has already been added or not. If it has, then don't bother to scan/re-add it.
//                            for(userPrefDeviceID in getMainActivity().userAccountInfo.getRegisteredBLEDeviceIDs()) {
//                                if(userPrefDeviceID.toLowerCase().startsWith(deviceID.toLowerCase())) {
//                                    Log.i("ProductList", "already added")
//                                    deviceAlreadyAdded = true
//                                    var myRunnable = Runnable {
//                                        dialog?.deviceAlreadyAdded(getMainActivity())
//                                    }
//
//                                    getMainActivity().runOnUiThread(myRunnable)
//                                }
//                            }
//
//                            if(!deviceAlreadyAdded) {
//                                getRegionBootstrapApplication().scanForNewDevice(device, dialog)
//                            }
//                        }
//                    }
//
//                    if(!deviceIDMatchesDeviceOnAccount) {
//                        // If the entered device ID doesn't match anything on the users account, tell them nothing was found
//                        var myRunnable = Runnable {
//                            dialog.noPeripheralsFoundAttachedtoAccount()
//                        }
//
//                        getMainActivity().runOnUiThread(myRunnable)
//                    }
//                } else {
//                    var myRunnable = Runnable {
//                        dialog.noPeripheralsFoundAttachedtoAccount()
//                    }
//
//                    getMainActivity().runOnUiThread(myRunnable)
//                }
//            } catch (exception: Exception) {
//                Timber.e(exception.localizedMessage)
//            }
//        }
    }

    companion object {
        private const val TAG = "DeviceListActivity"
        private const val REQUEST_ENABLE_BT = 1
    }
}
