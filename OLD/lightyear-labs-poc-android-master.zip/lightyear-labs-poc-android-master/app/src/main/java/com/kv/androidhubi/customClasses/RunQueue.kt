package com.kv.androidhubi.customClasses

import kotlinx.coroutines.delay

class RunQueue {
    private val list = ArrayList<Runnable>()

    var runnableCount: Int = 0
        get() = list.count()

    fun enqueue(task:Runnable) {
        list.add(task)
    }

    fun runNext() {
        if (list.size > 0) {
            val task = list[0]
            list.removeAt(0)
            task.run()
        }
    }
}
