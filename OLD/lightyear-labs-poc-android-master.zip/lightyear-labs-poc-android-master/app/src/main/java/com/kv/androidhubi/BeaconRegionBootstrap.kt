package com.kv.androidhubi

import android.app.Application
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import android.os.Handler
import android.os.RemoteException
import android.util.Log
import androidx.annotation.RequiresApi
import codes.alchemy.awskit.iot.IotAuthState
import codes.alchemy.lightyearlabs.LightyearLabs
import com.amazonaws.mobile.client.Callback
import com.kineticvision.resbitblesdk.BLEDevice
import com.kineticvision.resbitblesdk.SummaryData
import com.kv.androidhubi.customClasses.*
import org.altbeacon.beacon.*
import org.altbeacon.beacon.powersave.BackgroundPowerSaver
import org.altbeacon.beacon.startup.BootstrapNotifier
import org.altbeacon.beacon.startup.RegionBootstrap
import timber.log.Timber


class BeaconRegionBootstrap : Application(), BootstrapNotifier, BeaconConsumer {
    private var regionBootstrap: RegionBootstrap? = null
    private var backgroundPowerSaver: BackgroundPowerSaver? = null
    private var monitoringActivity: MainActivity? = null
    private val cumulativeLog = ""
    public lateinit var userPrefHandler: UserPrefHandler
    public lateinit var userAccountInfo: UserAccountInfo
    private var regionsToMonitor: ArrayList<Region> = ArrayList<Region>()
    public lateinit var lightYearHubHandler: LightYearHubHandler

    private lateinit var bleScanner: BLEScanner
    private var runQueue: RunQueue = RunQueue()

    override fun onCreate() {
        super.onCreate()

        bleScanner = BLEScanner(applicationContext)
        Log.d(TAG, "App started up")

        userPrefHandler = UserPrefHandler(
            this.getSharedPreferences(
                "MyPreferences",
                MODE_PRIVATE
            )
        )
        userAccountInfo = UserAccountInfo(userPrefHandler)
        if (!this::lightYearHubHandler.isInitialized) {
            lightYearHubHandler = LightYearHubHandler(this)
        }

        if(userAccountInfo.userIsSignedIn()) {
            val username = userAccountInfo.getUsername()!!
            val password = userAccountInfo.getPassword()!!
            attemptLogin(username, password)
        } else {
            userAccountInfo.setIgnoreDeviceIDs(true)
        }

        val beaconManager = BeaconManager.getInstanceForApplication(this)
        // To detect proprietary beacons, you must add a line like below corresponding to your beacon
        // type.  Do a web search for "setBeaconLayout" to get the proper expression.
        beaconManager.beaconParsers.clear()
        beaconManager!!.getBeaconParsers().add(BeaconParser().setBeaconLayout("m:2-3=0215,i:4-19,i:20-21,i:22-23,p:24-24"))
        BeaconManager.setDebug(false)

        // Uncomment the code below to use a foreground service to scan for beacons. This unlocks
        // the ability to continually scan for long periods of time in the background on Andorid 8+
        // in exchange for showing an icon at the top of the screen and a always-on notification to
        // communicate to users that your app is using resources in the background.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                "My Notification Channel ID",
                "My Notification Name", NotificationManager.IMPORTANCE_DEFAULT
            )
            channel.description = "My Notification Channel Description"
            channel.setSound(null, null)
            val notificationManager = getSystemService(
                Context.NOTIFICATION_SERVICE
            ) as NotificationManager
            notificationManager.createNotificationChannel(channel)

            val builder: Notification = Notification.Builder(this)
                .setContentTitle("Scanning for Beacons")
                .setChannelId(channel.id)
//            .setContentText(subject)
                .setSmallIcon(R.drawable.logo)
//            .setLargeIcon(aBitmap)
                .build()

//        val builder = Notification.Builder(this, "test")
//        builder.setSmallIcon(R.drawable.logo)
//        builder.setContentTitle("Scanning for Beacons")
//        val intent = Intent(this, MainActivity::class.java)
//        val pendingIntent = PendingIntent.getActivity(
//            this, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT
//        )
//        builder.setContentIntent(pendingIntent)
            beaconManager.enableForegroundServiceScanning(builder, 456)
        }

        // For the above foreground scanning service to be useful, you need to disable
        // JobScheduler-based scans (used on Android 8+) and set a fast background scan
        // cycle that would otherwise be disallowed by the operating system.
        //
        beaconManager.setEnableScheduledScanJobs(false)
        beaconManager.backgroundBetweenScanPeriod = 3000
        beaconManager.backgroundScanPeriod = 1100


        // If we are ignoring deviceIDs then add an empty region which will monitor for any and all nearby beacons
        if(userAccountInfo.getIgnoreDeviceIDs()) {
            val region = Region(
                "backgroundRegion",
                null,
                null,
                null
            )

            regionsToMonitor.add(region)
            Log.d(TAG, "Monitoring ALL regions")
        } else {
            for(device in userAccountInfo.getRegisteredDevices()) {
                // wake up the app when a known beacon is seen. NOTE: This is ONLY for background monitoring.
                // In order to detect known beacons while the app is active we also need to set regions on the beaconManager inside the 'onBeaconServiceConnect' function
                val region = Region(
                    device.serialID,
                    Identifier.parse(device.iBeaconUUID.toString()),
                    Identifier.parse(device.iBeaconMajor.toString()),
                    Identifier.parse(
                        device.iBeaconMinor.toString()
                    )
                )

                regionsToMonitor.add(region)
                Log.d(TAG, "Monitoring specific regions")
            }
        }


        regionBootstrap = RegionBootstrap(this, regionsToMonitor)

        // simply constructing this class and holding a reference to it in your custom Application
        // class will automatically cause the BeaconLibrary to save battery whenever the application
        // is not visible.  This reduces bluetooth power usage by about 60%
        backgroundPowerSaver = BackgroundPowerSaver(this)

        beaconManager.bind(this)
    }

    override fun didDetermineStateForRegion(arg0: Int, arg1: Region?) {
        // Don't care
    }

    override fun didEnterRegion(arg0: Region?) {
        Log.d(TAG, "Got a didEnterRegion call")
        Log.d(TAG, arg0!!.uniqueId)

//        CoroutineScope(Dispatchers.IO).launch {
//            this@BeaconRegionBootstrap.performBackgroundScan(getRegisteredBLEDeviceIDs())
//        }
//        this.performBackgroundScan(getRegisteredBLEDeviceIDs())
    }

    public fun addNewRegionToMonitorForDevice(device: BLEDevice?) {
        val region = if(device == null) {
            Region(
                "backgroundRegion",
                null,
                null,
                null
            )
        } else {
            Region(
                device!!.serialID,
                Identifier.parse(device.iBeaconUUID.toString()),
                Identifier.parse(device.iBeaconMajor.toString()),
                Identifier.parse(device.iBeaconMinor.toString())
            )
        }

        regionsToMonitor.add(region)
        regionBootstrap!!.addRegion(region)
        val beaconManager = BeaconManager.getInstanceForApplication(this)

        try {
            beaconManager.startRangingBeaconsInRegion(region)
            // No range notifier needed, we already created one on initial beacon service connect.
        } catch (e: RemoteException) {
        }
    }

    public fun removeRegionFromMonitorForDevice(device: BLEDevice) {
        var regionToRemove: Region? = null
        for(region in regionsToMonitor) {
            if(region.uniqueId == device.serialID) {
                regionToRemove = region
            }
        }

        val beaconManager = BeaconManager.getInstanceForApplication(this)

        if(regionToRemove != null) {
            regionsToMonitor.remove(regionToRemove)
            beaconManager.stopRangingBeaconsInRegion(regionToRemove)
            regionBootstrap?.removeRegion(regionToRemove)
        }
    }

    public fun removeAllRegions() {
        val beaconManager = BeaconManager.getInstanceForApplication(this)

        for(region in regionsToMonitor) {
            beaconManager.stopRangingBeaconsInRegion(region)
            regionBootstrap?.removeRegion(region)
        }

        regionsToMonitor.clear()
    }

    fun setMonitoringActivity(activity: MainActivity?) {
        monitoringActivity = activity
    }

    public fun scanForNewDevice(deviceID: String, dialog: HubiAlertDialog) {
        bleScanner.scanForNewDevice(deviceID, this, dialog)
    }

    public fun performBackgroundScan(deviceID: String) {
        Log.d(TAG, "currently Scanning")
        bleScanner.performScan(this, deviceID) { Log.d(TAG, "peripherals Found: " + it) }
    }

    public fun getTotalRegisteredBLEDeviceCount() : Int {
        return userAccountInfo.getTotalRegisteredBLEDeviceCount()
    }

    public open fun foundValidPeripheralInScan(device: BLEDevice, dialog: HubiAlertDialog?) {
        if(dialog != null) {
            var myRunnable = Runnable { dialog?.connectionSuccessful(this.monitoringActivity!!) }

            this.monitoringActivity!!.runOnUiThread(myRunnable)
        }

        // If we just added one that means we're in its region because it had to broadcasting in order to be found.
        // While in the region we won't do anything, so let's force a scan
        var mainHandler = Handler(this.mainLooper);
        var myRunnable = Runnable { bleScanner.getSummaryDataFromDevice(this, device) {} }
        mainHandler.post(myRunnable);

    }

    public open fun noValidPeripheralsFoundInScan(dialog: HubiAlertDialog?) {
        if(dialog != null) {
            var myRunnable = Runnable { dialog?.noPeripheralsFoundInScan() }

            this.monitoringActivity!!.runOnUiThread(myRunnable)
        }
    }

    public open fun errorDurngScan(dialog: HubiAlertDialog?) {
        if(dialog != null) {
            var myRunnable = Runnable { dialog?.errorDuringScan() }

            this.monitoringActivity!!.runOnUiThread(myRunnable)
        }
    }

    // This function is called if we scan for devices while IGNORING device IDs
    public open fun receivedMultipleDevicesInBackgroundScan(devices: ArrayList<BLEDevice>) {
        //var deviceToGetDataFrom = devices.first()
        //devices.removeAt(0)

        for ((index, device) in devices.withIndex()) {
            var myRunnable = Runnable {  Log.d(TAG, "Getting summary for item at index: " + index); bleScanner.getSummaryDataFromDevice(this, device) { runQueue.runNext() } }
            runQueue.enqueue(myRunnable)
        }
        runQueue.enqueue( Runnable { Log.d(TAG, "Finished getting summaries") } )

        runQueue.runNext()


        // Get a handler that can be used to post to the main thread
        //var mainHandler = Handler(this.mainLooper);
        //var myRunnable = Runnable { bleScanner.getSummaryDataFromDevices(this, deviceToGetDataFrom, devices) }
        //mainHandler.post(myRunnable);
    }

    public open fun receivedSummaryData(summaries: List<SummaryData>, device: BLEDevice) {
        var isNewDevice = userAccountInfo.userPrefUpdateBLEDevice(device)

        if(isNewDevice) {
            addNewRegionToMonitorForDevice(device)
        }

        var unsentDataIndex = userAccountInfo.addUnsentSummaryData(summaries, device)

        sendUnsentSummaryData()
    }

    public open fun sendUnsentSummaryData() {
        var mainHandler = Handler(this.mainLooper);
        var myRunnable = Runnable {
            for(i in 0..userAccountInfo.getUnsentSummaryDataCount()) {
                var unsentDataAsJSON = userAccountInfo.getUnsentSummaryDataAsJSON(i)
                monitoringActivity!!.lightYearHubHandler.sendSummaryDataJSON(unsentDataAsJSON!!,
                    object : Callback<Error> {
                        override fun onResult(result: Error?) {
                            Log.d(TAG, "Successfully sent summary data")
                            userAccountInfo.clearUnsentSummaryDataAtIndex(i)
                        }

                        override fun onError(e: Exception?) {
                            // Retry sending
                            Log.d(TAG, "Failed to send summary data")
                        }
                    })
            }
        }
        mainHandler.post(myRunnable);
    }

    public open fun sendTestData(dialog: HubiAlertDialog) {
        dialog.show()
        monitoringActivity!!.lightYearHubHandler.sendMqttTestMessage(
            object : Callback<Error> {
                override fun onResult(result: Error?) {
                    Log.d(TAG, "Successfully sent summary data")
                    var myRunnable = Runnable { dialog.dataSendingSuccess() }

                    monitoringActivity!!.runOnUiThread(myRunnable)

                }

                override fun onError(e: Exception?) {
                    // Retry sending
                    Log.d(TAG, "Failed to send summary data")
                    var myRunnable = Runnable { dialog.dataSendingFail() }

                    monitoringActivity!!.runOnUiThread(myRunnable)
                }
            })
    }

    public open fun finishedScan() {
        Log.d(TAG, "Finished Scan")
    }

    override fun didExitRegion(arg0: Region?) {
        Log.d(TAG, "Got a didExitRegion call")
        val beaconManager = BeaconManager.getInstanceForApplication(this)
    }

    companion object {
        private const val TAG = "RegionBootstrap"
        private const val RANGING_DONE = "RANGING_DONE"
    }

    override fun onBeaconServiceConnect() {
        val beaconManager = BeaconManager.getInstanceForApplication(this)

        val rangeNotifier = getRangeNotifier()
        // RangeNotifiers is a set and just defines what we do when we enter a beacon range
        // Since we'll be doing the same thing every time we only need to ever add 1 notifier
        // We can add more, but since its a set it won't add anything unless you define a new type of notifier
        beaconManager.addRangeNotifier(rangeNotifier)

        try {
            for(region in regionsToMonitor) {
                beaconManager.startRangingBeaconsInRegion(region)
            }
        } catch (e: RemoteException) {
        }

        Log.d(
            TAG,
            "Number of notifiers is:  " + beaconManager.rangingNotifiers.count()
        )
    }

    private fun getRangeNotifier() : RangeNotifier {
        return RangeNotifier { beacons, region ->
            Log.d(TAG, "Range Notify")
            if (beacons.isNotEmpty()) {
                if (!bleScanner.isWorking && runQueue.runnableCount == 0) {
                    var mainHandler = Handler(this.mainLooper);
                    var myRunnable = Runnable {
                        this.performBackgroundScan(region.uniqueId)
                        Log.d(
                            TAG,
                            "Found beacon, not currently scanning, starting scan"
                        )
                    }
                    mainHandler.post(myRunnable);
                }

                Log.d(
                    TAG,
                    "didRangeBeaconsInRegion called with beacon count:  " + beacons.size
                )
                for (i in beacons.indices) {
                    val beacon = beacons.elementAt(i)
                    Log.d(
                            TAG,
                            "The beacon " + beacon.toString() + " is about " + beacon.distance + " meters away."
                    )
                }
            }
        }
    }

    public fun attemptLogin(username: String, password: String) {
        lightYearHubHandler.loadLightyear(
            this,
            object : codes.alchemy.lightyearlabs.LightyearLabsCallback {
                override fun onResult(authState: IotAuthState, lightyear: LightyearLabs) {
//                lightYearHubHandler.deviceType = "STAND"//Constants.getDeviceName().toString()
                    Log.i(TAG, "Loaded Lightyear")

                    if (authState != IotAuthState.SignedIn) {
                        lightYearHubHandler.loginUser(username, password, object : Callback<Error> {
                            override fun onResult(result: Error?) {
                                Log.i(TAG, "Signed In")

                                // login successful, let's link this device to the lightyear account if we haven't already
                                lightYearHubHandler.getDevice(object : Callback<Error> {
                                    override fun onResult(result: Error?) {
                                        var mainHandler = Handler(mainLooper)
                                        var myRunnable = Runnable {
                                            if (!userAccountInfo.userIsSignedIn()) {
                                                userAccountInfo.setUsername(username)
                                                userAccountInfo.setPassword(password)
                                                userAccountInfo.setLightyearConsumerID(
                                                    lightYearHubHandler.device!!.consumerId!!
                                                )
                                            }

                                            lightYearHubHandler.setupMqttClient()
                                        }

                                        mainHandler.post(myRunnable)
                                    }

                                    override fun onError(e: java.lang.Exception?) {
                                        Log.i(TAG, "Failed getting device")
                                    }
                                })
                            }

                            override fun onError(e: java.lang.Exception?) {
                                Log.i(TAG, "Failed")
                            }
                        })
                    } else {
                        Log.i(TAG, "Not Signed in")
                        lightYearHubHandler.getDevice(object : Callback<Error> {
                            override fun onResult(result: Error?) {
                                var mainHandler = Handler(mainLooper)
                                var myRunnable = Runnable {
                                    if (!userAccountInfo.userIsSignedIn()) {
                                        userAccountInfo.setUsername(username)
                                        userAccountInfo.setPassword(password)
                                        userAccountInfo.setLightyearConsumerID(lightYearHubHandler.device!!.consumerId!!)
                                    }

                                    lightYearHubHandler.setupMqttClient()
                                }


                                mainHandler.post(myRunnable)
                            }

                            override fun onError(e: java.lang.Exception?) {
                                Log.i(TAG, "Failed getting device")
                            }
                        })
                    }
                }

                override fun onError(e: Throwable) {
                    // braodcast error
                    e.printStackTrace()
                    Log.i(TAG, "Failed")
                    Timber.e("LightyearLabs AuthERROR: %s", e.localizedMessage)
                }
            })
    }
}
