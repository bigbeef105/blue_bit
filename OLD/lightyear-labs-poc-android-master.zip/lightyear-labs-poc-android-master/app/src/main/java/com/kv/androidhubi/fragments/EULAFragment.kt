package com.kv.androidhubi.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.kv.androidhubi.customClasses.Constants
import com.kv.androidhubi.customClasses.HubiFragmentExtender
import com.kv.androidhubi.R
import kotlinx.android.synthetic.main.fragment_eula.view.*

class EULAFragment: HubiFragmentExtender() {
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        var view = inflater.inflate(R.layout.fragment_eula, container, false)
        view.webview.loadUrl(Constants.eulaUrlString)

        return view
    }

}