package com.kv.androidhubi.fragments

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TableLayout
import com.kv.androidhubi.BeaconRegionBootstrap
import com.kv.androidhubi.R
import com.kv.androidhubi.customClasses.Constants
import com.kv.androidhubi.customClasses.HubiFragmentExtender
import kotlinx.android.synthetic.main.fragment_product_list.view.*
import kotlinx.android.synthetic.main.layout_product_list_row.*
import kotlinx.android.synthetic.main.layout_product_list_row.view.*
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.TimeUnit
import kotlin.collections.HashMap

class ProductListFragment : HubiFragmentExtender() {

    lateinit var mainHandler: Handler
    lateinit var tableView: TableLayout
    lateinit var theInflater: LayoutInflater
    lateinit var addedDeviceRows : HashMap<String, View>

    private val updateTextTask = object : Runnable {
        override fun run() {
            updateTable()
            mainHandler.postDelayed(this, 8000)
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_product_list, container, false)
        tableView = view.findViewById(R.id.productTableView)
        theInflater = inflater

        mainHandler = Handler(Looper.getMainLooper())

        addedDeviceRows = HashMap<String, View>()

        // Inflate the layout for this fragment
        return view
    }

    override fun onPause() {
        super.onPause()
        mainHandler.removeCallbacks(updateTextTask)
    }

    override fun onResume() {
        super.onResume()
        mainHandler.post(updateTextTask)
    }

    fun updateTable() {
        if(this.getRegionBootstrapApplication().getTotalRegisteredBLEDeviceCount() > 0) {
            // Since this is already running anyways, lets attempt to send unsent summary data here too
            if(getRegionBootstrapApplication().userAccountInfo.getUnsentSummaryDataCount() > 0) {
                getRegionBootstrapApplication().sendUnsentSummaryData()
            }

            for(device in getMainActivity().userAccountInfo.getRegisteredDevices()) {
                val v: View
                if (!addedDeviceRows.containsKey(device.serialID)) {
                    v = theInflater.inflate(R.layout.layout_product_list_row, null)
                    tableView.addView(v)
                    addedDeviceRows[device.serialID!!] = v
                } else {
                    v = addedDeviceRows[device.serialID]!!
                }

                v.textDeviceName.text = device.peripheral.name + ": " + device.serialID

                Log.d(TAG, "last sync: " + device.lastSyncTime)
                if (device.lastSyncTime != null) {
                    val currentTime = Calendar.getInstance().time

                    val outputFormat = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'")
                    val calendar = Calendar.getInstance()
                    calendar.timeInMillis = device.lastSyncTime
                    val lastSyncAsDate: Date = outputFormat.parse(outputFormat.format(device.lastSyncTime))

                    val seconds =
                        TimeUnit.MILLISECONDS.toSeconds(currentTime.time - lastSyncAsDate.time)
                    val minutes =
                        TimeUnit.MILLISECONDS.toMinutes(currentTime.time - lastSyncAsDate.time)
                    val hours =
                        TimeUnit.MILLISECONDS.toHours(currentTime.time - lastSyncAsDate.time)
                    val days = TimeUnit.MILLISECONDS.toDays(currentTime.time - lastSyncAsDate.time)

                    var lastSyncText = ""

                    if (seconds < 60) {
                        lastSyncText = if (seconds > 1) {
                            "$seconds seconds ago";
                        } else {
                            "$seconds second ago";
                        }
                    } else if (minutes < 60) {
                        lastSyncText = if (minutes > 1) {
                            "$minutes minutes ago";
                        } else {
                            "$minutes minute ago";
                        }
                    } else if (hours < 24) {
                        lastSyncText = if (hours > 1) {
                            "$hours hours ago";
                        } else {
                            "$hours hour ago";
                        }
                    } else {
                        lastSyncText = if (days > 1) {
                            "$days days ago";
                        } else {
                            "$days day ago";
                        }
                    }

                    lastSyncText = "Last Usage: $lastSyncText"
                    v.textLastSyncTime.text = lastSyncText
                } else {
                    v.textLastSyncTime.text = "Last Usage: None"
                }

                view?.textViewNoProducts?.alpha = 0.0f
            }
        } else {
            view?.textViewNoProducts?.alpha = 1.0f
        }
    }

    companion object {
        private const val TAG = "ProductListFragment"
    }
}
