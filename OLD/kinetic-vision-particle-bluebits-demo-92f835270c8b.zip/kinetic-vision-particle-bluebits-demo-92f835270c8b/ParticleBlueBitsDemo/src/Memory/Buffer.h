/**
 ******************************************************************************
 * @file    Buffer.h
 * @brief   Software unit for handling basic buffering
 * @author  Jeffrey Hatton
******************************************************************************
 *
 * @copyright COPYRIGHT (c) 2020 SAEC Kinetic Vision, Inc 
 *            All Rights Reserved
 *
 * This software is property of SAEC Kinetic Vision, Inc and is considered
 * confidential.
 *
 ******************************************************************************
 *
 * Significant Modification History (Most Recent at top)
 * -----------------------------------------------------
 *
 * Date        | Initials | Description
 * ----------- | -------- | -----------
 * 17 Aug 2020 |   JH     | Original
 *
 * Theory of Operation
 * -------------------
 * TBD
 *
 *
 *
*/

#ifndef Buffer_H
#define Buffer_H

#include "Status\DeviceStatus.h"
#include "SoftwareUnits\SoftwareUnit.h"

enum BufferModes_t {
    /**
     * @brief Operate the buffer in standard FIFO mode. Will throw an error when full.
     * 
     */
    BufferModes_Fifo = 0,

    /**
     * @brief Operate the buffer in ring buffer mode. When full will over write the last item
     * 
     */
    BufferModes_Ring,
    BufferModes_Count,
};

/**
 * @brief Class for handling buffers
 * 
 * @tparam T The type of object to be buffered
 * @tparam Y The size of the buffer
 */
template <class T, uint16_t Y>
class Buffer_t : public SoftwareUnit_t {
    public:

    /**
     * @brief Init the buffer
     * 
     * @param id ID for the buffer
     * @param mode The mode to use the buffer in
     * @return StatusRet_t 
     */
    StatusRet_t Init(SuId_t id, BufferModes_t mode) {
        StatusRet_t ret = SoftwareUnit_t::Init(id);
        if (Status_IsError(ret)) return ret;

        _Status = ret;
        _Head = 0;
        _Tail = 0;
        _Mode = mode;

        return ret;
    };

    /**
     * @brief Flush the buffer from the consumers side. Call this if you want to flush the buffer
     * from the software unit that is consuming data from the buffer
     * 
     * @return StatusRet_t 
     */
    StatusRet_t FlushByConsumer() {
        StatusRet_t ret = Status_Ok;

        _Tail = _Head;

        return ret;
    }

    /**
     * @brief Flush the buffer from the producer side. Call this if you want to flush the buffer
     * from the software unit that is producing data for the buffer
     * 
     * @return StatusRet_t 
     */
    StatusRet_t FlushByProducer() {
        StatusRet_t ret = Status_Ok;

        _Head = _Tail;

        return ret;
    }

    /**
     * @brief Get the max number of items the buffer can store
     * 
     * @param size 
     * @return StatusRet_t 
     */
    StatusRet_t GetSize(uint16_t* size) {
        StatusRet_t ret = Status_Ok;
        if (size == NULL) return Status_Pack(Status_Null_Ptr);

        *size = _Size - 1;

        return ret;       
    }

    StatusRet_t GetNextSlot(T** item) {
        StatusRet_t ret = Status_Ok;
        if (item == NULL) return Status_Pack(Status_Null_Ptr);

        if (_Mode == BufferModes_Fifo) {
            uint16_t numAvailable;
            ret = NumAvailable(&numAvailable);
            if (Status_IsError(ret)) return ret;

            if (numAvailable == 0) return Status_Pack(Status_BufferFull);
        }

        T* ptr = _Data + _Head;
        memcpy(ptr, item, sizeof(T));

        int32_t temp = _Head + 1;
        if (temp >= _Size) temp = 0;
        _Head = temp;        

        if (_Head == _Tail) {
            temp = _Tail + 1;
            if (temp >= _Size) temp = 0;
            _Tail = temp;
        }

        return ret;
    }

    StatusRet_t Enqueue() {
        StatusRet_t ret = Status_Ok;

        if (_Mode == BufferModes_Fifo) {
            uint16_t numAvailable;
            ret = NumAvailable(&numAvailable);
            if (Status_IsError(ret)) return ret;

            if (numAvailable == 0) return Status_Pack(Status_BufferFull);
        }

        int32_t temp = _Head + 1;
        if (temp >= _Size) temp = 0;
        _Head = temp;        

        if (_Head == _Tail) {
            temp = _Tail + 1;
            if (temp >= _Size) temp = 0;
            _Tail = temp;
        }

        return ret;
    }

    /**
     * @brief Enqueue an item
     * 
     * @param item 
     * @return StatusRet_t 
     */
    StatusRet_t Enqueue(T* item) {
        StatusRet_t ret = Status_Ok;
        if (item == NULL) return Status_Pack(Status_Null_Ptr);

        if (_Mode == BufferModes_Fifo) {
            uint16_t numAvailable;
            ret = NumAvailable(&numAvailable);
            if (Status_IsError(ret)) return ret;

            if (numAvailable == 0) return Status_Pack(Status_BufferFull);
        }

        T* ptr = _Data + _Head;
        memcpy(ptr, item, sizeof(T));

        int32_t temp = _Head + 1;
        if (temp >= _Size) temp = 0;
        _Head = temp;        

        if (_Head == _Tail) {
            temp = _Tail + 1;
            if (temp >= _Size) temp = 0;
            _Tail = temp;
        }

        return ret;
    }

    /**
     * @brief Enqueue multiple items. If running in FIFO mode will not 
     *        store any it there is not space for the entire set
     * 
     * @param itemPtr 
     * @param count 
     * @return StatusRet_t 
     */
    StatusRet_t Enqueue(T* itemPtr, uint16_t count) {
        StatusRet_t ret = Status_Ok;
        if (itemPtr == NULL) return Status_Pack(Status_Null_Ptr);

        if (_Mode == BufferModes_Fifo) {
            uint16_t numAvailable;
            ret = NumAvailable(&numAvailable);
            if (Status_IsError(ret)) return ret;

            if (numAvailable < count) return Status_Pack(Status_BufferFull);
        }

        T* ptr = itemPtr;
        for (uint16_t i = 0; i < count; i++) {
            ret = Enqueue(ptr);
            if (Status_IsError(ret)) return ret;
            ptr++;
        }

        return ret;
    };

    /**
     * @brief Return the number of empty slots
     * 
     * @param num 
     * @return StatusRet_t 
     */
    StatusRet_t NumAvailable(uint16_t* num) {
        StatusRet_t ret = Status_Ok;
        if (num == NULL) return Status_Pack(Status_Null_Ptr);

        int32_t used = _Head - _Tail;
        if (used < 0) used += _Size;
        *num = (_Size - 1) - used;

        return ret;
    };

    /**
     * @brief Return the number of stored items
     * 
     * @param num 
     * @return StatusRet_t 
     */
    StatusRet_t NumEnqueued(uint16_t* num) {
        StatusRet_t ret = Status_Ok;
        if (num == NULL) return Status_Pack(Status_Null_Ptr);

        uint16_t availble;
        ret = NumAvailable(&availble);
        if (Status_IsError(ret)) return ret;

        *num =(_Size - 1) - availble;

        return ret;
    };

    /**
     * @brief Peek at the first enqueued item
     * 
     * @param item 
     * @return StatusRet_t 
     */
    StatusRet_t Peek(T** item) {
        StatusRet_t ret = Status_Ok;
        if (item == NULL) return Status_Pack(Status_Null_Ptr);
        if (_Head == _Tail) return Status_Pack(Status_BufferEmpty);

        T* temp = _Data + _Tail;
        *item = temp;

        return ret;
    };

    /**
     * @brief Dequeue a single item
     * 
     * @param item 
     * @return StatusRet_t 
     */
    StatusRet_t Dequeue(T* item) {
        StatusRet_t ret = Status_Ok;
        if (item == NULL) return Status_Pack(Status_Null_Ptr);
        if (_Head == _Tail) return Status_Pack(Status_BufferEmpty);

        T* temp = _Data + _Tail;
        memcpy(item, temp, sizeof(T));

        int32_t tempTail = _Tail + 1;
        if (tempTail >= _Size) tempTail = 0;
        _Tail = tempTail;

        return ret;
    };

    /**
     * @brief Dequeue a single item
     * 
     * @param item 
     * @return StatusRet_t 
     */
    StatusRet_t Dequeue() {
        StatusRet_t ret = Status_Ok;
        if (_Head == _Tail) return Status_Ok;

        int32_t tempTail = _Tail + 1;
        if (tempTail >= _Size) tempTail = 0;
        _Tail = tempTail;

        return ret;
    };    

    /**
     * @brief Dequeue a set of items. If there is not enough items in the buffer will throw an error.
     * 
     * @param num The number of items to get
     * @param item buffer for the items
     * @return StatusRet_t 
     */
    StatusRet_t Dequeue(uint16_t num, T* item) {
        StatusRet_t ret = Status_Ok;
        if (item == NULL) return Status_Pack(Status_Null_Ptr);

        uint16_t numEnqueued;
        ret = NumEnqueued(&numEnqueued);
        if (Status_IsError(ret)) return ret;

        if (numEnqueued < num) return Status_Pack(Status_BufferEmpty);

        T* ptr = item;
        for (uint16_t i = 0; i < numEnqueued; i++) {
            ret = Dequeue(ptr);
            if (Status_IsError(ret)) return ret;
            ptr++;
        }
        
        return ret;
    };

    protected:
    
    StatusRet_t InternalCbist() {
        StatusRet_t ret = Status_Ok;

        if (_OverflowCheck != 0xDEADBEEF) {
            _Status = Status_BufferOverflow;
        }

        return ret;        
    }

    private:

    BufferModes_t _Mode;
    uint16_t _Size = Y;
    int32_t _Head;
    int32_t _Tail;

    T _Data[Y];

    /**
     * @brief Variable for cheking overflow from the data array
     * 
     */
    uint32_t _OverflowCheck = 0xDEADBEEF;
};

#endif
