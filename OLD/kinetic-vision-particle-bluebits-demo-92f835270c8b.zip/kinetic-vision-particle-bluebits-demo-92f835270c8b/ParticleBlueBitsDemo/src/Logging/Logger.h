/**
 ******************************************************************************
 * @file    Logger.h
 * @brief   Software unit for logging strings
 * @author  Jeffrey Hatton
******************************************************************************
 *
 * @copyright COPYRIGHT (c) 2020 SAEC Kinetic Vision, Inc 
 *            All Rights Reserved
 *
 * This software is property of SAEC Kinetic Vision, Inc and is considered
 * confidential.
 *
 ******************************************************************************
 *
 * Significant Modification History (Most Recent at top)
 * -----------------------------------------------------
 *
 * Date        | Initials | Description
 * ----------- | -------- | -----------
 * 03 Apr 2020 |   JH     | Original
 *
 * Theory of Operation
 * -------------------
 * TBD
 *
 *
 *
 */

#ifndef LOGGER_H
#define LOGGER_H

#include "Status\DeviceStatus.h"

enum LogLevels_t {
    LogLevels_Info = 0,
    LogLevels_Warn,
    LogLevels_Error,
    LogLevels_Count,
};

class Logger_t {
    public:

    /**
     * @brief Log a message to the logger. Follows the same format as printf.
     * 
     * @param level The log level for the message
     * @param fmt The format string
     * @param ... 
     * @return StatusRet_t 
     */
    static StatusRet_t Log(LogLevels_t level, const char* fmt, ...);

    /**
     * @brief Log an info message. Follows the same format as printf.
     * 
     * @param fmt The format string
     * @param ... 
     * @return StatusRet_t 
     */
    static StatusRet_t Info(const char* fmt, ...);

    /**
     * @brief Log a warning message. Follows the same format as printf.
     * 
     * @param fmt The format string
     * @param ... 
     * @return StatusRet_t 
     */
    static StatusRet_t Warn(const char* fmt, ...);

    /**
     * @brief Log an error message. Follows the same format as printf.
     * 
     * @param fmt The format string
     * @param ... 
     * @return StatusRet_t 
     */
    static StatusRet_t Error(const char* fmt, ...);

    /**
     * @brief Init the log
     * 
     * @param serial The serial object to use for the log
     * @return StatusRet_t 
     */
    static StatusRet_t Init(Stream* serial);

    /**
     * @brief Method to generically handle the printf formated messages
     * 
     * @param level The level to log at
     * @param fmt The format string
     * @param args The additional arguments for the format string
     * @return StatusRet_t 
     */
    static StatusRet_t LogVa(LogLevels_t level, const char* fmt, va_list args);

    private:
    
    /**
     * @brief Init the singleton instance
     * 
     * @return StatusRet_t 
     */
    StatusRet_t Init();

    /**
     * @brief Buffer for the serial com object
     * 
     */
    static Stream* _Serial;

    /**
     * @brief Status of the singleton object
     * 
     */
    StatusRet_t _Status = Status_Not_Initialized;

    /**
     * @brief Buffer for converting formatted strings
     * 
     */
    static char _Buf[200];
};

#endif
