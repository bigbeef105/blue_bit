/**
 ******************************************************************************
 * @file    Config.h
 * @brief   File to house configuration settings for the device
 * @author  Jeffrey Hatton
******************************************************************************
 *
 * @copyright COPYRIGHT (c) 2020 SAEC Kinetic Vision, Inc 
 *            All Rights Reserved
 *
 * This software is property of SAEC Kinetic Vision, Inc and is considered
 * confidential.
 *
 ******************************************************************************
 *
 * Significant Modification History (Most Recent at top)
 * -----------------------------------------------------
 *
 * Date        | Initials | Description
 * ----------- | -------- | -----------
 * 03 Apr 2020 |   JH     | Original
 *
 * Theory of Operation
 * -------------------
 * TBD
 *
 */

#ifndef CORE_CONFIG_H
#define CORE_CONFIG_H

//
// Execution
//

/**
 * @brief Uncomment to enable logging in the system
 * 
 */
#define ENABLE_LOGGING

/**
 * @brief The buad rate to use for the diagnostic serial port
 * 
 */
#define DIAG_BAUD 115200

/**
 * @brief The serial port to use for diagnostic purposes
 * 
 */
#define DIAG_SERIAL Serial

//
// Debug
//

/**
 * @brief Code will spin before init before the diag serial port is connected
 * 
 */
#define WAIT_FOR_SERIAL

//
// CLI
//

/**
 * @brief the size of the internal buffer for the CLI
 * 
 */
#define CLI_BUF_SIZE 100

/**
 * @brief The size of the print buffer for the CLI
 * 
 */
#define CLI_PRINT_BUF_SIZE 8096

/**
 * @brief The max a single command can have
 * 
 */
#define CLI_MAX_ARGS 10

/**
 * @brief The stream to use for the CLI
 * 
 */
#define CLI_STREAM Serial

#endif
