/**
 ******************************************************************************
 * @file    CoreInfo.h
 * @brief   Software unit that contains core sdk info.
 * @author  Jeffrey Hatton
******************************************************************************
 *
 * @copyright COPYRIGHT (c) 2020 SAEC Kinetic Vision, Inc 
 *            All Rights Reserved
 *
 * This software is property of SAEC Kinetic Vision, Inc and is considered
 * confidential.
 *
 ******************************************************************************
 *
 * Significant Modification History (Most Recent at top)
 * -----------------------------------------------------
 *
 * Date        | Initials | Description
 * ----------- | -------- | -----------
 * 19 Aug 2020 |   JH     | Original
 *
 * Theory of Operation
 * -------------------
 * TBD
 *
 *
 *
 */

#ifndef CORE_INFO_H
#define CORE_INFO_H

/**
 * @brief The version fo the core sdk
 * 
 */
#define CORE_SDK_VER "v0.5.3.0"

#endif
