/**
 ******************************************************************************
 * @file    StringHelper.h
 * @brief   Module that contains logic for helping with strings
 * @author  Jeffrey Hatton
******************************************************************************
 *
 * @copyright COPYRIGHT (c) 2020 SAEC Kinetic Vision, Inc 
 *            All Rights Reserved
 *
 * This software is property of SAEC Kinetic Vision, Inc and is considered
 * confidential.
 *
 ******************************************************************************
 *
 * Significant Modification History (Most Recent at top)
 * -----------------------------------------------------
 *
 * Date        | Initials | Description
 * ----------- | -------- | -----------
 * 19 Aug 2020 |   JH     | Original
 *
 * Theory of Operation
 * -------------------
 * TBD
 *
 *
 *
 */

#ifndef STRING_HELPER_H
#define STRING_HELPER_H

#include "Status\DeviceStatus.h"

#define ASCII_CR '\r'
#define ASCII_LF '\n'
#define ASCII_TAB '\t'
#define ASCII_BS 8
#define ASCII_DEL 0x7f
#define ASCII_WHITE_SPACE(_c_) ((_c_==' ')||(_c_=='\t')||(_c_=='\r')||(_c_=='\n'))
#define ASCII_NEW_LINE_STR "\x0d\x0a"

StatusRet_t StrToLower(char* dest, char* src);

#endif
