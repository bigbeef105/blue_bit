/**
 ******************************************************************************
 * @file    DeviceStatus.h
 * @brief   Device status identifiers
 * @author  Jeffrey Hatton
******************************************************************************
 *
 * @copyright COPYRIGHT (c) 2020 SAEC Kinetic Vision, Inc 
 *            All Rights Reserved
 *
 * This software is property of SAEC Kinetic Vision, Inc and is considered
 * confidential.
 *
 ******************************************************************************
 *
 * Significant Modification History (Most Recent at top)
 * -----------------------------------------------------
 *
 * Date        | Initials | Description
 * ----------- | -------- | -----------
 * 07 FEB 2020 |   JH     | Original
 *
 * Theory of Operation
 * -------------------
 * TBD
 *
 *
 *
 */

#include "DeviceStatus.h"
#include <Arduino.h>
#include "string.h"

const char* StatusStrMap[Status_Last_Common_Status] = {
    [Status_Ok] = "Ok",
    [Status_Null_Ptr] = "Null Ptr",
    [Status_Not_Initialized] = "Not Initialized",
    [Status_Initialized] = "Initialized",
    [Status_Timeout] = "Timeout",
    [Status_SuIdSet] = "SuIdSet",
    [Status_InvalidSuId] = "Invalid SuId",
    [Status_BufferOverflow] = "Buffer overflow",
    [Status_BufferFull] = "Buffer Full",
    [Status_BufferEmpty] = "Buffer Empty",
    [Status_BufferTooSmall] = "Buffer Too Small",
    [Status_BufferTooLarge] = "Buffer Too Large",
    [Status_BufferInvalid] = "Buffer Invalid",
    [Status_AlreadyLinked] = "Already Linked",
    [Status_Item_Not_Found] = "Item Not Found",
    [Status_Unreachable] = "Unreachable",
    [Status_Busy] = "Busy",
    [Status_HardwareDoesNotExist] = "Hardware Does Not Exist",
    [Status_InvalidOperation] = "Invalid Operation",
    [Status_IncorrectDevice] = "Incorrect Device",
    [Status_Invalid_Format] = "Invalid Format",
    [Status_Invalid_Value] = "Invalid Value",
    [Status_ValueOutOfBounds] = "Value Out Of Bounds",
    [Status_AlreadyInitialized] = "Already Initialized",
    [Status_InvalidState] = "Invalid State",
    [Status_UnkownCommand] = "Unkown Command",
    [Status_NOP] = "NOP",
    [Status_ResourceLocked] = "Resource Locked",
};

StatusRet_t Status_GetStatusAsString(StatusRet_t status, const char** statusString){
    if(statusString == NULL) return Status_Null_Ptr;

    StatusRet_t ret = Status_Ok;
    Status_t temp = Status_GetStatus(status);

    if(temp < Status_Last_Common_Status){
        *statusString = StatusStrMap[temp];
    } else {
        ret = Status_Invalid_Value;
    }

    return ret;
}
