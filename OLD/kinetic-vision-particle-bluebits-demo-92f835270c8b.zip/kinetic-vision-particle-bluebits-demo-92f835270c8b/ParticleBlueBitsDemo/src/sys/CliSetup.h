/**
 ******************************************************************************
 * @file    CliSetup.h
 * @brief   Unit for managing setup the of the CLI
 * @author  Jeffrey Hatton
******************************************************************************
 *
 * @copyright COPYRIGHT (c) 2020 SAEC Kinetic Vision, Inc 
 *            All Rights Reserved
 *
 * This software is property of SAEC Kinetic Vision, Inc and is considered
 * confidential.
 *
 ******************************************************************************
 *
 * Significant Modification History (Most Recent at top)
 * -----------------------------------------------------
 *
 * Date        | Initials | Description
 * ----------- | -------- | -----------
 * 18 Aug 2020 |   JH     | Original
 *
 * Theory of Operation
 * -------------------
 * TBD
 *
 *
 *
 */

#ifndef CliSetup_H
#define CliSetup_H

#include "Status\DeviceStatus.h"
#include "sys\Cli.h"

StatusRet_t CliSetup(CLI* cli);

#endif
