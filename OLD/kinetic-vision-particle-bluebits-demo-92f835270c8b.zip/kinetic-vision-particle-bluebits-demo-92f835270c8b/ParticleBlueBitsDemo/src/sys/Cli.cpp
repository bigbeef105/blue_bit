/**
 ******************************************************************************
 * @file    Cli.cpp
 * @brief   Implementation for CLI
 * @author  Jeffrey Hatton
******************************************************************************
 *
 * @copyright COPYRIGHT (c) 2020 SAEC Kinetic Vision, Inc 
 *            All Rights Reserved
 *
 * This software is property of SAEC Kinetic Vision, Inc and is considered
 * confidential.
 *
 ******************************************************************************
 *
 * Significant Modification History (Most Recent at top)
 * -----------------------------------------------------
 *
 * Date        | Initials | Description
 * ----------- | -------- | -----------
 * 18 Aug 2020 |   JH     | Original
 *
 * Theory of Operation
 * -------------------
 * TBD
 *
 *
 *
 */

#include "Cli.h"
#include "misc\ArrayHelper.h"
#include "misc\StringHelper.h"

static CLI _Instance;
Stream* CLI::_Stream;

StatusRet_t CLI::Init(SuId_t id, Stream* stream) {
    if (stream == NULL) return Status_Null_Ptr;
    
    CLI::_Stream = stream;

    return _Instance.Init(id);
}

StatusRet_t CLI::Init(SuId_t id) {
    StatusRet_t ret = SoftwareUnit_t::Init(id);
    if (Status_IsError(ret)) return ret;

    _Name = "CLI";
    _Status = Status_Ok;

    _Status = Reset();
    if (Status_IsError(_Status)) return _Status;

    return _Status;   
}

StatusRet_t CLI::GetInstance(CLI** instance) {
    if (instance == NULL) return Status_Null_Ptr;

    *instance = &_Instance;

    return Status_Ok;
}

StatusRet_t CLI::IPrintf(const char* fmt, ...) {
    va_list args;
    va_start(args,fmt);

    StatusRet_t ret = PrintVa(fmt, args);
    va_end(args);

    return ret;
}

StatusRet_t CLI::Printf(const char* fmt, ...){
    va_list args;
    va_start(args,fmt);

    StatusRet_t ret = _Instance.PrintVa(fmt, args);
    va_end(args);
    return ret;
}

StatusRet_t CLI::PrintVa(const char* fmt, va_list args) {
    if (Status_IsError(_Status)) return _Status;
    uint16_t charCount = vsnprintf(_CliPrintBuf, sizeof(_CliPrintBuf), fmt, args);
    if (charCount == sizeof(_CliPrintBuf)) return Status_BufferTooSmall;

    _Stream->print(_CliPrintBuf);

    return Status_Ok;
}

StatusRet_t CLI::InternalTick() {
    StatusRet_t ret = Status_Ok;

    ret = ProcessInputs();
    if (Status_IsError(ret)) return ret;

    return ret;
}

StatusRet_t CLI::ProcessInputs() {
    StatusRet_t ret = Status_Ok;

    int bytes = _Stream->available();
    if (bytes == 0) return Status_NOP;

    while (bytes--) {
        char c;
        _Stream->readBytes(&c, 1);

        switch (c) {
            case ASCII_LF:
            case ASCII_CR:
                ret = HandleLine();
            break;
            case ASCII_TAB:
                _Stream->flush();
                ret = TabComplete();
                return ret;
            break;
            case ASCII_BS:
            case ASCII_DEL:
                if(_BufIdx > 0) {                
                    _CliBuf[--_BufIdx] = 0;
                    ret = IPrintf("\x08 \x08");
                    if (Status_IsError(ret)) return ret;
                }
                break;
            default:
                if (_BufIdx < CLI_BUF_SIZE) {
                    ret = IPrintf("%c", c);
                    if (Status_IsError(ret)) return ret;
                    _CliBuf[_BufIdx++] = c;
                } else {
                    ret = Status_Pack(Status_BufferFull);
                }
                break;
        }
    }

    return ret;    
}

StatusRet_t CLI::TabComplete() {
    StatusRet_t ret = Status_Ok;
    
    // Prevent null errors if first character is null
    if (_CliBuf[0] == 0) return ret;

    uint16_t count = 0;
    char* firstValue = NULL;
    StrToLower(_ToLowerBuf, _CliBuf);

    CliSuNode_t* node = _RootNode;
    while (node != NULL) {
        CliCmdNode_t* cmdNode = node->Cmds;
        while (cmdNode != NULL && cmdNode->Callback != NULL) {            
            StrToLower(_ToLowerBuf2, cmdNode->Name);
            int cmpResult = strncmp(_ToLowerBuf, _ToLowerBuf2, _BufIdx);
            if (0 == cmpResult) {
                if (count == 0) {
                    firstValue = cmdNode->Name;
                } else if (count == 1) {
                    ret = IPrintf("\n %s\t%s", firstValue, cmdNode->Name);
                    if (Status_IsError(ret)) return ret;
                } else {
                    ret = IPrintf("\t%s", cmdNode->Name);
                    if (Status_IsError(ret)) return ret;
                }

                count++;
            }
            cmdNode++;
        }

        node = node->Next;
    }

    if (count == 1) {
        // Clear out the current text
        for (uint16_t i = 0; i < _BufIdx; i++){
            ret = IPrintf("\x08");
            if (Status_IsError(ret)) return ret;
        }
        
        // Replace buffer with the found value
        strcpy(_CliBuf, firstValue);
        _BufIdx = strlen(firstValue);
        ret = IPrintf("%s", _CliBuf);
        if (Status_IsError(ret)) return ret;
    } else if (count > 1) {
        ret = IPrintf("\n%s", _CliBuf);
        if (Status_IsError(ret)) return ret;
    }

    return ret;
}

StatusRet_t CLI::HandleLine() {
    StatusRet_t ret = Status_Ok;

    // Move courser to knew line so handlers have a clean line to print to
    ret = IPrintf("\n");
    if (Status_IsError(ret)) return ret;

    ret = ParseLine();
    if (Status_IsError(ret)) return ret;

    if (_ArgCount > 0) {
        ret = CallCommand();
        if (Status_IsError(ret))  {
            if (Status_IsStatus(ret, Status_UnkownCommand)) {
                ret = IPrintf("Unkown Command");
                if (Status_IsError(ret)) return ret;

                ret = Status_Ok;
            } else {
                Reset();
                return ret;
            }
        }
    }

    ret = Reset();
    if (Status_IsError(ret)) return ret;

    return ret;
}

StatusRet_t CLI::ParseLine() {
    StatusRet_t ret = Status_Ok;

    uint16_t i = 0;

    // Parse RxBuffer
    for (i = 0; i < _BufIdx; i++) {

        // Remove leading white space
        if (ASCII_WHITE_SPACE(_CliBuf[i])) {
            continue;
        }

        // Protect array "pArg"
        if (_ArgCount >= HBOUND(_CliArgBuf)) {
            break;
        }

        // Prepare argument pointer
        _CliArgBuf[_ArgCount++] = &_CliBuf[i++];

        // Scan forward in "RxBuffer" looking for end of parameter
        for (; i < _BufIdx; i++) {

            // Keep processing this parameter until white space
            if (!ASCII_WHITE_SPACE(_CliBuf[i])) {
                continue;
            }

            // Null terminate this parameter by replacing the white space with a null terminator
            _CliBuf[i] = 0;

            // This parameter is setup, continue with the next one
            break;
        }
    }

    return ret;
}

StatusRet_t CLI::CallCommand() {
    StatusRet_t ret = Status_Ok;

    bool handled = false;
    ret = Status_UnkownCommand;
    StrToLower(_ToLowerBuf, _CliArgBuf[0]);

    CliSuNode_t* node = _RootNode;
    while (node != NULL) {
        CliCmdNode_t* cmdNode = node->Cmds;
        while (cmdNode != NULL && cmdNode->Callback != NULL) {
            // Does the command in argv[0], match the current command in the list?
            StrToLower(_ToLowerBuf2, cmdNode->Name);
            int cmpResult = strcmp(_ToLowerBuf, _ToLowerBuf2);
            if (0 == cmpResult) {
                if (_ArgCount < cmdNode->MinArgCount + 1) {
                    ret = IPrintf("Too Few Args");
                    if (Status_IsError(ret)) return ret;          
                } else if (_ArgCount > cmdNode->MaxArgCount + 1) {
                    ret = IPrintf("Too Many Args");
                } else {
                    ret = cmdNode->Callback(_ArgCount, _CliArgBuf);    
                }

                handled = true;
                break;
            }
            cmdNode++;
        }

        if (handled) break;

        node = node->Next;
    }

    return ret;
}

StatusRet_t CLI::Reset() {
    if (Status_IsError(_Status)) return _Status;
    StatusRet_t ret = Status_Ok;

    _Stream->flush();

    memset(_CliBuf, 0, CLI_BUF_SIZE);
    _BufIdx = 0;

    memset(_CliArgBuf, 0, sizeof(_CliArgBuf));
    _ArgCount = 0;

    return ret;
}

StatusRet_t CLI::RegisterNode(CliSuNode_t* node, CliCmdNode_t* cmds) {
    return _Instance.IRegisterNode(node, cmds);
}

StatusRet_t CLI::IRegisterNode(CliSuNode_t* node, CliCmdNode_t* cmds) {
    if (Status_IsError(_Status)) return _Status;
    if (node == NULL || cmds == NULL) return Status_Pack(Status_Null_Ptr);
    
    StatusRet_t ret = Status_Ok;

    node->Cmds = cmds;

    if (_RootNode == NULL) {
        _RootNode = node;
        return ret;
    } else {
        CliSuNode_t* searchNode = _RootNode;
        while (searchNode != NULL) {
            if (searchNode->Next == NULL) {
                searchNode->Next = node;
                break;
            }

            searchNode = searchNode->Next;
        }

        return ret;
    }
}

StatusRet_t CLI::PrintAllCommands(char* filterString) {
    StatusRet_t ret = Status_Ok;


    uint32_t filterLength;
    if(filterString == NULL) {
        filterLength = 0;
    } else {
        filterLength = strlen(filterString);
    }

    CliSuNode_t* node = _RootNode;
    while (node != NULL) {
        bool found = false;

        CliCmdNode_t* cmdNode = node->Cmds;
        while (cmdNode != NULL && cmdNode->Callback != NULL) {
            if (filterLength == 0 || 0 == strncmp(filterString, cmdNode->Name, filterLength)) {
                if (!found) {
                    // Only print the SU name if a match is
                    if (node->SuName != NULL) {
                        ret = IPrintf("%s\n", node->SuName);
                        if (Status_IsError(ret)) return ret;
                    } else {
                        ret = IPrintf("Unknown");
                        if (Status_IsError(ret)) return ret;
                    }

                    found = true;
                }

                // only print command if it matches the filter. If there is a filter.
                ret = IPrintf("\t%s(%u,%u)\t%s\n", cmdNode->Name, cmdNode->MinArgCount, cmdNode->MaxArgCount, cmdNode->Usage);
                if (Status_IsError(ret)) return ret;
            }

            delay(5);
            cmdNode++;
        }
        node = node->Next;
    }

    return ret;
}
