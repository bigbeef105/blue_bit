/**
 ******************************************************************************
 * @file    Cli.h
 * @brief   Unit for managing a CLI for the device
 * @author  Jeffrey Hatton
******************************************************************************
 *
 * @copyright COPYRIGHT (c) 2020 SAEC Kinetic Vision, Inc 
 *            All Rights Reserved
 *
 * This software is property of SAEC Kinetic Vision, Inc and is considered
 * confidential.
 *
 ******************************************************************************
 *
 * Significant Modification History (Most Recent at top)
 * -----------------------------------------------------
 *
 * Date        | Initials | Description
 * ----------- | -------- | -----------
 * 17 Aug 2020 |   JH     | Original
 *
 * Theory of Operation
 * -------------------
 * TBD
 *
 *
 *
 */

#ifndef CLI_H
#define CLI_H

#include "Status\DeviceStatus.h"
#include "SoftwareUnits\SoftwareUnit.h"
#include "CoreConfig.h"

enum CliStatuses_t {
    CliStatuses_TooFewArgs = Status_Last_Common_Status,
    CliStatuses_TooManyArgs,
    CliStatuses_ArgOoR,
    CliStatuses_IncorrectPassword,
    CliStatuses_Count
};

struct CliCmdNode_t {
    /**
     * @brief Name of the command. This is what will be called from the CLI. Is not case sensitive.
     * 
     */
    char* Name = NULL;

    /**
     * @brief String to descripe how to use the command.
     * 
     */
    char* Usage = NULL;

    /**
     * @brief Callback for when the command is called
     * 
     */
    StatusRet_t (*Callback)(uint16_t argc, char** argv);

    /**
     * @brief The minimum number of arguments for the command
     * 
     */
    uint16_t MinArgCount = 0;

    /**
     * @brief The maximum number of arguments for the command
     * 
     */
    uint16_t MaxArgCount = CLI_MAX_ARGS - 1;
};

struct CliSuNode_t {
    /**
     * @brief Name of the node. Should be the same as the software unit it represents. 
     * Used only for readability and sorting purposes.
     * 
     */
    char* SuName = NULL;

    /**
     * @brief List of the commands in the node. Must end with a command with a null callback
     * 
     */
    CliCmdNode_t* Cmds = NULL;

    /**
     * @brief The next node in the list
     * 
     */
    CliSuNode_t* Next = NULL;
};

class CLI : public SoftwareUnit_t {
    public:

    /**
     * @brief Init the static instance of the CLI
     * 
     * @param id 
     * @param stream 
     * @return StatusRet_t 
     */
    static StatusRet_t Init(SuId_t id, Stream* stream);

    /**
     * @brief print all registered commands on the CLI
     * 
     * @param filterString The string to use to filter the help list. Can be null to not filter.
     * @return StatusRet_t 
     */
    StatusRet_t PrintAllCommands(char* filterString);

    /**
     * @brief Register a node into the CLI
     * 
     * @param node The node to register
     * @param cmds The commands for the node
     * @return StatusRet_t 
     */
    StatusRet_t IRegisterNode(CliSuNode_t* node, CliCmdNode_t* cmds);
    
    /**
     * @brief Print a formatted string onto the CLI. Same format as Printf.
     * 
     * @param fmt 
     * @param ... 
     * @return StatusRet_t 
     */
    StatusRet_t IPrintf(const char* fmt, ...);

    /**
     * @brief Print a formatted string onto the static CLI. Same format as Printf.
     * 
     * @param fmt 
     * @param ... 
     * @return StatusRet_t 
     */
    static StatusRet_t Printf(const char* fmt, ...);

    /**
     * @brief Get the static instance of the CLI
     * 
     * @param instance 
     * @return StatusRet_t 
     */
    static StatusRet_t GetInstance(CLI** instance);

    /**
     * @brief Register a node into the static instance of the CLI
     * 
     * @param node The node to register
     * @param cmds The commands for the node
     * @return StatusRet_t 
     */
    static StatusRet_t RegisterNode(CliSuNode_t* node, CliCmdNode_t* cmds);

    protected:

    StatusRet_t InternalTick();

    private:

    /**
     * @brief Init the singleton instance
     * 
     * @return StatusRet_t 
     */
    StatusRet_t Init(SuId_t id);

    /**
     * @brief Print formated string to the stream.
     * 
     * @param fmt 
     * @param args 
     * @return StatusRet_t 
     */
    StatusRet_t PrintVa(const char* fmt, va_list args);

    /**
     * @brief Internal stream for sending receiving data
     * 
     */
    static Stream* _Stream;

    // Internal Buffers
    char _CliPrintBuf[CLI_PRINT_BUF_SIZE];
    char _ToLowerBuf[CLI_BUF_SIZE];
    char _ToLowerBuf2[CLI_BUF_SIZE];
    char _CliBuf[CLI_BUF_SIZE];
    char* _CliArgBuf[CLI_MAX_ARGS];

    /**
     * @brief the current argument count. Includes the base command.
     * 
     */
    uint16_t _ArgCount;

    /**
     * @brief current index into the cli buffer
     * 
     */
    uint16_t _BufIdx;

    /**
     * @brief Root node for the commands
     * 
     */
    CliSuNode_t* _RootNode = NULL;

    /**
     * @brief handle a tab complete event
     * 
     * @return StatusRet_t 
     */
    StatusRet_t TabComplete();

    /**
     * @brief Process inputs from thestream
     * 
     * @return StatusRet_t 
     */
    StatusRet_t ProcessInputs();

    /**
     * @brief handle a line from the stream
     * 
     * @return StatusRet_t 
     */
    StatusRet_t HandleLine();

    /**
     * @brief Parse a line from the stream and prep it for being called
     * 
     * @return StatusRet_t 
     */
    StatusRet_t ParseLine();

    /**
     * @brief Call the currently parsed command
     * 
     * @return StatusRet_t 
     */
    StatusRet_t CallCommand();

    /**
     * @brief Reset the CLI. Will flush all buffers and the stream.
     * 
     * @return StatusRet_t 
     */
    StatusRet_t Reset();
};

#endif
