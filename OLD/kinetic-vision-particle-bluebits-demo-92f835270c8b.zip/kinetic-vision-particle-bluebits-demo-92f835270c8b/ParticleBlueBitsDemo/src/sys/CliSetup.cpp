/**
 ******************************************************************************
 * @file    CliSetup.cpp
 * @brief   Implementation for CliSetup
 * @author  Jeffrey Hatton
******************************************************************************
 *
 * @copyright COPYRIGHT (c) 2020 SAEC Kinetic Vision, Inc 
 *            All Rights Reserved
 *
 * This software is property of SAEC Kinetic Vision, Inc and is considered
 * confidential.
 *
 ******************************************************************************
 *
 * Significant Modification History (Most Recent at top)
 * -----------------------------------------------------
 *
 * Date        | Initials | Description
 * ----------- | -------- | -----------
 * 18 Aug 2020 |   JH     | Original
 *
 * Theory of Operation
 * -------------------
 * TBD
 *
 *
 *
 */

#include "Status\DeviceStatus.h"
#include "CliSetup.h"
#include "sys\Cli.h"

static CLI* _Cli;

static StatusRet_t Help(uint16_t c, char** argv) {
    StatusRet_t ret = Status_Ok;

    char* filter = NULL;
    if (c > 1) {
        filter = argv[1];
    }

    ret = _Cli->PrintAllCommands(filter);

    return ret;
}

static CliSuNode_t _RootNode = {
    .SuName = "CLI",
};

CliCmdNode_t _Nodes[] = {
    {"help","Lists out all of the commands format: name(<min args>,<max args>) usage. Pass in a string to filter the command by that string", &Help},
    {NULL,NULL,NULL}
};

StatusRet_t CliSetup(CLI* cli) {
    if (cli == NULL) return Status_Null_Ptr;
    StatusRet_t ret = Status_Ok;

    _Cli = cli;

    ret = CLI::RegisterNode(&_RootNode, _Nodes);
    if (Status_IsError(ret)) return ret;

    return ret;
}