/**
 ******************************************************************************
 * @file    ResbitEvents.h
 * @brief   Module the defines resbit events
 * @author  Jeffrey Hatton
******************************************************************************
 *
 * @copyright COPYRIGHT (c) 2020 SAEC Kinetic Vision, Inc 
 *            All Rights Reserved
 *
 * This software is property of SAEC Kinetic Vision, Inc and is considered
 * confidential.
 *
 ******************************************************************************
 *
 * Significant Modification History (Most Recent at top)
 * -----------------------------------------------------
 *
 * Date        | Initials | Description
 * ----------- | -------- | -----------
 * 18 Sep 2020 |   JH     | Original
 *
 * Theory of Operation
 * -------------------
 * TBD
 *
 *
 *
 */

#ifndef RESBIT_EVENTS_H
#define RESBIT_EVENTS_H

#define RS_EVENT_DATA_SIZE 20
#define SERIAL_SIZE 12

enum ResbitEvents_t {
    ResbitEvents_WakeUp,
    ResbitEvents_TriggerPull,
    ResbitEvents_TiltAngle,
    ResbitEvents_Count
};

//TODO need data format field
struct RSEvent_t {
    uint16_t EventId;
    uint32_t Timestamp;
    uint8_t DataSize;
    uint8_t Data[RS_EVENT_DATA_SIZE];
};

#endif
