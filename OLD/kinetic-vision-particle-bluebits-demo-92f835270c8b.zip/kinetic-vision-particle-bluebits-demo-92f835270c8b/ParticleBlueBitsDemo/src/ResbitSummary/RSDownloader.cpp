/**
 ******************************************************************************
 * @file    RsDownloader.cpp
 * @brief   DESCRIPTION
 * @author  Jeffrey Hatton
******************************************************************************
 *
 * @copyright COPYRIGHT (c) 2020 SAEC Kinetic Vision, Inc 
 *            All Rights Reserved
 *
 * This software is property of SAEC Kinetic Vision, Inc and is considered
 * confidential.
 *
 ******************************************************************************
 *
 * Significant Modification History (Most Recent at top)
 * -----------------------------------------------------
 *
 * Date        | Initials | Description
 * ----------- | -------- | -----------
 * 16 Sep 2020 |   JH     | Original
 *
 * Theory of Operation
 * -------------------
 * TBD
 *
 *
 *
 */

#include "RSDownloader.h"

StatusRet_t RSDownloader_t::Init(SuId_t id, BlueBitsBle_t* ble, BlueBitsSummaryComs_t* coms, RSParticleFormater_t* formater) {
    if (ble == NULL || coms == NULL || formater == NULL) return Status_Pack(Status_Null_Ptr);

    _Status = SoftwareUnit_t::Init(id);

    _Ble = ble;
    _Coms = coms;
    _Formater = formater;

    return _Status;
}

StatusRet_t RSDownloader_t::Start() {
    if (Status_IsError(_Status)) return _Status;
    StatusRet_t ret = Status_Ok;
    
    if (_CurrentState != RsDownloaderStates_Idle) return ret;

    Logger_t::Info("Starting RS Downloader");

    ret = ClearCache();
    if (Status_IsError(ret)) return ret;

    ret = StartScan();

    return ret;
}

StatusRet_t RSDownloader_t::Stop() {
    if (Status_IsError(_Status)) return _Status;

    StatusRet_t ret = Status_Ok;

    if (_CurrentState == RsDownloaderStates_Idle) return ret;

    Logger_t::Info("Stopping RS Downloader");

    ret = _Ble->DisconnectCurrentDevice();
    if (Status_IsError(ret)) return ret;

    ret = _Ble->Enable(false);
    if (Status_IsError(ret)) return ret;

    ret = _Coms->Stop();
    if (Status_IsError(ret)) return ret;

    _CurrentState = RsDownloaderStates_Idle;

    return ret;
}

StatusRet_t RSDownloader_t::GetEvents(RSEvent_t** eventBuffer, uint16_t* eventCount) {
    if (Status_IsError(_Status)) return _Status;
    if (eventBuffer == NULL || eventCount == NULL) return Status_Pack(Status_Null_Ptr);
    if (_CurrentState != RsDownloaderStates_DataCached || _NumEventsBuffered == 0) return Status_Pack(Status_BufferEmpty);

    StatusRet_t ret = Status_Ok;

    *eventBuffer = _EventBuffer;
    *eventCount = _NumEventsBuffered;
    
    return ret;
}

StatusRet_t RSDownloader_t::GetEventJSON(char** buf) {
    if (Status_IsError(_Status)) return _Status;
    if (buf == NULL) return Status_Pack(Status_Null_Ptr);
    if (_CurrentState != RsDownloaderStates_DataCached || _NumEventsBuffered == 0) return Status_Pack(Status_BufferEmpty);

    return _Formater->GetPacket(buf);
}

StatusRet_t RSDownloader_t::NextJSON() {
    if (Status_IsError(_Status)) return _Status;
    if (_CurrentState != RsDownloaderStates_DataCached || _NumEventsBuffered == 0) return Status_Pack(Status_BufferEmpty);

    return _Formater->GenerateNextPacket();
}

StatusRet_t RSDownloader_t::StartScan() {
    StatusRet_t ret = _Ble->ScanForDevice();
    if (Status_IsError(ret)) return ret;

    Logger_t::Info("Starting RS Downloader Device Scan");

    _CurrentState = RsDownloaderStates_FindingDevice;

    return ret;
}

StatusRet_t RSDownloader_t::ClearCache() {
    if (Status_IsError(_Status)) return _Status;

    StatusRet_t ret = Status_Ok;
    if (_NumEventsBuffered == 0) return ret;

    Logger_t::Info("Clearing RS Downloader Cache");

    ret = _Formater->Clear();
    if (Status_IsError(ret)) return ret;

    _NumEventsBuffered = 0;
    ret = StartScan();
    
    return ret;
}

StatusRet_t RSDownloader_t::HandleFindingDevice()  {
    StatusRet_t ret = Status_Ok;

    BlePeerDevice* device;
    ret = _Ble->GetConnectedDevice(&device);
    if (Status_IsError(ret)) {
        if (Status_IsStatus(ret, Status_BufferEmpty)) {
            ret = Status_Ok;
        } else {
            return ret;
        }
    } else {
        Logger_t::Info("RS Downloader Found Device Starting Download");

        ret = _Coms->StartDownload(device);
        if (Status_IsError(ret)) return ret;

        _CurrentState = RsDownloaderStates_DownloadingData;
    }

    return ret;
}

StatusRet_t RSDownloader_t::HandleDownloadingData() {
    StatusRet_t ret = Status_Ok;

    uint8_t* buf;
    uint16_t bytesRead;
    ret = _Coms->GetData(&buf, &bytesRead);
    if (Status_IsError(ret)) {
        if (Status_IsStatus(ret, Status_BufferEmpty)) {
            ret = Status_Ok;
        } else {
            return ret;
        }
    } else {        
        ret = ParseSummaryData(buf, bytesRead);
        if (Status_IsError(ret)) {
            Logger_t::Error("Error parsing downloaded data: 0x%0.8x", ret);
            return ret;
        }

        ret = _Coms->ClearData();
        if (Status_IsError(ret)) {
            Logger_t::Error("Error clearing coms data: 0x%0.8x", ret);
            return ret;
        }
    }

    //TODO need to download all data
    //TODO move this into a function
    if (_Coms->SummaryDone) {
        uint16_t read;
        ret = _Coms->GetSerial(sizeof(_SerialNumber), _SerialNumber, &read);
        if (Status_IsError(ret)) {
            Logger_t::Error("Error getting serial number: 0x%0.8x", ret);
            return ret;
        }

        Logger_t::Info("RS Downloader Download Finished. Downloaded %u Events", _NumEventsBuffered);
        _CurrentState = RsDownloaderStates_DataCached;

        ret = _Formater->StartPacketGen(_EventBuffer, _NumEventsBuffered, _SerialNumber, read);
        if (Status_IsError(ret)) return ret;

        ret = _Ble->DisconnectCurrentDevice();
        if (Status_IsError(ret)) return ret;

        ret = _Coms->Stop();
        if (Status_IsError(ret)) return ret;
    }

    return ret;
}

StatusRet_t RSDownloader_t::GetSerial(uint8_t** buffer, uint16_t* size) {
    if (Status_IsError(_Status)) return _Status;
    if (buffer == NULL || size == NULL) return Status_Pack(Status_Null_Ptr);
    if (_CurrentState != RsDownloaderStates_DataCached || _NumEventsBuffered == 0) return Status_Pack(Status_BufferEmpty);

    StatusRet_t ret = Status_Ok;

    *buffer = _SerialNumber;
    *size = sizeof(_SerialNumber);

    return ret;
}

StatusRet_t RSDownloader_t::ParseSummaryData(uint8_t* data, uint16_t dataSize) {
    StatusRet_t ret = Status_Ok;

    uint8_t* ptr = data;

    uint32_t count = _NumEventsBuffered;
    Logger_t::Info("Parsing Events form %u bytes", dataSize);

    while (ptr < data + dataSize) {
        if (_NumEventsBuffered >= MAX_EVENTS_BUFFERED) return Status_BufferTooSmall;

        // If there is not enough byte left for an event exit
        uint16_t delta = data + dataSize - ptr;        
        if (delta < 7) break;

        RSEvent_t* event = _EventBuffer + _NumEventsBuffered;
        event->EventId = *(uint16_t*)ptr;
        ptr += 2;
        event->Timestamp = *(uint32_t*)ptr;
        ptr += 4;
        event->DataSize = *(uint8_t*)ptr;
        ptr += 1;

        // If the data left is a packet or less and all the fields are zero
        // the remaining data is just padding so stop
        if (data + dataSize - ptr < 18) {
            if (event->EventId == 0 && event->Timestamp == 0 && event->DataSize == 0) {
                break;
            }
        }

        memcpy(event->Data, ptr, event->DataSize);
        ptr += event->DataSize;    

        _NumEventsBuffered++;
    }

    Logger_t::Info("Parsed %u Events", _NumEventsBuffered - count);

    return ret;
}

StatusRet_t RSDownloader_t::Tick() {
    StatusRet_t ret = Status_Ok;

    ret = _Ble->Tick();
    if (Status_IsError(ret)) {
        Logger_t::Error("Error in BLE: 0x%0.8x. Restarting downloader", ret);
        ret = Restart();
        if (Status_IsError(ret)) return ret;  

        return ret;
    }

    ret = _Coms->Tick();
    if (Status_IsError(ret)) {
        Logger_t::Error("Error in Coms: 0x%0.8x. Restarting downloader", ret);
        ret = Restart();
        if (Status_IsError(ret)) return ret;     
        
        return ret;
    }

    switch (_CurrentState){
        case RsDownloaderStates_Idle:
        // Do nothing
        break;
        case RsDownloaderStates_FindingDevice:
            ret = HandleFindingDevice();
        break;
        case RsDownloaderStates_DownloadingData:
            ret = HandleDownloadingData();
        break;
        case RsDownloaderStates_DataCached:
        // Do nothing
        break;
        default:
        return Status_Pack(Status_InvalidState);
    }

    if (_CurrentState != RsDownloaderStates_Idle) {
        if (Status_IsError(ret)) {
            Logger_t::Error("Error in Downloader: 0x%0.8x. Restarting downloader", ret);
            ret = Restart();
            if (Status_IsError(ret)) return ret;

            return ret;
        } else if (_CurrentState == RsDownloaderStates_DownloadingData) {
            bool connected;
            ret = _Ble->IsConnected(&connected);
            if (Status_IsError(ret)) return ret;

            if (!connected) {
                ret = StartScan();
                if (Status_IsError(ret)) return ret;
            }
        }
    }

    return ret;
}

StatusRet_t RSDownloader_t::Restart() {
    if (Status_IsError(_Status)) return _Status;

    StatusRet_t ret = Status_Ok;
    if (_CurrentState == RsDownloaderStates_Idle) return ret;

    ret = Stop();
    if (Status_IsError(ret)) return ret;
    
    ret = ClearCache();
    if (Status_IsError(ret)) return ret;

    ret = Start();
    if (Status_IsError(ret)) return ret;

    return ret;
}
