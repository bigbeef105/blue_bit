/**
 ******************************************************************************
 * @file    RSDownloader.h
 * @brief   DESCRIPTION
 * @author  Jeffrey Hatton
******************************************************************************
 *
 * @copyright COPYRIGHT (c) 2020 SAEC Kinetic Vision, Inc 
 *            All Rights Reserved
 *
 * This software is property of SAEC Kinetic Vision, Inc and is considered
 * confidential.
 *
 ******************************************************************************
 *
 * Significant Modification History (Most Recent at top)
 * -----------------------------------------------------
 *
 * Date        | Initials | Description
 * ----------- | -------- | -----------
 * 16 Sep 2020 |   JH     | Original
 *
 * Theory of Operation
 * -------------------
 * TBD
 *
 *
 *
 */

#ifndef R_S_DOWNLOADER_H
#define R_S_DOWNLOADER_H

#include "Status\DeviceStatus.h"
#include "SoftwareUnits\SoftwareUnit.h"
#include "BlueBitsSummaryComs.h"
#include "BlueBitsBle.h"
#include "ResbitEvents.h"
#include "RSParticleFormater.h"
#include "RE_SDK_Config.h"

class RSDownloader_t : public SoftwareUnit_t {
    public:

    enum RsDownloaderStates_t {
        RsDownloaderStates_Idle,
        RsDownloaderStates_FindingDevice,
        RsDownloaderStates_DownloadingData,
        RsDownloaderStates_DataCached,
        RsDownloaderStates_Count
    };

    /**
     * @brief Init the unit
     * 
     * @param id ID of the module
     * @param ble Reference to the BLE module
     * @param coms Reference to the coms module
     * @return StatusRet_t 
     */
    StatusRet_t Init(SuId_t id, BlueBitsBle_t* ble, BlueBitsSummaryComs_t* coms,RSParticleFormater_t* formater);

    /**
     * @brief Start the downloader
     * 
     * @return StatusRet_t 
     */
    StatusRet_t Start();

    /**
     * @brief Stop the downloader
     * 
     * @return StatusRet_t 
     */
    StatusRet_t Stop();

    /**
     * @brief Restart the Downloader. Does nothing if the downloader is stopped.
     * 
     * @return StatusRet_t 
     */
    StatusRet_t Restart();

    /**
     * @brief Get the currently cached events
     * 
     * @param eventBuffer Buffer for the events
     * @param eventCount The number of the events in the buffer
     * @return StatusRet_t 
     */
    StatusRet_t GetEvents(RSEvent_t** eventBuffer, uint16_t* eventCount);

    /**
     * @brief Get the cached events as json
     * 
     * @param buf The buffer to store the json
     * @return StatusRet_t 
     */
    StatusRet_t GetEventJSON(char** buf);

    /**
     * @brief Move to the next JSON Packet. Will return Status_BufferEmpty if there are
     * no more packets
     * 
     * @return StatusRet_t 
     */
    StatusRet_t NextJSON();

    /**
     * @brief Get the serial number that generated the events
     * 
     * @param buffer Buffer to hold serial number
     * @param size The size of the serial number
     * @return StatusRet_t 
     */
    StatusRet_t GetSerial(uint8_t** buffer, uint16_t* size);

    /**
     * @brief Clear the current cache
     * 
     * @return StatusRet_t 
     */
    StatusRet_t ClearCache();

    /**
     * @brief Give processing time to the module
     * 
     * @return StatusRet_t 
     */
    StatusRet_t Tick();

    private:

    BlueBitsBle_t* _Ble;
    BlueBitsSummaryComs_t* _Coms;
    RSParticleFormater_t* _Formater;
    RsDownloaderStates_t _CurrentState;    

    uint16_t _NumEventsBuffered;
    RSEvent_t _EventBuffer[MAX_EVENTS_BUFFERED];
    uint8_t _SerialNumber[SERIAL_SIZE];

    /**
     * @brief Start the scanning process
     * 
     * @return StatusRet_t 
     */
    StatusRet_t StartScan();

    /**
     * @brief Handler for when the unit is in the finding device state
     * 
     * @return StatusRet_t 
     */
    StatusRet_t HandleFindingDevice();

    /**
     * @brief Handler for when the unit is in the downloading data state
     * 
     * @return StatusRet_t 
     */    
    StatusRet_t HandleDownloadingData();

    /**
     * @brief Parses summary data out of binary data
     * 
     * @param data 
     * @param dataSize 
     * @return StatusRet_t 
     */
    StatusRet_t ParseSummaryData(uint8_t* data, uint16_t dataSize);
};

#endif
