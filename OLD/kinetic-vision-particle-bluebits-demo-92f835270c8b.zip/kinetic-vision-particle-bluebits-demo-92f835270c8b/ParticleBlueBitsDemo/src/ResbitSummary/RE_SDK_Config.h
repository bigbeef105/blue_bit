/**
 ******************************************************************************
 * @file    RE_SDK_Config.h
 * @brief   File to house configuration settings for the Resbit Event SDK
 * @author  Jeffrey Hatton
******************************************************************************
 *
 * @copyright COPYRIGHT (c) 2020 SAEC Kinetic Vision, Inc 
 *            All Rights Reserved
 *
 * This software is property of SAEC Kinetic Vision, Inc and is considered
 * confidential.
 *
 ******************************************************************************
 *
 * Significant Modification History (Most Recent at top)
 * -----------------------------------------------------
 *
 * Date        | Initials | Description
 * ----------- | -------- | -----------
 * 21 Sep 2020 |   JH     | Original
 *
 * Theory of Operation
 * -------------------
 * TBD
 *
 */

//
// BLE
//

/**
 * @brief The version of the sdk
 * 
 */
#define RESBIT_EVENT_SDK_VERSION "v1.0.2.0"

/**
 * @brief Amount of time to wait before disconnecting from a device
 * 
 */
#define DEFAULT_CONNECTION_TIME_OUT 5000

//
// Event Downloader
//

/**
 * @brief The max number of events to buffer in the downloader
 * 
 */
#define MAX_EVENTS_BUFFERED 200

/**
 * @brief Max packets per chunk
 * 
 */
#define MAX_PACKETS_PER_CHUNK 100

/**
 * @brief The size of the particle formater buffer
 * 
 */
#define PARTICLE_FORMATER_BUFFER_SIZE 623