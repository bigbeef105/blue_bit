/**
 ******************************************************************************
 * @file    BlueBitsSummaryComs.h
 * @brief   DESCRIPTION
 * @author  Jeffrey Hatton
******************************************************************************
 *
 * @copyright COPYRIGHT (c) 2020 SAEC Kinetic Vision, Inc 
 *            All Rights Reserved
 *
 * This software is property of SAEC Kinetic Vision, Inc and is considered
 * confidential.
 *
 ******************************************************************************
 *
 * Significant Modification History (Most Recent at top)
 * -----------------------------------------------------
 *
 * Date        | Initials | Description
 * ----------- | -------- | -----------
 * 16 Sep 2020 |   JH     | Original
 *
 * Theory of Operation
 * -------------------
 * TBD
 *
 *
 *
 */

#ifndef BLUE_BITS_SUMMARY_COMS_H
#define BLUE_BITS_SUMMARY_COMS_H

#include "Status\DeviceStatus.h"
#include "SoftwareUnits\SoftwareUnit.h"
#include "ResbitEvents.h"
#include "RE_SDK_Config.h"

#define PACKET_DATA_SIZE 18
#define PACKET_HEADER_SIZE 2
#define PACKET_SIZE (PACKET_HEADER_SIZE + PACKET_DATA_SIZE)

class BlueBitsSummaryComs_t : public SoftwareUnit_t {
    public:

    enum BBSummaryStates_t {
        BBSummaryStates_Idle,
        BBSummaryStates_Downloading,
        BBSummaryStates_HasData,
        BBSummaryStates_Count,
    };

    /**
     * @brief Init the software unit
     * 
     * @param id 
     * @return StatusRet_t 
     */
    StatusRet_t Init(SuId_t id);

    /**
     * @brief Start a download from the passed device
     * 
     * @param device 
     * @return StatusRet_t 
     */
    StatusRet_t StartDownload(BlePeerDevice* device);

    /**
     * @brief Get the last downlaoded data
     * 
     * @param bufferSize The size of the buffer
     * @param summaryBuffer The buffer to place the data
     * @param bytesRead The number of bytes placed into the buffer
     * @return StatusRet_t 
     */
    StatusRet_t GetData(uint8_t** summaryBuffer, uint16_t* bytesRead);

    /**
     * @brief Get the serial number for the resbit device being downloaded
     * 
     * @param bufferSize Size of the buffer
     * @param buffer The buffer to place the serial number
     * @param bytesRead The number of bytes read
     * @return StatusRet_t 
     */
    StatusRet_t GetSerial(uint16_t bufferSize, uint8_t* buffer, uint16_t* bytesRead);

    /**
     * @brief Get the current state of the coms
     * 
     * @param state 
     * @return StatusRet_t 
     */
    StatusRet_t GetState(BBSummaryStates_t* state);

    /**
     * @brief Clear the cached data
     * 
     * @return StatusRet_t 
     */
    StatusRet_t ClearData();

    /**
     * @brief Stop the coms
     * 
     * @return StatusRet_t 
     */
    StatusRet_t Stop();

    /**
     * @brief Give Processing time to the unit
     * 
     * @return StatusRet_t 
     */
    StatusRet_t Tick();

    /**
     * @brief The current index into the internal buffer for data download
     * 
     */
    uint16_t TotalPacket = 0;

    /**
     * @brief Buffer for the downloaded data
     * 
     */
    uint8_t DataBuffer[MAX_PACKETS_PER_CHUNK * PACKET_DATA_SIZE];

    /**
     * @brief Buffer for the headers
     * 
     */
    uint8_t HeaderBuffer[MAX_PACKETS_PER_CHUNK];
    
    enum BBProtocolStates_t {
        BBProtocolStates_Idle,
        BBProtocolStates_GettingPackets,
        BBProtocolStates_VerifyPackets,
        BBProtocolStates_Done,
        BBProtocolStates_Count,
    };

    /**
     * @brief The current state of the coms
     * 
     */
    BBSummaryStates_t _CurrentSummaryState;

    /**
     * @brief Current state of the protocol
     * 
     */
    BBProtocolStates_t _CurrentProtoState;

    /**
     * @brief If the blue bits device is down sending summary data
     * 
     */
    bool SummaryDone = false;

    private:

    BlePeerDevice* _BlueBitsDevice;
    BleCharacteristic ResBitSerialChar;
    BleCharacteristic DataChar;
    BleCharacteristic TransferingChar;
    BleCharacteristic TransferSumDataChar;
    BleCharacteristic ResponseChar;
    BleCharacteristic AckChar;

    /**
     * @brief The time out to use for data download
     * 
     */
    uint32_t _DownloadTimeout;

    /**
     * @brief The start time for the data download
     * 
     */
    uint32_t _DownloadStartTime;

    /**
     * @brief Verifies that all packets are presents and responds to BlueBits device
     * 
     * @return StatusRet_t 
     */
    StatusRet_t VerifyPackets();
};

#endif
